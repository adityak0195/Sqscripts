--------------------------------------------------------------
--------------------------------------------------------------
print '-- cpTWXICERPlannedProductionTime';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'cpTWXICERPlannedProductionTime') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE cpTWXICERPlannedProductionTime  AS BEGIN SET NOCOUNT ON; END')
GO

/*	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
	-- shift model valid from 13.1.2021
	3 shift model: 6 a.m. - 2 p.m. + 2 p.m. - 10 p.m. + 10 p.m. to 6 a.m.; 
	No production on 25.12. + 01.01. + 9 a.m. - 4 p.m. at 31.12."

	Exactly the shifts are:
	5:50-13:40
	13:50-21:40
	21:50-5:40

	The hour of break are at (not excluded):		Additional break before lunch (exclusions)
	09:30-09:45						09:20-09:30
	18:30-18:45						18:20-18:30
	02:30-02:45						02:20-02:30


-- standard shift model valid since 1.8.2020
	3 shift model: 6 a.m. - 2 p.m. + 2 p.m. - 10 p.m. + 10 p.m. to 6 a.m.; 
	No production on 25.12. + 01.01. + 9 a.m. - 4 p.m. at 31.12."

	Since 1.8.2020
	Exactly the shifts are:
	5:50-13:50
	13:50-21:50
	21:50-5:50

	The hour of break are at:
	09:30-09:45
	18:30-18:45
	02:30-02:45

*/

/*	-- COVID19 shift model - original setup
	3 shift model:		Morning shift                6:20                 13:30
						Evening shift                14:20               21:30
						Night shift                    22:20               5:30

	No production on 25.12. + 01.01. + 9 a.m. - 4 p.m. at 31.12."
*/




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[cpTWXICERPlannedProductionTime] 
	-- Add the parameters for the stored procedure here
	@DateStart as datetime
	
	--@DateEnd as datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @DUMMY as Bit
	DECLARE @StartTime as DateTime
	DECLARE @EndTime as DateTime
	DECLARE @Machine as nvarchar(20)
	DECLARE @CapAdd as integer
	DECLARE @TempVal as DateTime
	DECLARE @TempVal2 as DateTime
	DECLARE @DateEnd as DateTime
	DECLARE @SAPCalendar as bit
	DECLARE @idoc int
	DECLARE @doc varchar(8000)
	DECLARE @IntervalType nvarchar(10)
	DECLARE @ShiftType nvarchar(10)
	DECLARE @ChangeType integer

	Set @DateEnd = DATEADD(DAY,1,@DateStart)
	
	
	
	-- ***** Definition of temporary table for shift result *****
	CREATE TABLE #TempCap
	(ID int Identity,
	 StartTime  Datetime,
	 EndTime  DateTime,
	 WpIdent  nvarchar(20),
	 IntervalType nvarchar(10),
	 ShiftType nvarchar(10))
	 
	
    SET DATEFIRST 1

	IF DATEPART(DW,@DateStart) in (6,7) 
    BEGIN
    
		-- ***** Weekend - Check additional capacity (Type=2) *****
		-- Cursor definition - definition of additional capacity of WCs for selected days
		DECLARE DefCap  CURSOR
		FOR
		SELECT		WT.StartTime
					, WT.EndTime
					, WT.Machine
					, 'W' as IntervalType
					, WT.ShiftName
					, WT.Type
		FROM		dbo.[tblWorkTimeS3] as WT 
		INNER JOIN  dbo.tblOEEWC as WC
		ON			WT.Machine = WC.Machine 
		WHERE	    WT.StartTime between @DateStart and @DateEnd
		AND			WT.Type = 2 AND WT.Location = 'PNA' 
		UNION
		SELECT		DATEADD(MINUTE,360,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,360+480,@DateStart) as EndTime			-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Morning' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE	 WC.Machine like 'SSL' and WC.Location = 'PNA'
		UNION
		SELECT		DATEADD(MINUTE,840,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,840+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Day' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine like 'SSL' AND WC.Location = 'PNA'
		UNION
		SELECT		DATEADD(MINUTE,1320,@DateStart) as StartTime		-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,1320+480,@DateStart) as EndTime	-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Evening' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC	
		WHERE		WC.Machine like 'SSL' AND WC.Location = 'PNA'
		
	END	
	ELSE
	BEGIN		
	-- ***** All days - default capacity *****
	-- Cursor definition - definition of default capacity of WCs for selected days
		DECLARE DefCap  CURSOR
		FOR
		SELECT		DATEADD(MINUTE,350,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,350+210,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
	--	SELECT		DATEADD(MINUTE,350,@DateStart) as StartTime			-- standard shift model valid from 1.8.2020
	--				, DATEADD(MINUTE,350+480,@DateStart) as EndTime		-- standard shift model valid from 1.8.2020
	--	SELECT		DATEADD(MINUTE,380,@DateStart) as StartTime			-- COVID19 shift model original
	--				, DATEADD(MINUTE,380+430,@DateStart) as EndTime		-- COVID19 shift model original			
					, WC.Machine
					, 'W' as IntervalType
					, 'Morning' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine not like 'SSL' AND WC.Location = 'PNA'
		AND DATEPART(weekday, DATEADD(MINUTE,350+210,@DateStart))<6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,560,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,560+10,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
	--	SELECT		DATEADD(MINUTE,350,@DateStart) as StartTime			-- standard shift model valid from 1.8.2020
	--				, DATEADD(MINUTE,350+480,@DateStart) as EndTime		-- standard shift model valid from 1.8.2020
	--	SELECT		DATEADD(MINUTE,380,@DateStart) as StartTime			-- COVID19 shift model original
	--				, DATEADD(MINUTE,380+430,@DateStart) as EndTime		-- COVID19 shift model original			
					, WC.Machine
					, 'B' as IntervalType
					, 'Morning' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine not like 'SSL' AND WC.Location = 'PNA'
		AND DATEPART(weekday, DATEADD(MINUTE,560+10,@DateStart))<6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends 
		UNION
		SELECT		DATEADD(MINUTE,570,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,570+250,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
	--	SELECT		DATEADD(MINUTE,350,@DateStart) as StartTime			-- standard shift model valid from 1.8.2020
	--				, DATEADD(MINUTE,350+480,@DateStart) as EndTime		-- standard shift model valid from 1.8.2020
	--	SELECT		DATEADD(MINUTE,380,@DateStart) as StartTime			-- COVID19 shift model original
	--				, DATEADD(MINUTE,380+430,@DateStart) as EndTime		-- COVID19 shift model original			
					, WC.Machine
					, 'W' as IntervalType
					, 'Morning' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine not like 'SSL' AND WC.Location = 'PNA'
		AND DATEPART(weekday, DATEADD(MINUTE,570+260,@DateStart))<6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,830,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,830+470,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
	--	SELECT		DATEADD(MINUTE,830,@DateStart) as StartTime			-- standard shift model valid from 1.8.2020
	--				, DATEADD(MINUTE,830+480,@DateStart) as EndTime		-- standard shift model valid from 1.8.2020
	--	SELECT		DATEADD(MINUTE,860,@DateStart) as StartTime			-- COVID19 shift model original
	--				, DATEADD(MINUTE,860+430,@DateStart) as EndTime		-- COVID19 shift model original
					, WC.Machine
					, 'W' as IntervalType
					, 'Day' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		 WC.Machine not like 'SSL' AND WC.Location = 'PNA'
		AND DATEPART(weekday, DATEADD(MINUTE,830+470,@DateStart))<6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,1310,@DateStart) as StartTime		-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,1310+470,@DateStart) as EndTime	-- standard shift model valid from 13.1.2021
	--	SELECT		DATEADD(MINUTE,1310,@DateStart) as StartTime		-- standard shift model valid from 1.8.2020
	--				, DATEADD(MINUTE,1310+480,@DateStart) as EndTime	-- standard shift model valid from 1.8.2020
	--	SELECT		DATEADD(MINUTE,1340,@DateStart) as StartTime		-- COVID19 shift model original
	--				, DATEADD(MINUTE,1340+430,@DateStart) as EndTime	-- COVID19 shift model original
					, WC.Machine
					, 'W' as IntervalType
					, 'Evening' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC	
		WHERE		WC.Machine not like 'SSL' AND WC.Location = 'PNA'
		AND DATEPART(weekday, DATEADD(MINUTE,1310+470,@DateStart))<6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,360,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,360+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021	
					, WC.Machine
					, 'W' as IntervalType
					, 'Morning' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine like 'SSL' AND WC.Location = 'PNA'
						And DATEPART(weekday, DATEADD(MINUTE,360+480,@DateStart))<=5	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,840,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,840+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Day' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine like 'SSL' AND WC.Location = 'PNA'
						And DATEPART(weekday, DATEADD(MINUTE,840+480,@DateStart))<=5	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,1320,@DateStart) as StartTime		-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,1320+480,@DateStart) as EndTime	-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Evening' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine like 'SSL' AND WC.Location = 'PNA'
						And DATEPART(weekday, DATEADD(MINUTE,1320+480,@DateStart))<=5
	   UNION
		SELECT		DATEADD(MINUTE,360,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,360+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Morning' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE	 WC.Machine like 'SSL' AND WC.Location = 'PNA'
		And DATEPART(weekday, DATEADD(MINUTE,360+480,@DateStart))=6
		UNION
		SELECT		DATEADD(MINUTE,840,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,840+480,@DateStart) as EndTime			-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Day' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine like 'SSL' AND WC.Location = 'PNA'
		And DATEPART(weekday, DATEADD(MINUTE,840+480,@DateStart))=6
		UNION
		SELECT		DATEADD(MINUTE,1320,@DateStart) as StartTime		-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,1320+480,@DateStart) as EndTime	-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 'W' as IntervalType
					, 'Evening' as ShiftType
					, 3 as ChangeType
		FROM		dbo.tblOEEWC as WC	
		WHERE		WC.Machine like 'SSL' AND WC.Location = 'PNA'
		And DATEPART(weekday, DATEADD(MINUTE,1320+480,@DateStart))=6
		UNION
	SELECT		WT.StartTime as StartTime, WT.EndTime as EndTime, WT.Machine as Machine
			, WT.IntervalType as IntervalType
			, WT.ShiftName as ShiftType
				, WT.Type as ChangeType
			FROM		dbo.[tblWorkTimeS3] as WT 
			WHERE	    WT.Location='PNA' 
			AND			WT.StartTime between @DateStart and @DateEnd
			AND			WT.Type = 3
		
		
	END	
			
	OPEN DefCap
	FETCH DefCap into @StartTime,@EndTime,@Machine, @IntervalType,@ShiftType,@ChangeType
	
	WHILE (@@FETCH_STATUS = 0) BEGIN
		-- ***** Work day & Weekend - Check capacity reduction (Type=3) *****
		SET @CapAdd=1
		SET @TempVal = NULL
		SET @TempVal2 = NULL
		--SET @IntervalType = 'W'
		-----------------------------------------
		/*IF  EXISTS(
			SELECT		*
			FROM	    dbo.[tblWorkTimeS3] as WT 
			WHERE	    WT.Machine=@Machine 
			AND			WT.StartTime <= @StartTime and WT.EndTime >= @EndTime 
			AND			WT.Type = 3)
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Komplet ' + @Machine
			IF @ChangeType <> 2 
			BEGIN	
				SET @CapAdd=0	
			END
		END
		-----------------------------------------
		SELECT		@TempVal = WT.StartTime
		FROM		dbo.[tblWorkTimeS3] as WT
		WHERE	    WT.Machine=@Machine
		AND			((WT.StartTime > @StartTime and WT.StartTime< @EndTime) and WT.EndTime > @EndTime)
		AND			WT.Type = 3

		IF  @TempVal IS NOT NULL
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Zprava ' + @Machine
			SET @CapAdd=1	
			SET @EndTime=@TempVal	
			SET @TempVal=NULL
		END
		-----------------------------------------
		SELECT		@TempVal = WT.EndTime 
		FROM		dbo.[tblWorkTimeS3] as WT
		WHERE	    WT.Machine=@Machine
		AND			(WT.StartTime < @StartTime and (WT.EndTime > @StartTime and WT.EndTime < @EndTime))
		AND			WT.Type = 3

		IF  @TempVal IS NOT NULL
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Zleva ' + @Machine
			SET @CapAdd=1	
			SET @StartTime=@TempVal	
			SET @TempVal=NULL
		END		
		-----------------------------------------
		SELECT		@TempVal = WT.StartTime, @TempVal2 = WT.EndTime
		FROM		dbo.[tblWorkTimeS3] as WT
		WHERE	    WT.Machine=@Machine
		AND			((WT.StartTime >= @StartTime and WT.EndTime < @EndTime) or (WT.StartTime > @StartTime and WT.EndTime <= @EndTime))
		--AND			WT.StartTime > @StartTime and WT.EndTime < @EndTime
		AND			WT.Type = 3

		IF  @TempVal IS NOT NULL AND @TempVal2 IS NOT NULL AND @CapAdd=1
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Mezi ' + @Machine
			SET @CapAdd=0	
			IF @TempVal>@StartTime  BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@TempVal,@Machine, 'W',@ShiftType) END
			IF @TempVal2<@EndTime BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@TempVal2,@EndTime,@Machine,'W',@ShiftType) END
			INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@TempVal,@TempVal2,@Machine,'B',@ShiftType)
			SET @TempVal=NULL
			SET @TempVal2=NULL	
		END		
		-----------------------------------------
		
		IF @CapAdd = 1 */
		BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@EndTime,@Machine,@IntervalType,@ShiftType) END
		FETCH DefCap into @StartTime,@EndTime,@Machine,@IntervalType,@ShiftType,@ChangeType
	END
	
	-- Special capacity (Type=1) setting in tblWorkTimeS3 table is not considered because it hasn't been used for machines of our interest *****
	
	SELECT * FROM #TempCap order by WpIdent, StartTime,IntervalType, ShiftType 
	
	CLOSE DefCap
	DEALLOCATE DefCap	
	DROP TABLE #TempCap 

END