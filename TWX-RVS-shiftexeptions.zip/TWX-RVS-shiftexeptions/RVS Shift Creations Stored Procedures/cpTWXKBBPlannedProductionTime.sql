--------------------------------------------------------------
--------------------------------------------------------------
print '-- cpTWXKBBPlannedProductionTime';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'cpTWXKBBPlannedProductionTime') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE cpTWXKBBPlannedProductionTime  AS BEGIN SET NOCOUNT ON; END')
GO

/*	-- standard shift model valid from 1.1.2022 - startup shift model setup
	

Machine	Days	Shift 1			Shift 2			Shift 3		
				From	To		From	To		From	To	
1904	Mo-Do	6:00	14:00	14:00	22:00	22:00	6:00	
1904	Fr		6:00	14:00	14:00	22:00			
1904	Sa		6:00	14:00					If necessary
1904	So								22:00	6:00	
1883	Mo-Do	6:00	14:00	14:00	22:00	22:00	6:00	
1883	Fr		6:00	14:00	14:00	22:00			
1883	Sa		6:00	14:00					If necessary
1883	So								22:00	6:00	
1990	Mo-Do	6:00	14:00	14:00	22:00	22:00	6:00	
1990	Fr		6:00	14:00	14:00	22:00			
1990	Sa		6:00	14:00					If necessary
1990	So								22:00	6:00	
1918	Mo-Do	6:00	14:00	14:00	22:00	22:00	6:00	
1918	Fr		6:00	14:00	14:00	22:00			
1918	Sa		6:00	14:00					If necessary
1918	So								22:00	6:00	
1972	Mo-Do	6:00	14:00	14:00	22:00	22:00	6:00	
1972	Fr		6:00	14:00	14:00	22:00			
1972	Sa		6:00	14:00					If necessary
1972	So								22:00	6:00	


*/






-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[cpTWXKBBPlannedProductionTime] 
	-- Add the parameters for the stored procedure here
	@DateStart as datetime
	
	--@DateEnd as datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @DUMMY as Bit
	DECLARE @StartTime as DateTime
	DECLARE @EndTime as DateTime
	DECLARE @Machine as nvarchar(20)
	DECLARE @CapAdd as integer
	DECLARE @TempVal as DateTime
	DECLARE @TempVal2 as DateTime
	DECLARE @DateEnd as DateTime
	DECLARE @SAPCalendar as bit
	DECLARE @idoc int
	DECLARE @doc varchar(8000)
	DECLARE @IntervalType nvarchar(10)
	DECLARE @ShiftType nvarchar(10)

	Set @DateEnd = DATEADD(DAY,1,@DateStart)
	
	
	
	-- ***** Definition of temporary table for shift result *****
	CREATE TABLE #TempCap
	(ID int Identity,
	 StartTime  Datetime,
	 EndTime  DateTime,
	 WpIdent  nvarchar(20),
	 IntervalType nvarchar(10),
	 ShiftType nvarchar(10))
	
    SET DATEFIRST 1
		
	-- ***** All days - default capacity *****
	-- Cursor definition - definition of default capacity of WCs for selected days
	DECLARE DefCap  CURSOR
	FOR
	SELECT		DATEADD(MINUTE,360,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
				, DATEADD(MINUTE,360+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021

				, WC.Machine
				, 'W' as IntervalType
				, 'Morning' as ShiftType
	FROM		dbo.tblOEEWC as WC
	WHERE		WC.Location='KBB' AND DATEPART(weekday, DATEADD(MINUTE,360,@DateStart)) between 1 and 5	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
	UNION
	SELECT		DATEADD(MINUTE,840,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
				, DATEADD(MINUTE,840+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021

				, WC.Machine
				, 'W' as IntervalType
				, 'Day' as ShiftType
	FROM		dbo.tblOEEWC as WC
	WHERE		WC.Location='KBB' AND  DATEPART(weekday, DATEADD(MINUTE,840,@DateStart)) between 1 and 5	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
	UNION
	SELECT		DATEADD(MINUTE,1320,@DateStart) as StartTime		-- standard shift model valid from 13.1.2021
				, DATEADD(MINUTE,1320+480,@DateStart) as EndTime	-- standard shift model valid from 13.1.2021

				, WC.Machine
				, 'W' as IntervalType
				, 'Evening' as ShiftType
	FROM		dbo.tblOEEWC as WC	
	WHERE		WC.Location='KBB' AND (DATEPART(weekday, DATEADD(MINUTE,1320,@DateStart)) between 1 and 4)
	UNION
	SELECT		DATEADD(MINUTE,1320,@DateStart) as StartTime		-- standard shift model valid from 13.1.2021
				, DATEADD(MINUTE,1320+480,@DateStart) as EndTime	-- standard shift model valid from 13.1.2021

				, WC.Machine
				, 'W' as IntervalType
				, 'Evening' as ShiftType
	FROM		dbo.tblOEEWC as WC	
	WHERE		WC.Location='KBB' AND
	DATEPART(weekday, DATEADD(MINUTE,1320,@DateStart))=7	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
	
			
	OPEN DefCap
	FETCH DefCap into @StartTime,@EndTime,@Machine, @IntervalType,@ShiftType
	
	WHILE (@@FETCH_STATUS = 0) BEGIN
		
		-- ***** Work day & Weekend - Check capacity reduction (Type=3) *****
		SET @CapAdd=1
		SET @TempVal = NULL
		SET @TempVal2 = NULL
		SET @IntervalType = 'W'
		-----------------------------------------
		IF  EXISTS(
			SELECT		*
			FROM		dbo.[tblWorkTimeS3] as WT 
			WHERE	    WT.Machine=@Machine AND WT.Location='KBB'
			AND			WT.StartTime <= @StartTime and WT.EndTime >= @EndTime 
			AND			WT.Type = 3)
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Komplet ' + @Machine
			SET @CapAdd=0		
		END
		-----------------------------------------
		SELECT		@TempVal = WT.StartTime
		FROM		dbo.[tblWorkTimeS3] as WT 
		
		WHERE	    WT.Machine=@Machine AND WT.Location='KBB'
		AND			((WT.StartTime > @StartTime and WT.StartTime< @EndTime) and WT.EndTime > @EndTime)
		AND			WT.Type = 3
		IF  @TempVal IS NOT NULL
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Zprava ' + @Machine
			SET @CapAdd=1	
			SET @EndTime=@TempVal	
			SET @TempVal=NULL
		END
		-----------------------------------------
		SELECT		@TempVal = WT.EndTime 
		FROM		dbo.[tblWorkTimeS3] as WT 
		
		WHERE	    WT.Machine=@Machine  AND WT.Location='KBB'
		AND			(WT.StartTime < @StartTime and (WT.EndTime > @StartTime and WT.EndTime < @EndTime))
		AND			WT.Type = 3
		IF  @TempVal IS NOT NULL
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Zleva ' + @Machine
			SET @CapAdd=1	
			SET @StartTime=@TempVal	
			SET @TempVal=NULL
		END		
		-----------------------------------------
		SELECT		@TempVal = WT.StartTime, @TempVal2 = WT.EndTime
		FROM		dbo.[tblWorkTimeS3] as WT 
		
		WHERE	    WT.Machine=@Machine AND WT.Location='KBB'
		AND			((WT.StartTime >= @StartTime and WT.EndTime < @EndTime) or (WT.StartTime > @StartTime and WT.EndTime <= @EndTime))
		--AND			WT.StartTime > @StartTime and WT.EndTime < @EndTime
		AND			WT.Type = 3
		IF  @TempVal IS NOT NULL AND @TempVal2 IS NOT NULL AND @CapAdd=1
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Mezi ' + @Machine
			SET @CapAdd=0
			IF @TempVal>@StartTime  BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@TempVal,@Machine, 'W',@ShiftType) END
			IF @TempVal2<@EndTime BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@TempVal2,@EndTime,@Machine,'W',@ShiftType) END
			--INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@TempVal,@TempVal2,@Machine,'B',@ShiftType)
			SET @TempVal=NULL
			SET @TempVal2=NULL	
		END		
		-----------------------------------------
		
		IF @CapAdd = 1 BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@EndTime,@Machine,@IntervalType,@ShiftType) END
		FETCH DefCap into @StartTime,@EndTime,@Machine,@IntervalType,@ShiftType
	END
	
	-- Special capacity (Type=1) setting in tblWorkTimeS3 table is not considered because it hasn't been used for machines of our interest *****
	
	SELECT * FROM #TempCap order by WpIdent, StartTime,IntervalType, ShiftType 
	
	CLOSE DefCap
	DEALLOCATE DefCap	
	DROP TABLE #TempCap 

END
