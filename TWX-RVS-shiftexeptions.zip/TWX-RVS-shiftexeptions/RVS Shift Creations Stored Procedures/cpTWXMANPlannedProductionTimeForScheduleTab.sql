/****** Object:  StoredProcedure [dbo].[cpTWXMANPlannedProductionTimeForScheduleTab]    Script Date: 11/7/2024 7:58:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*	-- standard shift model valid from 01.10.2023 in Manchester:
	Monday to Friday:
	6:00-14:00
	14:00-22:00
	22:00-6:00

	Saturday:
	6:00-14:00
	14:00-22:00
	
	No planned breaks

*/

/*	
	No production on 25.12. + 01.01. + 9 a.m. - 4 p.m. at 31.12."
*/




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[cpTWXMANPlannedProductionTimeForScheduleTab] 
	-- Add the parameters for the stored procedure here
	@DateStart as datetime

	--@DateEnd as datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @DUMMY as Bit
	DECLARE @StartTime as DateTime
	DECLARE @EndTime as DateTime
	DECLARE @Machine as nvarchar(20)
	DECLARE @CapAdd as integer
	DECLARE @TempVal as DateTime
	DECLARE @TempVal2 as DateTime
	DECLARE @DateEnd as DateTime
	DECLARE @SAPCalendar as bit
	DECLARE @idoc int
	DECLARE @doc varchar(8000)
	DECLARE @ChangeType integer
	DECLARE @IntervalType nvarchar(10)
	DECLARE @ShiftType nvarchar(10)

	Set @DateEnd = DATEADD(DAY,1,@DateStart)
	
	
	
	-- ***** Definition of temporary table for shift result *****
	CREATE TABLE #TempCap
	(ID int Identity,
	 StartTime  Datetime,
	 EndTime  DateTime,
	 WpIdent  nvarchar(20),
IntervalType nvarchar(10),
	 ShiftType nvarchar(10))
	 
	
    SET DATEFIRST 1
	IF DATEPART(DW,@DateStart) in (7) 
	-- IF DATEPART(DW,@DateStart) in (6,7) This was for Saturday, Sunday not running
    BEGIN
    
		-- ***** Weekend - Check additional capacity (Type=2) *****
		-- Cursor definition - definition of additional capacity of WCs for selected days
		DECLARE DefCap  CURSOR
		FOR
		SELECT		WT.StartTime
					, WT.EndTime
					, WT.Machine
					, WT.Type, 
					'W' as IntervalType 
					, 'Morning' as ShiftType
		FROM		dbo.[tblWorkTimeS3] as WT 
		INNER JOIN  dbo.tblOEEWC as WC
		ON			WT.Machine = WC.Machine 
		WHERE	    WT.StartTime between @DateStart and @DateEnd AND WT.Location='MLK'
		AND			WT.Type = 2
	END	
	ELSE
	BEGIN		
	-- ***** All days - default capacity *****
	-- Cursor definition - definition of default capacity of WCs for selected days
		DECLARE DefCap  CURSOR
		FOR
		SELECT		DATEADD(MINUTE,360,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,360+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021	
					, WC.Machine
					, 3 as ChangeType
					, 'W' as IntervalType
					, 'Morning' as ShiftType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine like 'MAN%'  AND WC.Location='MLK'
						And DATEPART(weekday, DATEADD(MINUTE,360+480,@DateStart))<6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,840,@DateStart) as StartTime			-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,840+480,@DateStart) as EndTime		-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 3 as ChangeType
					, 'W' as IntervalType
					, 'Day' as ShiftType
		FROM		dbo.tblOEEWC as WC
		WHERE		WC.Machine like 'MAN%' AND WC.Location='MLK'
						And DATEPART(weekday, DATEADD(MINUTE,840+480,@DateStart))<6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
		UNION
		SELECT		DATEADD(MINUTE,1320,@DateStart) as StartTime		-- standard shift model valid from 13.1.2021
					, DATEADD(MINUTE,1320+480,@DateStart) as EndTime	-- standard shift model valid from 13.1.2021
					, WC.Machine
					, 3 as ChangeType
					, 'W' as IntervalType
					, 'Evening' as ShiftType
		FROM		dbo.tblOEEWC as WC	
		WHERE		WC.Machine like 'MAN%' AND WC.Location='MLK'
						And DATEPART(weekday, DATEADD(MINUTE,1320+480,@DateStart))<=6	-- standard shift model valid from 29.4.2021 - Exclusions of weekends
	UNION
	SELECT		DATEADD(MINUTE,360,@DateStart) as StartTime			-- standard shift model valid from 1.10.2023
				, DATEADD(MINUTE,360+480,@DateStart) as EndTime		-- standard shift model valid from 1.10.2023
				, WC.Machine
				, 3 as ChangeType
				, 'W' as IntervalType
				, 'Morning' as ShiftType
	FROM		dbo.tblOEEWC as WC
	WHERE		WC.Machine like 'MAN%' AND WC.Location='MLK'
						And DATEPART(weekday, DATEADD(MINUTE,360+480,@DateStart))=6	-- standard saturday morning shift
	UNION
	SELECT		DATEADD(MINUTE,840,@DateStart) as StartTime			-- standard shift model valid from 1.10.2023
				, DATEADD(MINUTE,840+480,@DateStart) as EndTime		-- standard shift model valid from 1.10.2023
				, WC.Machine
				, 3 as ChangeType
				, 'W' as IntervalType
				, 'Day' as ShiftType
	FROM		dbo.tblOEEWC as WC
	WHERE		WC.Machine like 'MAN%' AND WC.Location='MLK'
						And DATEPART(weekday, DATEADD(MINUTE,840+480,@DateStart))=6	-- standard saturday afternoon shift
	END	
			
	OPEN DefCap
	FETCH DefCap into @StartTime,@EndTime,@Machine,@ChangeType,@IntervalType,@ShiftType
	
	WHILE (@@FETCH_STATUS = 0) BEGIN
		-- ***** Work day & Weekend - Check capacity reduction (Type=3) *****
		SET @CapAdd=1
		SET @TempVal = NULL
		SET @TempVal2 = NULL
		SET @IntervalType = 'W'
		-----------------------------------------
		IF  EXISTS(
			SELECT		*
			FROM		dbo.[tblWorkTimeS3] as WT 
			WHERE	    WT.Machine=@Machine AND WT.Location='MLK' 
			AND			WT.StartTime <= @StartTime and WT.EndTime >= @EndTime 
			AND			WT.Type = 3)
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Komplet ' + @Machine
			IF @ChangeType <> 2 
			BEGIN	
				SET @CapAdd=0	
			END
		END
		-----------------------------------------
		SELECT		@TempVal = WT.StartTime
		FROM		dbo.[tblWorkTimeS3] as WT 
		WHERE	    WT.Machine=@Machine AND WT.Location='MLK' 
		AND			((WT.StartTime > @StartTime and WT.StartTime< @EndTime) and WT.EndTime > @EndTime)
		AND			WT.Type = 3

		IF  @TempVal IS NOT NULL
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Zprava ' + @Machine
			SET @CapAdd=1	
			SET @EndTime=@TempVal	
			SET @TempVal=NULL
		END
		-----------------------------------------
		SELECT		@TempVal = WT.EndTime 
		FROM		dbo.[tblWorkTimeS3] as WT 
		WHERE	    WT.Machine=@Machine AND WT.Location='MLK' 
		AND			(WT.StartTime < @StartTime and (WT.EndTime > @StartTime and WT.EndTime < @EndTime))
		AND			WT.Type = 3

		IF  @TempVal IS NOT NULL
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Zleva ' + @Machine
			SET @CapAdd=1	
			SET @StartTime=@TempVal	
			SET @TempVal=NULL
		END		
		-----------------------------------------
		SELECT		@TempVal = WT.StartTime, @TempVal2 = WT.EndTime
		FROM		dbo.[tblWorkTimeS3] as WT 
		WHERE	    WT.Machine=@Machine AND WT.Location='MLK' 
		AND			((WT.StartTime >= @StartTime and WT.EndTime < @EndTime) or (WT.StartTime > @StartTime and WT.EndTime <= @EndTime))
		--AND			WT.StartTime > @StartTime and WT.EndTime < @EndTime
		AND			WT.Type = 3

		IF  @TempVal IS NOT NULL AND @TempVal2 IS NOT NULL AND @CapAdd=1
		BEGIN
			PRINT Cast(@StartTime as varchar(50)) + ' Mezi ' + @Machine
			SET @CapAdd=0	
			IF @TempVal>@StartTime  BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@TempVal,@Machine,@IntervalType,@ShiftType) END
			IF @TempVal2<@EndTime BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@TempVal2,@EndTime,@Machine,@IntervalType,@ShiftType) END
			--INSERT #TempCap (StartTime,EndTime,WpIdent) VALUES (@TempVal,@TempVal2,@Machine)
			SET @TempVal=NULL
			SET @TempVal2=NULL	
		END		
		-----------------------------------------
		
		IF @CapAdd = 1 BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@EndTime,@Machine,@IntervalType,@ShiftType) END
		FETCH DefCap into @StartTime,@EndTime,@Machine,@ChangeType,@IntervalType,@ShiftType
	END
	
	-- Special capacity (Type=1) setting in tblWorkTimeS3 table is not considered because it hasn't been used for machines of our interest *****
	
	SELECT * FROM #TempCap order by WpIdent, StartTime, IntervalType, ShiftType
	
	CLOSE DefCap
	DEALLOCATE DefCap	
	DROP TABLE #TempCap 

END

