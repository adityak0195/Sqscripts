--------------------------------------------------------------
--------------------------------------------------------------
print '-- cpTWXKBBPlannedProductionTimeUTC';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'cpTWXKBBPlannedProductionTimeUTC') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE cpTWXKBBPlannedProductionTimeUTC  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE [dbo].[cpTWXKBBPlannedProductionTimeUTC] 
@DateStart as datetime
AS
BEGIN
SET NOCOUNT ON;
declare @table table (ID int, StartTime datetime2, EndTime datetime2, WpIdent varchar(255), IntervalType varchar(255), ShiftType varchar(255));

insert into @table
EXEC cpTWXKBBPlannedProductionTime @DateStart=@DateStart;

update @table set StartTime = StartTime AT TIME ZONE 'Central European Standard Time' AT TIME ZONE 'UTC';
update @table set EndTime = EndTime AT TIME ZONE 'Central European Standard Time' AT TIME ZONE 'UTC';

select * from @table; 
END
GO
