--------------------------------------------------------------
--------------------------------------------------------------
print '-- [cpTWXPlannedProductionTime]';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[cpTWXPlannedProductionTime]') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE [cpTWXPlannedProductionTime]  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE [dbo].[cpTWXPlannedProductionTime]
    @Location AS NVARCHAR(10),
    @DateStart AS DATETIME
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare a variable to hold the stored procedure name
    DECLARE @ProcName NVARCHAR(100);

    -- Determine the appropriate stored procedure based on the location
    SET @ProcName = 
        CASE @Location
            WHEN 'PNA' THEN 'cpTWXICERPlannedProductionTime'
            WHEN 'MIL' THEN 'cpTWXMILPlannedProductionTime'
            WHEN 'MLK' THEN 'cpTWXKBRSMPlannedProductionTime'
            WHEN 'MAN' THEN 'cpTWXMANPlannedProductionTime'
            WHEN 'KBB' THEN 'cpTWXKBBPlannedProductionTime'
            ELSE NULL
        END;

    -- Check if a valid stored procedure was found
    IF @ProcName IS NOT NULL
    BEGIN
        DECLARE @SQL NVARCHAR(MAX);
        SET @SQL = 'EXEC ' + @ProcName + ' @DateStart = @DateStartParam';

        -- Execute the stored procedure with parameters
        EXEC sp_executesql @SQL, N'@DateStartParam DATETIME', @DateStartParam = @DateStart;

    END
    ELSE
    BEGIN
        PRINT 'Location not recognized';
    END
END