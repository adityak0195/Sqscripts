--------------------------------------------------------------
--------------------------------------------------------------
print '-- [cpTWXMANPlannedProductionTimeUTC]';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[cpTWXMANPlannedProductionTimeUTC]') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE [cpTWXMANPlannedProductionTimeUTC]  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE [dbo].[cpTWXMANPlannedProductionTimeUTC] 
@DateStart as datetime
AS
BEGIN
SET NOCOUNT ON;
declare @table table (ID int, StartTime datetime2, EndTime datetime2, WpIdent varchar(255));
DECLARE @DBUtcTimeOffset int = datediff(minute, GETDATE(), GETUTCDATE());

insert into @table
EXEC [cpTWXMANPlannedProductionTime] @DateStart = @DateStart;

update @table set StartTime = StartTime AT TIME ZONE 'GMT Standard Time' AT TIME ZONE 'UTC';
update @table set EndTime = EndTime AT TIME ZONE 'GMT Standard Time' AT TIME ZONE 'UTC';




select * from @table; 
END
