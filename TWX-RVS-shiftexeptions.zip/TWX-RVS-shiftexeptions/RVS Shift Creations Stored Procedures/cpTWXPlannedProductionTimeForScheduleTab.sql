/****** Object:  StoredProcedure [dbo].[cpTWXPlannedProductionTimeForScheduleTab]    Script Date: 11/7/2024 7:59:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[cpTWXPlannedProductionTimeForScheduleTab]
    @Location AS NVARCHAR(10),
    @DateStart AS DATETIME
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare a variable to hold the stored procedure name
    DECLARE @ProcName NVARCHAR(100);

    -- Determine the appropriate stored procedure based on the location
    SET @ProcName = 
        CASE @Location
            WHEN 'PNA' THEN 'cpTWXICERPlannedProductionTimeForScheduleTab'
            WHEN 'MIL' THEN 'cpTWXMILPlannedProductionTimeForScheduleTab'
            WHEN 'MLK' THEN 'cpTWXKBRSMPlannedProductionTimeForScheduleTab'
            WHEN 'MAN' THEN 'cpTWXMANPlannedProductionTimeForScheduleTab'
            WHEN 'KBB' THEN 'cpTWXKBBPlannedProductionTimeForScheduleTab'
            ELSE NULL
        END;

    -- Check if a valid stored procedure was found
    IF @ProcName IS NOT NULL
    BEGIN
        DECLARE @SQL NVARCHAR(MAX);
        SET @SQL = 'EXEC ' + @ProcName + ' @DateStart = @DateStartParam';

        -- Execute the stored procedure with parameters
        EXEC sp_executesql @SQL, N'@DateStartParam DATETIME', @DateStartParam = @DateStart;

    END
    ELSE
    BEGIN
        PRINT 'Location not recognized';
    END
END

