--------------------------------------------------------------
--------------------------------------------------------------
print '-- [cpTWXKBRSMPlannedProductionTime]';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[cpTWXKBRSMPlannedProductionTime]') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE [cpTWXKBRSMPlannedProductionTime]  AS BEGIN SET NOCOUNT ON; END')
GO

/*        -- standard shift model
3 shift model: 6 a.m. - 2 p.m. + 2 p.m. - 10 p.m. + 10 p.m. to 6 a.m.; 
No production on 25.12. + 01.01. + 9 a.m. - 4 p.m. at 31.12."
 
Since 1.8.2020
Exactly the shifts are:
5:50-13:50
13:50-21:50
21:50-5:50
 
The hour of break are at:
09:30-09:45
18:30-18:45
02:30-02:45
 
*/
 
/*        -- COVID19 shift model
3 shift model:                Morning shift                6:20                 13:30
Evening shift                14:20               21:30
Night shift                    22:20               5:30
 
No production on 25.12. + 01.01. + 9 a.m. - 4 p.m. at 31.12."
*/
 
 
 
 
-- =============================================
-- Author:                <Author,,Name>
-- Create date: <Create Date,,>
-- Description:        <Description,,>
-- VERSION: 1.1 LF 22/09/2020 - INITIAL SHIFT SET UP (7AM-7PM All Machines)
-- V 1.2 CM 25/09/2020 - Amended Miyano Late shift so only applies Mon - Thu
-- V 1.3 LF 02/03/2021 - Amended to include new shift patterns at KBRSM
-- =============================================
ALTER PROCEDURE [dbo].[cpTWXKBRSMPlannedProductionTime] 
-- Add the parameters for the stored procedure here
@DateStart as datetime

--@DateEnd as datetime
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
DECLARE @DUMMY as Bit
DECLARE @StartTime as DateTime
DECLARE @EndTime as DateTime
DECLARE @Machine as nvarchar(20)
DECLARE @CapAdd as integer
DECLARE @TempVal as DateTime
DECLARE @TempVal2 as DateTime
DECLARE @DateEnd as DateTime
DECLARE @SAPCalendar as bit
DECLARE @idoc int
DECLARE @doc varchar(8000)
DECLARE @ShiftType nvarchar(10)
DECLARE @IntervalType nvarchar(10)
 
Set @DateEnd = DATEADD(DAY,1,@DateStart)
 
 
 
-- ***** Definition of temporary table for shift result *****
CREATE TABLE #TempCap
(ID int Identity,
StartTime  Datetime,
EndTime  DateTime,
WpIdent  nvarchar(20),
IntervalType nvarchar(10),
ShiftType nvarchar(10))
 
   SET DATEFIRST 1 
 
-- ***** All days - default capacity *****
-- Cursor definition - definition of default capacity of WCs for selected days
DECLARE DefCap  CURSOR
FOR

/*
-- Shift Pattern: Heller Machines (KBRSM) - Heller 1

SELECT                DATEADD(MINUTE,360,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,360+450,@DateStart) as EndTime                -- standard shift model               
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 1' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4,5)

UNION
SELECT                DATEADD(MINUTE,870,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,870+600,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 1' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4)

UNION
SELECT                DATEADD(MINUTE,870,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,870+570,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 1' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (5)

UNION
SELECT                DATEADD(MINUTE,360,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,360+390,@DateStart) as EndTime                -- standard shift model                      
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 1' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (6)

UNION

-- Shift Pattern: Heller Machines (KBRSM) - Heller 2

SELECT                DATEADD(MINUTE,360,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,360+450,@DateStart) as EndTime                -- standard shift model                      
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 2' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4,5)

UNION
SELECT                DATEADD(MINUTE,870,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,870+600,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 2' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4)

UNION
SELECT                DATEADD(MINUTE,870,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,870+570,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 2' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (5)

UNION
SELECT                DATEADD(MINUTE,360,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,360+390,@DateStart) as EndTime                -- standard shift model                   
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 2' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (6)

UNION

-- Shift Pattern: Heller Machines (KBRSM) - Heller 3

SELECT                DATEADD(MINUTE,360,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,360+450,@DateStart) as EndTime                -- standard shift model                      
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 3' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4,5)

UNION
SELECT                DATEADD(MINUTE,870,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,870+600,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 3' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4)

UNION
SELECT                DATEADD(MINUTE,870,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,870+570,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 3' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (5)

UNION
SELECT                DATEADD(MINUTE,360,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,360+390,@DateStart) as EndTime                -- standard shift model                      
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 3' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (6)

UNION

-- Shift Pattern: Heller Machines (KBRSM) - Heller 5

SELECT                DATEADD(MINUTE,420,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,420+690,@DateStart) as EndTime                -- standard shift model                     
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 5' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4,5)

UNION
SELECT                DATEADD(MINUTE,1230,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,1230+600,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 5' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4)

UNION
SELECT                DATEADD(MINUTE,1230,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,1230+540,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 5' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (5)

UNION
SELECT                DATEADD(MINUTE,420,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,420+690,@DateStart) as EndTime                -- standard shift model                  
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 5' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (6,7,1)

UNION
*/
-- Shift Pattern: Heller Machines (KBRSM) - Heller 6

SELECT                DATEADD(MINUTE,420,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,420+690,@DateStart) as EndTime                -- standard shift model                        
, WC.Machine, 'W' as IntervalType, 'Morning' as ShiftType
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 6' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (1,2,3,4,5,6,7)

UNION
SELECT                DATEADD(MINUTE,1230,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,1230+600,@DateStart) as EndTime                -- standard shift model
, WC.Machine, 'W' as IntervalType, 'Evening' as ShiftType
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 6' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (1,2,3,4)

/*UNION
SELECT                DATEADD(MINUTE,1230,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,1230+540,@DateStart) as EndTime                -- standard shift model
, WC.Machine, 'W' as IntervalType, 'Evening' as ShiftType
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 6' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (5)
*/

--Commented here
/* UNION
SELECT                DATEADD(MINUTE,420,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,420+690,@DateStart) as EndTime                -- standard shift model                      
, WC.Machine, 'W' as IntervalType, 'Morning' as ShiftType
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Heller 6' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (6,7,1) */

UNION

-- Shift Pattern: Miyano Machines (KBRSM)- Weekday Shifts

SELECT                DATEADD(MINUTE,420,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,420+690,@DateStart) as EndTime                -- standard shift model                    
, WC.Machine, 'W' as IntervalType, 'Morning' as ShiftType
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'MIYANO%' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4,5)
	-- Mod added to exclude Fri/Sat/Sun from this section of the shift pattern LATES
	-- Uses day of week, Friday is 6, Saturday 7, Sunday 1
/*
UNION
SELECT                DATEADD(MINUTE,1230,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,1230+600,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Miyano%' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (2,3,4)

UNION
SELECT                DATEADD(MINUTE,1230,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,1230+540,@DateStart) as EndTime                -- standard shift model
, WC.Machine
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'Miyano%' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (5)
*/
UNION
SELECT                DATEADD(MINUTE,420,@DateStart) as StartTime                        -- standard shift model
, DATEADD(MINUTE,420+690,@DateStart) as EndTime                -- standard shift model
, WC.Machine, 'W' as IntervalType, 'Morning' as ShiftType
FROM                dbo.tblOEEWC as WC
WHERE WC.Machine like 'MIYANO%' AND WC.Location='MLK'
		And DATEPART( dw , @DateStart) IN (6,7,1)
		UNION
	SELECT		WT.StartTime as StartTime, WT.EndTime as EndTime, WT.Machine
				, WT.IntervalType as IntervalType
				, WT.ShiftName as ShiftType
			FROM		dbo.[tblWorkTimeS3] as WT 
			WHERE	    WT.Location='MLK' and Machine not like 'MANPress%'
			AND			WT.StartTime between @DateStart and @DateEnd
			AND			WT.Type = 3


-- LIAM: LEAVE THE CODE BELOW ALONE.

 
OPEN DefCap
FETCH DefCap into @StartTime,@EndTime,@Machine,@IntervalType,@ShiftType
 
WHILE (@@FETCH_STATUS = 0) BEGIN
-- ***** Work day & Weekend - Check capacity reduction (Type=3) *****
SET @CapAdd=1
SET @TempVal = NULL
SET @TempVal2 = NULL
--SET @IntervalType = 'W'
-----------------------------------------
/*IF  EXISTS(
SELECT                *
FROM                dbo.[tblWorkTimeS3] as WT 
WHERE            WT.Machine=@Machine AND WT.Location='MLK'
AND                        WT.StartTime <= @StartTime and WT.EndTime >= @EndTime 
AND                        WT.Type = 3)
BEGIN
PRINT Cast(@StartTime as varchar(50)) + ' Komplet ' + @Machine
SET @CapAdd=0                
END
-----------------------------------------
SELECT                @TempVal = WT.StartTime
FROM               dbo.[tblWorkTimeS3] as WT 
 
WHERE            WT.Machine=@Machine 
AND                        ((WT.StartTime > @StartTime and WT.StartTime< @EndTime) and WT.EndTime > @EndTime)
AND                        WT.Type = 3  AND WT.Location='MLK'
IF  @TempVal IS NOT NULL
BEGIN
PRINT Cast(@StartTime as varchar(50)) + ' Zprava ' + @Machine
SET @CapAdd=1        
SET @EndTime=@TempVal        
SET @TempVal=NULL
END
-----------------------------------------
SELECT                @TempVal = WT.EndTime 
FROM               dbo.[tblWorkTimeS3] as WT 
 
WHERE            WT.Machine=@Machine 
AND                        (WT.StartTime < @StartTime and (WT.EndTime > @StartTime and WT.EndTime < @EndTime))
AND                        WT.Type = 3  AND WT.Location='MLK'
IF  @TempVal IS NOT NULL
BEGIN
PRINT Cast(@StartTime as varchar(50)) + ' Zleva ' + @Machine
SET @CapAdd=1        
SET @StartTime=@TempVal        
SET @TempVal=NULL
END                
-----------------------------------------
SELECT                @TempVal = WT.StartTime, @TempVal2 = WT.EndTime 
FROM                dbo.[tblWorkTimeS3] as WT 
 
WHERE            WT.Machine=@Machine 
AND                        ((WT.StartTime >= @StartTime and WT.EndTime < @EndTime) or (WT.StartTime > @StartTime and WT.EndTime <= @EndTime))
--AND                        WT.StartTime > @StartTime and WT.EndTime < @EndTime
AND                        WT.Type = 3  AND WT.Location='MLK'
IF  @TempVal IS NOT NULL AND @TempVal2 IS NOT NULL
BEGIN
PRINT Cast(@StartTime as varchar(50)) + ' Mezi ' + @Machine
SET @CapAdd=0
IF @TempVal>@StartTime  BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@TempVal,@Machine,'W',@ShiftType) END
IF @TempVal2<@EndTime BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@TempVal2,@EndTime,@Machine,'W',@ShiftType) END
SET @TempVal=NULL
SET @TempVal2=NULL        
END                
-----------------------------------------
 
IF @CapAdd = 1 */
BEGIN INSERT #TempCap (StartTime,EndTime,WpIdent,IntervalType,ShiftType) VALUES (@StartTime,@EndTime,@Machine,@IntervalType,@ShiftType) END
FETCH DefCap into @StartTime,@EndTime,@Machine,@IntervalType,@ShiftType
END
 
-- Special capacity (Type=1) setting in tblWorkTimeS3 table is not considered because it hasn't been used for machines of our interest *****
 
SELECT * FROM #TempCap order by WpIdent, StartTime, IntervalType, ShiftType
 
CLOSE DefCap
DEALLOCATE DefCap        
DROP TABLE #TempCap 
 
END