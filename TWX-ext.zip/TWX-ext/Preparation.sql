delete from [smartKPIMachineKeyValueData] where PropertyKey like 'OEE2Per%';
delete from [smartKPIMachineKeyValueData] where PropertyKey like 'UtilizationPer%';
delete from [smartKPIMachineKeyValueData] where PropertyKey like 'OKPer%';
delete from [smartKPIMachineKeyValueData] where PropertyKey like 'NOKPer%';
delete from [smartKPIMachineKeyValueData] where PropertyKey like 'RqPer%';
delete from [smartKPIMachineKeyValueData] where PropertyKey like '%ScalingMax';
delete from [smartKPIMachineKeyValueData] where PropertyKey like '%ScalingMin';
delete from [smartKPIMachineKeyValueData] where PropertySubKey1 = 'undefined' and PropertySubKey2 = 'undefined';

print 'Remome years KPI calculations';
delete FROM [dbo].[smartKPIValues]   where KPITimeBase = 'year';


print 'Archiving definition DeleteArchivedDataTimeInMonths';
insert into [smartKPIMachineKeyValueData] ([PropertyKey]
      ,[FloatValue]
      ,[isFloatValue]
      ,[Machine])
	  select 'DeleteArchivedDataTimeInMonths', 6, 1, 'DB'
	  where not exists (select * from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedDataTimeInMonths' and [Machine] = 'DB');

print 'Archiving definition DeleteArchivedProcessDataTimeInMonths';
insert into [smartKPIMachineKeyValueData] ([PropertyKey]
      ,[FloatValue]
      ,[isFloatValue]
      ,[Machine])
	  select 'DeleteArchivedProcessDataTimeInMonths', 3, 1, 'DB'
	  where not exists (select * from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedProcessDataTimeInMonths' and [Machine] = 'DB');

print 'fixing long text logins for fluent EncryptUserData procedure recreation'
Update [smartKPIMachineMessageData] SET Message=MyMessage from (
Select *,
CAST(ROW_NUMBER() OVER(ORDER BY UTCCreationTime ASC) AS varchar(3))+'eT3c2dykCPEFeGSlwSwlg==' as MyMessage
from [smartKPIMachineMessageData] where Message in 
(select distinct [Message] from [smartKPIMachineMessageData] 
	where [MessageType1] = 'STAFF'
	and [MessageType2] = 'Operator'
	and  [Message] not like '%='
	and  [Message] not like 'User_%')) a where [smartKPIMachineMessageData].Id=a.Id