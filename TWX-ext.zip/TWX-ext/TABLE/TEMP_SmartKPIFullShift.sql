print ('CREATE TABLE TEMP_SmartKPIFullShift');

	IF NOT EXISTS (SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'TEMP_SmartKPIFullShift')
	CREATE TABLE TEMP_SmartKPIFullShift
		(
			Machine varchar(255),
			CurrentName varchar(255),
			CurrentStartTime datetime2,
			CurrentEndTime datetime2,
			CreationTime DateTime2 not null default CURRENT_TIMESTAMP
			CONSTRAINT AK_SmartKPIGetFullShiftUniqueConstraintDefinition 
			UNIQUE(Machine, CurrentStartTime, CurrentEndTime)
		);

	PRINT ('alter table TEMP_SmartKPIFullShift ADD UTCCreationTime');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPIFullShift'
			and lower(COLUMN_NAME) = lower('UTCCreationTime'))
		alter table TEMP_SmartKPIFullShift ADD UTCCreationTime datetime2 not null default GETUTCDATE();
	GO
