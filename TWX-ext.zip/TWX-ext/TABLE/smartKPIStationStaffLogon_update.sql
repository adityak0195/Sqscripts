print ('DROP TRIGGER IF EXISTS smartKPIStationStaffLogon_update');

	PRINT ('DROP TRIGGER [smartKPIStationStaffLogon_update]');
		DROP TRIGGER IF EXISTS smartKPIStationStaffLogon_update;
	GO
