--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessDateTimeData
--************************************************************************************************************
--************************************************************************************************************
print ('CREATE TABLE [smartKPIProcessDateTimeData]');

	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessDateTimeData')
	CREATE TABLE [smartKPIProcessDateTimeData](
		[Id] [bigint] IDENTITY(1,1) NOT NULL,
		[CreationTime] [datetime2](7) NOT NULL DEFAULT (getdate()),
		[Machine] [varchar](255) NOT NULL,
		[ProcesDataType] [varchar](255) NOT NULL,
		[ProcesDataType2] [varchar](255) NULL,
		[ProductionTime] [datetime2](7) NOT NULL,
		[ProcesData] [datetime2] NULL,
		[SerialNumber] [varchar](255) NULL,
		[PartNumber] [varchar](255) NULL,
		[OrderNumber] [varchar](255) NULL,
		[TrackingNumber] [varchar](255) NULL,
		[PartNumberRevision] [varchar](255) NULL,
		[Identifier] [varchar](255) NULL,
		[ProcesDataTargetValue] [datetime2] NULL,
		[description] [varchar](255) NULL,
		[comment] [varchar](255) NULL,
		[isUpdated] [bit] NOT NULL DEFAULT ((0)),
	PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	 CONSTRAINT [AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition] UNIQUE NONCLUSTERED 
	(
		[Machine] ASC,
		[ProductionTime] ASC,
		[ProcesDataType] ASC,
		[TrackingNumber] ASC,
		[Identifier] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]
	GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIProcessDateTimeData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessDateTimeData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIProcessDateTimeData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIProcessDateTimeData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessDateTimeData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIProcessDateTimeData ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIProcessDateTimeData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIProcessDateTimeData_modification_trigger] ON [smartKPIProcessDateTimeData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIProcessDateTimeData_modification_trigger] ON [smartKPIProcessDateTimeData] AFTER UPDATE, INSERT
AS
	update [smartKPIProcessDateTimeData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIProcessDateTimeData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIProcessDateTimeData_modification_trigger_delete] ON [smartKPIProcessDateTimeData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIProcessDateTimeData_modification_trigger_delete] ON [smartKPIProcessDateTimeData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIProcessDateTimeData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIProcessDateTimeData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table smartKPIProcessDateTimeData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessDateTimeData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIProcessDateTimeData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIProcessDateTimeData drop CONSTRAINT AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition')
	alter table smartKPIProcessDateTimeData drop CONSTRAINT AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition;
GO

PRINT ('alter table smartKPIProcessDateTimeData ADD AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition1');
	if not exists (SELECT object_id  FROM sys.objects  WHERE name='AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition1' union SELECT object_id  FROM sys.indexes  WHERE name='AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition1')
	ALTER TABLE smartKPIProcessDateTimeData   
	ADD CONSTRAINT AK_ShortName_smartKPIProcessDateTimeDataUniqueConstraintDefinition1 
	UNIQUE([Machine] ASC,
		[ProductionTime] ASC,
		[ProcesDataType] ASC,
		[ProcesDataType2] ASC,
		[TrackingNumber] ASC,
		[Identifier] ASC);   
GO

