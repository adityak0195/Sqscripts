--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIUserKeyValueData
--************************************************************************************************************
--************************************************************************************************************


PRINT ('create table smartKPIUserKeyValueData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserKeyValueData')
	create table smartKPIUserKeyValueData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		UpdateTime DateTime2 not null default CURRENT_TIMESTAMP,
		PropertyKey varchar(255)  not null,
		FloatValue float  null,
		TextValue varchar(max)  null,
		DateTimeValue DateTime2  null,
		isFloatValue bit not null default 0,
		isTextValue bit not null default 0,
		isDateTimeValue bit not null default 0,
		UserId varchar(255)
		CONSTRAINT AK_smartKPIUserKeyValueDataUniqueConstraintDefinition 
		UNIQUE(UserId, PropertyKey));
GO

PRINT ('alter table smartKPIUserKeyValueData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserKeyValueData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIUserKeyValueData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
PRINT ('alter table smartKPIUserKeyValueData ADD UTCUpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserKeyValueData'
		and lower(COLUMN_NAME) = lower('UTCUpdateTime'))
	alter table smartKPIUserKeyValueData ADD UTCUpdateTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIUserKeyValueData ADD System');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserKeyValueData'
		and lower(COLUMN_NAME) = lower('System'))
	alter table smartKPIUserKeyValueData ADD System varchar(255) not null;
GO

PRINT ('alter table smartKPIUserKeyValueData drop CONSTRAINT AK_smartKPIUserKeyValueDataUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_smartKPIUserKeyValueDataUniqueConstraintDefinition')
	alter table smartKPIUserKeyValueData drop CONSTRAINT AK_smartKPIUserKeyValueDataUniqueConstraintDefinition;
GO
  
PRINT ('alter table smartKPIUserKeyValueData ADD CONSTRAINT');
	if not exists (SELECT object_id  FROM sys.objects  WHERE name='AK_smartKPIUserKeyValueDataUniqueConstraintDefinition1' union SELECT object_id  FROM sys.indexes  WHERE name='AK_smartKPIUserKeyValueDataUniqueConstraintDefinition1')
	ALTER TABLE smartKPIUserKeyValueData   
	ADD CONSTRAINT AK_smartKPIUserKeyValueDataUniqueConstraintDefinition1 
	UNIQUE (UserId, PropertyKey, System);   
GO


--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIUserKeyValueData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserKeyValueData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIUserKeyValueData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIUserKeyValueData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserKeyValueData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIUserKeyValueData ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIUserKeyValueData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIUserKeyValueData_modification_trigger] ON [smartKPIUserKeyValueData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIUserKeyValueData_modification_trigger] ON [smartKPIUserKeyValueData] AFTER UPDATE, INSERT
AS
	update [smartKPIUserKeyValueData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIUserKeyValueData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIUserKeyValueData_modification_trigger_delete] ON [smartKPIUserKeyValueData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIUserKeyValueData_modification_trigger_delete] ON [smartKPIUserKeyValueData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIUserKeyValueData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIUserKeyValueData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************

