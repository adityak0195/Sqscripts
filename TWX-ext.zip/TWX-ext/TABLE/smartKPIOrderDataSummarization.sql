--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIOrderDataSummarization
--************************************************************************************************************
--************************************************************************************************************

PRINT ('drop table smartKPIOrderDataSummarization');
	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderDataSummarization')
	drop table smartKPIOrderDataSummarization;
 
GO

DROP TRIGGER IF EXISTS [smartKPIOrderKeyValueData_Summarization] ;
GO

DROP TRIGGER IF EXISTS [smartKPIOrderKeyValueData_Summarization1] ;
GO
