--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineData
--************************************************************************************************************
--************************************************************************************************************


PRINT ('create table smartKPIMachineData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineData')
	create table smartKPIMachineData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)
		CONSTRAINT AK_smartKPIMachineDataUniqueConstraintDefinition 
		UNIQUE(Machine));
GO

PRINT ('alter table smartKPIMachineData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIMachineData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
		
PRINT ('alter table smartKPIMachineData ADD isMachineActive');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineData'
		and lower(COLUMN_NAME) = lower('isMachineActive'))
	alter table smartKPIMachineData ADD isMachineActive bit not null default 1;
GO
  
PRINT ('alter table smartKPIMachineData ADD UpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineData'
		and lower(COLUMN_NAME) = lower('UpdateTime'))
	alter table smartKPIMachineData ADD UpdateTime DateTime2 not null default CURRENT_TIMESTAMP;
GO

PRINT ('alter table smartKPIMachineData ADD UTCUpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineData'
		and lower(COLUMN_NAME) = lower('UTCUpdateTime'))
	alter table smartKPIMachineData ADD UTCUpdateTime datetime2 not null default GETUTCDATE();
GO

PRINT ('insert into [smartKPIMachineData]');
	insert into [smartKPIMachineData] ([Machine]) 
	select 'DatabaseVersionFromDBScript' 
	where not exists (select 'ok' from [smartKPIMachineData] where Machine = 'DatabaseVersionFromDBScript');
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIMachineData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIMachineData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIMachineData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIMachineData ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIMachineData_modification_trigger] ON [smartKPIMachineData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineData_modification_trigger] ON [smartKPIMachineData] AFTER UPDATE, INSERT
AS
	update [smartKPIMachineData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIMachineData_modification_trigger_delete] ON [smartKPIMachineData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineData_modification_trigger_delete] ON [smartKPIMachineData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIMachineData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIMachineData set move_to_history = move_to_history where modification_id is null;

--*************************************************For Archiving, do not change***********************************************************
