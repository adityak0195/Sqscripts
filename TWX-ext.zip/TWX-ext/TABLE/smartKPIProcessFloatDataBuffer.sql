--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessFloatDataBuffer
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIProcessFloatDataBuffer');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatDataBuffer')
	create table smartKPIProcessFloatDataBuffer (
		Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		Type varchar(255)  not null,
		JSON varchar(max));
GO

PRINT ('alter table smartKPIProcessFloatDataBuffer ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatDataBuffer'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIProcessFloatDataBuffer ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
