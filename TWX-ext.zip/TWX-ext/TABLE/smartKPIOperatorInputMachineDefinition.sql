--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIOperatorInputMachineDefinition
--************************************************************************************************************
--************************************************************************************************************
PRINT ('create table smartKPIOperatorInputMachineDefinition');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition')
	create table smartKPIOperatorInputMachineDefinition 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		Devision varchar(255)  not null,
		SubStatus varchar(255)  not null,
		Status varchar(255)  not null,
		SortingIndex int not null,
		StatusType varchar(255)  not null
		CONSTRAINT AK_smartKPIOperatorInputMachineDefinition_UniqueConstraintDefinition 
		UNIQUE(Machine, Devision, SubStatus, Status));
GO

PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIOperatorInputMachineDefinition ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD TimeLossInSec');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('TimeLossInSec'))
	alter table smartKPIOperatorInputMachineDefinition ADD TimeLossInSec int not null default 0;
GO

PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD isDeleted');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('isDeleted'))
	alter table smartKPIOperatorInputMachineDefinition ADD isDeleted bit not null default 0;
GO

PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD JSON');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('JSON'))
	alter table smartKPIOperatorInputMachineDefinition ADD JSON varchar(max) not null default '{"dataShape":{"fieldDefinitions":{}},"rows":[]}';
GO

PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD externalIdent');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('externalIdent'))
	alter table smartKPIOperatorInputMachineDefinition ADD externalIdent varchar(255);
GO

PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD StatusType1');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('StatusType1'))
	alter table smartKPIOperatorInputMachineDefinition ADD StatusType1 varchar(255) not null default 'default definition';
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIOperatorInputMachineDefinition ADD modification_id bigint;
GO
PRINT ('alter table smartKPIOperatorInputMachineDefinition ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOperatorInputMachineDefinition'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIOperatorInputMachineDefinition ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIOperatorInputMachineDefinition_modification_trigger'))
exec('CREATE TRIGGER [smartKPIOperatorInputMachineDefinition_modification_trigger] ON [smartKPIOperatorInputMachineDefinition] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIOperatorInputMachineDefinition_modification_trigger] ON [smartKPIOperatorInputMachineDefinition] AFTER UPDATE, INSERT
AS
	update [smartKPIOperatorInputMachineDefinition] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIOperatorInputMachineDefinition_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIOperatorInputMachineDefinition_modification_trigger_delete] ON [smartKPIOperatorInputMachineDefinition] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIOperatorInputMachineDefinition_modification_trigger_delete] ON [smartKPIOperatorInputMachineDefinition] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIOperatorInputMachineDefinition', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIOperatorInputMachineDefinition set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************
