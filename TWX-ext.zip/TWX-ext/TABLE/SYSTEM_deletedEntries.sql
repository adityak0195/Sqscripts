--************************************************************************************************************
--************************************************************************************************************
-- Table SYSTEM_deletedEntries
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table SYSTEM_deletedEntries');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'SYSTEM_deletedEntries')
	create table SYSTEM_deletedEntries 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		UTCCreationTime DateTime2 not null default GETUTCDATE(),
		TableName varchar(255)  not null,
		DeletedId bigint not null,
		modification_id bigint,
		identifier varchar(20)  not null);
GO

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIMachineFloatData_DELETED_FOR_AZURE];	
GO

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStringData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIMachineStringData_DELETED_FOR_AZURE];	
GO	

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI_DELETED_FOR_AZURE')
		DROP TABLE [smartKPI_DELETED_FOR_AZURE];	
GO

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStatusData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIMachineStatusData_DELETED_FOR_AZURE];
GO
	

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineMessageData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIMachineMessageData_DELETED_FOR_AZURE];
GO
	

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'shiftCalendar_DELETED_FOR_AZURE')
		DROP TABLE [shiftCalendar_DELETED_FOR_AZURE];
GO

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessDateTimeData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIProcessDateTimeData_DELETED_FOR_AZURE];
GO

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIProcessFloatData_DELETED_FOR_AZURE];
GO

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessStringData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIProcessStringData_DELETED_FOR_AZURE];
GO
	
	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIOrderKeyValueData_DELETED_FOR_AZURE];
GO
	
	
	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData_DELETED_FOR_AZURE')
		DROP TABLE [smartKPIOrderData_DELETED_FOR_AZURE];
GO
