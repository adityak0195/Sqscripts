--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineStatusData
--************************************************************************************************************
--************************************************************************************************************
		
PRINT ('create table smartKPIMachineStatusData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStatusData')
	create table smartKPIMachineStatusData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		StatusTime DateTime2 not null,
		Status varchar(255),
		SubStatus varchar(255)
		CONSTRAINT AK_ShortName_StatusUniqueConstraintDefinition 
		UNIQUE(Machine, StatusTime));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIMachineStatusData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStatusData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIMachineStatusData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIMachineStatusData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStatusData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIMachineStatusData ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineStatusData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIMachineStatusData_modification_trigger] ON [smartKPIMachineStatusData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineStatusData_modification_trigger] ON [smartKPIMachineStatusData] AFTER UPDATE, INSERT
AS
	update [smartKPIMachineStatusData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineStatusData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIMachineStatusData_modification_trigger_delete] ON [smartKPIMachineStatusData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineStatusData_modification_trigger_delete] ON [smartKPIMachineStatusData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIMachineStatusData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIMachineStatusData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table smartKPIMachineStatusData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStatusData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIMachineStatusData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIMachineStatusData ADD description');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStatusData'
		and lower(COLUMN_NAME) = lower('description'))
	alter table smartKPIMachineStatusData ADD description varchar(255);
GO

PRINT ('alter table smartKPIMachineStatusData ALTER COLUMN [description]');
	alter table smartKPIMachineStatusData ALTER COLUMN [description] varchar(max);
GO
  
PRINT ('alter table smartKPIMachineStatusData ADD StatusType');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStatusData'
		and lower(COLUMN_NAME) = lower('StatusType'))
	alter table smartKPIMachineStatusData ADD StatusType varchar(255);
GO
  
PRINT ('alter table smartKPIMachineStatusData drop CONSTRAINT AK_ShortName_StatusUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_StatusUniqueConstraintDefinition')
	alter table smartKPIMachineStatusData drop CONSTRAINT AK_ShortName_StatusUniqueConstraintDefinition;
GO
