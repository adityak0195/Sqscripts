--************************************************************************************************************
--************************************************************************************************************
--Table shiftCalendar
--************************************************************************************************************
--************************************************************************************************************


PRINT ('create table shiftCalendar');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'shiftCalendar')
	create table shiftCalendar 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Plant varchar(255)  not null,
		Machine varchar(255)  not null,
		StartTime DateTime2 not null,
		EndTime DateTime2 not null,
		Qualifier varchar(10)  not null,
		Name varchar(255)  not null,
		Machine_Full_Name varchar(255));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table shiftCalendar ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'shiftCalendar'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table shiftCalendar ADD modification_id bigint;
GO
PRINT ('alter table shiftCalendar ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'shiftCalendar'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table shiftCalendar ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'shiftCalendar_modification_trigger'))
exec('CREATE TRIGGER [shiftCalendar_modification_trigger] ON [shiftCalendar] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [shiftCalendar_modification_trigger] ON [shiftCalendar] AFTER UPDATE, INSERT
AS
	update [shiftCalendar] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'shiftCalendar_modification_trigger_delete'))
exec('CREATE TRIGGER [shiftCalendar_modification_trigger_delete] ON [shiftCalendar] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [shiftCalendar_modification_trigger_delete] ON [shiftCalendar] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'shiftCalendar', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) shiftCalendar set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table shiftCalendar ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'shiftCalendar'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table shiftCalendar ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table shiftCalendar ADD Utilization');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'shiftCalendar'
		and lower(COLUMN_NAME) = lower('Utilization'))
	alter table shiftCalendar ADD Utilization float not null default 100.0;
GO

