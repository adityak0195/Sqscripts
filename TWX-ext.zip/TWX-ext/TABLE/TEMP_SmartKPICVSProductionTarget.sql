print ('CREATE TABLE TEMP_SmartKPICVSProductionTarget');

	IF NOT EXISTS (SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTarget')
	CREATE TABLE TEMP_SmartKPICVSProductionTarget
		(
			LineThingName varchar(255),
			StartTime datetime2,
			EndTime datetime2,
			Target int,
			CreationTime DateTime2 not null default CURRENT_TIMESTAMP
			CONSTRAINT AK_SmartKPICVSProductionTargetUniqueConstraintDefinition 
			UNIQUE(LineThingName, StartTime, EndTime)
		);

	PRINT ('alter table TEMP_SmartKPICVSProductionTarget ADD UTCCreationTime');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTarget'
			and lower(COLUMN_NAME) = lower('UTCCreationTime'))
		alter table TEMP_SmartKPICVSProductionTarget ADD UTCCreationTime datetime2 not null default GETUTCDATE();
	GO

	PRINT ('alter table TEMP_SmartKPICVSProductionTarget ADD SumPlannedNumberOfWorkers');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTarget'
			and lower(COLUMN_NAME) = lower('SumPlannedNumberOfWorkers'))
		alter table TEMP_SmartKPICVSProductionTarget ADD SumPlannedNumberOfWorkers int not null default 0;
	GO

	PRINT ('alter table TEMP_SmartKPICVSProductionTarget ADD ShiftFactorInPercent');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTarget'
			and lower(COLUMN_NAME) = lower('ShiftFactorInPercent'))
		alter table TEMP_SmartKPICVSProductionTarget ADD ShiftFactorInPercent float not null default 0;
	GO
