--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineStringData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIMachineStringData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStringData')
	create table smartKPIMachineStringData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		MachineTime DateTime2 not null,
		MachineDataType varchar(255)  not null,
		MachineData varchar(max),
		CONSTRAINT AK_ShortName_smartKPIMachineStringDataUniqueConstraintDefinition 
		UNIQUE(Machine, MachineTime, MachineDataType));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIMachineStringData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStringData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIMachineStringData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIMachineStringData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStringData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIMachineStringData ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineStringData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIMachineStringData_modification_trigger] ON [smartKPIMachineStringData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineStringData_modification_trigger] ON [smartKPIMachineStringData] AFTER UPDATE, INSERT
AS
	update [smartKPIMachineStringData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineStringData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIMachineStringData_modification_trigger_delete] ON [smartKPIMachineStringData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineStringData_modification_trigger_delete] ON [smartKPIMachineStringData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIMachineStringData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIMachineStringData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************

PRINT ('alter table smartKPIMachineStringData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStringData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIMachineStringData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
		
PRINT ('alter table smartKPIMachineStringData ADD comment');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStringData'
		and lower(COLUMN_NAME) = lower('comment'))
	alter table smartKPIMachineStringData ADD comment varchar(255);
GO

PRINT ('alter table smartKPIMachineStringData ADD description');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineStringData'
		and lower(COLUMN_NAME) = lower('description'))
	alter table smartKPIMachineStringData ADD description varchar(255);
GO

PRINT ('alter table smartKPIMachineStringData drop CONSTRAINT AK_ShortName_smartKPIMachineStringDataUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_smartKPIMachineStringDataUniqueConstraintDefinition')
	alter table smartKPIMachineStringData drop CONSTRAINT AK_ShortName_smartKPIMachineStringDataUniqueConstraintDefinition;
GO

