
--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineMessageData
--************************************************************************************************************
--************************************************************************************************************
  
PRINT ('create table smartKPIMachineMessageData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineMessageData')
	create table smartKPIMachineMessageData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		MessageTime DateTime2 not null,
		MessageType1 varchar(255),
		MessageType2 varchar(255),
		Message varchar(255),
		description varchar(255)
		CONSTRAINT AK_ShortName_MessageUniqueConstraintDefinition 
		UNIQUE(Machine, MessageTime));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIMachineMessageData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineMessageData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIMachineMessageData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIMachineMessageData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineMessageData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIMachineMessageData ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineMessageData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIMachineMessageData_modification_trigger] ON [smartKPIMachineMessageData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineMessageData_modification_trigger] ON [smartKPIMachineMessageData] AFTER UPDATE, INSERT
AS
	update [smartKPIMachineMessageData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineMessageData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIMachineMessageData_modification_trigger_delete] ON [smartKPIMachineMessageData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineMessageData_modification_trigger_delete] ON [smartKPIMachineMessageData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIMachineMessageData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIMachineMessageData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table smartKPIMachineMessageData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineMessageData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIMachineMessageData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIMachineMessageData drop CONSTRAINT AK_ShortName_MessageUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_MessageUniqueConstraintDefinition')
	alter table smartKPIMachineMessageData drop CONSTRAINT AK_ShortName_MessageUniqueConstraintDefinition;
GO
  
PRINT ('DROP TRIGGER [smartKPIMachineMessageData_update]');
GO
DROP TRIGGER IF EXISTS [smartKPIMachineMessageData_update] ;
GO

PRINT ('alter table smartKPIMachineMessageData ALTER COLUMN [Message]');
	alter table smartKPIMachineMessageData ALTER COLUMN [Message] varchar(max);
GO

