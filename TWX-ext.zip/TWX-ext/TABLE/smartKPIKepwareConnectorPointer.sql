--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIKepwareConnectorPointer
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIKepwareConnectorPointer');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIKepwareConnectorPointer')
	create table smartKPIKepwareConnectorPointer
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		LastRun DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		UpdatedId bigint not null default 0);
GO

PRINT ('alter table smartKPIKepwareConnectorPointer ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIKepwareConnectorPointer'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIKepwareConnectorPointer ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
