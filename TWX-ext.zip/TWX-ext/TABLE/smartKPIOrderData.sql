--************************************************************************************************************
--************************************************************************************************************
-- Table smartKPIOrderData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIOrderData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData')
	create table smartKPIOrderData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		System varchar(255)  not null,
		OrderNumber varchar(255)
		CONSTRAINT AK_smartKPIOrderDataUniqueConstraintDefinition 
		UNIQUE(OrderNumber, System));
GO

PRINT ('alter table smartKPIOrderData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIOrderData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

	
PRINT ('alter table smartKPIOrderData ADD isProductionStarted');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('isProductionStarted'))
	alter table smartKPIOrderData ADD isProductionStarted bit not null default 0;
GO
  
PRINT ('alter table smartKPIOrderData ADD UpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('UpdateTime'))
	alter table smartKPIOrderData ADD UpdateTime DateTime2 not null default CURRENT_TIMESTAMP;
GO

PRINT ('alter table smartKPIOrderData ADD UTCUpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('UTCUpdateTime'))
	alter table smartKPIOrderData ADD UTCUpdateTime datetime2 not null default GETUTCDATE();
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIOrderData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIOrderData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIOrderData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIOrderData ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIOrderData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIOrderData_modification_trigger] ON [smartKPIOrderData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIOrderData_modification_trigger] ON [smartKPIOrderData] AFTER UPDATE, INSERT
AS
	update [smartKPIOrderData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIOrderData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIOrderData_modification_trigger_delete] ON [smartKPIOrderData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIOrderData_modification_trigger_delete] ON [smartKPIOrderData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIOrderData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIOrderData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************
	

PRINT ('alter table smartKPIOrderData ADD isCAPSProductionFinalized');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('isCAPSProductionFinalized'))
	alter table smartKPIOrderData ADD isCAPSProductionFinalized bit not null default 0;
GO

PRINT ('alter table smartKPIOrderData ADD isCAPSDataUpdated');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('isCAPSDataUpdated'))
	alter table smartKPIOrderData ADD isCAPSDataUpdated bit not null default 1;
GO

--------- Changing isCAPSDataUpdated default value to 0 ------------------------------------------------
--------- Must be done like this because it already exists on name DBs and cannot be changed normaly ---
DECLARE @constraint VARCHAR(255) = (
SELECT 
    --TableName = t.Name,
    --ColumnName = c.Name,
    dc.Name
    --dc.definition
FROM sys.tables t
INNER JOIN sys.default_constraints dc ON t.object_id = dc.parent_object_id
INNER JOIN sys.columns c ON dc.parent_object_id = c.object_id AND c.column_id = dc.parent_column_id
WHERE t.Name = 'smartKPIOrderData'
	and c.Name = 'isCAPSDataUpdated'
)

DECLARE @sql VARCHAR(1000);

SET @sql = 'ALTER TABLE smartKPIOrderData DROP CONSTRAINT ' + @constraint
PRINT (@sql)
EXEC (@sql)

SET @sql = 'ALTER TABLE smartKPIOrderData ADD CONSTRAINT ' + @constraint + ' DEFAULT 0 FOR isCAPSDataUpdated'
PRINT (@sql)
EXEC (@sql)
--------------------------------------------------------------------------------------------------------

PRINT ('alter table smartKPIOrderData ADD isCAPSOrderError');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('isCAPSOrderError'))
	alter table smartKPIOrderData ADD isCAPSOrderError bit not null default 0;
GO

PRINT ('alter table smartKPIOrderData ADD CAPSOrderError');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('CAPSOrderError'))
	alter table smartKPIOrderData ADD CAPSOrderError varchar(255);
GO

PRINT ('alter table smartKPIOrderData ADD PlantId');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderData'
		and lower(COLUMN_NAME) = lower('PlantId'))
	alter table smartKPIOrderData ADD PlantId varchar(255);
GO

update [smartKPIOrderData] 
set PlantId = (select x.TextValue
			from [smartKPIOrderKeyValueData] as x
			where x.PropertyKey = 'Plant'
			and x.OrderNumber = [smartKPIOrderData].OrderNumber
			and x.System = [smartKPIOrderData].System)
where PlantId is NULL;

