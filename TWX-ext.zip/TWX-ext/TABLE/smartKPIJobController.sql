--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIJobController
--************************************************************************************************************
--************************************************************************************************************
  
PRINT ('create table smartKPIJobController');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIJobController')
	create table smartKPIJobController 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Job varchar(255)  not null,
		isRunnung Bit not null default 0,
		isContinuing Bit not null default 1,
		LastStart DateTime2 null,
		LastRunningTimeSec float  null,
		LogLevel int not null default 0
		CONSTRAINT AK_smartKPIJobControllerUniqueConstraintDefinition 
		UNIQUE(Job));
GO
  
PRINT ('alter table smartKPIJobController ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIJobController'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIJobController ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
