print ('DROP TABLE [smartKPISAPProcessDataBufferError]');

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPProcessDataBufferError')
	DROP TABLE [smartKPISAPProcessDataBufferError];
GO