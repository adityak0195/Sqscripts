--************************************************************************************************************
--************************************************************************************************************
--Table SAPTimePerPart
--************************************************************************************************************
--************************************************************************************************************
PRINT ('create table SAPTimePerPart');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'SAPTimePerPart')
	create table SAPTimePerPart 
		(orderNumber varchar(15)  not null,
		orderNumberShort varchar(15)  not null,
		timePerPartFromSAP float,
		timeUnit varchar(15),
		timePerPartInSec float
		CONSTRAINT AK_orderNumber_SAPTimePerPartUniqueConstraintDefinition 
		UNIQUE(orderNumber));
GO
		
PRINT ('alter table SAPTimePerPart ADD Workcenter');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'SAPTimePerPart'
		and lower(COLUMN_NAME) = lower('Workcenter'))
	alter table SAPTimePerPart ADD Workcenter varchar(255);
GO

