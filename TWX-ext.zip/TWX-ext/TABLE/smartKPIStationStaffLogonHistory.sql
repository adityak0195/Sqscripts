print ('DROP TABLE smartKPIStationStaffLogonHistory');

	IF EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIStationStaffLogonHistory')
	DROP TABLE [smartKPIStationStaffLogonHistory];
GO
	