--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIValues
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIValues');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIValues')
	create table smartKPIValues 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		KPIName varchar(255)  not null,
		KPICalculationBase varchar(255)  not null,
		KPIDateTime DateTime2 not null,
		KPIFloatValue float  not null
		CONSTRAINT AK_smartKPIValuesUniqueConstraintDefinition 
		UNIQUE(Machine, KPIName, KPICalculationBase, KPIDateTime));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIValues ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIValues'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIValues ADD modification_id bigint;
GO
PRINT ('alter table smartKPIValues ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIValues'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIValues ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIValues_modification_trigger'))
exec('CREATE TRIGGER [smartKPIValues_modification_trigger] ON [smartKPIValues] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIValues_modification_trigger] ON [smartKPIValues] AFTER UPDATE, INSERT
AS
	update [smartKPIValues] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIValues_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIValues_modification_trigger_delete] ON [smartKPIValues] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIValues_modification_trigger_delete] ON [smartKPIValues] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIValues', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIValues set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table smartKPIValues ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIValues'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIValues ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIValues ADD KPIDateTimeEnd');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIValues'
		and lower(COLUMN_NAME) = lower('KPIDateTimeEnd'))
	alter table smartKPIValues ADD KPIDateTimeEnd DateTime2 not null default getdate();
GO

PRINT ('alter table smartKPIValues ADD KPIDateTimeEnd');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIValues'
		and lower(COLUMN_NAME) = lower('KPITimeBase'))
	alter table smartKPIValues ADD KPITimeBase varchar(255) not null default 'flex';
GO

PRINT ('alter table smartKPIValues drop CONSTRAINT AK_smartKPIValuesUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_smartKPIValuesUniqueConstraintDefinition')
	alter table smartKPIValues drop CONSTRAINT AK_smartKPIValuesUniqueConstraintDefinition;
GO

PRINT ('alter table smartKPIValues drop CONSTRAINT AK_smartKPIValuesUniqueConstraintDefinition1');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_smartKPIValuesUniqueConstraintDefinition1')
	alter table smartKPIValues drop CONSTRAINT AK_smartKPIValuesUniqueConstraintDefinition1;
GO

PRINT ('alter table smartKPIValues ADD AK_smartKPIValuesUniqueConstraintDefinition2');
	if not exists (SELECT object_id  FROM sys.objects  WHERE name='AK_smartKPIValuesUniqueConstraintDefinition2' union SELECT object_id  FROM sys.indexes  WHERE name='AK_smartKPIValuesUniqueConstraintDefinition2')
	ALTER TABLE smartKPIValues   
	ADD CONSTRAINT AK_smartKPIValuesUniqueConstraintDefinition2 
	UNIQUE(Machine, KPIName, KPIDateTime, KPIDateTimeEnd, KPICalculationBase);   
GO

