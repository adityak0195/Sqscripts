--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIJobLogger
--************************************************************************************************************
--************************************************************************************************************
PRINT ('create table smartKPIJobLogger');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIJobLogger')
	create table smartKPIJobLogger 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Job varchar(255)  not null,
		LogLevel int not null default 0,
		LogText varchar(1024) null);
GO

PRINT ('alter table smartKPIJobLogger ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIJobLogger'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIJobLogger ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
  

