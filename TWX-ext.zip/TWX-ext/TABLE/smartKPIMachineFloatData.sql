--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineFloatData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIMachineFloatData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData')
	create table smartKPIMachineFloatData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		MachineTime DateTime2 not null,
		MachineDataType varchar(255)  not null,
		MachineData float,
		CONSTRAINT AK_ShortName_smartKPIMachineFloatDataUniqueConstraintDefinition 
		UNIQUE(Machine, MachineTime, MachineDataType));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIMachineFloatData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIMachineFloatData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIMachineFloatData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIMachineFloatData ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineFloatData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIMachineFloatData_modification_trigger] ON [smartKPIMachineFloatData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineFloatData_modification_trigger] ON [smartKPIMachineFloatData] AFTER UPDATE, INSERT
AS
	update [smartKPIMachineFloatData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineFloatData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIMachineFloatData_modification_trigger_delete] ON [smartKPIMachineFloatData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineFloatData_modification_trigger_delete] ON [smartKPIMachineFloatData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIMachineFloatData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIMachineFloatData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************

PRINT ('alter table smartKPIMachineFloatData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIMachineFloatData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
		
PRINT ('alter table smartKPIMachineFloatData ADD MachineDataLSL');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('MachineDataLSL'))
	alter table smartKPIMachineFloatData ADD MachineDataLSL float;
GO
  
PRINT ('alter table smartKPIMachineFloatData ADD MachineDataUSL');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('MachineDataUSL'))
	alter table smartKPIMachineFloatData ADD MachineDataUSL float;
GO
  
PRINT ('alter table smartKPIMachineFloatData ADD isUpdated');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('isUpdated'))
	alter table smartKPIMachineFloatData ADD isUpdated Bit not null default 1;
GO
  
PRINT ('alter table smartKPIMachineFloatData ADD comment');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('comment'))
	alter table smartKPIMachineFloatData ADD comment varchar(255);
GO

PRINT ('alter table smartKPIMachineFloatData ADD Unit');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('Unit'))
	alter table smartKPIMachineFloatData ADD Unit varchar(255);
GO
  
PRINT ('alter table smartKPIMachineFloatData ADD description');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineFloatData'
		and lower(COLUMN_NAME) = lower('description'))
	alter table smartKPIMachineFloatData ADD description varchar(255);
GO
  
PRINT ('alter table smartKPIMachineFloatData drop CONSTRAINT AK_ShortName_smartKPIMachineFloatDataUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_smartKPIMachineFloatDataUniqueConstraintDefinition')
	alter table smartKPIMachineFloatData drop CONSTRAINT AK_ShortName_smartKPIMachineFloatDataUniqueConstraintDefinition;
GO

