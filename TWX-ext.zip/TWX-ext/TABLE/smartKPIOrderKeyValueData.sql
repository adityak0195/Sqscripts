--************************************************************************************************************
--************************************************************************************************************
-- Table smartKPIOrderKeyValueData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIOrderKeyValueData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData')
	create table smartKPIOrderKeyValueData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		PropertyKey varchar(255)  not null,
		FloatValue float  null,
		TextValue varchar(255)  null,
		DateTimeValue DateTime2  null,
		isFloatValue bit not null default 0,
		isTextValue bit not null default 0,
		isDateTimeValue bit not null default 0,
		System varchar(255)  not null,
		OrderNumber varchar(255)
		CONSTRAINT AK_smartKPIOrderKeyValueDataUniqueConstraintDefinition 
		UNIQUE(OrderNumber, PropertyKey, System));
GO

PRINT ('alter table smartKPIOrderKeyValueData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIOrderKeyValueData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO


PRINT ('alter table smartKPIOrderKeyValueData ADD UpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('UpdateTime'))
	alter table smartKPIOrderKeyValueData ADD UpdateTime DateTime2 not null default CURRENT_TIMESTAMP;
GO

PRINT ('alter table smartKPIOrderKeyValueData ADD UTCUpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('UTCUpdateTime'))
	alter table smartKPIOrderKeyValueData ADD UTCUpdateTime datetime2 not null default GETUTCDATE();
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIOrderKeyValueData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIOrderKeyValueData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIOrderKeyValueData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIOrderKeyValueData ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIOrderKeyValueData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIOrderKeyValueData_modification_trigger] ON [smartKPIOrderKeyValueData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIOrderKeyValueData_modification_trigger] ON [smartKPIOrderKeyValueData] AFTER UPDATE, INSERT
AS
	update [smartKPIOrderKeyValueData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIOrderKeyValueData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIOrderKeyValueData_modification_trigger_delete] ON [smartKPIOrderKeyValueData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIOrderKeyValueData_modification_trigger_delete] ON [smartKPIOrderKeyValueData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIOrderKeyValueData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIOrderKeyValueData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table smartKPIOrderKeyValueData ADD PlantId');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('PlantId'))
	alter table smartKPIOrderKeyValueData ADD PlantId varchar(255);
GO  

PRINT ('alter table smartKPIOrderKeyValueData ADD PropertyKey1');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('PropertyKey1'))
	alter table smartKPIOrderKeyValueData ADD PropertyKey1 varchar(255);
GO  

PRINT ('alter table smartKPIOrderKeyValueData ADD Operation');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('Operation'))
	alter table smartKPIOrderKeyValueData ADD Operation varchar(255);
GO  

PRINT ('alter table smartKPIOrderKeyValueData ADD TextValue1');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIOrderKeyValueData'
		and lower(COLUMN_NAME) = lower('TextValue1'))
	alter table smartKPIOrderKeyValueData ADD TextValue1 varchar(255);
GO  

PRINT ('update smartKPIOrderKeyValueData --> TextValue1');
update [smartKPIOrderKeyValueData]
set [TextValue1] = substring(TextValue,1,254)
	where [TextValue1] is null
	and TextValue is not null
    and DB_NAME() != 'twx_muc_prod_ext';


PRINT ('update smartKPIOrderKeyValueData --> PropertyKey1');
update [smartKPIOrderKeyValueData]
set [PropertyKey1] = case when (SUBSTRING([PropertyKey], CASE when (DATALENGTH([PropertyKey]) > 4) then DATALENGTH([PropertyKey])-4 else 0 end,1) = '-') then SUBSTRING([PropertyKey],1,DATALENGTH([PropertyKey])-5)
		else [PropertyKey]
		end
	where [PropertyKey1] is null;

PRINT ('update smartKPIOrderKeyValueData --> Operation');
update [smartKPIOrderKeyValueData]
set [Operation] = case when (SUBSTRING([PropertyKey], CASE when (DATALENGTH([PropertyKey]) > 4) then DATALENGTH([PropertyKey])-4 else 0 end,1) = '-') then SUBSTRING([PropertyKey],DATALENGTH([PropertyKey])-3,4)
		else ''
		end
	where [Operation] is null;
  
PRINT ('alter table smartKPIOrderKeyValueData ALTER COLUMN [TextValue]');
	alter table smartKPIOrderKeyValueData ALTER COLUMN [TextValue] varchar(max);
GO

PRINT ('update smartKPIOrderKeyValueData --> PlantId');
update [smartKPIOrderKeyValueData] 
set PlantId = (select x.TextValue
			from [smartKPIOrderKeyValueData] as x
			where x.PropertyKey = 'Plant'
			and x.OrderNumber = [smartKPIOrderKeyValueData].OrderNumber
			and x.System = [smartKPIOrderKeyValueData].System)
where PlantId is NULL;

