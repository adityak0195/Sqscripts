--************************************************************************************************************
--************************************************************************************************************
--Table smartKPISAPPMKeyValueData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPISAPPMKeyValueData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData')
	CREATE TABLE smartKPISAPPMKeyValueData(
	Id bigint IDENTITY(1,1) NOT NULL,
	CreationTime datetime2(7) NOT NULL default GETDATE(),
	PropertyKey varchar(255) NOT NULL,
	FloatValue float NULL,
	TextValue varchar(max) NULL,
	DateTimeValue datetime2(7) NULL,
	Description varchar(max) NULL,
	isFloatValue bit not null default 0,
	isTextValue bit not null default 0,
	isDateTimeValue bit not null default 0,
	Machine varchar(255) NULL,
	PropertyKey1 varchar(255) NULL,
	PropertyKey2 varchar(255) NULL,
	PlantId varchar(255) NULL,
	UTCCreationTime datetime2(7) NOT NULL default GETUTCDATE(),
	PRIMARY KEY CLUSTERED (Id ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	
GO

PRINT ('alter table smartKPISAPPMKeyValueData ADD CreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData'
		and lower(COLUMN_NAME) = lower('CreationTime'))
	alter table smartKPISAPPMKeyValueData ADD CreationTime datetime2 not null default GETDATE();
GO
PRINT ('alter table smartKPISAPPMKeyValueData ADD isFloatValue');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData'
		and lower(COLUMN_NAME) = lower('isFloatValue'))
	alter table smartKPISAPPMKeyValueData ADD isFloatValue bit not null default 0;
GO
PRINT ('alter table smartKPISAPPMKeyValueData ADD isTextValue');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData'
		and lower(COLUMN_NAME) = lower('isTextValue'))
	alter table smartKPISAPPMKeyValueData ADD isTextValue bit not null default 0;
GO

PRINT ('alter table smartKPISAPPMKeyValueData ADD isDateTimeValue');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData'
		and lower(COLUMN_NAME) = lower('isDateTimeValue'))
	alter table smartKPISAPPMKeyValueData ADD isDateTimeValue bit not null default 0;
GO
PRINT ('alter table smartKPISAPPMKeyValueData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPISAPPMKeyValueData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPISAPPMKeyValueData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPISAPPMKeyValueData ADD modification_id bigint;
GO
PRINT ('alter table smartKPISAPPMKeyValueData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPISAPPMKeyValueData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPISAPPMKeyValueData ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPISAPPMKeyValueData_modification_trigger'))
exec('CREATE TRIGGER [smartKPISAPPMKeyValueData_modification_trigger] ON [smartKPISAPPMKeyValueData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPISAPPMKeyValueData_modification_trigger] ON [smartKPISAPPMKeyValueData] AFTER UPDATE, INSERT
AS
	update [smartKPISAPPMKeyValueData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPISAPPMKeyValueData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPISAPPMKeyValueData_modification_trigger_delete] ON [smartKPISAPPMKeyValueData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPISAPPMKeyValueData_modification_trigger_delete] ON [smartKPISAPPMKeyValueData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPISAPPMKeyValueData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPISAPPMKeyValueData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************
