print ('CREATE TABLE TEMP_SmartKPICVSProductionTargetDetail');

	IF NOT EXISTS (SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTargetDetail')
	CREATE TABLE TEMP_SmartKPICVSProductionTargetDetail
		(
			LineThingName varchar(255),
			StartTime datetime2,
			EndTime datetime2,
			ProductionTime datetime2, 
			counter int, 
			OrderNumber varchar(255), 
			SinglePartTargetCount INT, 
			WorkingTimeInMinutes float,
			TimeToProducePartsInMinutes float, 
			TimeForProducedParts float, 
			ProcessingTime float,
			SetupTime float,
			CreationTime DateTime2 not null default CURRENT_TIMESTAMP
			CONSTRAINT AK_SmartKPICVSProductionTargetDetailUniqueConstraintDefinition 
			UNIQUE(LineThingName, StartTime, EndTime, counter)
		);

	PRINT ('alter table TEMP_SmartKPICVSProductionTargetDetail ADD UTCCreationTime');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTargetDetail'
			and lower(COLUMN_NAME) = lower('UTCCreationTime'))
		alter table TEMP_SmartKPICVSProductionTargetDetail ADD UTCCreationTime datetime2 not null default GETUTCDATE();
	GO

	PRINT ('alter table TEMP_SmartKPICVSProductionTargetDetail ADD ShiftFactorInPercent');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTargetDetail'
			and lower(COLUMN_NAME) = lower('ShiftFactorInPercent'))
		alter table TEMP_SmartKPICVSProductionTargetDetail ADD ShiftFactorInPercent float not null default 0;
	GO

	PRINT ('alter table TEMP_SmartKPICVSProductionTargetDetail ADD FullCyclePartsProduced');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTargetDetail'
			and lower(COLUMN_NAME) = lower('FullCyclePartsProduced'))
		alter table TEMP_SmartKPICVSProductionTargetDetail ADD FullCyclePartsProduced int not null default 0;
	GO

	PRINT ('alter table TEMP_SmartKPICVSProductionTargetDetail ADD SumPlannedNumberOfWorkers');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTargetDetail'
			and lower(COLUMN_NAME) = lower('SumPlannedNumberOfWorkers'))
		alter table TEMP_SmartKPICVSProductionTargetDetail ADD SumPlannedNumberOfWorkers float not null default 0;
	GO

	PRINT ('alter table TEMP_SmartKPICVSProductionTargetDetail ADD ProcessNumber');
		IF NOT EXISTS
		(SELECT COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_NAME = 'TEMP_SmartKPICVSProductionTargetDetail'
			and lower(COLUMN_NAME) = lower('ProcessNumber'))
		alter table TEMP_SmartKPICVSProductionTargetDetail ADD ProcessNumber float not null default 1;
	GO
	
	PRINT ('Change table TEMP_SmartKPICVSProductionTargetDetail type of SumPlannedNumberOfWorkers');
	DECLARE @SumPlannedNumberOfWorkersCheck as varchar(20);
	DECLARE @tableTempName NVARCHAR(128) = 'TEMP_SmartKPICVSProductionTargetDetail';
	DECLARE @columnTempName NVARCHAR(128) = 'SumPlannedNumberOfWorkers';
	SELECT @SumPlannedNumberOfWorkersCheck=DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @tableTempName and COLUMN_NAME=@columnTempName

	  IF(@SumPlannedNumberOfWorkersCheck='int') 
		BEGIN
			DECLARE @ConstraintName  NVARCHAR(128);
			SET @ConstraintName=(select top 1 dc.name FROM sys.default_constraints dc
			INNER JOIN sys.columns col ON dc.parent_object_id = col.object_id AND dc.parent_column_id = col.column_id
			WHERE dc.type_desc='DEFAULT_CONSTRAINT' and 
			OBJECT_NAME(dc.parent_object_id) = @tableTempName AND col.name = @columnTempName
			)
			
			DECLARE @sql NVARCHAR(MAX);
			SET @sql = N'ALTER TABLE ' + QUOTENAME(@tableTempName) + N' DROP CONSTRAINT ' + QUOTENAME(@ConstraintName);
			EXEC sp_executesql @sql;
			
			ALTER TABLE TEMP_SmartKPICVSProductionTargetDetail ALTER COLUMN SumPlannedNumberOfWorkers float
			ALTER TABLE TEMP_SmartKPICVSProductionTargetDetail ADD  DEFAULT ((0)) FOR SumPlannedNumberOfWorkers
		END
	GO
