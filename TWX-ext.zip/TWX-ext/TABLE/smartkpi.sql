--************************************************************************************************************
--************************************************************************************************************
-- Table smartkpi
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPI');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI')
	create table smartKPI 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		ProductionTime DateTime2 not null,
		isPartOK Bit not null,
		PartNumber varchar(255),
		SerialNumber varchar(255)
		CONSTRAINT AK_ShortName_smartKpiUniqueConstraintDefinition 
		UNIQUE(Machine, ProductionTime));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPI ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPI ADD modification_id bigint;
GO
PRINT ('alter table smartKPI ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPI ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPI_modification_trigger'))
exec('CREATE TRIGGER [smartKPI_modification_trigger] ON [smartKPI] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPI_modification_trigger] ON [smartKPI] AFTER UPDATE, INSERT
AS
	update [smartKPI] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPI_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPI_modification_trigger_delete] ON [smartKPI] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPI_modification_trigger_delete] ON [smartKPI] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPI', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPI set move_to_history = move_to_history where modification_id is null;

--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table smartKPI ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPI ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO


		
PRINT ('alter table smartKPI ADD confirmToSAP');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('confirmToSAP'))
	alter table smartKPI ADD confirmToSAP bit not null default 0;
GO
		
PRINT ('alter table smartKPI ADD confirmedToSAP');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('confirmedToSAP'))
	alter table smartKPI ADD confirmedToSAP bit not null default 0;
GO
  
  
PRINT ('alter table smartKPI ADD SAPconfirmationResult');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('SAPconfirmationResult'))
	alter table smartKPI ADD SAPconfirmationResult varchar(255);
GO
  
PRINT ('alter table smartKPI ALTER COLUMN [SAPconfirmationResult]');

	alter table smartKPI ALTER COLUMN [SAPconfirmationResult] varchar(max);
GO
  
PRINT ('alter table smartKPI ADD SAPOperationNumber');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('SAPOperationNumber'))
	alter table smartKPI ADD SAPOperationNumber varchar(255);
GO
  
PRINT ('alter table smartKPI ADD OrderNumber');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('OrderNumber'))
	alter table smartKPI ADD OrderNumber varchar(255);
GO

PRINT ('alter table smartKPI ADD timePerPartSec');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('timePerPartSec'))
	alter table smartKPI ADD timePerPartSec float;
GO
  
PRINT ('alter table smartKPI ADD ScrapReason');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('ScrapReason'))
	alter table smartKPI ADD ScrapReason varchar(255);
GO
  
PRINT ('alter table smartKPI ADD isUpdated');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('isUpdated'))
	alter table smartKPI ADD isUpdated Bit not null default 1;
GO
  
PRINT ('alter table smartKPI ADD numberOfParts');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('numberOfParts'))
	alter table smartKPI ADD numberOfParts integer not null default 1;
GO
  
PRINT ('alter table smartKPI ADD Station');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('Station'))
	alter table smartKPI ADD Station varchar(255) not null default 'Unknown';
GO

PRINT ('alter table smartKPI ADD JSON');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPI'
		and lower(COLUMN_NAME) = lower('JSON'))
	alter table smartKPI ADD JSON varchar(max) not null default '{"dataShape":{"fieldDefinitions":{}},"rows":[]}';
GO

  
  
PRINT ('alter table smartKPI DROP CONSTRAINT');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_smartKpiUniqueConstraintDefinition')
	alter table smartKPI DROP CONSTRAINT AK_ShortName_smartKpiUniqueConstraintDefinition; 
GO

PRINT ('alter table smartKPI ADD CONSTRAINT');
	if not exists (SELECT object_id  FROM sys.objects  WHERE name='AK_ShortName_smartKpiUniqueConstraintDefinition1' union SELECT object_id  FROM sys.indexes  WHERE name='AK_ShortName_smartKpiUniqueConstraintDefinition1')
	ALTER TABLE smartKPI   
	ADD CONSTRAINT AK_ShortName_smartKpiUniqueConstraintDefinition1 
	UNIQUE (Machine, Station, ProductionTime);   
GO

