--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProductiveStateDefinition
--************************************************************************************************************
--************************************************************************************************************
  
PRINT ('create table smartKPIProductiveStateDefinition');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProductiveStateDefinition')
	create table smartKPIProductiveStateDefinition (
		Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		Station varchar(255)  not null,
		StatusName varchar(255)  not null,
		StatusComparer  varchar(255)  not null,
		StatusValue varchar(255)  not null);
GO

PRINT ('alter table smartKPIProductiveStateDefinition ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProductiveStateDefinition'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIProductiveStateDefinition ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

update [smartKPIMachineStatusData]
  set Status = 'KBMaschStatus.1.OI.AutoSet', SubStatus = 'KBMaschStatus.2.OI.AutoSet.Start'
  where (isnull(Status,'') = '' or isnull(SubStatus,'') = '')
  and StatusType = 'Operator Screen';

