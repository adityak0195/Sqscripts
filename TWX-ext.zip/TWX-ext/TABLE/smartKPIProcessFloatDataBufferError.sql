--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessFloatDataBufferError
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIProcessFloatDataBufferError');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatDataBufferError')
	create table smartKPIProcessFloatDataBufferError (
		Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		JSON varchar(max),
		Type varchar(255)  not null,
		Reason varchar(255));
GO

PRINT ('alter table smartKPIProcessFloatDataBufferError ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatDataBufferError'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIProcessFloatDataBufferError ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
