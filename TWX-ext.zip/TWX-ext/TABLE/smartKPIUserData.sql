--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIUserData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIUserData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserData')
	create table smartKPIUserData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		UpdateTime DateTime2 not null default CURRENT_TIMESTAMP,
		UserId varchar(255),
		isUserActive bit not null default 1
		CONSTRAINT AK_smartKPIUserDataUniqueConstraintDefinition 
		UNIQUE(UserId));
GO

PRINT ('alter table smartKPIUserData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIUserData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO
PRINT ('alter table smartKPIUserData ADD UTCUpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserData'
		and lower(COLUMN_NAME) = lower('UTCUpdateTime'))
	alter table smartKPIUserData ADD UTCUpdateTime datetime2 not null default GETUTCDATE();
GO
		
PRINT ('alter table smartKPIUserData ADD System');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserData'
		and lower(COLUMN_NAME) = lower('System'))
	alter table smartKPIUserData ADD System varchar(255) not null;
GO

PRINT ('alter table smartKPIUserData drop CONSTRAINT AK_smartKPIUserDataUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_smartKPIUserDataUniqueConstraintDefinition')
	alter table smartKPIUserData drop CONSTRAINT AK_smartKPIUserDataUniqueConstraintDefinition;
GO
  
PRINT ('alter table smartKPIUserData ADD CONSTRAINT');
	if not exists (SELECT object_id  FROM sys.objects  WHERE name='AK_smartKPIUserDataUniqueConstraintDefinition1' union SELECT object_id  FROM sys.indexes  WHERE name='AK_smartKPIUserDataUniqueConstraintDefinition1')
	ALTER TABLE smartKPIUserData   
	ADD CONSTRAINT AK_smartKPIUserDataUniqueConstraintDefinition1 
	UNIQUE (UserId, System);   
GO

PRINT ('alter table smartKPIUserData ADD isProductionStarted');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserData'
		and lower(COLUMN_NAME) = lower('isCAPSDataUpdated'))
	alter table smartKPIUserData ADD isCAPSDataUpdated bit not null default 1;
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIUserData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIUserData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIUserData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIUserData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIUserData ADD move_to_history bit not null default 0;
GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIUserData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIUserData_modification_trigger] ON [smartKPIUserData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIUserData_modification_trigger] ON [smartKPIUserData] AFTER UPDATE, INSERT
AS
	update [smartKPIUserData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIUserData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIUserData_modification_trigger_delete] ON [smartKPIUserData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIUserData_modification_trigger_delete] ON [smartKPIUserData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIUserData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIUserData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************

