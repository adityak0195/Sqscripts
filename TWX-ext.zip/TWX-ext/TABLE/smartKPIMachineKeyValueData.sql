--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineKeyValueData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIMachineKeyValueData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData')
	create table smartKPIMachineKeyValueData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		PropertyKey varchar(255)  not null,
		FloatValue float  null,
		TextValue varchar(255)  null,
		DateTimeValue DateTime2  null,
		isFloatValue bit not null default 0,
		isTextValue bit not null default 0,
		isDateTimeValue bit not null default 0,
		Machine varchar(255)
		CONSTRAINT AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition 
		UNIQUE(Machine, PropertyKey));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIMachineKeyValueData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIMachineKeyValueData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIMachineKeyValueData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIMachineKeyValueData ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineKeyValueData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIMachineKeyValueData_modification_trigger] ON [smartKPIMachineKeyValueData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineKeyValueData_modification_trigger] ON [smartKPIMachineKeyValueData] AFTER UPDATE, INSERT
AS
	update [smartKPIMachineKeyValueData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIMachineKeyValueData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIMachineKeyValueData_modification_trigger_delete] ON [smartKPIMachineKeyValueData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIMachineKeyValueData_modification_trigger_delete] ON [smartKPIMachineKeyValueData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIMachineKeyValueData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIMachineKeyValueData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************

PRINT ('alter table smartKPIMachineKeyValueData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIMachineKeyValueData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIMachineKeyValueData ADD UpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData'
		and lower(COLUMN_NAME) = lower('UpdateTime'))
	alter table smartKPIMachineKeyValueData ADD UpdateTime DateTime2 not null default CURRENT_TIMESTAMP;
GO

PRINT ('alter table smartKPIMachineKeyValueData ADD UTCUpdateTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData'
		and lower(COLUMN_NAME) = lower('UTCUpdateTime'))
	alter table smartKPIMachineKeyValueData ADD UTCUpdateTime datetime2 not null default GETUTCDATE();
GO
  
PRINT ('alter table smartKPIMachineKeyValueData ADD PropertySubKey1');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData'
		and lower(COLUMN_NAME) = lower('PropertySubKey1'))
	alter table smartKPIMachineKeyValueData ADD PropertySubKey1 varchar(150)  null;
GO
  
PRINT ('alter table smartKPIMachineKeyValueData ADD PropertySubKey2');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIMachineKeyValueData'
		and lower(COLUMN_NAME) = lower('PropertySubKey2'))
	alter table smartKPIMachineKeyValueData ADD PropertySubKey2 varchar(150)  null;
GO
  
PRINT ('alter table smartKPIMachineKeyValueData drop CONSTRAINT AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition')
	alter table smartKPIMachineKeyValueData drop CONSTRAINT AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition;
GO

PRINT ('alter table smartKPIMachineKeyValueData ADD AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition1');
	if not exists (SELECT object_id  FROM sys.objects  WHERE name='AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition1' union SELECT object_id  FROM sys.indexes  WHERE name='AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition1')
	ALTER TABLE smartKPIMachineKeyValueData   
	ADD CONSTRAINT AK_smartKPIMachineKeyValueDataUniqueConstraintDefinition1 
	UNIQUE(Machine, PropertyKey, PropertySubKey1, PropertySubKey2);   
GO

PRINT ('alter table smartKPIMachineKeyValueData ALTER COLUMN [TextValue]');
	alter table smartKPIMachineKeyValueData ALTER COLUMN [TextValue] Nvarchar(max);
GO

PRINT ('insert into [smartKPIMachineKeyValueData]');
	insert into [smartKPIMachineKeyValueData] ([Machine], [PropertyKey], [TextValue], [isTextValue]) 
	  select 'DatabaseVersionFromDBScript', 'DatabaseVersionFromDBScript', '1.0', 1
	  where not exists (select 'ok' from [smartKPIMachineKeyValueData] where Machine = 'DatabaseVersionFromDBScript' and [PropertyKey] = 'DatabaseVersionFromDBScript');
GO

PRINT ('insert into [smartKPIMachineKeyValueData]');
	insert into [smartKPIMachineKeyValueData] ([Machine], [PropertyKey], [TextValue], [isTextValue]) 
	  select 'DatabaseVersionFromDBScript', 'FunctionVersionFromDBScript', '1.0', 1
	  where not exists (select 'ok' from [smartKPIMachineKeyValueData] where Machine = 'DatabaseVersionFromDBScript' and [PropertyKey] = 'FunctionVersionFromDBScript');
GO

