--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessFloatData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create table smartKPIProcessFloatData');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData')
	create table smartKPIProcessFloatData 
		(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
		CreationTime DateTime2 not null default CURRENT_TIMESTAMP,
		Machine varchar(255)  not null,
		ProductionTime DateTime2 not null,
		ProcesDataType varchar(255)  not null,
		ProcesData float,
		SerialNumber varchar(255),
		PartNumber varchar(255),
		OrderNumber varchar(255)
		CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition 
		UNIQUE(Machine, ProductionTime, ProcesDataType));
GO

--*************************************************For Archiving, do not change***********************************************************
PRINT ('alter table smartKPIProcessFloatData ADD modification_id');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('modification_id'))
	alter table smartKPIProcessFloatData ADD modification_id bigint;
GO
PRINT ('alter table smartKPIProcessFloatData ADD move_to_history');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('move_to_history'))
	alter table smartKPIProcessFloatData ADD move_to_history bit not null default 0;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIProcessFloatData_modification_trigger'))
exec('CREATE TRIGGER [smartKPIProcessFloatData_modification_trigger] ON [smartKPIProcessFloatData] AFTER UPDATE, INSERT  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIProcessFloatData_modification_trigger] ON [smartKPIProcessFloatData] AFTER UPDATE, INSERT
AS
	update [smartKPIProcessFloatData] set modification_id = next value for modification_sequence
	where [Id] in (select Id from Inserted where isnull(modification_id,0) != -1);

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'smartKPIProcessFloatData_modification_trigger_delete'))
exec('CREATE TRIGGER [smartKPIProcessFloatData_modification_trigger_delete] ON [smartKPIProcessFloatData] FOR DELETE  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER  TRIGGER [smartKPIProcessFloatData_modification_trigger_delete] ON [smartKPIProcessFloatData] FOR DELETE
AS
		insert into SYSTEM_deletedEntries (TableName, DeletedId, modification_id, identifier)
		select 'smartKPIProcessFloatData', Id, next value for modification_sequence, CASE move_to_history WHEN 0 THEN 'DELETED' ELSE 'moved_to_history' END from Deleted where modification_id != -1;
GO

--update top(25000) smartKPIProcessFloatData set move_to_history = move_to_history where modification_id is null;
--*************************************************For Archiving, do not change***********************************************************


PRINT ('alter table smartKPIProcessFloatData ADD UTCCreationTime');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('UTCCreationTime'))
	alter table smartKPIProcessFloatData ADD UTCCreationTime datetime2 not null default GETUTCDATE();
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataLSL');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataLSL'))
	alter table smartKPIProcessFloatData ADD ProcesDataLSL float;
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataUSL');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataUSL'))
	alter table smartKPIProcessFloatData ADD ProcesDataUSL float;
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD isUpdated');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('isUpdated'))
	alter table smartKPIProcessFloatData ADD isUpdated Bit not null default 0;
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD Unit');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('Unit'))
	alter table smartKPIProcessFloatData ADD Unit varchar(255);
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD description');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('description'))
	alter table smartKPIProcessFloatData ADD description varchar(255);
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD comment');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('comment'))
	alter table smartKPIProcessFloatData ADD comment varchar(255);
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD TrackingNumber');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('TrackingNumber'))
	alter table smartKPIProcessFloatData ADD TrackingNumber varchar(255);
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataType2');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataType2'))
	alter table smartKPIProcessFloatData ADD ProcesDataType2 varchar(255);
GO
  
PRINT ('alter table smartKPIProcessFloatData ADD PartNumberRevision');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('PartNumberRevision'))
	alter table smartKPIProcessFloatData ADD PartNumberRevision varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD Identifier');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('Identifier'))
	alter table smartKPIProcessFloatData ADD Identifier varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataPrecision');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataPrecision'))
	alter table smartKPIProcessFloatData ADD ProcesDataPrecision varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataTargetValueName');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataTargetValueName'))
	alter table smartKPIProcessFloatData ADD ProcesDataTargetValueName varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataTargetValue');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataTargetValue'))
	alter table smartKPIProcessFloatData ADD ProcesDataTargetValue float;
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataLowerLimitName');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataLowerLimitName'))
	alter table smartKPIProcessFloatData ADD ProcesDataLowerLimitName varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataUpperLimitName');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataUpperLimitName'))
	alter table smartKPIProcessFloatData ADD ProcesDataUpperLimitName varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataTolerancePos');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataTolerancePos'))
	alter table smartKPIProcessFloatData ADD ProcesDataTolerancePos varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataTolerancePosFloat');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataTolerancePosFloat'))
	alter table smartKPIProcessFloatData ADD ProcesDataTolerancePosFloat float;
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataToleranceNeg');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataToleranceNeg'))
	alter table smartKPIProcessFloatData ADD ProcesDataToleranceNeg varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcesDataToleranceNegFloat');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcesDataToleranceNegFloat'))
	alter table smartKPIProcessFloatData ADD ProcesDataToleranceNegFloat float;
GO

PRINT ('alter table smartKPIProcessFloatData ADD ProcessDataTargetValueTolUnit');
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'smartKPIProcessFloatData'
		and lower(COLUMN_NAME) = lower('ProcessDataTargetValueTolUnit'))
	alter table smartKPIProcessFloatData ADD ProcessDataTargetValueTolUnit varchar(255);
GO

PRINT ('alter table smartKPIProcessFloatData drop CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition')
	alter table smartKPIProcessFloatData drop CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition;
GO

PRINT ('alter table smartKPIProcessFloatData drop CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition1');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition1')
	alter table smartKPIProcessFloatData drop CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition1;
GO


PRINT ('alter table smartKPIProcessFloatData drop CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition2');
	if exists (SELECT *  FROM sys.objects  WHERE name='AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition2')
	alter table smartKPIProcessFloatData drop CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition2;
GO

PRINT ('alter table smartKPIProcessFloatData ADD AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition3');
	if not exists (SELECT object_id  FROM sys.objects  WHERE name='AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition3' union SELECT object_id  FROM sys.indexes  WHERE name='AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition3')
	ALTER TABLE smartKPIProcessFloatData   
	ADD CONSTRAINT AK_ShortName_smartKPIProcessFloatDataUniqueConstraintDefinition3 
	UNIQUE([Machine] ASC,
		[ProductionTime] ASC,
		[ProcesDataType] ASC,
		[ProcesDataType2] ASC,
		[TrackingNumber] ASC,
		[Identifier] ASC);   
GO

	
--	delete duplicates:
--	  select * from
--	  (select max(Id) as Id, Machine, ProductionTime, ProcesDataType, count(*) as anz 
--	  FROM smartKPIProcessFloatData
--	  group by Machine, ProductionTime, ProcesDataType) x
--	  where x.anz > 1
--
--
--	declare @counter int = 0;
--	while (@counter<xxxx)
--	BEGIN
--
--	delete from smartKPIProcessFloatData where Id in
--	(select x.Id from
--	  (select max(Id) as Id, Machine, ProductionTime, ProcesDataType, count(*) as anz 
--	  FROM smartKPIProcessFloatData
--	  group by Machine, ProductionTime, ProcesDataType) x
--	  where x.anz > 1)	;
--
--	SET @counter = @counter + 1;
--	END;

