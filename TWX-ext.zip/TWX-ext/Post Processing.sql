--------------------------------------------------------------
--------------------------------------------------------------
print 'Some updates...';
--------------------------------------------------------------
--------------------------------------------------------------
update [smartKPIValues] set KPIName =  'CVS: Sum tgmax times for IO parts in seconds' where KPIName = 'sumTgmaxIOInSec';
update [smartKPIValues] set KPIName =  'CVS: Sum tgmax times for NIO parts in seconds' where KPIName = 'sumTgmaxNIOInSec';
update [smartKPIValues] set KPIName =  'CVS: Planned working time in seconds (from start to end of shift)' where KPIName = 'PlannedWorkingTimeInSec';
update [smartKPIValues] set KPIName =  'CVS: Time base for utilization in seconds' where KPIName = 'TimeBaseUtilizationInSec';
update [smartKPIValues] set KPIName =  'CVS DLP1: Calculated Production Target till now' where KPIName = 'ProductionTargetNow';
update [smartKPIValues] set KPIName =  'CVS DLP1: Calculated Production Target' where KPIName = 'Dlp1ProductionTarget';
update [smartKPIValues] set KPIName =  'CVS DLP1: Time in seconds within shift(s)' where KPIName = 'TimebaseForDLP1InSec';
update [smartKPIValues] set KPIName =  'CVS DLP1: Time in seconds passed till now and within shift(s)' where KPIName = 'DLP1TimeNow';
update [smartKPIValues] set KPIName =  'CVS: Planned number of workers from SAP' where KPIName = 'PlannedNumberOfWorkersPerPart';
update [smartKPIValues] set KPIName =  'CVS: Actual number of workers at Line' where KPIName = 'ActualNumberOfWorkersPerPart';
update [smartKPIValues] set KPIName =  'CVS DLP1: Actual' where KPIName = 'CVSDlp1Actual';
update [smartKPIValues] set KPIName =  'CVS DLP1: Calculated Target' where KPIName = 'CVSDlp1Target';
update [smartKPIValues] set KPIName =  'CVS DLP1: Ratio (Actual/Calculated Target)' where KPIName = 'CVSDlp1';
update [smartKPIValues] set KPIName =  'CVS DLP3: Ratio (Customer paid hours/KB paid hours)' where KPIName = 'CVSDlp3';
update [smartKPIValues] set KPIName =  'CVS DLP3: KB paid hours' where KPIName = 'CVSDlp3KBPaidHours';
update [smartKPIValues] set KPIName =  'CVS DLP3: Customer paid hours' where KPIName = 'CVSDlp3CustomerPaidHours';
update [smartKPIValues] set KPIName =  'CVS: Sum of processing times (CO) in seconds' where KPIName = 'ProcessingTimeInSecCO';
update [smartKPIValues] set KPIName =  'CVS: Sum of login times at line' where KPIName = 'CVSLoginTimeAtLine';
update [smartKPIValues] set KPIName =  'CVS: OEE (Version 2)' where KPIName = 'OEE2Truck';
update [smartKPIValues] set KPIName =  'CVS: APO shift factor in percent' where KPIName = 'ShiftFactorInPercent';
update [smartKPIValues] set KPIName =  'CVS: Utilization' where KPIName = 'UtilizationTruck';
update [smartKPIValues] set KPIName =  'CVS: Retests' where KPIName = 'Retest';
delete from [smartKPIValues] where KPIName like 'CVS: OEE2 planned working time%'

--------------------------------------------------------------
--------------------------------------------------------------
print 'DeleteDoubleShiftCalendarEntries...';
--------------------------------------------------------------
--------------------------------------------------------------
exec DeleteDoubleShiftCalendarEntries;
