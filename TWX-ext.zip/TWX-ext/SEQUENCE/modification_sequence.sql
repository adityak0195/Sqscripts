--************************************************************************************************************
--************************************************************************************************************
print '-- Sequence modification_sequence';
--************************************************************************************************************
--************************************************************************************************************

IF NOT EXISTS
	(select SEQUENCE_NAME from INFORMATION_SCHEMA.SEQUENCES where SEQUENCE_NAME = 'modification_sequence')
	create sequence modification_sequence as bigint start with 1 increment by 1 minvalue 1 no maxvalue no cycle no cache;
go