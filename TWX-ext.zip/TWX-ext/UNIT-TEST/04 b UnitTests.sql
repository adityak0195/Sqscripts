

--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--
-- Test run
--
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************



print '--Doing some Testings:';


DECLARE @testresultInt int;
DECLARE @testresultDateTime datetime2;
DECLARE @testresultVarchar varchar(max);



--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      Only one data row given back from GetFullShiftFunction ('TESTMACHINE', '2020-01-01 00:00:00')
--**************************************************
select @testresultInt=count(*) from GetFullShiftFunction ('TESTMACHINE', '2020-01-01 00:00:00');
exec AssertEqualInt @value = @testresultInt, @targetvalue = 1, @messagetext = 'Only one data row given back from GetFullShiftFunction (''TESTMACHINE'', ''2020-01-01 00:00:00'')';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      GetFullShiftFunction ('TESTMACHINE', '2020-01-01 00:00:00') should return '2020-01-01 00:00:00'
--**************************************************
select top 1 @testresultDateTime=CurrentStartTime from GetFullShiftFunction ('TESTMACHINE', '2020-01-01 00:00:00');
exec AssertEqualDateTime @value = @testresultDateTime, @targetvalue = '2020-01-01 00:00:00', @messagetext = 'GetFullShiftFunction (''TESTMACHINE'', ''2020-01-01 00:00:00'') should return ''2020-01-01 00:00:00''';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      Only one data row given back from GetFullShiftFunction ('TESTMACHINE', '2020-01-01 01:00:00')
--**************************************************
select @testresultInt=count(*) from GetFullShiftFunction ('TESTMACHINE', '2020-01-01 01:00:00');
exec AssertEqualInt @value = @testresultInt, @targetvalue = 1, @messagetext = 'Only one data row given back from GetFullShiftFunction (''TESTMACHINE'', ''2020-01-01 01:00:00'')';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      GetFullShiftFunction ('TESTMACHINE', '2020-01-01 01:00:00') should return '2020-01-02 00:00:00'
--**************************************************
select top 1 @testresultDateTime=CurrentStartTime from GetFullShiftFunction ('TESTMACHINE', '2020-01-01 01:00:00');
exec AssertEqualDateTime @value = @testresultDateTime, @targetvalue = '2020-01-02 00:00:00', @messagetext = 'GetFullShiftFunction (''TESTMACHINE'', ''2020-01-01 01:00:00'') should return ''2020-01-02 00:00:00''';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      Only one data row given back from GetFullShiftFunction ('TESTMACHINE', '2020-01-02 00:00:00')
--**************************************************
select @testresultInt=count(*) from GetFullShiftFunction ('TESTMACHINE', '2020-01-02 00:00:00');
exec AssertEqualInt @value = @testresultInt, @targetvalue = 1, @messagetext = 'Only one data row given back from GetFullShiftFunction (''TESTMACHINE'', ''2020-01-02 00:00:00'')';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      GetFullShiftFunction ('TESTMACHINE', '2020-01-02 00:00:00') should return '2020-01-02 00:00:00'
--**************************************************
select top 1 @testresultDateTime=CurrentStartTime from GetFullShiftFunction ('TESTMACHINE', '2020-01-02 00:00:00');
exec AssertEqualDateTime @value = @testresultDateTime, @targetvalue = '2020-01-02 00:00:00', @messagetext = 'GetFullShiftFunction (''TESTMACHINE'', ''2020-01-02 00:00:00'') should return ''2020-01-02 00:00:00''';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      Only one data row given back from GetFullShiftFunction ('TESTMACHINE', '2020-01-02 12:00:00')
--**************************************************
select @testresultInt=count(*) from GetFullShiftFunction ('TESTMACHINE', '2020-01-02 12:00:00');
exec AssertEqualInt @value = @testresultInt, @targetvalue = 1, @messagetext = 'Only one data row given back from GetFullShiftFunction (''TESTMACHINE'', ''2020-01-02 12:00:00'')';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetFullShiftFunction
-- Description:      GetFullShiftFunction ('TESTMACHINE', '2020-01-02 12:00:00') should return '2020-01-02 00:00:00'
--**************************************************
select top 1 @testresultDateTime=CurrentStartTime from GetFullShiftFunction ('TESTMACHINE', '2020-01-02 12:00:00');
exec AssertEqualDateTime @value = @testresultDateTime, @targetvalue = '2020-01-02 00:00:00', @messagetext = 'GetFullShiftFunction (''TESTMACHINE'', ''2020-01-02 12:00:00'') should return ''2020-01-02 00:00:00''';





--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   TEMP_SmartKPIFullShift
-- Description:      No data row given back from TEMP_SmartKPIFullShift where '2020-01-01 10:00:00' between CurrentStartTime and CurrentEndTime and Machine = 'TESTMACHINE'
-- Temporarily disables https://knorr-bremse.atlassian.net/browse/TWX-3829
--**************************************************
--select @testresultInt=count(*) from TEMP_SmartKPIFullShift where '2020-01-01 10:00:00' between CurrentStartTime and CurrentEndTime and Machine = 'TESTMACHINE';
--exec AssertEqualInt @value = @testresultInt, @targetvalue = 0, @messagetext = 'No data row given back from TEMP_SmartKPIFullShift where ''2020-01-01 10:00:00'' between CurrentStartTime and CurrentEndTime and Machine = ''TESTMACHINE''';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   TEMP_SmartKPIFullShift
-- Description:      CurrentEndTime from TEMP_SmartKPIFullShift where '2020-01-01 10:00:00' between CurrentStartTime and CurrentEndTime and Machine = 'TESTMACHINE' should be '2020-01-01 12:00:00'
-- Temporarily disables https://knorr-bremse.atlassian.net/browse/TWX-3829
--**************************************************
--select top 1 @testresultDateTime=CurrentEndTime from TEMP_SmartKPIFullShift where '2020-01-01 10:00:00' between CurrentStartTime and CurrentEndTime and Machine = 'TESTMACHINE';
--exec AssertEqualDateTime @value = @testresultDateTime, @targetvalue = '2020-01-01 12:00:00', @messagetext = 'CurrentEndTime from TEMP_SmartKPIFullShift where ''2020-01-01 10:00:00'' between CurrentStartTime and CurrentEndTime and Machine = ''TESTMACHINE'' should be ''2020-01-01 12:00:00''';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   TEMP_SmartKPIFullShift
-- Description:      CurrentStartTime from TEMP_SmartKPIFullShift where '2020-01-01 10:00:00' between CurrentStartTime and CurrentEndTime and Machine = 'TESTMACHINE' should be '2020-01-01 00:00:00'
-- Temporarily disables https://knorr-bremse.atlassian.net/browse/TWX-3829
--**************************************************
--select top 1 @testresultDateTime=CurrentStartTime from TEMP_SmartKPIFullShift where '2020-01-01 10:00:00' between CurrentStartTime and CurrentEndTime and Machine = 'TESTMACHINE';
--exec AssertEqualDateTime @value = @testresultDateTime, @targetvalue = '2020-01-01 00:00:00', @messagetext = 'CurrentStartTime from TEMP_SmartKPIFullShift where ''2020-01-01 10:00:00'' between CurrentStartTime and CurrentEndTime and Machine = ''TESTMACHINE'' should be ''2020-01-01 00:00:00''';


--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER');
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where OperationNumber = '0010'
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where OperationNumber = '0010';
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where OperationNumber = ''0010''';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where SetupTime = 1 and SetupTimeUnit = 'MIN' and SetupTimeInSec = 60
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where SetupTime = 1 and SetupTimeUnit = 'MIN' and SetupTimeInSec = 60;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where SetupTime = 1 and SetupTimeUnit = ''MIN'' and SetupTimeInSec = 60';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where SetupTimeAPO = 2 and SetupTimeUnitAPO = 'MIN' and SetupTimeInSecAPO = 120
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where SetupTimeAPO = 2 and SetupTimeUnitAPO = 'MIN' and SetupTimeInSecAPO = 120;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where SetupTimeAPO = 2 and SetupTimeUnitAPO = ''MIN'' and SetupTimeInSecAPO = 120';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where SetupTimeCO = 3 and SetupTimeUnitCO = 'MIN' and SetupTimeInSecCO = 180
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where SetupTimeCO = 3 and SetupTimeUnitCO = 'MIN' and SetupTimeInSecCO = 180;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where SetupTimeCO = 3 and SetupTimeUnitCO = ''MIN'' and SetupTimeInSecCO = 180';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where TeardownTime = 1 and TeardownTimeUnit = 'DAY' and TeardownTimeInSec = 86400
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where TeardownTime = 1 and TeardownTimeUnit = 'DAY' and TeardownTimeInSec = 86400;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where TeardownTime = 1 and TeardownTimeUnit = ''DAY'' and TeardownTimeInSec = 86400';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where tgMaxTime = 10 and tgMaxTimeUnit = 'SEC' and tgMaxTimeInSec = 10
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where tgMaxTime = 10 and tgMaxTimeUnit = 'SEC' and tgMaxTimeInSec = 10;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where tgMaxTime = 10 and tgMaxTimeUnit = ''SEC'' and tgMaxTimeInSec = 10';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where ProcessingTime = 4 and ProcessingTimeUnit = 'SEC' and ProcessingTimeInSec = 4
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where ProcessingTime = 4 and ProcessingTimeUnit = 'SEC' and ProcessingTimeInSec = 4;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where ProcessingTime = 4 and ProcessingTimeUnit = ''SEC'' and ProcessingTimeInSec = 4';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where ProcessingTimeCO = 5 and ProcessingTimeUnitCO = 'SEC' and ProcessingTimeInSecCO = 5
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where ProcessingTimeCO = 5 and ProcessingTimeUnitCO = 'SEC' and ProcessingTimeInSecCO = 5;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where ProcessingTimeCO = 5 and ProcessingTimeUnitCO = ''SEC'' and ProcessingTimeInSecCO = 5';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where ProcessingTimeAPO = 6 and ProcessingTimeUnitAPO = 'SEC' and ProcessingTimeInSecAPO = 6
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where ProcessingTimeAPO = 6 and ProcessingTimeUnitAPO = 'SEC' and ProcessingTimeInSecAPO = 6;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where ProcessingTimeAPO = 6 and ProcessingTimeUnitAPO = ''SEC'' and ProcessingTimeInSecAPO = 6';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPart
-- Description:      At least one data row given back from GetSAPTimePerPart('TESTORDER')  where PlannedNumberOfWorkers = 20
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPart('TESTORDER')  where PlannedNumberOfWorkers = 20;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPart(''TESTORDER'')  where PlannedNumberOfWorkers = 20';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE')
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE');
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'')';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where SetupTimeInSec = 60
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where SetupTimeInSec = 60;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where SetupTimeInSec = 60';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where SetupTimeInSecAPO = 120;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where SetupTimeInSecAPO = 120;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where SetupTimeInSecAPO = 120';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where SetupTimeInSecCO = 180;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where SetupTimeInSecCO = 180;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where SetupTimeInSecCO = 180';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where TeardownTimeInSec = 86400;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where TeardownTimeInSec = 86400;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where TeardownTimeInSec = 86400';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where tgMaxTimeInSec = 10;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where tgMaxTimeInSec = 10;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where tgMaxTimeInSec = 10';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where ProcessingTimeInSec = 4;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where ProcessingTimeInSec = 4;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where ProcessingTimeInSec = 4';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where ProcessingTimeInSecCO = 5;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where ProcessingTimeInSecCO = 5;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where ProcessingTimeInSecCO = 5';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where ProcessingTimeInSecAPO = 6;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where ProcessingTimeInSecAPO = 6;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where ProcessingTimeInSecAPO = 6';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetSAPTimePerPartPerMachine
-- Description:      At least one data row given back from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where PlannedNumberOfWorkersCO = 20;
--**************************************************
select @testresultInt=count(*) from GetSAPTimePerPartPerMachine('TESTORDER', 'TESTMACHINE') where PlannedNumberOfWorkersCO = 20;
exec AssertNotEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'At least one data row given back from GetSAPTimePerPartPerMachine(''TESTORDER'', ''TESTMACHINE'') where PlannedNumberOfWorkersCO = 20';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeCVSInSeconds
-- Description:      GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-01-01 00:00:00', '2019-01-02 00:00:00') = 82800
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-01-01 00:00:00', '2019-01-02 00:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 82800, @messagetext = 'GetWorkingTimeCVSInSeconds(''TESTMACHINE'', ''2019-01-01 00:00:00'', ''2019-01-02 00:00:00'') = 82800';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeCVSInSeconds
-- Description:      GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-02-01 00:00:00', '2019-02-02 00:00:00') = 39600
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-02-01 00:00:00', '2019-02-02 00:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 39600, @messagetext = 'GetWorkingTimeCVSInSeconds(''TESTMACHINE'', ''2019-02-01 00:00:00'', ''2019-02-02 00:00:00'') = 39600';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeCVSInSeconds
-- Description:      GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-03-01 00:00:00', '2019-03-02 00:00:00') = 36000
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-03-01 00:00:00', '2019-03-02 00:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 36000, @messagetext = 'GetWorkingTimeCVSInSeconds(''TESTMACHINE'', ''2019-03-01 00:00:00'', ''2019-03-02 00:00:00'') = 36000';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeCVSInSeconds
-- Description:      GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-04-01 00:00:00', '2019-04-02 00:00:00') = 34200
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds('TESTMACHINE', '2019-04-01 00:00:00', '2019-04-02 00:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 34200, @messagetext = 'GetWorkingTimeCVSInSeconds(''TESTMACHINE'', ''2019-04-01 00:00:00'', ''2019-04-02 00:00:00'') = 34200';

--**************************************************
-- Test provided by: Badma Balzhinimaev
-- What is tested:   GetWorkingTimeCVSInSeconds_V2
-- Description:      GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-09 12:00:00', '2024-09-09 13:00:00') = 3600
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-09 12:00:00', '2024-09-09 13:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 3600, @messagetext = 'GetWorkingTimeCVSInSeconds_V2(''TESTMACHINE99'', ''2024-09-09 12:00:00'', ''2024-09-09 13:00:00'') = 3600';

--**************************************************
-- Test provided by: Badma Balzhinimaev
-- What is tested:   GetWorkingTimeCVSInSeconds_V2
-- Description:      GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-09 22:00:00', '2024-09-09 23:00:00') = 3600
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-09 22:00:00', '2024-09-09 23:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 3600, @messagetext = 'GetWorkingTimeCVSInSeconds_V2(''TESTMACHINE99'', ''2024-09-09 22:00:00'', ''2024-09-09 23:00:00'') = 3600';

--**************************************************
-- Test provided by: Badma Balzhinimaev
-- What is tested:   GetWorkingTimeCVSInSeconds_V2
-- Description:      GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-26 07:00:00', '2024-09-26 08:00:00') = 0
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-26 07:00:00', '2024-09-26 08:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 0, @messagetext = 'GetWorkingTimeCVSInSeconds_V2(''TESTMACHINE99'', ''2024-09-26 07:00:00'', ''2024-09-26 08:00:00'') = 0';

--**************************************************
-- Test provided by: Badma Balzhinimaev
-- What is tested:   GetWorkingTimeCVSInSeconds_V2
-- Description:      GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-10 23:00:00', '2024-09-11 00:00:00') = 3600
--**************************************************
select @testresultInt=dbo.GetWorkingTimeCVSInSeconds_V2('TESTMACHINE99', '2024-09-10 23:00:00', '2024-09-11 00:00:00');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 3600, @messagetext = 'GetWorkingTimeCVSInSeconds_V2(''TESTMACHINE99'', ''2024-09-10 23:00:00'', ''2024-09-11 00:00:00'') = 3600';


--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSecondsV2
-- Description:      GetWorkingTimeRailInSecondsV2('2019-01-01 00:00:00', '2019-01-02 00:00:00', 'TESTMACHINE1') = 54000
--**************************************************
select @testresultInt=dbo.GetWorkingTimeRailInSecondsV2('2019-01-01 00:00:00', '2019-01-02 00:00:00', 'TESTMACHINE1');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 54000, @messagetext = 'GetWorkingTimeRailInSecondsV2(''2019-01-01 00:00:00'', ''2019-01-02 00:00:00'', ''TESTMACHINE1'') = 54000';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSecondsV2
-- Description:      GetWorkingTimeRailInSecondsV2('2019-02-01 00:00:00', '2019-02-02 00:00:00', 'TESTMACHINE1') = 10800
--**************************************************
select @testresultInt=dbo.GetWorkingTimeRailInSecondsV2('2019-02-01 00:00:00', '2019-02-02 00:00:00', 'TESTMACHINE1');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 10800, @messagetext = 'GetWorkingTimeRailInSecondsV2(''2019-02-01 00:00:00'', ''2019-02-02 00:00:00'', ''TESTMACHINE1'') = 10800';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSecondsV2
-- Description:      GetWorkingTimeRailInSecondsV2('2019-02-01 00:00:00', '2019-02-02 00:00:00', 'TESTMACHINE1') = 10800
--**************************************************
select @testresultInt=dbo.GetWorkingTimeRailInSecondsV2('2019-02-01 00:00:00', '2019-02-02 00:00:00', 'TESTMACHINE1');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 10800, @messagetext = 'GetWorkingTimeRailInSecondsV2(''2019-02-01 00:00:00'', ''2019-02-02 00:00:00'', ''TESTMACHINE1'') = 10800';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSecondsV2
-- Description:      GetWorkingTimeRailInSecondsV2('2019-03-01 00:00:00', '2019-03-02 00:00:00', 'TESTMACHINE1') = 7200
--**************************************************
select @testresultInt=dbo.GetWorkingTimeRailInSecondsV2('2019-03-01 00:00:00', '2019-03-02 00:00:00', 'TESTMACHINE1');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 7200, @messagetext = 'GetWorkingTimeRailInSecondsV2(''2019-03-01 00:00:00'', ''2019-03-02 00:00:00'', ''TESTMACHINE1'') = 7200';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSecondsV2
-- Description:      GetWorkingTimeRailInSecondsV2('2019-04-01 00:00:00', '2019-04-02 00:00:00', 'TESTMACHINE1') = 7200
--**************************************************
select @testresultInt=dbo.GetWorkingTimeRailInSecondsV2('2019-04-01 00:00:00', '2019-04-02 00:00:00', 'TESTMACHINE1');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 7200, @messagetext = 'GetWorkingTimeRailInSecondsV2(''2019-04-01 00:00:00'', ''2019-04-02 00:00:00'', ''TESTMACHINE1'') = 7200';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L0/%' or StatusType ='Unplanned' = 86400
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L0/%' or StatusType ='Unplanned';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 86400, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType like ''L0/%'' or StatusType =''Unplanned'' = 86400';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType = 'L0/KBMaschStatus.1.OI' = 9900
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType = 'L0/KBMaschStatus.1.OI';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 9900, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType = ''L0/KBMaschStatus.1.OI'' = 9900';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType = 'L0/KBMaschStatus.1.Pr' = 21600
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType = 'L0/KBMaschStatus.1.Pr';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 21600, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType = ''L0/KBMaschStatus.1.Pr'' = 21600';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType = 'L0/KBMaschStatus.1.TI' = 19800
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType = 'L0/KBMaschStatus.1.TI';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 19800, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType = ''L0/KBMaschStatus.1.TI'' = 19800';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.1.OI%' = 9900
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.1.OI%';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 9900, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType like ''L1/KBMaschStatus.1.OI%'' = 9900';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.1.Pr%' = 21600
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.1.Pr%';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 21600, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType like ''L1/KBMaschStatus.1.Pr%'' = 21600';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.1.TI%' = 19800
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.1.TI%';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 19800, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType like ''L1/KBMaschStatus.1.TI%'' = 19800';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.2.OI%' = 9900
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.2.OI%';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 9900, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType like ''L1/KBMaschStatus.2.OI%'' = 9900';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.2.Pr%' = 21600
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.2.Pr%';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 21600, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType like ''L1/KBMaschStatus.2.Pr%'' = 21600';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetDowntimeStatistic
-- Description:      sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.2.TI%' = 19800
--**************************************************
select @testresultInt=sum(TimeSumInSeconds) from GetDowntimeStatistic ('2019-04-01 00:00:00',	'2019-04-02 00:00:00',	'TESTMACHINE',	'TESTSTATION2') where StatusType like 'L1/KBMaschStatus.2.TI%';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 19800, @messagetext = 'sum(TimeSumInSeconds) from GetDowntimeStatistic (''2019-04-01 00:00:00'',	''2019-04-02 00:00:00'',	''TESTMACHINE'',	''TESTSTATION2'') where StatusType like ''L1/KBMaschStatus.2.TI%'' = 19800';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetCVSTimeLossRawDataAll
-- Description:      StatusLevel2 from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 11:00:00.0000000','2019-04-01 12:00:00.0000000', 'Operator Screen') = 'KBMaschStatus.2.OI.Break.479'
--**************************************************
select @testresultVarchar=StatusLevel2 from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 11:00:00.0000000','2019-04-01 12:00:00.0000000', 'Operator Screen');
exec AssertEqualString @value = @testresultVarchar, @targetvalue = 'KBMaschStatus.2.OI.Break.479', @messagetext = 'StatusLevel2 from GetCVSTimeLossRawDataAll (''TESTMACHINE'',''2019-04-01 11:00:00.0000000'',''2019-04-01 12:00:00.0000000'', ''Operator Screen'') = ''KBMaschStatus.2.OI.Break.479''';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetCVSTimeLossRawDataAll
-- Description:      Duration_in_min from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 11:00:00.0000000','2019-04-01 12:00:00.0000000', 'Operator Screen') = 60
--**************************************************
select @testresultInt=Duration_in_min from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 11:00:00.0000000','2019-04-01 12:00:00.0000000', 'Operator Screen');
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 60, @messagetext = 'Duration_in_min from GetCVSTimeLossRawDataAll (''TESTMACHINE'',''2019-04-01 11:00:00.0000000'',''2019-04-01 12:00:00.0000000'', ''Operator Screen'') = 60';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetCVSTimeLossRawDataAll
-- Description:      SUM(Duration_in_min) from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 00:00:00.0000000','2019-04-02 00:00:00.0000000', 'Operator Screen') where StatusLevel2='KBMaschStatus.2.Productive.Start' = 420
--**************************************************
select @testresultInt=SUM(Duration_in_min) from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 00:00:00.0000000','2019-04-02 00:00:00.0000000', 'Operator Screen') where StatusLevel2='KBMaschStatus.2.Productive.Start';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 420, @messagetext = 'SUM(Duration_in_min) from GetCVSTimeLossRawDataAll (''TESTMACHINE'',''2019-04-01 00:00:00.0000000'',''2019-04-02 00:00:00.0000000'', ''Operator Screen'' where StatusLevel2=''KBMaschStatus.2.Productive.Start'') = 420';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetCVSTimeLossRawDataAll
-- Description:      SUM(Duration_in_min) from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 00:00:00.0000000','2019-04-02 00:00:00.0000000', 'Operator Screen') where StatusLevel2='KBMaschStatus.1.TI.MachineBreakdown' = 240
--**************************************************
select @testresultInt=SUM(Duration_in_min) from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 00:00:00.0000000','2019-04-02 00:00:00.0000000', 'Operator Screen') where StatusLevel2='KBMaschStatus.1.TI.MachineBreakdown';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 240, @messagetext = 'SUM(Duration_in_min) from GetCVSTimeLossRawDataAll (''TESTMACHINE'',''2019-04-01 00:00:00.0000000'',''2019-04-02 00:00:00.0000000'', ''Operator Screen'' where StatusLevel2=''KBMaschStatus.1.TI.MachineBreakdown'') = 240';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetCVSTimeLossRawDataAll
-- Description:      SUM(Duration_in_min) from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 00:00:00.0000000','2019-04-02 00:00:00.0000000', 'Operator Screen') where StatusLevel2='KBMaschStatus.1.Productive' = 1020
--**************************************************
select @testresultInt=SUM(Duration_in_min) from GetCVSTimeLossRawDataAll ('TESTMACHINE','2019-04-01 00:00:00.0000000','2019-04-02 00:00:00.0000000', 'Operator Screen') where StatusLevel2='KBMaschStatus.1.Productive';
exec AssertEqualFloat @value = @testresultInt, @targetvalue = 1020, @messagetext = 'SUM(Duration_in_min) from GetCVSTimeLossRawDataAll (''TESTMACHINE'',''2019-04-01 00:00:00.0000000'',''2019-04-02 00:00:00.0000000'', ''Operator Screen'' where StatusLevel2=''KBMaschStatus.1.Productive'') = 1020';
 
