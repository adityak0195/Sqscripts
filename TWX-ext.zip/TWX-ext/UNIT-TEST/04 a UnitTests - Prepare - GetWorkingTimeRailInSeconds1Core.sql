--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--
-- Test Preparation for GetWorkingTimeRailInSeconds1Core
--
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************

print 'Insert Test data for GetWorkingTimeRailInSeconds1Core';
--------------------------------------------------------------------------------

declare @Machine varchar(255) = 'GetWorkingTimeRailInSeconds1CoreTESTMACHINE';
declare @Plant varchar(255) = 'TEST';
declare @Shift varchar(255) = 'TESTSHIFT';


		insert into smartKPIMachineKeyValueData ([TextValue], Machine, PropertyKey)
        select @Machine, @Machine, 'SAPWorkcenterNumber' where not exists (select * from smartKPIMachineKeyValueData
		  where Machine = @Machine
		  and PropertyKey = 'SAPWorkcenterNumber');


-- Data for Testcase 1: Only 'W' entry
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-01-01 01:00:00', '2040-01-01 12:00:00', 'W', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-01-01 01:00:00'
		and [EndTime]= '2040-01-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

-- Data for Testcase 2: 'W' entry, E during W
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-01-02 01:00:00', '2040-01-02 12:00:00', 'W', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-01-02 01:00:00'
		and [EndTime]= '2040-01-02 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-01-02 02:00:00', '2040-01-02 03:00:00', 'E', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-01-02 02:00:00'
		and [EndTime]= '2040-01-02 03:00:00'
		and [Qualifier]= 'E'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

-- Data for Testcase 3: 'W' entry, E end of W
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-01-03 01:00:00', '2040-01-03 12:00:00', 'W', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-01-03 01:00:00'
		and [EndTime]= '2040-01-03 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-01-03 11:00:00', '2040-01-03 12:00:00', 'E', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-01-03 11:00:00'
		and [EndTime]= '2040-01-03 12:00:00'
		and [Qualifier]= 'E'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);
  
  -- Data for Testcase 4: 'W' entry, E beginning of W
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-01-04 01:00:00', '2040-01-04 12:00:00', 'W', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-01-04 01:00:00'
		and [EndTime]= '2040-01-04 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-01-04 01:00:00', '2040-01-04 02:00:00', 'E', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-01-04 01:00:00'
		and [EndTime]= '2040-01-04 02:00:00'
		and [Qualifier]= 'E'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);
  
  

-- Data for Testcase 5: 'W' entry, E-T during W
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-02-02 01:00:00', '2040-02-02 12:00:00', 'W', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-02-02 01:00:00'
		and [EndTime]= '2040-02-02 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-02-02 02:00:00', '2040-02-02 03:00:00', 'E-T', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-02-02 02:00:00'
		and [EndTime]= '2040-02-02 03:00:00'
		and [Qualifier]= 'E-T'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

-- Data for Testcase 6: 'W' entry, E-T end of W
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-02-03 01:00:00', '2040-02-03 12:00:00', 'W', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-02-03 01:00:00'
		and [EndTime]= '2040-02-03 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-02-03 11:00:00', '2040-02-03 12:00:00', 'E-T', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-02-03 11:00:00'
		and [EndTime]= '2040-02-03 12:00:00'
		and [Qualifier]= 'E-T'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);
  
  -- Data for Testcase 7: 'W' entry, E-T beginning of W
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-02-04 01:00:00', '2040-02-04 12:00:00', 'W', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-02-04 01:00:00'
		and [EndTime]= '2040-02-04 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select @Plant, @Machine, '2040-02-04 01:00:00', '2040-02-04 02:00:00', 'E-T', @Shift, @Machine
	  where not exists (select * from [shiftCalendar] 
		where [Plant]=@Plant
		and [Machine]= @Machine
		and [StartTime]= '2040-02-04 01:00:00'
		and [EndTime]= '2040-02-04 02:00:00'
		and [Qualifier]= 'E-T'
		and [Name]= @Shift
		and [Machine_Full_Name]= @Machine);
  
  
