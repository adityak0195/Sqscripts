

--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--
-- Test run for GetWorkingTimeRailInSeconds1Extended
--
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************



print '--Doing some Testings for GetWorkingTimeRailInSeconds1Extended:';


DECLARE @testresultInt int;
DECLARE @targetvalue int;
DECLARE @testresultDateTime datetime2;
DECLARE @testresultVarchar varchar(max);

declare @Machine varchar(255) = 'GetWorkingTimeRailInSeconds1ExtendedTESTMACHINE';

--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
-- 1. only W defined
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 1.1
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot > Shift Definition
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                           WWWWW
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-01 00:00:00', '2040-01-02 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 1.1';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 1.2
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot > Shift Definition
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                WWWWW
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-01 01:00:00', '2040-01-02 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 1.2';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 1.3
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot = Shift Definition
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWW
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-01 00:00:00', '2040-01-01 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 1.3';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 1.4
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot = Shift Definition
--                   Test Timeslot                   |---|
--                   Shift Definition                WWWWW
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-01 01:00:00', '2040-01-01 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 1.4';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 1.5
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition
--                   Test Timeslot                     |----------------------------------|
--                   Shift Definition                WWWWW
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-01 02:00:00', '2040-01-02 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 1.5';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 1.6
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                                  WWWWW
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-01 00:00:00', '2040-01-01 11:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 1.6';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 1.7
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition
--                   Test Timeslot                     |---|
--                   Shift Definition                WWWWWWWWWW
--**************************************************
set @targetvalue = 9 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-01 02:00:00', '2040-01-01 11:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 1.7';



--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
-- 2. W and E defined, E during W
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.1
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot > Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                           WWWWW
--                   Exeption Definition                          EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 00:00:00', '2040-01-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.1';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.2
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot > Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition               EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:00:00', '2040-01-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.2';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.3
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot = Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWW
--                   Exeption Definition                                             EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 00:00:00', '2040-01-02 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.3';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.4
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot = Shift Definition, E during W
--                   Test Timeslot                   |---|
--                   Shift Definition                WWWWW
--                   Exeption Definition              EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:00:00', '2040-01-02 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.4';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.5
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E during W
--                   Test Timeslot                    |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition               EE
--**************************************************
set @targetvalue = 9.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:30:00', '2040-01-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.5';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.6
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E during W
--                   Test Timeslot                    |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition              EE
--**************************************************
set @targetvalue = 9 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 02:00:00', '2040-01-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.6';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.7
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E during W
--                   Test Timeslot                     |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition              EEE
--**************************************************
set @targetvalue = 9 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 02:30:00', '2040-01-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.7';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.8
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E during W
--                   Test Timeslot                      |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition               EE
--**************************************************
set @targetvalue = 9 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 03:00:00', '2040-01-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.8';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.9
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E during W
--                   Test Timeslot                       |----------------------------------|
--                   Shift Definition                WWWWWW
--                   Exeption Definition              EE
--**************************************************
set @targetvalue = 8.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 03:30:00', '2040-01-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.9';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.10
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWW
--                   Exeption Definition                                             EE
--**************************************************
set @targetvalue = 2 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:00:00', '2040-01-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.10';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.11
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWW
--                   Exeption Definition                                               EE
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:00:00', '2040-01-02 03:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.11';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.12
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWWW
--                   Exeption Definition                                               EEE
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:00:00', '2040-01-02 02:30:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.12';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.13
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWWW
--                   Exeption Definition                                                EE
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 03:00:00', '2040-01-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.13';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.14
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWWWWWW
--                   Exeption Definition                                                  EE
--**************************************************
set @targetvalue = 0.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:15:00', '2040-01-02 01:45:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.14';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.15
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition                     EE
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 01:30:00', '2040-01-02 03:30:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.15';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.16
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition               EE
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 02:00:00', '2040-01-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.16';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.17
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition              EEE
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 02:30:00', '2040-01-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.17';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 2.18
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition              EE
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-02 03:00:00', '2040-01-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 2.18';

--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
-- 3. W and E defined, E end of W
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 3.1
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot > Shift Definition, E end of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                           WWWWW
--                   Exeption Definition                           EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-03 00:00:00', '2040-01-04 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 3.1';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 3.2
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot > Shift Definition, E end of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition                EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-03 01:00:00', '2040-01-04 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 3.2';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 3.3
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot = Shift Definition, E end of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWW
--                   Exeption Definition                                               EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-03 00:00:00', '2040-01-03 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 3.3';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 3.4
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot = Shift Definition, E end of
--                   Test Timeslot                   |---|
--                   Shift Definition                WWWWW
--                   Exeption Definition                EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-03 01:00:00', '2040-01-03 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 3.4';

--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
-- 4. W and E defined, E beginning of W
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 4.1
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot > Shift Definition, E beginning of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                           WWWWW
--                   Exeption Definition                        EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-04 00:00:00', '2040-01-05 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 4.1';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 4.2
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot > Shift Definition, E beginning of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition             EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-04 01:00:00', '2040-01-05 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 4.2';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 4.3
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot = Shift Definition, E beginning of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWW
--                   Exeption Definition                                            EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-04 00:00:00', '2040-01-04 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 4.3';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 4.4
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot = Shift Definition, E beginning of
--                   Test Timeslot                   |---|
--                   Shift Definition                WWWWW
--                   Exeption Definition             EE
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-01-04 01:00:00', '2040-01-04 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 4.4';





--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
-- 5. W and E-T defined, E-T during W
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.1
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot > Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                           WWWWW
--                   Exeption Definition                          ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 00:00:00', '2040-02-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.1';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.2
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot > Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition               ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:00:00', '2040-02-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.2';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.3
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot = Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWW
--                   Exeption Definition                                             ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 00:00:00', '2040-02-02 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.3';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.4
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot = Shift Definition, E-T during W
--                   Test Timeslot                   |---|
--                   Shift Definition                WWWWW
--                   Exeption Definition              ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:00:00', '2040-02-02 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.4';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.5
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E-T during W
--                   Test Timeslot                    |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition               ET
--**************************************************
set @targetvalue = 10.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:30:00', '2040-02-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.5';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.6
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E-T during W
--                   Test Timeslot                    |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition              ET
--**************************************************
set @targetvalue = 10 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 02:00:00', '2040-02-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.6';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.7
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E-T during W
--                   Test Timeslot                     |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition               E-T 
--**************************************************
set @targetvalue = 9.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 02:30:00', '2040-02-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.7';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.8
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E-T during W
--                   Test Timeslot                      |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition               ET
--**************************************************
set @targetvalue = 9 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 03:00:00', '2040-02-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.8';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.9
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot > Shift Definition, E-T during W
--                   Test Timeslot                       |----------------------------------|
--                   Shift Definition                WWWWWW
--                   Exeption Definition              ET
--**************************************************
set @targetvalue = 8.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 03:30:00', '2040-02-03 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.9';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.10
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWW
--                   Exeption Definition                                             ET
--**************************************************
set @targetvalue = 3 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:00:00', '2040-02-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.10';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.11
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWW
--                   Exeption Definition                                               ET
--**************************************************
set @targetvalue = 2 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:00:00', '2040-02-02 03:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.11';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.12
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWWW
--                   Exeption Definition                                                E-T 
--**************************************************
set @targetvalue = 1.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:00:00', '2040-02-02 02:30:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.12';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.13
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWWW
--                   Exeption Definition                                                ET
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 03:00:00', '2040-02-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.13';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.14
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWWWWWWW
--                   Exeption Definition                                                  ET
--**************************************************
set @targetvalue = 0.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:15:00', '2040-02-02 01:45:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.14';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.15
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition                     ET
--**************************************************
set @targetvalue = 2 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 01:30:00', '2040-02-02 03:30:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.15';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.16
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition               ET
--**************************************************
set @targetvalue = 2 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 02:00:00', '2040-02-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.16';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.17
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition               E-T 
--**************************************************
set @targetvalue = 1.5 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 02:30:00', '2040-02-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.17';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 5.18
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot > Shift Definition, End Test Timeslot < Shift Definition, E-T during W
--                   Test Timeslot                     |-------------|
--                   Shift Definition                WWWWWWWWWWWWWWWWWWWWW
--                   Exeption Definition              ET
--**************************************************
set @targetvalue = 1 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-02 03:00:00', '2040-02-02 04:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 5.18';

--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
-- 6. W and E-T defined, E-T end of W
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 6.1
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot > Shift Definition, E-T end of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                           WWWWW
--                   Exeption Definition                           ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-03 00:00:00', '2040-02-04 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 6.1';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 6.2
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot > Shift Definition, E-T end of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition                ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-03 01:00:00', '2040-02-04 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 6.2';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 6.3
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot = Shift Definition, E-T end of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWW
--                   Exeption Definition                                               ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-03 00:00:00', '2040-02-03 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 6.3';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 6.4
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot = Shift Definition, E-T end of
--                   Test Timeslot                   |---|
--                   Shift Definition                WWWWW
--                   Exeption Definition                ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-03 01:00:00', '2040-02-03 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 6.4';

--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
-- 7. W and E-T defined, E-T beginning of W
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 7.1
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot > Shift Definition, E-T beginning of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                           WWWWW
--                   Exeption Definition                        ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-04 00:00:00', '2040-02-05 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 7.1';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 7.2
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot > Shift Definition, E-T beginning of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                WWWWW
--                   Exeption Definition             ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-04 01:00:00', '2040-02-05 00:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 7.2';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 7.3
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot < Shift Definition, End Test Timeslot = Shift Definition, E-T beginning of
--                   Test Timeslot                   |----------------------------------|
--                   Shift Definition                                               WWWWW
--                   Exeption Definition                                            ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-04 00:00:00', '2040-02-04 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 7.3';

--**************************************************
-- Test provided by: Martin Flassak
-- What is tested:   GetWorkingTimeRailInSeconds1Extended 7.4
-- Description:      GetWorkingTimeRailInSeconds1Extended Start Test Timeslot = Shift Definition, End Test Timeslot = Shift Definition, E-T beginning of
--                   Test Timeslot                   |---|
--                   Shift Definition                WWWWW
--                   Exeption Definition             ET
--**************************************************
set @targetvalue = 11 * 60 * 60;
select @testresultInt=dbo.GetWorkingTimeRailInSeconds1Extended('2040-02-04 01:00:00', '2040-02-04 12:00:00', @Machine);
exec AssertEqualFloat @value = @testresultInt, @targetvalue = @targetvalue, @messagetext = 'GetWorkingTimeRailInSeconds1Extended 7.4';
