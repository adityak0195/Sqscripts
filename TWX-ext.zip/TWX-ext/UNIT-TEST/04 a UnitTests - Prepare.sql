--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--
-- Test Preparation
--
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************************************************************************
--delete from shiftCalendar where Machine in ('SAPTESTMACHINE', 'SAPTESTMACHINE1');
--delete from TEMP_SmartKPIFullShift where Machine in ('TESTMACHINE', 'TESTMACHINE1');

print 'Insert Test data';
--------------------------------------------------------------------------------
-----------Delete old test data
--DELETE from [smartKPIOrderKeyValueData] where System='TESTSYSTEM' and (OrderNumber = 'TESTORDER' OR OrderNumber = 'TESTORDER2')
--DELETE from [shiftCalendar] where ([Plant]='TEST' and [Machine]='SAPTESTMACHINE') OR ([Plant]='TEST1' and [Machine] ='SAPTESTMACHINE1')
-------------------------------------
insert into [smartKPIMachineKeyValueData] ([PropertyKey]
      ,[TextValue]
      ,[isTextValue]
      ,[Machine])
	  select 'SAPWorkcenterNumber', 'SAPTESTMACHINE', 1, 'TESTMACHINE'
	  where not exists (select * from [smartKPIMachineKeyValueData] where [PropertyKey] = 'SAPWorkcenterNumber' and [TextValue] = 'SAPTESTMACHINE' and [Machine] = 'TESTMACHINE');
insert into [smartKPIMachineKeyValueData] ([PropertyKey]
      ,[TextValue]
      ,[isTextValue]
      ,[Machine])
	  select 'SAPWorkcenterNumber', 'SAPTESTMACHINE1', 1, 'TESTMACHINE1'
	  where not exists (select * from [smartKPIMachineKeyValueData] where [PropertyKey] = 'SAPWorkcenterNumber' and [TextValue] = 'SAPTESTMACHINE1' and [Machine] = 'TESTMACHINE1');

--change1 start: adding a new test machine for unit testing of hourly kpi calculation with overlapped handling ([GetWorkingTimeCVSInSeconds_V2] 
insert into [smartKPIMachineKeyValueData] ([PropertyKey]
      ,[TextValue]
      ,[isTextValue]
      ,[Machine])
	  select 'SAPWorkcenterNumber', 'SAPTESTMACHINE99', 1, 'TESTMACHINE99'
	  where not exists (select * from [smartKPIMachineKeyValueData] where [PropertyKey] = 'SAPWorkcenterNumber' and [TextValue] = 'SAPTESTMACHINE99' and [Machine] = 'TESTMACHINE99');
--change1 end  

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2020-01-01 00:00:00', '2020-01-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2020-01-01 00:00:00'
		and [EndTime]= '2020-01-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2020-01-02 00:00:00', '2020-01-02 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2020-01-02 00:00:00'
		and [EndTime]= '2020-01-02 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');

insert into [smartKPIMachineKeyValueData] (PropertyKey
      ,FloatValue
      ,TextValue
      ,isFloatValue
      ,isTextValue
	  ,isDateTimeValue
	  ,Machine
	  ,PropertySubKey1
	  ,PropertySubKey2)
	  select 'MainStationForLineStatus',0,'TESTSTATION1',0,1,0,'TESTMACHINE','GenericThing','KBLocalMachineThingTemplate' where not exists (select * from [smartKPIMachineKeyValueData] 
		 where PropertyKey='MainStationForLineStatus'
      and FloatValue=0
      and TextValue='TESTSTATION1'
      and isFloatValue=0
      and isTextValue=1
	  and isDateTimeValue=0
	  and Machine='TESTMACHINE'
	  and PropertySubKey1='GenericThing'
	  and PropertySubKey2='KBLocalMachineThingTemplate');
	  
insert into [smartKPIMachineKeyValueData] (PropertyKey
      ,FloatValue
      ,TextValue
      ,isFloatValue
      ,isTextValue
	  ,isDateTimeValue
	  ,Machine
	  ,PropertySubKey1
	  ,PropertySubKey2)
	  select 'MainStationForLineStatus',0,'TESTSTATION2',0,1,0,'TESTMACHINE1','GenericThing','KBLocalMachineThingTemplate' where not exists (select * from [smartKPIMachineKeyValueData] 
		 where PropertyKey='MainStationForLineStatus'
      and FloatValue=0
      and TextValue='TESTSTATION2'
      and isFloatValue=0
      and isTextValue=1
	  and isDateTimeValue=0
	  and Machine='TESTMACHINE1'
	  and PropertySubKey1='GenericThing'
	  and PropertySubKey2='KBLocalMachineThingTemplate');


--------------------------------------------------------------
--------------------------------------------------------------
print 'Inserting Test Data';
--------------------------------------------------------------
--------------------------------------------------------------

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 00:00:00', '2019-04-01 12:00:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 00:00:00'
		and [EndTime]= '2019-04-01 12:00:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 20:30:00', '2019-04-01 21:30:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 20:30:00'
		and [EndTime]= '2019-04-01 21:30:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
		 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 23:30:00', '2019-04-02 00:30:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 23:30:00'
		and [EndTime]= '2019-04-02 00:30:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
		insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 12:15:00', '2019-04-01 12:45:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 12:15:00'
		and [EndTime]= '2019-04-01 12:45:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE'); 
		  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 00:00:00', '2019-04-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 00:00:00'
		and [EndTime]= '2019-04-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 12:00:00', '2019-04-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 12:00:00'
		and [EndTime]= '2019-04-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 10:00:00', '2019-04-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 10:00:00'
		and [EndTime]= '2019-04-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-04-01 21:00:00', '2019-04-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-04-01 21:00:00'
		and [EndTime]= '2019-04-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-03-01 00:00:00', '2019-03-01 12:00:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-03-01 00:00:00'
		and [EndTime]= '2019-03-01 12:00:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-03-01 20:30:00', '2019-03-01 21:30:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-03-01 20:30:00'
		and [EndTime]= '2019-03-01 21:30:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
		 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-03-01 23:30:00', '2019-03-02 00:30:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-03-01 23:30:00'
		and [EndTime]= '2019-03-02 00:30:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
		 
		  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-03-01 00:00:00', '2019-03-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-03-01 00:00:00'
		and [EndTime]= '2019-03-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-03-01 12:00:00', '2019-03-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-03-01 12:00:00'
		and [EndTime]= '2019-03-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-03-01 10:00:00', '2019-03-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-03-01 10:00:00'
		and [EndTime]= '2019-03-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-03-01 21:00:00', '2019-03-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-03-01 21:00:00'
		and [EndTime]= '2019-03-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
	
	
 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-02-01 00:00:00', '2019-02-01 12:00:00', 'D', '', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-02-01 00:00:00'
		and [EndTime]= '2019-02-01 12:00:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-02-01 00:00:00', '2019-02-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-02-01 00:00:00'
		and [EndTime]= '2019-02-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-02-01 12:00:00', '2019-02-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-02-01 12:00:00'
		and [EndTime]= '2019-02-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-02-01 10:00:00', '2019-02-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-02-01 10:00:00'
		and [EndTime]= '2019-02-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-02-01 21:00:00', '2019-02-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-02-01 21:00:00'
		and [EndTime]= '2019-02-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');


  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-01-01 00:00:00', '2019-01-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-01-01 00:00:00'
		and [EndTime]= '2019-01-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-01-01 12:00:00', '2019-01-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-01-01 12:00:00'
		and [EndTime]= '2019-01-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-01-01 10:00:00', '2019-01-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-01-01 10:00:00'
		and [EndTime]= '2019-01-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST', 'SAPTESTMACHINE', '2019-01-01 21:00:00', '2019-01-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST'
		and [Machine]= 'SAPTESTMACHINE'
		and [StartTime]= '2019-01-01 21:00:00'
		and [EndTime]= '2019-01-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE');

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 00:00:00', '2019-04-01 12:00:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 00:00:00'
		and [EndTime]= '2019-04-01 12:00:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 20:30:00', '2019-04-01 21:30:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 20:30:00'
		and [EndTime]= '2019-04-01 21:30:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
		 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 23:30:00', '2019-04-02 00:30:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 23:30:00'
		and [EndTime]= '2019-04-02 00:30:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
		insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 12:15:00', '2019-04-01 12:45:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 12:15:00'
		and [EndTime]= '2019-04-01 12:45:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1'); 
		  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 00:00:00', '2019-04-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 00:00:00'
		and [EndTime]= '2019-04-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 12:00:00', '2019-04-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 12:00:00'
		and [EndTime]= '2019-04-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 10:00:00', '2019-04-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 10:00:00'
		and [EndTime]= '2019-04-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-04-01 21:00:00', '2019-04-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-04-01 21:00:00'
		and [EndTime]= '2019-04-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-03-01 00:00:00', '2019-03-01 12:00:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-03-01 00:00:00'
		and [EndTime]= '2019-03-01 12:00:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-03-01 20:30:00', '2019-03-01 21:30:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-03-01 20:30:00'
		and [EndTime]= '2019-03-01 21:30:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
		 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-03-01 23:30:00', '2019-03-02 00:30:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-03-01 23:30:00'
		and [EndTime]= '2019-03-02 00:30:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
		 
		  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-03-01 00:00:00', '2019-03-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-03-01 00:00:00'
		and [EndTime]= '2019-03-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-03-01 12:00:00', '2019-03-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-03-01 12:00:00'
		and [EndTime]= '2019-03-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-03-01 10:00:00', '2019-03-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-03-01 10:00:00'
		and [EndTime]= '2019-03-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-03-01 21:00:00', '2019-03-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-03-01 21:00:00'
		and [EndTime]= '2019-03-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
	
	
 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-02-01 00:00:00', '2019-02-01 12:00:00', 'PE', '', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-02-01 00:00:00'
		and [EndTime]= '2019-02-01 12:00:00'
		and [Qualifier]= 'PE'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-02-01 00:00:00', '2019-02-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-02-01 00:00:00'
		and [EndTime]= '2019-02-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-02-01 12:00:00', '2019-02-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-02-01 12:00:00'
		and [EndTime]= '2019-02-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-02-01 10:00:00', '2019-02-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-02-01 10:00:00'
		and [EndTime]= '2019-02-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-02-01 21:00:00', '2019-02-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-02-01 21:00:00'
		and [EndTime]= '2019-02-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');


  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-01-01 00:00:00', '2019-01-01 12:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-01-01 00:00:00'
		and [EndTime]= '2019-01-01 12:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-01-01 12:00:00', '2019-01-01 13:00:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-01-01 12:00:00'
		and [EndTime]= '2019-01-01 13:00:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-01-01 10:00:00', '2019-01-01 20:00:00', 'M', 'TESTSHIFT1', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-01-01 10:00:00'
		and [EndTime]= '2019-01-01 20:00:00'
		and [Qualifier]= 'M'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');
  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST1', 'SAPTESTMACHINE1', '2019-01-01 21:00:00', '2019-01-02 00:00:00', 'W', 'TESTSHIFT2', 'SAPTESTMACHINE1'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST1'
		and [Machine]= 'SAPTESTMACHINE1'
		and [StartTime]= '2019-01-01 21:00:00'
		and [EndTime]= '2019-01-02 00:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT2'
		and [Machine_Full_Name]= 'SAPTESTMACHINE1');



--change2 start: adding data for unit testing of hourly kpi calculation with overlapped handling ([GetWorkingTimeCVSInSeconds_V1] 

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-09 12:00:00', '2024-09-09 16:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-09 12:00:00'
		and [EndTime]= '2024-09-09 16:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-09 12:00:00', '2024-09-09 12:30:00', 'P', 'TESTSHIFT1', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-09 12:00:00'
		and [EndTime]= '2024-09-09 12:30:00'
		and [Qualifier]= 'P'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-09 22:00:00', '2024-09-09 23:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-09 22:00:00'
		and [EndTime]= '2024-09-09 23:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-09 22:00:00', '2024-09-10 12:00:00', 'M', '', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-09 22:00:00'
		and [EndTime]= '2024-09-10 12:00:00'
		and [Qualifier]= 'M'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');
		

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-26 05:30:00', '2024-09-26 07:10:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-26 05:30:00'
		and [EndTime]= '2024-09-26 07:10:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

  insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-26 07:00:00', '2024-09-26 08:00:00', 'D', '', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-26 07:00:00'
		and [EndTime]= '2024-09-26 08:00:00'
		and [Qualifier]= 'D'
		and [Name]= ''
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');
		
 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-26 07:10:00', '2024-09-26 07:20:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-26 07:10:00'
		and [EndTime]= '2024-09-26 07:20:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-26 07:20:00', '2024-09-26 09:10:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-26 07:20:00'
		and [EndTime]= '2024-09-26 09:10:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-10 23:35:00', '2024-09-11 04:00:00', 'W', 'TESTSHIFT1', 'SAPTESTMACHINE99'     
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-10 23:35:00'
		and [EndTime]= '2024-09-11 04:00:00'
		and [Qualifier]= 'W'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

 insert into [shiftCalendar] ([Plant]
      ,[Machine]
      ,[StartTime]
      ,[EndTime]
      ,[Qualifier]
      ,[Name]
      ,[Machine_Full_Name])
	  select 'TEST99', 'SAPTESTMACHINE99', '2024-09-10 23:00:00', '2024-09-10 23:35:00', 'B', 'TESTSHIFT1', 'SAPTESTMACHINE99'
	  where not exists (select * from [shiftCalendar] 
		where [Plant]='TEST99'
		and [Machine]= 'SAPTESTMACHINE99'
		and [StartTime]= '2024-09-10 23:00:00'
		and [EndTime]= '2024-09-10 23:35:00'
		and [Qualifier]= 'B'
		and [Name]= 'TESTSHIFT1'
		and [Machine_Full_Name]= 'SAPTESTMACHINE99');

--change2 end



insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'SetupTime-0010', 'MIN', 'MIN', 1
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'SetupTime-0010' and [TextValue] = 'MIN' and System = 'TESTSYSTEM' and FloatValue = 1);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'SetupTimeAPO-0010', 'MIN', 'MIN', 2
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'SetupTimeAPO-0010' and [TextValue] = 'MIN' and System = 'TESTSYSTEM' and FloatValue = 2);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'SetupTimeCO-0010', 'MIN', 'MIN', 3
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'SetupTimeCO-0010' and [TextValue] = 'MIN' and System = 'TESTSYSTEM' and FloatValue = 3);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'ProcessingTime-0010', 'SEC', 'SEC', 4
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'ProcessingTime-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 4);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'ProcessingTimeCO-0010', 'SEC', 'SEC', 5
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'ProcessingTimeCO-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 5);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'ProcessingTimeAPO-0010', 'SEC', 'SEC', 6
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'ProcessingTimeAPO-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 6);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'TeardownTime-0010', 'DAY', 'DAY', 1
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'TeardownTime-0010' and [TextValue] = 'DAY' and System = 'TESTSYSTEM' and FloatValue = 1);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'tgMaxTime-0010', 'SEC', 'SEC', 10
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'tgMaxTime-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 10);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER', 'PlannedNumberOfWorkers-0010',20
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'PlannedNumberOfWorkers-0010' and System = 'TESTSYSTEM' and FloatValue = 20);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
	  ,[PropertyKey1]
	  ,Operation
      ,[TextValue1])
	  select 'TESTSYSTEM', 'TESTORDER', 'Operation-0010', '0010', 'Operation', '0010', '0010'
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'Operation-0010' and PropertyKey1='Operation'and  Operation='0010' and [TextValue] = '0010' and System = 'TESTSYSTEM');
insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1])
	  select 'TESTSYSTEM', 'TESTORDER', 'Line-0010', 'SAPTESTMACHINE', 'SAPTESTMACHINE'
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'Line-0010' and [TextValue] = 'SAPTESTMACHINE' and System = 'TESTSYSTEM');

insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-02 00:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-02 00:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 23:30:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test1','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 23:30:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test1'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 23:00:00','KBMaschStatus.1.OI.AutoSet','KBMaschStatus.2.OI.AutoSet.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 23:00:00'
		and [Status]= 'KBMaschStatus.1.OI.AutoSet'
		and [SubStatus]= 'KBMaschStatus.2.OI.AutoSet.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 22:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 22:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 22:00:00','KBMaschStatus.1.TI.RegularChangeover','KBMaschStatus.2.TI.RegularChangeover.test3','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 22:00:00'
		and [Status]= 'KBMaschStatus.1.TI.RegularChangeover'
		and [SubStatus]= 'KBMaschStatus.2.TI.RegularChangeover.test3'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 21:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 21:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 21:00:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test2','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 21:00:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test2'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 10:00:00','KBMaschStatus.1.OI.Break','KBMaschStatus.2.OI.Break.479','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 10:00:00'
		and [Status]= 'KBMaschStatus.1.OI.Break'
		and [SubStatus]= 'KBMaschStatus.2.OI.Break.479'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 09:00:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 09:00:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 08:00:00','KBMaschStatus.1.TI.5Sactivities','KBMaschStatus.2.TI.5Sactivities.test4','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 08:00:00'
		and [Status]= 'KBMaschStatus.1.TI.5Sactivities'
		and [SubStatus]= 'KBMaschStatus.2.TI.5Sactivities.test4'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 05:00:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 05:00:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 04:00:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test2','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 04:00:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test2'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 03:00:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 03:00:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-04-01 01:00:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test1','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-04-01 01:00:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test1'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION1','2019-03-31 22:00:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION1'
		and [StatusTime]= '2019-03-31 22:00:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');

-- Insert STATUSES for TESTSTATION2
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-02 0:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-02 0:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 23:30:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test1','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 23:30:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test1'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 23:15:00','KBMaschStatus.1.OI.AutoSet','KBMaschStatus.2.OI.AutoSet.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 23:15:00'
		and [Status]= 'KBMaschStatus.1.OI.AutoSet'
		and [SubStatus]= 'KBMaschStatus.2.OI.AutoSet.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 23:00:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 23:00:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 22:30:00','KBMaschStatus.1.TI.RegularChangeover','KBMaschStatus.2.TI.RegularChangeover.test3','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 22:30:00'
		and [Status]= 'KBMaschStatus.1.TI.RegularChangeover'
		and [SubStatus]= 'KBMaschStatus.2.TI.RegularChangeover.test3'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 21:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 21:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 21:00:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test2','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 21:00:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test2'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 10:30:00','KBMaschStatus.1.OI.Break','KBMaschStatus.2.OI.Break.479','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 10:30:00'
		and [Status]= 'KBMaschStatus.1.OI.Break'
		and [SubStatus]= 'KBMaschStatus.2.OI.Break.479'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 09:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 09:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 08:00:00','KBMaschStatus.1.TI.5Sactivities','KBMaschStatus.2.TI.5Sactivities.test4','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 08:00:00'
		and [Status]= 'KBMaschStatus.1.TI.5Sactivities'
		and [SubStatus]= 'KBMaschStatus.2.TI.5Sactivities.test4'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 05:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 05:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 04:30:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test2','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 04:30:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test2'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 03:30:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 03:30:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-04-01 01:30:00','KBMaschStatus.1.TI.MachineBreakdown','KBMaschStatus.2.TI.MachineBreakdown.test1','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-04-01 01:30:00'
		and [Status]= 'KBMaschStatus.1.TI.MachineBreakdown'
		and [SubStatus]= 'KBMaschStatus.2.TI.MachineBreakdown.test1'
		and [description]= 'Test data'
		and [StatusType]= 'Operator Screen');
 insert into [smartKPIMachineStatusData] ([Machine]
      ,[StatusTime]
      ,[Status]
      ,[SubStatus]
      ,[description]
      ,[StatusType])
	  select 'TESTSTATION2','2019-03-31 22:00:00','KBMaschStatus.1.Productive','KBMaschStatus.2.Productive.Start','Test data','Operator Screen' where not exists (select * from [smartKPIMachineStatusData] 
		 where  [Machine]='TESTSTATION2'
		and [StatusTime]= '2019-03-31 22:00:00'
		and [Status]= 'KBMaschStatus.1.Productive'
		and [SubStatus]= 'KBMaschStatus.2.Productive.Start'
		and [description]= 'Test data'		
		and [StatusType]= 'Operator Screen');

-- INSERTING TestOrder DATA


  insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
	  ,[PropertyKey1]
      ,[TextValue]
      ,[TextValue1])
	  select 'TESTSYSTEM', 'TESTORDER', 'MaterialNumber', 'MaterialNumber', 'TestMaterial1', 'TestMaterial1'
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER' and [PropertyKey] = 'MaterialNumber' and [PropertyKey1] = 'MaterialNumber' and [TextValue] = 'TestMaterial1' and System = 'TESTSYSTEM' and TextValue1 = 'TestMaterial1');


insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'SetupTime-0010', 'MIN', 'MIN', 1
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'SetupTime-0010' and [TextValue] = 'MIN' and System = 'TESTSYSTEM' and FloatValue = 1);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'SetupTimeAPO-0010', 'MIN', 'MIN', 2
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'SetupTimeAPO-0010' and [TextValue] = 'MIN' and System = 'TESTSYSTEM' and FloatValue = 2);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'SetupTimeCO-0010', 'MIN', 'MIN', 3
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'SetupTimeCO-0010' and [TextValue] = 'MIN' and System = 'TESTSYSTEM' and FloatValue = 3);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'ProcessingTime-0010', 'SEC', 'SEC', 4
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'ProcessingTime-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 4);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'ProcessingTimeCO-0010', 'SEC', 'SEC', 5
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'ProcessingTimeCO-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 5);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'ProcessingTimeAPO-0010', 'SEC', 'SEC', 6
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'ProcessingTimeAPO-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 6);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'TeardownTime-0010', 'DAY', 'DAY', 1
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'TeardownTime-0010' and [TextValue] = 'DAY' and System = 'TESTSYSTEM' and FloatValue = 1);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'tgMaxTime-0010', 'SEC', 'SEC', 10
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'tgMaxTime-0010' and [TextValue] = 'SEC' and System = 'TESTSYSTEM' and FloatValue = 10);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
	  , FloatValue)
	  select 'TESTSYSTEM', 'TESTORDER2', 'PlannedNumberOfWorkers-0010',20
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'PlannedNumberOfWorkers-0010' and System = 'TESTSYSTEM' and FloatValue = 20);

insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
	  ,PropertyKey1
	  ,Operation
      ,[TextValue1])
	  select 'TESTSYSTEM', 'TESTORDER2', 'Operation-0010', '0010', 'Operation', '0010', '0010'
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'Operation-0010'  and Operation='0010' and [TextValue] = '0010' and PropertyKey1='Operation' and System = 'TESTSYSTEM');
insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
      ,[TextValue]
      ,[TextValue1])
	  select 'TESTSYSTEM', 'TESTORDER2', 'Line-0010', 'SAPTESTMACHINE', 'SAPTESTMACHINE'
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'Line-0010' and [TextValue] = 'SAPTESTMACHINE' and System = 'TESTSYSTEM');
	  
insert into [smartKPIOrderKeyValueData] (System, [OrderNumber]
      ,[PropertyKey]
	  ,[PropertyKey1]
      ,[TextValue]
      ,[TextValue1])
	  select 'TESTSYSTEM', 'TESTORDER2', 'MaterialNumber', 'MaterialNumber', 'TestMaterial2', 'TestMaterial2'
	  where not exists (select * from [smartKPIOrderKeyValueData] where [OrderNumber] = 'TESTORDER2' and [PropertyKey] = 'MaterialNumber' and [PropertyKey1] = 'MaterialNumber' and [TextValue] = 'TestMaterial2' and System = 'TESTSYSTEM' and TextValue1 = 'TestMaterial2');
	  

-- INSERTING Production DATA
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 00:30:00',1,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 00:30:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 00:40:00',1,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 00:40:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 00:50:00',0,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 00:50:00'
		and [isPartOK]= 0
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 09:30:00',1,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 09:30:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 09:40:00',1,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 09:40:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 21:30:00',1,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 21:30:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 21:40:00',1,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 21:40:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 21:50:00',1,'TestMaterial','TESTORDER','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 21:50:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 23:00:00',1,'TestMaterial2','TESTORDER2','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 23:00:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial2'
		and [OrderNumber]= 'TESTORDER2'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION1','2019-04-01 23:10:00',1,'TestMaterial2','TESTORDER2','TESTSTATION1'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION1'
		and [ProductionTime]= '2019-04-01 23:10:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial2'
		and [OrderNumber]= 'TESTORDER2'
		and [Station]= 'TESTSTATION1');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 00:35:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 00:35:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 00:45:00',0,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 00:45:00'
		and [isPartOK]= 0
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 00:55:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 00:55:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 09:35:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 09:35:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 09:45:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 09:45:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 21:35:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 21:35:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 21:45:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 21:45:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 21:55:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 21:55:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 23:05:00',1,'TestMaterial2','TESTORDER2','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 23:05:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial2'
		and [OrderNumber]= 'TESTORDER2'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTSTATION2','2019-04-01 23:15:00',1,'TestMaterial2','TESTORDER2','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTSTATION2'
		and [ProductionTime]= '2019-04-01 23:15:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial2'
		and [OrderNumber]= 'TESTORDER2'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 00:35:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 00:35:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 00:45:00',0,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 00:45:00'
		and [isPartOK]= 0
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 00:55:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 00:55:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 09:35:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 09:35:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 09:45:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 09:45:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 21:35:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 21:35:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 21:45:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 21:45:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 21:55:00',1,'TestMaterial','TESTORDER','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 21:55:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial'
		and [OrderNumber]= 'TESTORDER'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 23:05:00',1,'TestMaterial2','TESTORDER2','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 23:05:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial2'
		and [OrderNumber]= 'TESTORDER2'
		and [Station]= 'TESTSTATION2');
insert into [smartKPI] ([Machine]
      ,[ProductionTime]
      ,[isPartOK]
      ,[PartNumber]
      ,[OrderNumber]
      ,[Station])
	  select 
   'TESTMACHINE','2019-04-01 23:15:00',1,'TestMaterial2','TESTORDER2','TESTSTATION2'  where not exists (select * from [smartKPI] 
		 where  [Machine]='TESTMACHINE'
		and [ProductionTime]= '2019-04-01 23:15:00'
		and [isPartOK]= 1
		and [PartNumber]= 'TestMaterial2'
		and [OrderNumber]= 'TESTORDER2'
		and [Station]= 'TESTSTATION2');
insert into [smartKPIMachineKeyValueData] (PropertyKey
      ,FloatValue
      ,TextValue
      ,isFloatValue
      ,isTextValue
	  ,isDateTimeValue
	  ,Machine
	  ,PropertySubKey1
	  ,PropertySubKey2)
	  select 'MainStationForLineStatus',0,'TESTSTATION2',0,1,0,'TESTMACHINE1','GenericThing','KBLocalMachineThingTemplate' where not exists (select * from [smartKPIMachineKeyValueData] 
		 where PropertyKey='MainStationForLineStatus'
      and FloatValue=0
      and TextValue='TESTSTATION2'
      and isFloatValue=0
      and isTextValue=1
	  and isDateTimeValue=0
	  and Machine='TESTMACHINE1'
	  and PropertySubKey1='GenericThing'
	  and PropertySubKey2='KBLocalMachineThingTemplate');

insert into [smartKPIMachineKeyValueData] (PropertyKey
      ,FloatValue
      ,TextValue
      ,isFloatValue
      ,isTextValue
	  ,isDateTimeValue
	  ,Machine
	  ,PropertySubKey1
	  ,PropertySubKey2)
	  select 'MainStationForLineStatus',0,'TESTSTATION1',0,1,0,'TESTMACHINE','GenericThing','KBLocalMachineThingTemplate' where not exists (select * from [smartKPIMachineKeyValueData] 
		 where PropertyKey='MainStationForLineStatus'
      and FloatValue=0
      and TextValue='TESTSTATION1'
      and isFloatValue=0
      and isTextValue=1
	  and isDateTimeValue=0
	  and Machine='TESTMACHINE'
	  and PropertySubKey1='GenericThing'
	  and PropertySubKey2='KBLocalMachineThingTemplate');


