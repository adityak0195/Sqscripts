$User = $args[0]
$PW = $args[1]
$server = $args[2]
$DB = $args[3]

echo '********************************************************'
echo 'User:'
echo $User
echo 'Server:'
echo $server
echo 'DB:'
echo $DB
echo '********************************************************'

if ($DB -ne 'none') {
	echo 'start'

    cmd /c "MSSQL-DB-Scripts\TWX-ext\azure-devops-02-Functions.bat $User $PW $server $DB"

    Get-Content .\dboutput.txt

    $File = "$pwd\dblogfile.txt"
    $DBError = [IO.File]::ReadAllText($File)
    if ($DBError -ne '' ) {Write-Error $DBError}
    
    echo 'end'
} else {
  Write-Host "Skipped!"
}
echo '********************************************************'
