--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetKPIRail';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetKPIRail') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetKPIRail  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetKPIRail
	@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@Machine varchar(255),
	@doSelection bit = 1
AS
BEGIN


	SET NOCOUNT ON
	select @StartDateTime as StartDateTime,
			@EndDateTime as EndDateTime, 
			Machine, 
			KPIName, 
			KPICalculationBase, 
			KPIDateTime as KPIDateTime,  
			KPIDateTimeEndOfCalculation as KPIDateTimeEndOfCalculation,
			[KPIFloatValue], 
			[KPIName] as Label, 
			ROUND([KPIFloatValue],2) as KPI 
		from GetCIPKPIsRail(@StartDateTime, @EndDateTime, @Machine);  

END;

GO


--declare @dt1 as DateTime2 = '2019-11-07 02:00:00.000';
--declare @dt2 as DateTime2 = '2019-11-08 02:00:00.000';

--EXECUTE GetKPIRail @StartDateTime = @dt1, @EndDateTime = @dt2, @Machine = 'KBBUD10424-NBH170MachineThing';  
--GO
