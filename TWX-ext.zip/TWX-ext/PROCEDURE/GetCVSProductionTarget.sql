--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTarget';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTarget') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetCVSProductionTarget  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetCVSProductionTarget
	@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2
AS
BEGIN
	SET NOCOUNT ON

	declare @target int;
	
	select @target=Target from TEMP_SmartKPICVSProductionTarget
		where LineThingName = @LineThingName
		and StartTime >= dateadd(minute,-1,@StartTime)
		and StartTime <= dateadd(minute,1,@StartTime)
		and EndTime >= dateadd(minute,-1,@EndTime)
		and EndTime <= dateadd(minute,1,@EndTime);

	if (@target is null)
		select @target=dbo.GetCVSProductionTargetFunctionV2(@LineThingName, @StartTime, @EndTime);  
			
	select @target as OK;
	
END;

GO


--declare @StartTime as DateTime2 = '2019-06-01 00:00:00';
--declare @EndTime as DateTime2 = '2019-09-08 00:00:00';

--EXECUTE GetCVSProductionTarget @LineThingName = 'KBLisLaa6MachineThing', @StartTime=@StartTime, @EndTime=@EndTime;  
--GO
