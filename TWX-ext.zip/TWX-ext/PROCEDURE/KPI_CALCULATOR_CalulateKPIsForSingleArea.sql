--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalulateKPIsForSingleArea';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalulateKPIsForSingleArea') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleArea  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleArea
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Area varchar(255)
AS
BEGIN;

    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


    declare @json varchar(max);
    declare @machines varchar(max) = '';
    declare @machine varchar(255);
    declare @counter int = 0;

    select @json = TextValue from smartKPIMachineKeyValueData
    where Machine = @Area
    and PropertyKey = 'KBMachineThings';




	DECLARE @machinecursor CURSOR;
	
	SET @machinecursor = CURSOR FOR select jsondata.KBMachineThing
			from OPENJSON(@json, N'$.rows')
				WITH(
					KBMachineThing varchar(255) N'$.KBMachineThing'
				) as jsondata;

	OPEN @machinecursor;
		FETCH NEXT FROM @machinecursor into @machine

		WHILE @@FETCH_STATUS = 0
		BEGIN;
            if (@counter > 0) set @machines = @machines + ',';
            set @machines = @machines + '''' + @machine + '''';
            set @counter = @counter + 1;
			FETCH NEXT FROM @machinecursor into @machine
		END;
	CLOSE @machinecursor;
	DEALLOCATE @machinecursor;

            
    exec CalulateKPIsForSingleArea 
        @StartDate,
        @EndDate,
        @CalculationBase,
        @Area,
        @machines;


END;
GO
