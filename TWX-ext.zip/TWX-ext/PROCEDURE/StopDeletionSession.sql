--------------------------------------------------------------
--------------------------------------------------------------
print '-- StopDeletionSession';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID('StopDeletionSession') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE StopDeletionSession AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE StopDeletionSession
    @SessionID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
    SELECT 1 
    FROM sys.dm_exec_sessions des
    INNER JOIN sys.dm_exec_connections dec ON des.session_id = dec.session_id
    INNER JOIN sys.dm_exec_requests er ON er.session_id = des.session_id
    CROSS APPLY sys.dm_exec_sql_text(dec.most_recent_sql_handle) dest
    WHERE dest.text LIKE 'CREATE PROCEDURE DeleteArchivedData%' 
      AND des.session_id = @SessionID
)
BEGIN
    DECLARE @KillCommand NVARCHAR(100);
    SET @KillCommand = 'KILL ' + CAST(@SessionID AS NVARCHAR);
    EXEC (@KillCommand);
END
END;
GO
