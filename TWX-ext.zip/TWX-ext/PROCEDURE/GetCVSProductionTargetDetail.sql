--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetDetail';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetDetail') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetCVSProductionTargetDetail  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetCVSProductionTargetDetail
	@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2
AS
BEGIN

	SET NOCOUNT ON

	DECLARE @NumberOfParallelProcesses int = 1;
	DECLARE @isMultiPalletMachine int = 0;
	DECLARE @table table (
			LineThingName varchar(255),
			StartTime datetime2,
			EndTime datetime2,
			ProductionTime datetime2, 
			counter int, 
			OrderNumber varchar(255), 
			SinglePartTargetCount INT, 
			WorkingTimeInMinutes float,
			TimeToProducePartsInMinutes float, 
			TimeForProducedParts float, 
			ProcessingTime float,
			SetupTime float,
			ProcessNumber int,
			FullCyclePartsProduced int);
			
	SELECT @isMultiPalletMachine=isnull([FloatValue],0)
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @LineThingName
		  and PropertyKey = 'isMultiPalletMachine';
	SELECT @NumberOfParallelProcesses=isnull([FloatValue],1)
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @LineThingName
	  and PropertyKey = 'NumberOfParallelProcessesForMultiPalletMachine';
	  
	if (@isMultiPalletMachine = 0 or @NumberOfParallelProcesses = 1 or (@isMultiPalletMachine = 1 and @NumberOfParallelProcesses > 1 and (datediff(hour,@StartTime, @EndTime) > 24 or getutcdate() not between @StartTime and @EndTime)))
		insert into @table (LineThingName,
				StartTime, 
				EndTime, 
				ProductionTime, 
				counter, 
				OrderNumber, 
				SinglePartTargetCount, 
				WorkingTimeInMinutes,
				TimeToProducePartsInMinutes, 
				TimeForProducedParts, 
				ProcessingTime,
				SetupTime,
				ProcessNumber,
				FullCyclePartsProduced)
			select LineThingName,
				StartTime, 
				EndTime, 
				ProductionTime, 
				counter, 
				OrderNumber, 
				SinglePartTargetCount, 
				WorkingTimeInMinutes,
				TimeToProducePartsInMinutes, 
				TimeForProducedParts, 
				ProcessingTime,
				SetupTime,
				ProcessNumber,
				FullCyclePartsProduced
				from TEMP_SmartKPICVSProductionTargetDetail
				where LineThingName = @LineThingName
				and StartTime >= dateadd(minute,-1,@StartTime)
				and StartTime <= dateadd(minute,1,@StartTime)
				and EndTime >= dateadd(minute,-1,@EndTime)
				and EndTime <= dateadd(minute,1,@EndTime);
			
	if (select count(*) from @table) = 0
		BEGIN
		insert into @table (LineThingName,
														StartTime, 
														EndTime, 
														ProductionTime, 
														counter, 
														OrderNumber, 
														SinglePartTargetCount, 
														WorkingTimeInMinutes,
														TimeToProducePartsInMinutes, 
														TimeForProducedParts, 
														ProcessingTime,
														SetupTime,
														ProcessNumber,
														FullCyclePartsProduced)
			select @LineThingName,
					@StartTime, 
					@EndTime, 
					ProductionTime, 
					counter, 
					OrderNumber, 
					SinglePartTargetCount, 
					WorkingTimeInMinutes,
					TimeToProducePartsInMinutes, 
					TimeForProducedParts, 
					ProcessingTime,
					SetupTime,
					ProcessNumber,
					FullCyclePartsProduced
				from GetCVSProductionTargetFunction1V2(@LineThingName, @StartTime, @EndTime);  
		END;
	select 	ProductionTime, 
			counter, 
			OrderNumber, 
			SinglePartTargetCount, 
			WorkingTimeInMinutes,
			TimeToProducePartsInMinutes, 
			TimeForProducedParts, 
			ProcessingTime,
			SetupTime,
			ProcessNumber,
			FullCyclePartsProduced
		from @table
			order by counter;  
END;

GO


--declare @StartTime as DateTime2 = '2019-06-01 00:00:00';
--declare @EndTime as DateTime2 = '2019-09-08 00:00:00';

--EXECUTE GetCVSProductionTargetDetail @LineThingName = 'KBLisLaa6MachineThing', @StartTime=@StartTime, @EndTime=@EndTime;  
--GO
