--------------------------------------------------------------
--------------------------------------------------------------
print '-- StartIndexReorganize';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'StartIndexReorganize') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE StartIndexReorganize  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE StartIndexReorganize
	@IndexName varchar(255),
	@TableName varchar(255)
AS
BEGIN
	SET NOCOUNT ON
	declare @command varchar(200);
	set @command = 'ALTER INDEX ' + @IndexName + ' ON ' + @TableName + ' REORGANIZE';
	exec(@command);
END;
GO