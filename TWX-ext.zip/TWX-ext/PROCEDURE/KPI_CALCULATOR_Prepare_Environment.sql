--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_Prepare_Environment';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_Prepare_Environment') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_Prepare_Environment  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_Prepare_Environment
AS
BEGIN;
    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


	DECLARE @command varchar(255);
	DECLARE @tablecursor CURSOR;

    SET @tablecursor = CURSOR FOR SELECT 'drop table ' + name + ';'
    FROM sys.tables
    WHERE name like 'TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_%'
    and DATEDIFF(minute,create_date,GETDATE()) > 45;
	

	OPEN @tablecursor;
		FETCH NEXT FROM @tablecursor into @command

		WHILE @@FETCH_STATUS = 0
		BEGIN;
            EXEC (@command);

			FETCH NEXT FROM @tablecursor into @command
		END;
	CLOSE @tablecursor;
	DEALLOCATE @tablecursor;


END;
GO

