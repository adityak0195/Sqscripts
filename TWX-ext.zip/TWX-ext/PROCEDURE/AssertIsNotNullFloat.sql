--------------------------------------------------------------
--------------------------------------------------------------
print '-- AssertIsNotNullFloat';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'AssertIsNotNullFloat') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE AssertIsNotNullFloat  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE AssertIsNotNullFloat
	@value float,
	@messagetext varchar(255) = ''
AS
BEGIN

	SET NOCOUNT ON;

	if  (@value is null	)
	BEGIN
		declare @text varchar(max) =  @messagetext +': @value is null';
		RAISERROR (@text, -- Message text.
					   16, -- Severity.
					   1 -- State.
					   );
	END;
END;
GO