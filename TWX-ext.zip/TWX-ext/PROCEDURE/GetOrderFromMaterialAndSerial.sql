--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetOrderFromMaterialAndSerial';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetOrderFromMaterialAndSerial') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetOrderFromMaterialAndSerial  AS BEGIN SET NOCOUNT ON; END');
GO
ALTER PROCEDURE GetOrderFromMaterialAndSerial
	@PartNumber [nvarchar](64),
	@SerialNumber [nvarchar](64)
	
AS
-- ============================================================================================================
-- Author:        Michal Burian
-- Version:       1.0
-- Description:   Retrieves order number based on provided parameteres
-- ALTER date:    20220202 1.0
-- Changelog:     1.0 - Create stored procedure
-- ============================================================================================================
BEGIN

	DECLARE @serialNumberLong VARCHAR(275) = '00000000000000000000'+@SerialNumber
	SET @serialNumberLong = SUBSTRING(@serialNumberLong,len(@serialNumberLong)-17,18);


	SELECT  SUBSTRING(OrderNumber,1,CHARINDEX('-',OrderNumber)-1) [OrderNumber] FROM smartKPIOrderKeyValueData
		   where PropertyKey = 'SerialNumber'
		   AND    TextValue1 = @serialNumberLong
	INTERSECT
	SELECT OrderNumber FROM smartKPIOrderKeyValueData
		   WHERE PropertyKey = 'MaterialNumber'
		   AND TextValue1 = @PartNumber

END;
GO