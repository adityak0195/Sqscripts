--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalulateKPIsForSinglePlant';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalulateKPIsForSinglePlant') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalulateKPIsForSinglePlant  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE [dbo].[KPI_CALCULATOR_CalulateKPIsForSinglePlant]
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Plant varchar(255)
AS
BEGIN;

    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


    declare @json varchar(max);
    declare @machines varchar(max) = '';
    declare @machine varchar(255);
    declare @counter int = 0;




	DECLARE @machinecursor CURSOR;
	
	SET @machinecursor = CURSOR FOR Select Machine from smartKPIMachineKeyValueData
    where PropertyKey = 'KBPlantThing'  and  PropertySubKey2='KBLocalMachineThingTemplate'
    and TextValue=@Plant;

	OPEN @machinecursor;
		FETCH NEXT FROM @machinecursor into @machine

		WHILE @@FETCH_STATUS = 0
		BEGIN;
            if (@counter > 0) set @machines = @machines + ',';
            set @machines = @machines + '''' + @machine + '''';
            set @counter = @counter + 1;
			FETCH NEXT FROM @machinecursor into @machine
		END;
	CLOSE @machinecursor;
	DEALLOCATE @machinecursor;

            
    exec CalulateKPIsForSinglePlant 
        @StartDate,
        @EndDate,
        @CalculationBase,
        @Plant,
        @machines;


END;
GO
