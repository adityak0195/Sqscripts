--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetRailLast5Orders';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetRailLast5Orders') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetRailLast5Orders  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetRailLast5Orders
@Station varchar(255)
AS
BEGIN
	SET NOCOUNT ON


	declare @table table (MaxProductionTimeInternal datetime2, 
		MinProductionTimeInternal datetime2, 
		PartnumberInternal varchar(255), 
		OperationNumberInternal varchar(255), 
		OrdernumberInternal varchar(255),
		numberOfOKPartsInternal int, 
		numberOfNOKPartsInternal int);
	insert into @table (MaxProductionTimeInternal, MinProductionTimeInternal, PartnumberInternal, OperationNumberInternal)
		select top(5) max(ProductionTime), min(ProductionTime), [PartNumber], SAPOperationNumber
		from [smartKPI] 
		where Station = @Station 
		group by [PartNumber] , SAPOperationNumber
		order by 1 desc;
	update @table set OrdernumberInternal = OrderNumber
		from [smartKPI] 
		where Station = @Station 
		and MaxProductionTimeInternal = ProductionTime
		and PartNumber = PartnumberInternal
		COLLATE database_default
		and SAPOperationNumber = OperationNumberInternal
		COLLATE database_default;
	update @table set numberOfOKPartsInternal = (select sum(numberOfParts) 
		from [smartKPI] 
		where Station = @Station
		and  isPartOK = '1'
		and ProductionTime >= MinProductionTimeInternal
		and ProductionTime <= MaxProductionTimeInternal
		and PartNumber = PartnumberInternal
		COLLATE database_default
		and SAPOperationNumber = OperationNumberInternal
		COLLATE database_default);
	update @table set numberOfNOKPartsInternal = (select sum(numberOfParts) 
		from [smartKPI] 
		where Station = @Station
		and  isPartOK = '0'
		and ProductionTime >= MinProductionTimeInternal
		and ProductionTime <= MaxProductionTimeInternal
		and PartNumber = PartnumberInternal
		COLLATE database_default
		and SAPOperationNumber = OperationNumberInternal
		COLLATE database_default);

	select MaxProductionTimeInternal as MaxProductionTime,
		MinProductionTimeInternal as MinProductionTime, 
		PartnumberInternal as PartNumber, 
		OperationNumberInternal as SAPOperationNumber,
		OrdernumberInternal as OrderNumber,
		numberOfOKPartsInternal as numberOfOKParts ,
		numberOfNOKPartsInternal as numberOfNOKParts
		from @table 
		order by 1 desc;
END;

GO

--exec GetRailLast5Orders @Station='KBBRQ364HA1BAV1PLCStationThing'

