--------------------------------------------------------------
--------------------------------------------------------------
print '-- InsertTestBenchDataJSON_V9';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertTestBenchDataJSON_V9') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE InsertTestBenchDataJSON_V9  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE InsertTestBenchDataJSON_V9
	@JSON_String varchar(max),
	@Machine varchar(255)
AS
BEGIN;
	--PRINT ('Start');
	--PRINT ('JSON_String = ' + @JSON_String);
	
	DECLARE @rowcounter  int = 0;
	DECLARE @JSON_row varchar(max);
	Declare @JSON CURSOR;
	
	DECLARE @ProcessDataDateTime DateTime2;
	DECLARE @Description varchar(255);
	DECLARE @PartNumber varchar(255);
	DECLARE @TrackingNumber varchar(255);
	DECLARE @ProcessDataDateTimeTargetValue DateTime2;
	DECLARE @ProcessDataPrecision varchar(255);
	DECLARE @OrderNumber varchar(255);
	DECLARE @Unit varchar(255);
	DECLARE @ProductionDateTime DateTime2;
    DECLARE @ProcessDataUSL float;
    DECLARE @ProcessDataStringTargetValue varchar(max);
    DECLARE @PartNumberRevision varchar(255);
    DECLARE @ProcessDataLSL float;
    DECLARE @Identifier varchar(255);
    DECLARE @ProcessDataTargetValueName varchar(255);
    DECLARE @ProcessDataFloat float;
    DECLARE @ProcessDataTargetValueTolUnit varchar(255);
    DECLARE @ProcessDataTolerancePos varchar(255);
    DECLARE @isProcessDataFloat bit;
    DECLARE @ProcessDataString varchar(max);
    DECLARE @ProcessDataLowerLimitName varchar(255);
    DECLARE @isProcessDataString bit;
    DECLARE @ProcessDataToleranceNeg varchar(255);
    DECLARE @ProcessDataUpperLimitName varchar(255);
    DECLARE @isProcessDataDateTime bit;
    DECLARE @SerialNumber varchar(255);
    DECLARE @ProcessDataFloatTargetValue float;
    DECLARE @ProcessDataType varchar(255);
    DECLARE @ProcessDataType2 varchar(255);
	DECLARE @timehelper1 int;
	DECLARE @timehelper2 int;
    DECLARE @isProcessDataBlob bit;
    DECLARE @ProcessDataBlob varchar(max);

	--PRINT ('End DECLARE');
	
	SET @JSON = CURSOR FOR SELECT value FROM OPENJSON(@JSON_String, '$.rows');
	OPEN @JSON;
		FETCH NEXT FROM @JSON into @JSON_row;
			
		WHILE @@FETCH_STATUS = 0
		BEGIN;
		--PRINT ('JSON_row = ' + @JSON_row);

		SET @timehelper1 = convert(int,convert(bigint,JSON_VALUE(@JSON_row,'$.ProcessDataDateTime'))%60000);
		SET @timehelper2 = convert(int,convert(bigint,JSON_VALUE(@JSON_row,'$.ProcessDataDateTime'))/60000);
		SET @ProcessDataDateTime = DATEADD(ms, @timehelper1, DATEADD(minute, @timehelper2, convert(DateTime2, DATEFROMPARTS(1970,1,1))));
		--PRINT (@ProcessDataDateTime);
		SET @Description = JSON_VALUE(@JSON_row,'$.Description');
		--PRINT (@Description);
		SET @PartNumber = JSON_VALUE(@JSON_row,'$.PartNumber');
		--PRINT (@PartNumber);
		SET @TrackingNumber = JSON_VALUE(@JSON_row,'$.TrackingNumber');
		--PRINT (@TrackingNumber);
		SET @timehelper1 = convert(int,convert(bigint,JSON_VALUE(@JSON_row,'$.ProcessDataDateTimeTargetValue'))%60000);
		SET @timehelper2 = convert(int,convert(bigint,JSON_VALUE(@JSON_row,'$.ProcessDataDateTimeTargetValue'))/60000);
		SET @ProcessDataDateTimeTargetValue = DATEADD(ms, @timehelper1, DATEADD(minute, @timehelper2, convert(DateTime2, DATEFROMPARTS(1970,1,1))));
		--PRINT (@ProcessDataDateTimeTargetValue);
		SET @ProcessDataPrecision = JSON_VALUE(@JSON_row,'$.ProcessDataPrecision');
		--PRINT (@ProcessDataPrecision);
		SET @OrderNumber = JSON_VALUE(@JSON_row,'$.OrderNumber');
		--PRINT (@OrderNumber);
		SET @Unit = JSON_VALUE(@JSON_row,'$.Unit');
		--PRINT (@Unit);
		SET @timehelper1 = convert(int,convert(bigint,JSON_VALUE(@JSON_row,'$.ProductionDateTime'))%60000);
		SET @timehelper2 = convert(int,convert(bigint,JSON_VALUE(@JSON_row,'$.ProductionDateTime'))/60000);
		SET @ProductionDateTime = DATEADD(ms, @timehelper1, DATEADD(minute, @timehelper2, convert(DateTime2, DATEFROMPARTS(1970,1,1))));
		--PRINT (@ProductionDateTime);
        SET @ProcessDataUSL                = convert(float, replace(JSON_VALUE(@JSON_row,'$.ProcessDataUSL'),',','.'));
		--PRINT (@ProcessDataUSL               );
		SELECT @ProcessDataStringTargetValue=ProcessDataStringTargetValue FROM OPENJSON(@JSON_row) WITH (ProcessDataStringTargetValue varchar(max) '$.ProcessDataStringTargetValue')
		--PRINT (@ProcessDataStringTargetValue );
        SET @PartNumberRevision            = JSON_VALUE(@JSON_row,'$.PartNumberRevision');
		--PRINT (@PartNumberRevision           );
        SET @ProcessDataLSL                = convert(float, replace(JSON_VALUE(@JSON_row,'$.ProcessDataLSL'),',','.'));
		--PRINT (@ProcessDataLSL               );
        SET @Identifier                    = JSON_VALUE(@JSON_row,'$.Identifier');
		--PRINT (@Identifier                   );
        SET @ProcessDataTargetValueName    = JSON_VALUE(@JSON_row,'$.ProcessDataTargetValueName');
		--PRINT (@ProcessDataTargetValueName   );
        SET @ProcessDataFloat              = convert(float, replace(JSON_VALUE(@JSON_row,'$.ProcessDataFloat'),',','.'));
		--PRINT (@ProcessDataFloat             );
        SET @ProcessDataTargetValueTolUnit = JSON_VALUE(@JSON_row,'$.ProcessDataTargetValueTolUnit');
		--PRINT (@ProcessDataTargetValueTolUnit);
        SET @ProcessDataTolerancePos       = JSON_VALUE(@JSON_row,'$.ProcessDataTolerancePos');
		--PRINT (@ProcessDataTolerancePos      );
        SET @isProcessDataFloat            = JSON_VALUE(@JSON_row,'$.isProcessDataFloat');
		--PRINT (@isProcessDataFloat           );
		SELECT @ProcessDataString=ProcessDataString FROM OPENJSON(@JSON_row) WITH (ProcessDataString varchar(max) '$.ProcessDataString')
		--PRINT (@ProcessDataString            );
        SET @ProcessDataLowerLimitName     = JSON_VALUE(@JSON_row,'$.ProcessDataLowerLimitName');
		--PRINT (@ProcessDataLowerLimitName    );
        SET @isProcessDataString           = JSON_VALUE(@JSON_row,'$.isProcessDataString');
		--PRINT (@isProcessDataString          );
        SET @ProcessDataToleranceNeg       = JSON_VALUE(@JSON_row,'$.ProcessDataToleranceNeg');
		--PRINT (@ProcessDataToleranceNeg      );
        SET @ProcessDataUpperLimitName     = JSON_VALUE(@JSON_row,'$.ProcessDataUpperLimitName');
		--PRINT (@ProcessDataUpperLimitName    );
        SET @isProcessDataDateTime         = JSON_VALUE(@JSON_row,'$.isProcessDataDateTime');
		--PRINT (@isProcessDataDateTime        );
        SET @SerialNumber                  = JSON_VALUE(@JSON_row,'$.SerialNumber');
		--PRINT (@SerialNumber                 );
        SET @ProcessDataFloatTargetValue   = convert(float, replace(JSON_VALUE(@JSON_row,'$.ProcessDataFloatTargetValue'),',','.'));
		--PRINT (@ProcessDataFloatTargetValue  );
        SET @ProcessDataType               = JSON_VALUE(@JSON_row,'$.ProcessDataType');
		--PRINT (@ProcessDataType              );
        SET @ProcessDataType2              = JSON_VALUE(@JSON_row,'$.ProcessDataType2');
		--PRINT (@ProcessDataType2             );
		SELECT @ProcessDataBlob=ProcessDataBlob FROM OPENJSON(@JSON_row) WITH (ProcessDataBlob varchar(max) '$.ProcessDataBlob')
		--PRINT (@ProcessDataBlob            );
        SET @isProcessDataBlob            = JSON_VALUE(@JSON_row,'$.isProcessDataBlob');
		--PRINT (@isProcessDataBlob           );


		SET @ProcessDataType = isnull(@ProcessDataType,'NULL');
		--PRINT (@ProcessDataType);
		SET @TrackingNumber = isnull(@TrackingNumber,'NULL');
		--PRINT (@TrackingNumber);
		SET @Identifier = isnull(@Identifier,'NULL');
		--PRINT (@Identifier);
		SET @ProductionDateTime = isnull(@ProductionDateTime,convert(datetime2,'1970-01-01'));
		--PRINT (@ProductionDateTime);

		if (@isProcessDataFloat = 1)
		BEGIN
			insert into [smartKPIProcessFloatData] (Machine, ProductionTime, ProcesDataType, ProcesDataType2, TrackingNumber, Identifier)
			select @Machine, @ProductionDateTime, @ProcessDataType, @ProcessDataType2, @TrackingNumber, @Identifier
			where not exists (select 'ok' from [smartKPIProcessFloatData] 
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier);

			update [smartKPIProcessFloatData] 
			set [ProcesData] = @ProcessDataFloat
				  ,[SerialNumber] = @SerialNumber
				  ,[PartNumber] = @PartNumber
				  ,[OrderNumber] = @OrderNumber
				  ,[ProcesDataLSL] = @ProcessDataLSL
				  ,[ProcesDataUSL] = @ProcessDataUSL
				  ,[Unit] = @Unit
				  ,[description] = @Description
				  ,[ProcessDataTargetValueTolUnit] = @ProcessDataTargetValueTolUnit
				  ,[PartNumberRevision] = @PartNumberRevision
				  ,[ProcesDataPrecision] = @ProcessDataPrecision
				  ,[ProcesDataTargetValueName] = @ProcessDataTargetValueName
				  ,[ProcesDataTargetValue] = @ProcessDataFloatTargetValue
				  ,[ProcesDataLowerLimitName] = @ProcessDataLowerLimitName
				  ,[ProcesDataUpperLimitName] = @ProcessDataUpperLimitName
				  ,[ProcesDataTolerancePosFloat] = @ProcessDataTolerancePos
				  ,[ProcesDataToleranceNegFloat] = @ProcessDataToleranceNeg
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier;

		END;
		if (@isProcessDataString = 1)
		BEGIN
			insert into [smartKPIProcessStringData] (Machine, ProductionTime, ProcesDataType, ProcesDataType2, TrackingNumber, Identifier)
			select @Machine, @ProductionDateTime, @ProcessDataType, @ProcessDataType2, @TrackingNumber, @Identifier
			where not exists (select 'ok' from [smartKPIProcessStringData] 
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier);

			update [smartKPIProcessStringData] 
			set [ProcesData] = @ProcessDataString
				  ,[SerialNumber] = @SerialNumber
				  ,[PartNumber] = @PartNumber
				  ,[OrderNumber] = @OrderNumber
				  ,[description] = @Description
				  ,[PartNumberRevision] = @PartNumberRevision
				  ,[ProcesDataTargetValue] = @ProcessDataStringTargetValue
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier;

		END;
		
		if (@isProcessDataDateTime = 1)
		BEGIN
			insert into [smartKPIProcessDateTimeData] (Machine, ProductionTime, ProcesDataType, ProcesDataType2, TrackingNumber, Identifier)
			select @Machine, @ProductionDateTime, @ProcessDataType, @ProcessDataType2, @TrackingNumber, @Identifier
			where not exists (select 'ok' from [smartKPIProcessDateTimeData] 
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier);

			update [smartKPIProcessDateTimeData] 
			set [ProcesData] = @ProcessDataDateTime
				  ,[SerialNumber] = @SerialNumber
				  ,[PartNumber] = @PartNumber
				  ,[OrderNumber] = @OrderNumber
				  ,[description] = @Description
				  ,[PartNumberRevision] = @PartNumberRevision
				  ,[ProcesDataTargetValue] = @ProcessDataDateTimeTargetValue
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier;

		END;
		
		if (@isProcessDataBlob = 1)
		BEGIN
			insert into [smartKPIProcessStringData] (Machine, ProductionTime, ProcesDataType, ProcesDataType2, TrackingNumber, Identifier)
			select @Machine, @ProductionDateTime, @ProcessDataType, @ProcessDataType2, @TrackingNumber, @Identifier
			where not exists (select 'ok' from [smartKPIProcessStringData] 
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier);

			update [smartKPIProcessStringData] 
			set [ProcesData] = @ProcessDataBlob
				  ,[SerialNumber] = @SerialNumber
				  ,[PartNumber] = @PartNumber
				  ,[OrderNumber] = @OrderNumber
				  ,[description] = @Description
				  ,[PartNumberRevision] = @PartNumberRevision
				  ,[ProcesDataTargetValue] = @ProcessDataStringTargetValue
			where Machine=@Machine
			and ProductionTime=@ProductionDateTime
			and ProcesDataType=@ProcessDataType
			and ProcesDataType2=@ProcessDataType2
			and TrackingNumber=@TrackingNumber
			and Identifier=@Identifier;

		END;

	FETCH NEXT FROM @JSON into @JSON_row;
			END;
	CLOSE @JSON;
	DEALLOCATE @JSON;
END;


GO

