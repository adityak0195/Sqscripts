--------------------------------------------------------------
--------------------------------------------------------------
print '-- CalulateKPIsForSinglePlant';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateKPIsForSinglePlant') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE CalulateKPIsForSinglePlant  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE [dbo].[CalulateKPIsForSinglePlant]
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Plant varchar(255),
	@Machines varchar(max)
AS
BEGIN;

	DECLARE @sql nvarchar(max)
	DECLARE @ParmDefinition nvarchar(1000);
	declare @CalculationType varchar(255);

	Declare @CVS_DMS_Day_Offset_in_Minutes int;
	declare @StartDateOffsetForSingleMachine datetime2 = @StartDate;
	declare @EndDateOffsetForSingleMachine datetime2 = @EndDate;
	declare @table table (Machine varchar(255), KPIName varchar(255), KPICalculationBase varchar(255), KPIDateTime datetime2, KPIDateTimeEnd datetime2, KPIFloatValue float);
	declare @division varchar(255);

	BEGIN TRY
	
        declare @DeleteArchivedDataTimeInMonths int;
        declare @DeleteArchivedProcessDataTimeInMonths int;

		select @DeleteArchivedDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedDataTimeInMonths' and [Machine] = 'DB';
		select @DeleteArchivedProcessDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedProcessDataTimeInMonths' and [Machine] = 'DB';


		declare @deleteDate dateTime2 = dateadd(month,-1 * @DeleteArchivedDataTimeInMonths,getutcdate());
		declare @deleteDateForProcessAndMachineData dateTime2 = dateadd(month,-1 * @DeleteArchivedProcessDataTimeInMonths,getutcdate());

        if (@StartDate >= @deleteDate and  @StartDate >= @deleteDateForProcessAndMachineData)
        BEGIN
	

			set @ParmDefinition = N'@division varchar(255) OUTPUT';
		
			SET @sql = 'SELECT @division=TextValue '+
				'FROM [smartKPIMachineKeyValueData] '+
				'where Machine = (select top(1) [TextValue] FROM [smartKPIMachineKeyValueData] '+
				'where Machine in ('+@Machines+') '+
				'and PropertyKey = ''KBPlantThing'') COLLATE database_default '+
				'and PropertyKey = ''KBDivisionThing''';
			EXEC  sp_executesql @sql, @ParmDefinition, @division OUTPUT;

			if @division = 'KBTruckDivisionThing'
			BEGIN
				--sum(KPIs)
				SET @sql = 'select '''+@Plant+''', KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, sum(KPIFloatValue) '+
						'from smartKPIValues '+
						'where KPITimeBase = '''+@CalculationBase +''' '+
						'and KPIDateTime = '''+convert(varchar,@StartDate)+ ''' '+
						'and KPIDateTimeEnd = '''+convert(varchar,@EndDate) + ''' '+
						'and Machine in ('+@Machines+') '+
						'and KPICalculationBase = ''GetKPIsTruckWorker'' '+
						'and KPIName in ('+
							'''OutputIO'','+
							'''OutputNIO'','+ 
							'''CVS: Planned number of workers from SAP'','+ 
							'''CVS: Planned working time in seconds (from start to end of shift)'','+
							'''ProductionTarget'','+
							'''CVS: Atoss Target'','+
							'''CVS: Retests'','+
							'''CVS: Sum of login times at line'','+
							'''CVS: Sum of processing times (CO) in seconds'','+
							'''CVS: Sum tgmax times for IO parts in seconds'','+
							'''CVS: Sum tgmax times for NIO parts in seconds'','+
							'''CVS: Actual number of workers at Line'','+
							'''CVS DLP1: Time in seconds passed till now and within shift(s)'','+
							'''CVS DLP1: Time in seconds within shift(s)'','+
							'''CVS DLP1: Calculated Production Target till now'','+
							'''CVS DLP1: Calculated Production Target'','+
							'''CVS: Time base for utilization in seconds'','+
							'''CVS DLP1: Parts Actual'' '+
							') '+
						'group by KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd ';

				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					EXEC (@sql);

				--AVG(KPIs)
				SET @sql = 'select '''+@Plant+''', KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, round(AVG(KPIFloatValue),2) '+
						'from smartKPIValues '+
						'where KPITimeBase = '''+@CalculationBase +''' '+
						'and KPIDateTime = '''+convert(varchar,@StartDate)+ ''' '+
						'and KPIDateTimeEnd = '''+convert(varchar,@EndDate) + ''' '+
						'and Machine in ('+@Machines+') '+
						'and KPICalculationBase = ''GetKPIsTruckWorker'' '+
						'and KPIName in ('+
							'''CVS: APO shift factor in percent'' '+
							') '+
						'group by KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd ';

				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					EXEC (@sql);

				--RQ
				declare @KPIPartsIO float = 0.0;
				declare @KPIPartsNIO float = 0.0;
				declare @KPIPartsRework float = 0.0;
				
				select @KPIPartsIO=KPIFloatValue, @CalculationType=KPICalculationBase from @table where KPIName = 'OutputIO';
				select @KPIPartsNIO=KPIFloatValue from @table where KPIName = 'OutputNIO';
				select @KPIPartsRework=KPIFloatValue from @table where KPIName = 'CVS: Retests';

				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select @Plant, 'RQ', 'GetKPIsTruckWorker', @StartDate, @EndDate, dbo.GetCVSRQ(@KPIPartsIO,@KPIPartsNIO,@KPIPartsRework);

				--OEE
				declare @timeBaseOee float = 0.0;
				declare @KPIsumTgmaxIO float = 0.0;
				
				select @timeBaseOee=KPIFloatValue from @table where KPIName = 'CVS: Planned working time in seconds (from start to end of shift)';
				select @KPIsumTgmaxIO=KPIFloatValue from @table where KPIName = 'CVS: Sum tgmax times for IO parts in seconds';

				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select @Plant, 'CVS: OEE (Version 2)', 'GetKPIsTruckWorker', @StartDate, @EndDate, dbo.GetCVSOEE(@KPIsumTgmaxIO,@timeBaseOee);
				
				--Utilization
				declare @timeBaseUtilization float = 0.0;
				
				select @timeBaseUtilization=KPIFloatValue from @table where KPIName = 'CVS: Time base for utilization in seconds';
				
				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select @Plant, 'CVS: Utilization', 'GetKPIsTruckWorker', @StartDate, @EndDate, dbo.GetCVSUtilization(@KPIsumTgmaxIO,@timeBaseUtilization);
					
					
				--DLP1
				declare @PartsActual float = 0.0;
				declare @OperatorsActual float = 0.0;
				declare @PartsTarget float = 0.0;
				declare @OperatorsTargetTime float = 0.0;
				declare @OperatorsTargetWorkers float = 0.0;
				declare @Actual float = 0.0;
				declare @Target float = 0.0;
				
				select @PartsActual=KPIFloatValue from @table where KPIName = 'CVS DLP1: Parts Actual';
				select @OperatorsActual=KPIFloatValue from @table where KPIName = 'CVS: Sum of login times at line';
				select @PartsTarget=KPIFloatValue from @table where KPIName = 'CVS DLP1: Calculated Production Target';
				select @OperatorsTargetTime=KPIFloatValue from @table where KPIName = 'CVS DLP1: Time in seconds within shift(s)';
				select @OperatorsTargetWorkers=KPIFloatValue from @table where KPIName = 'CVS: Planned number of workers from SAP';
				set @Actual = dbo.GetCVSDlp1(@PartsActual,@OperatorsActual,1);
				set @Target = dbo.GetCVSDlp1(@PartsTarget,@OperatorsTargetTime,@OperatorsTargetWorkers);

				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select @Plant, 'CVS DLP1: Actual', 'GetKPIsTruckWorker', @StartDate, @EndDate, @Actual;
				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select @Plant, 'CVS DLP1: Calculated Target', 'GetKPIsTruckWorker', @StartDate, @EndDate, @Target;
				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select @Plant, 'CVS DLP1: Ratio (Actual/Calculated Target)', 'GetKPIsTruckWorker', @StartDate, @EndDate, dbo.GetCVSDlp1Ratio(@Actual,@Target);


				--sum(KPIs)
				SET @sql = 'select '''+@Plant+''', KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, sum(KPIFloatValue) '+
						'from smartKPIValues '+
						'where KPITimeBase = '''+@CalculationBase +''' '+
						'and KPIDateTime = '''+convert(varchar,@StartDate)+ ''' '+
						'and KPIDateTimeEnd = '''+convert(varchar,@EndDate) + ''' '+
						'and Machine in ('+@Machines+') '+
						'and KPIName like (''CVS: Main Station Downtime Statistic%'') '+
						'group by KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd ';
				
				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					EXEC (@sql);

			END;
	--		ELSE if @division = 'KBRailDivisionThing'
	--		BEGIN
				-- to do

	--		END;
			


			WAITFOR DELAY '00:00:01';  
			delete from [smartKPIValues] where KPIDateTime = @StartDateOffsetForSingleMachine and KPIDateTimeEnd = @EndDateOffsetForSingleMachine and Machine = @Plant;
			WAITFOR DELAY '00:00:01';  
			insert into [smartKPIValues] (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue, KPITimeBase)
				select Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue, @CalculationBase from @table;
		END;

	END TRY  
	BEGIN CATCH  
		set @CVS_DMS_Day_Offset_in_Minutes = 0;
	END CATCH 


END;
GO
