--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalculateSummedUpKPIs_Postprocessing';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalculateSummedUpKPIs_Postprocessing') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalculateSummedUpKPIs_Postprocessing  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_CalculateSummedUpKPIs_Postprocessing
	@Id varchar(255)
AS
BEGIN;

    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


    declare @query varchar(max);
    declare @inputDataTableName  varchar(255) = 'TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_IN_'+@Id;
    declare @outputDataTableName varchar(255) = 'TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_OUT_'+@Id;

    set @query = 'drop table '+@inputDataTableName;
    EXEC(@query);    

    set @query = 'drop table '+@outputDataTableName;
    EXEC(@query);    

END;
GO
