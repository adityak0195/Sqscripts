--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalulateKPIsForSingleModule';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalulateKPIsForSingleModule') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleModule  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleModule
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Module varchar(255)
AS
BEGIN;

    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


    declare @xx varchar(20) = 'To be implemented';


END;
GO
