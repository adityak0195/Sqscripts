--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalulateKPIsForSingleMachine';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalulateKPIsForSingleMachine') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleMachine  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleMachine
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Machine varchar(255)
AS
BEGIN;

    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


    exec CalulateKPIsForSingleMachine 
        @StartDate,
        @EndDate,
        @CalculationBase,
        @Machine;


END;
GO
