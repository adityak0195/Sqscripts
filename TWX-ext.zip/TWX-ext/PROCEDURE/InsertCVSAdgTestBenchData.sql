--------------------------------------------------------------
--------------------------------------------------------------
print '-- InsertCVSAdgTestBenchData';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertCVSAdgTestBenchData') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE InsertCVSAdgTestBenchData  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE InsertCVSAdgTestBenchData
	@JSON_String varchar(max),
	@Machine varchar(255)
AS
BEGIN;
SET NOCOUNT ON;
EXEC InsertTestBenchDataJSON_V9
	@JSON_String=@JSON_String,
	@Machine=@Machine
	
END;
GO