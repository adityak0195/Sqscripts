-- =============================================
-- Author: Martin Flassak
-- Create date: 03/2024
-- Description: Triggers the KPI calculation for all Machines and Stations to get daily and shift based results
-- Parameters:
-- @startDayForCalculation,date not null - starting date for the calculation
-- @daysBack,int not null - Number of days the calculation is backwards done related to the starting date,including shifts defined in TEMP_SmartKPIFullShift 
--                           0  = only starting date day with all shifts of starting date day (if defined in TEMP_SmartKPIFullShift); 
--                           -1 = only starting date day,only currently running shift (if defined in TEMP_SmartKPIFullShift and starting date is today --> getutcdate() is in current shift)
-- Returns: nothing
-- =============================================


if not exists (select * from sys.objects where object_id = object_id(N'CalculateDayShiftKPIs') and type in (N'P',N'PC'))
exec('create procedure CalculateDayShiftKPIs  as begin set nocount on; end')
GO

alter procedure CalculateDayShiftKPIs 
    @startDayForCalculation date
    ,@daysBack int
as
begin

    set nocount on;

--Check input variables
--throw exeption if @startDayForCalculation is null
    if (@startDayForCalculation is null)
    begin
        throw 51000,'startdayforcalculation is null.',1;
    end
--throw exeption if @daysBack is null
    if (@daysBack is null)
    begin
        throw 51000,'daysback is null.',1;
    end


    
--DECLARATIONS
    declare @startDayForCalculationAsDateTime datetime2 = DATEFROMPARTS(year(@startDayForCalculation),month(@startDayForCalculation),day(@startDayForCalculation));
    declare @deleteArchivedDataTimeInMonths int;
    declare @deviceList table 
        (plant varchar(255)
        ,area varchar(255)
        ,machine varchar(255)
        ,station varchar(255)
        ,type varchar(255)
        ,offset int
        );
    declare @maxCalculationStartDate dateTime2;
    declare @deviceListCursor cursor;
    declare @shiftcursor cursor;
    declare @plant varchar(255);
    declare @area varchar(255);
    declare @machine varchar(255);
    declare @station varchar(255);
    declare @type varchar(255);
    declare @offset int;
    declare @finalStartOfDayUtcBased datetime2;
    declare @finalEndOfDayUtcBased datetime2;
    declare @shiftStartOfDayUtcBased datetime2;
    declare @shiftEndOfDayUtcBased datetime2;
    declare @dayCounter int;

--getting archiving date
    select 
        @deleteArchivedDataTimeInMonths=[FloatValue] 
    from 
        smartKPIMachineKeyValueData
    where 
        PropertyKey = 'DeleteArchivedDataTimeInMonths' 
        and [Machine] = 'DB';
    
    set @maxCalculationStartDate = dateadd(day,1,dateadd(month,-1 * @deleteArchivedDataTimeInMonths,getutcdate()));
    print 'maxCalculationStartDate';
    print @maxCalculationStartDate;

--throw exeption if start date older then archiving date --> no data
    if (@startDayForCalculation < @maxCalculationStartDate)
    begin
        throw 51000,'startdayforcalculation older then archiving date.',1;
    end

--set max number of days backward in relation to archiving date
    if (@daysBack > datediff(day,@maxCalculationStartDate,@startDayForCalculation))
    begin
        set @daysBack = datediff(day,@maxCalculationStartDate,@startDayForCalculation);
    end
    
--Get List of Plants/Machines/Stations
    insert into @deviceList (plant,area,machine,station,type,offset)
        select 
            plant
            ,area
            ,machine
            ,station
            ,type
            ,isnull(offset,0)
        from 
            dbo.GetDeviceListForAreasMachinesStations();


    set 
        @deviceListCursor = cursor for 
    select 
        plant
        ,area
        ,machine
        ,station
        ,type
        ,offset 
    from 
        @deviceList 
    where 
        type = 'KBLocalMachineThingTemplate'
    ;

    print '************************ Calc Machine ************************' 
    print '-------------------------------------'
    print getutcdate()
    print '-------------------------------------'
    open @deviceListCursor;
        fetch next 
        from @deviceListCursor 
        into 
            @plant
            ,@area
            ,@machine
            ,@station
            ,@type
            ,@offset

        while @@fetch_status = 0
        begin;
            
            set @finalStartOfDayUtcBased = dbo.GetUTCTimeFromLocalTime(dateadd(minute,@offset,@startDayForCalculationAsDateTime));
            set @finalEndOfDayUtcBased = dbo.GetUTCTimeFromLocalTime(dateadd(day,1,dateadd(minute,@offset,@startDayForCalculationAsDateTime)));

            print '************************ Machine************************' 
            print '-------------------------------------'
            print getutcdate()
            print '-------------------------------------'
            print @offset
            print @machine
            print 'day';
            print @finalStartOfDayUtcBased;
            print @finalEndOfDayUtcBased;
            
            --Calculation  for Machines --> day
            execute CalulateKPIsForSingleMachine @StartDate = @finalStartOfDayUtcBased,@EndDate=@finalEndOfDayUtcBased,@CalculationBase='day',@Machine=@machine;

            if (@daysBack = -1)
            begin
                set 
                    @shiftcursor = cursor for 
                select CurrentStartTime,CurrentEndTime 
                from 
                    TEMP_SmartKPIFullShift 
                where 
                    Machine = @machine 
                    and CurrentStartTime >= @finalStartOfDayUtcBased 
                    and CurrentEndTime <= @finalEndOfDayUtcBased
                    and CurrentStartTime <= getutcdate() 
                    and CurrentEndTime >= getutcdate()
                ;
            end
            else
            begin
                set 
                    @shiftcursor = cursor for 
                select 
                    CurrentStartTime
                    ,CurrentEndTime 
                from 
                    TEMP_SmartKPIFullShift 
                where 
                    Machine = @machine 
                    and CurrentStartTime >= @finalStartOfDayUtcBased 
                    and CurrentEndTime <= @finalEndOfDayUtcBased
                ;
            end
                    
            open @shiftcursor;
                fetch next 
                from 
                    @shiftcursor 
                into 
                    @shiftStartOfDayUtcBased
                    ,@shiftEndOfDayUtcBased

                while @@fetch_status = 0
                begin;
                    
                    print 'shift';
                    print @shiftStartOfDayUtcBased;
                    print @shiftEndOfDayUtcBased;
                    
                    --Calculation  for Machines --> shift
                    execute CalulateKPIsForSingleMachine @StartDate = @shiftStartOfDayUtcBased,@EndDate=@shiftEndOfDayUtcBased,@CalculationBase='shift',@Machine=@machine;
                    
                fetch next 
                from 
                    @shiftcursor 
                into 
                    @shiftStartOfDayUtcBased
                    ,@shiftEndOfDayUtcBased
                ;
                end;
                close @shiftcursor;
            deallocate @shiftcursor;
            
            
            set @dayCounter = 0;
            while (@daysBack > @dayCounter and @finalStartOfDayUtcBased > @maxCalculationStartDate)
            begin

                set @dayCounter = @dayCounter + 1;
                set @finalStartOfDayUtcBased = dateadd(day,-1,@finalStartOfDayUtcBased);
                set @finalEndOfDayUtcBased = dateadd(day,-1,@finalEndOfDayUtcBased);
                print 'day';
                print @finalStartOfDayUtcBased;
                print @finalEndOfDayUtcBased;
                
                --Calculation  for Machines --> day --> loop days backwards
                execute CalulateKPIsForSingleMachine @StartDate = @finalStartOfDayUtcBased,@EndDate=@finalEndOfDayUtcBased,@CalculationBase='day',@Machine=@machine;

                set 
                    @shiftcursor = cursor for 
                select CurrentStartTime,CurrentEndTime 
                from 
                    TEMP_SmartKPIFullShift 
                where 
                    Machine = @machine 
                    and CurrentStartTime >= @finalStartOfDayUtcBased 
                    and CurrentEndTime <= @finalEndOfDayUtcBased
                ;
                open @shiftcursor;
                    fetch next 
                    from 
                        @shiftcursor 
                    into 
                        @shiftStartOfDayUtcBased
                        ,@shiftEndOfDayUtcBased
                    ;

                    while @@fetch_status = 0
                    begin;
                        
                        print 'shift';
                        print @shiftStartOfDayUtcBased;
                        print @shiftEndOfDayUtcBased;
                        
                        --Calculation  for Machines --> shift --> loop shifts and days backwards
                        execute CalulateKPIsForSingleMachine @StartDate = @shiftStartOfDayUtcBased,@EndDate=@shiftEndOfDayUtcBased,@CalculationBase='shift',@Machine=@machine;
                        
                    fetch next 
                    from 
                        @shiftcursor 
                    into 
                        @shiftStartOfDayUtcBased
                        ,@shiftEndOfDayUtcBased
                    ;
                    end;
                    close @shiftcursor;
                deallocate @shiftcursor;

            end;
            print '-------------------------------------'
            print getutcdate()
            print '-------------------------------------'
            
            fetch next 
            from 
                @deviceListCursor 
            into 
                @plant
                ,@area
                ,@machine
                ,@station
                ,@type
                ,@offset
            ;
        end;
        close @deviceListCursor;
    deallocate @deviceListCursor;

    print '-------------------------------------'
    print getutcdate()
    print '-------------------------------------'

    set 
        @deviceListCursor = cursor for 
    select 
        plant
        ,area
        ,machine
        ,station
        ,type
        ,offset 
    from 
        @deviceList 
    where 
        type = 'KBLocalStationThingTemplate'
    ;

    print '************************ Calc Station ************************' 
    print '-------------------------------------'
    print getutcdate()
    print '-------------------------------------'
    open @deviceListCursor;
        fetch next 
        from 
            @deviceListCursor 
        into 
            @plant
            ,@area
            ,@machine
            ,@station
            ,@type
            ,@offset
    ;

        while @@fetch_status = 0
        begin;
            
            set @finalStartOfDayUtcBased = dbo.GetUTCTimeFromLocalTime(dateadd(minute,@offset,@startDayForCalculationAsDateTime));
            set @finalEndOfDayUtcBased = dbo.GetUTCTimeFromLocalTime(dateadd(day,1,dateadd(minute,@offset,@startDayForCalculationAsDateTime)));

            print '************************ Station************************' 
            print '-------------------------------------'
            print getutcdate()
            print '-------------------------------------'
            print @offset
            print @machine
            print @station
            print 'day';
            print @finalStartOfDayUtcBased;
            print @finalEndOfDayUtcBased;
            
            --Calculation  for Station --> day
            execute CalulateKPIsForSingleStation @StartDate = @finalStartOfDayUtcBased,@EndDate=@finalEndOfDayUtcBased,@CalculationBase='day',@Machine=@machine,@Station = @station;

            set 
                @shiftcursor = cursor for 
            select 
                CurrentStartTime
                ,CurrentEndTime 
            from 
                TEMP_SmartKPIFullShift 
            where 
                Machine = @machine 
                and CurrentStartTime >= @finalStartOfDayUtcBased 
                and CurrentEndTime <= @finalEndOfDayUtcBased
            ;
            open @shiftcursor;
                fetch next 
                from 
                    @shiftcursor 
                into 
                    @shiftStartOfDayUtcBased
                    ,@shiftEndOfDayUtcBased
                ;

                while @@fetch_status = 0
                begin;
                    
                    print 'shift';
                    print @shiftStartOfDayUtcBased;
                    print @shiftEndOfDayUtcBased;
                    
                    --Calculation  for Station --> shift
                    execute CalulateKPIsForSingleStation @StartDate = @shiftStartOfDayUtcBased,@EndDate=@shiftEndOfDayUtcBased,@CalculationBase='shift',@Machine=@machine,@Station = @station;
                    
                fetch next 
                from 
                    @shiftcursor 
                into 
                    @shiftStartOfDayUtcBased
                    ,@shiftEndOfDayUtcBased
                ;
                end;
                close @shiftcursor;
            deallocate @shiftcursor;

            set @dayCounter = 0;
            while (@daysBack > @dayCounter and @finalStartOfDayUtcBased > @maxCalculationStartDate)
            begin
                set @dayCounter = @dayCounter + 1;
                set @finalStartOfDayUtcBased = dateadd(day,-1,@finalStartOfDayUtcBased);
                set @finalEndOfDayUtcBased = dateadd(day,-1,@finalEndOfDayUtcBased);
                print 'day';
                print @finalStartOfDayUtcBased;
                print @finalEndOfDayUtcBased;
            
                --Calculation  for Station --> day --> loop days backwards
                execute CalulateKPIsForSingleStation @StartDate = @finalStartOfDayUtcBased,@EndDate=@finalEndOfDayUtcBased,@CalculationBase='day',@Machine=@machine,@Station = @station;
                
                set 
                    @shiftcursor = cursor for 
                select 
                    CurrentStartTime
                    ,CurrentEndTime 
                from TEMP_SmartKPIFullShift 
                where 
                    Machine = @machine 
                    and CurrentStartTime >= @finalStartOfDayUtcBased 
                    and CurrentEndTime <= @finalEndOfDayUtcBased
                ;
                open @shiftcursor;
                    fetch next 
                    from 
                        @shiftcursor 
                    into 
                        @shiftStartOfDayUtcBased
                        ,@shiftEndOfDayUtcBased
                    ;

                    while @@FETCH_STATUS = 0
                    begin;
                        
                        print 'shift';
                        print @shiftStartOfDayUtcBased;
                        print @shiftEndOfDayUtcBased;
                        
                        --Calculation  for Station --> shift  --> loop shifts and days backwards
                        execute CalulateKPIsForSingleStation @StartDate = @shiftStartOfDayUtcBased,@EndDate=@shiftEndOfDayUtcBased,@CalculationBase='shift',@Machine=@machine,@Station = @station;
                        
                    fetch next from @shiftcursor into @shiftStartOfDayUtcBased,@shiftEndOfDayUtcBased
                    end;
                    close @shiftcursor;
                deallocate @shiftcursor;
            end;
            print '-------------------------------------'
            print getutcdate()
            print '-------------------------------------'
            
            fetch next from @deviceListCursor 
                into @plant
                ,@area
                ,@machine
                ,@station
                ,@type
                ,@offset
            ;
        end;
        close @deviceListCursor;
    deallocate @deviceListCursor;

    print '-------------------------------------'
    print getutcdate()
    print '-------------------------------------'

end;

go

--exec dbo.CalculateDayShiftKPIs @startDayForCalculation='2024-03-01',@daysBack=0;
--exec dbo.CalculateDayShiftKPIs @startDayForCalculation='2024-03-01',@daysBack=1;
-- select distinct KPIName from smartKPIValues where KPIName not like 'CVS: KPI planned working time %' order by 1
--select top(1000) * from smartKPIValues where Machine = 'KBBERAM06MachineThing' and KpiName = 'RQ' and KPITimeBase = 'shift' order by KPIDateTime desc

