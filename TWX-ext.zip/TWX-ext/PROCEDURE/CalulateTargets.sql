--------------------------------------------------------------
--------------------------------------------------------------
print '-- CalulateTargets';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateTargets') AND type in (N'P', N'PC'))
DROP PROCEDURE CalulateTargets;
GO

CREATE PROCEDURE CalulateTargets
AS
BEGIN;

	DECLARE @cnt INT = 0;

	delete from TEMP_SmartKPICVSProductionTargetDetail where StartTime < dateadd(year, -2, getutcdate());

	--fill [TEMP_SmartKPICVSProductionTargetDetail] for shifts
	--> targets for shifts will be filled during FillTEMPSmartKPIFullShift
	Declare @getMachines CURSOR;
	Declare @Machine varchar(255);
	Declare @DateStart datetime2;
	Declare @DateEnd datetime2;

	--fill [smartKPIValues] for days
	SET @cnt = 0;
	WHILE @cnt <= 1
	BEGIN

		set @DateStart = dateadd(day,@cnt,datetimefromparts(DATEPART(year,getutcdate()),DATEPART(month,getutcdate()),DATEPART(day,getutcdate()),0,0,0,0));
		set @DateEnd = dateadd(day,1,@DateStart);

		SET @getMachines = CURSOR for select Machine from smartKPIMachineKeyValueData where TextValue = 'KBLocalMachineThingTemplate' order by 1;
		OPEN @getMachines;
			FETCH NEXT FROM @getMachines into @Machine
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				exec CalulateTarget @Machine=@Machine, @DateStart=@DateStart, @DateEnd=@DateEnd;
				FETCH NEXT FROM @getMachines into @Machine;
			END;
		CLOSE @getMachines;
		DEALLOCATE @getMachines;

	   
	   SET @cnt = @cnt + 1;
	END;	

	--fill [smartKPIValues] for days with offset
	DECLARE @CVS_DMS_Day_Offset_in_Minutes int;
	SET @cnt = 0;
	WHILE @cnt <= 1
	BEGIN


		SET @getMachines = CURSOR for select Machine from smartKPIMachineKeyValueData where TextValue = 'KBLocalMachineThingTemplate' order by 1;
		OPEN @getMachines;
			FETCH NEXT FROM @getMachines into @Machine
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				SELECT @CVS_DMS_Day_Offset_in_Minutes=isnull(convert(int,[FloatValue]),0)
					FROM [smartKPIMachineKeyValueData]
					where Machine = (select [TextValue] FROM [smartKPIMachineKeyValueData]
					where Machine = @Machine
					and PropertyKey = 'KBPlantThing') COLLATE database_default
					and PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes';

				set @DateStart = dateadd(minute,@CVS_DMS_Day_Offset_in_Minutes,dateadd(day,@cnt,datetimefromparts(DATEPART(year,getutcdate()),DATEPART(month,getutcdate()),DATEPART(day,getutcdate()),0,0,0,0)));
				set @DateEnd = dateadd(day,1,@DateStart);

				exec CalulateTarget @Machine=@Machine, @DateStart=@DateStart, @DateEnd=@DateEnd;
				FETCH NEXT FROM @getMachines into @Machine;
			END;
		CLOSE @getMachines;
		DEALLOCATE @getMachines;

	   
	   SET @cnt = @cnt + 1;
	END;	

	--fill [smartKPIValues] for weeks with offset
	SET @cnt = 0;
	WHILE @cnt <= 1
	BEGIN

		SET @getMachines = CURSOR for select Machine from smartKPIMachineKeyValueData where TextValue = 'KBLocalMachineThingTemplate' order by 1;
		OPEN @getMachines;
			FETCH NEXT FROM @getMachines into @Machine
			WHILE @@FETCH_STATUS = 0
			BEGIN;

				SELECT @CVS_DMS_Day_Offset_in_Minutes=isnull(convert(int,[FloatValue]),0)
					FROM [smartKPIMachineKeyValueData]
					where Machine = (select [TextValue] FROM [smartKPIMachineKeyValueData]
					where Machine = @Machine
					and PropertyKey = 'KBPlantThing') COLLATE database_default
					and PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes';

				set @DateStart = dateadd(week,@cnt,datetimefromparts(DATEPART(year,dateadd(day,(datepart(weekday, getutcdate())-2)*-1,getutcdate())),DATEPART(month,dateadd(day,(datepart(weekday, getutcdate())-2)*-1,getutcdate())),DATEPART(day,dateadd(day,(datepart(weekday, getutcdate())-2)*-1,getutcdate())),0,0,0,0));
				set @DateEnd = dateadd(week,1,@DateStart);
				set @DateStart = dateadd(minute,@CVS_DMS_Day_Offset_in_Minutes,@DateStart);
				set @DateEnd = dateadd(minute,@CVS_DMS_Day_Offset_in_Minutes,@DateEnd);

				exec CalulateTarget @Machine=@Machine, @DateStart=@DateStart, @DateEnd=@DateEnd;
				FETCH NEXT FROM @getMachines into @Machine;
			END;
		CLOSE @getMachines;
		DEALLOCATE @getMachines;
	   
	   SET @cnt = @cnt + 1;
	END;	

	--fill [smartKPIValues] for months
	SET @cnt = 0;
	WHILE @cnt < 1
	BEGIN

		set @DateStart = dateadd(month,@cnt,datetimefromparts(DATEPART(year,getutcdate()),DATEPART(month,getutcdate()),1,0,0,0,0));
		set @DateEnd = dateadd(month,1,@DateStart);
		SET @getMachines = CURSOR for select Machine from smartKPIMachineKeyValueData where TextValue = 'KBLocalMachineThingTemplate' order by 1;
		OPEN @getMachines;
			FETCH NEXT FROM @getMachines into @Machine
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				exec CalulateTarget @Machine=@Machine, @DateStart=@DateStart, @DateEnd=@DateEnd;
				FETCH NEXT FROM @getMachines into @Machine;
			END;
		CLOSE @getMachines;
		DEALLOCATE @getMachines;
	   SET @cnt = @cnt + 1;
	END;	

	--fill [smartKPIValues] for years
--	SET @cnt = 0;
--	WHILE @cnt < 1
--	BEGIN
--
--		set @DateStart = dateadd(year,@cnt,datetimefromparts(DATEPART(year,getutcdate()),1,1,0,0,0,0));
--		set @DateEnd = dateadd(year,1,@DateStart);
--		SET @getMachines = CURSOR for select Machine from smartKPIMachineKeyValueData where TextValue = 'KBLocalMachineThingTemplate' order by 1;
--		OPEN @getMachines;
--			FETCH NEXT FROM @getMachines into @Machine
--			WHILE @@FETCH_STATUS = 0
--			BEGIN;
--				exec CalulateTarget @Machine=@Machine, @DateStart=@DateStart, @DateEnd=@DateEnd;
--				FETCH NEXT FROM @getMachines into @Machine;
--			END;
--		CLOSE @getMachines;
--		DEALLOCATE @getMachines;
--	   
--	   SET @cnt = @cnt + 1;
--	END;	


END;
GO
