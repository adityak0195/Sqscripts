--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetSingleKPIRail';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetSingleKPIRail') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetSingleKPIRail  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetSingleKPIRail
	@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@Machine varchar(255),
	@KPIName varchar(255)
AS
BEGIN

	SET NOCOUNT ON
	select @StartDateTime,
			@EndDateTime, 
			Machine, 
			KPIName, 
			KPICalculationBase, 
			KPIDateTime,  
			KPIDateTimeEndOfCalculation,
			[KPIFloatValue], 
			[KPIName] as Label, 
			ROUND([KPIFloatValue],2) as KPI,
			round([KPIFloatValue]/60,2) as TimeInMin,
			round([KPIFloatValue]/60/60,2) as TimeInH, 
			CASE ([KPIName])
				WHEN 'PlannedProductionNIO' then 'Planning Loss' 
				WHEN 'EfficiencyRailShiftAdjustedNIO' then 'Downtime'
				WHEN 'PerformanceRailShiftProdAdjustedNIO' then 'Speed Loss'
				WHEN 'RQNIO' then 'Quality Loss'
				WHEN 'RQIO' then 'Productive Time'
				ELSE ''
			END as Type, 
			CASE ([KPIName])
				WHEN 'PlannedProductionNIO' then 'Plan. L.' 
				WHEN 'EfficiencyRailShiftAdjustedNIO' then 'Downtime'
				WHEN 'PerformanceRailShiftProdAdjustedNIO' then 'Speed L.'
				WHEN 'RQNIO' then 'Qual. L.'
				WHEN 'RQIO' then 'Prod.'
				ELSE ''
			END as  ShortType, 
			CASE ([KPIName])
				WHEN 'PlannedProductionNIO' then 1 
				WHEN 'EfficiencyRailShiftAdjustedNIO' then 2
				WHEN 'PerformanceRailShiftProdAdjustedNIO' then 3
				WHEN 'RQNIO' then 4
				WHEN 'RQIO' then 5
				ELSE 0
			END as  sequenze, 
			0 as persentage, 
			KPIDateTime MinTime, 
			KPIDateTimeEndOfCalculation MaxTime
		from GetCIPKPIsRail(@StartDateTime, @EndDateTime, @Machine)
		where ([KPIName] IN ('PlannedProductionNIO', 'EfficiencyRailShiftAdjustedNIO', 'PerformanceRailShiftProdAdjustedNIO', 'RQNIO', 'RQIO') and @KPIName = 'Utilization')
		OR  ([KPIName] IN ('EfficiencyRailShiftAdjustedNIO', 'PerformanceRailShiftProdAdjustedNIO', 'RQNIO', 'RQIO') and @KPIName = 'OEE')
		OR (KPIName = @KPIName and @KPIName not in ('OEE', 'Utilization'))
		order by sequenze;  
END;

GO

--EXECUTE dbo.GetSingleKPIRail @StartDateTime = [[TimeStart]], @EndDateTime = [[TimeEnd]], @Machine = [[Machine]], @KPIName=[[KPIType]];  
											

--declare @dt1 as DateTime2 = '2019-11-07 02:00:00.000';
--declare @dt2 as DateTime2 = '2019-11-08 02:00:00.000';

--EXECUTE GetSingleKPIRail @StartDateTime = @dt1, @EndDateTime = @dt2, @Machine = 'KBBUD10424-NBH170MachineThing';  
--GO
