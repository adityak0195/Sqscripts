
--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetFullShift';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetFullShift') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetFullShift  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetFullShift
	@Machine varchar(255),
	@ShiftStart DateTime2,
	@UtcTimeOffset int = null
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @table table (CurrentName varchar(255), CurrentStartTime datetime2, CurrentEndTime datetime2);

	insert into @table
	EXECUTE GetFullShiftMinus @Machine = @Machine, @ShiftStart = @ShiftStart, @MinusIterations=0;  	
	
	update @table set CurrentStartTime = CurrentStartTime, CurrentEndTime = CurrentEndTime;
	select * from @table;

END;

GO

--declare @dt as DateTime2 = '2019-02-07 02:00:00.000';

--EXECUTE GetFullShift @Machine = 'KBLisLaa2MachineThing', @ShiftStart = @dt;  
--GO
