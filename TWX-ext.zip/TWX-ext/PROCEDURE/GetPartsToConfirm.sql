--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetPartsToConfirm';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPartsToConfirm') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetPartsToConfirm  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetPartsToConfirm
AS
BEGIN
	SET NOCOUNT ON


exec GetPartsToConfirmRail;
  
END;
GO
