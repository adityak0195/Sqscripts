-------------------------------------------------------------- 
--------------------------------------------------------------
print '-- Remove old PROCEDUREs';
--------------------------------------------------------------
--------------------------------------------------------------
print 'DROP PROCEDURE GetFullShift1;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetFullShift1') AND type in (N'P', N'PC'))
DROP PROCEDURE GetFullShift1;
GO

print 'DROP PROCEDURE KpiLogger;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KpiLogger') AND type in (N'P', N'PC'))
DROP PROCEDURE KpiLogger;
GO

print 'DROP PROCEDURE CalculatePlannedProduction;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculatePlannedProduction') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculatePlannedProduction;
GO

print 'DROP PROCEDURE CalculateKpiRqAndOutput;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateKpiRqAndOutput') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateKpiRqAndOutput;
GO

print 'DROP PROCEDURE CalculateKpiPlannedProduction;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateKpiPlannedProduction') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateKpiPlannedProduction;
GO
	
print 'DROP PROCEDURE CalculateEfficiencyRail;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateEfficiencyRail') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateEfficiencyRail;
GO

print 'DROP PROCEDURE CalculateKpiEfficiencyRail;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateKpiEfficiencyRail') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateKpiEfficiencyRail;
GO

print 'DROP PROCEDURE CalculateUtilizationOeeRail;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateUtilizationOeeRail') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateUtilizationOeeRail;
GO

print 'DROP PROCEDURE CalculateKpisForRailCIP;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateKpisForRailCIP') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateKpisForRailCIP;
GO

print 'DROP PROCEDURE CalculateKpiUtilizationOee2Truck;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateKpiUtilizationOee2Truck') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateKpiUtilizationOee2Truck;
GO

print 'DROP PROCEDURE CalculateKpiUtilizationOeeRail;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateKpiUtilizationOeeRail') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateKpiUtilizationOeeRail;
GO

print 'DROP PROCEDURE CalculatePerformanceRail;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculatePerformanceRail') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculatePerformanceRail;
GO

print 'DROP PROCEDURE CalculateKpiPerformanceRail;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateKpiPerformanceRail') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateKpiPerformanceRail;
GO

print 'DROP PROCEDURE CalculateRqAndOutput;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateRqAndOutput') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateRqAndOutput;
GO

print 'DROP PROCEDURE CalculateUtilizationOee2Truck;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateUtilizationOee2Truck') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateUtilizationOee2Truck;
GO

print 'DROP PROCEDURE CalculateAllKpisForRailCIP;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalculateAllKpisForRailCIP') AND type in (N'P', N'PC'))
DROP PROCEDURE CalculateAllKpisForRailCIP;
GO
