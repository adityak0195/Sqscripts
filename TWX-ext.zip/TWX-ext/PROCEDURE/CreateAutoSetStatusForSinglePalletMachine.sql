--------------------------------------------------------------
--------------------------------------------------------------
print '-- CreateAutoSetStatusForSinglePalletMachine';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CreateAutoSetStatusForSinglePalletMachine') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE CreateAutoSetStatusForSinglePalletMachine  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE CreateAutoSetStatusForSinglePalletMachine
	@station varchar(255)
AS
BEGIN

	DECLARE @lastPieceChange datetime2;
	DECLARE @Operation varchar(255);
	DECLARE @OrderNumber varchar(255);
	DECLARE @MachineLoadingTime float;
	DECLARE @NewStatusTime datetime2;

	SELECT TOP (1) @lastPieceChange=[StatusTime]
	  FROM [smartKPIMachineStatusData]
	  where Machine = @station
	  and StatusType = 'Operator Screen'
	  and Status = 'KBMaschStatus.1.PieceChange'
	  order by StatusTime desc;

	if @lastPieceChange is not null
	BEGIN

		select top (1) @Operation=SAPOperationNumber, @OrderNumber=OrderNumber from smartKPI
			where Station = @station
			and ProductionTime < @lastPieceChange
			order by ProductionTime desc;

		select @MachineLoadingTime=CASE TextValue
											WHEN 'SEC' THEN FloatValue
											WHEN 'MIN' THEN FloatValue * 60
											WHEN 'DAY' THEN FloatValue * 24 * 60 * 60
											ELSE 0	 END
			from smartKPIOrderKeyValueData
			where OrderNumber = @OrderNumber
			and Operation = @Operation
			and PropertyKey1 = 'MachineLoadingTime';

			set @NewStatusTime = dateadd(second, @MachineLoadingTime, @lastPieceChange);

			if (select count(*) 
				from [smartKPIMachineStatusData]
				  where Machine = @station
				  and StatusType = 'Operator Screen'
				  and Status != 'KBMaschStatus.1.PieceChange'
				  and StatusTime > @lastPieceChange
				  and StatusTime <= @NewStatusTime) = 0
				BEGIN
				  insert into [smartKPIMachineStatusData] (Machine, StatusTime, Status, SubStatus, description, StatusType)
				  values (@station, @NewStatusTime, 'KBMaschStatus.1.OI.AutoSet', 'KBMaschStatus.2.OI.AutoSet.Start', 'OIV2 Auto', 'Operator Screen');
				  
				  select @station, @NewStatusTime, 'KBMaschStatus.1.OI.AutoSet' as Status, 'KBMaschStatus.2.OI.AutoSet.Start' as SubStatus, 'OIV2 Auto' as description, 'Operator Screen' as StatusType;
				END


	END;

END;

go
