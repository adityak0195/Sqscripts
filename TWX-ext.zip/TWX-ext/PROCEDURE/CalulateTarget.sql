--------------------------------------------------------------
--------------------------------------------------------------
print '-- CalulateTarget';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateTarget') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE CalulateTarget  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE CalulateTarget
@Machine varchar(255),
@DateStart datetime2, 
@DateEnd datetime2
AS
BEGIN;

	-- WAITFOR DELAY '00:00:01';  
	delete from TEMP_SmartKPICVSProductionTargetDetail where LineThingName = @Machine and StartTime = @DateStart and EndTime = @DateEnd;
	WAITFOR DELAY '00:00:01';
	insert into TEMP_SmartKPICVSProductionTargetDetail (LineThingName,
													StartTime, 
													EndTime, 
													ProductionTime, 
													counter, 
													OrderNumber, 
													SinglePartTargetCount, 
													WorkingTimeInMinutes,
													TimeToProducePartsInMinutes, 
													TimeForProducedParts, 
													ProcessingTime,
													SetupTime,
													ShiftFactorInPercent,
													SumPlannedNumberOfWorkers,
													ProcessNumber,
													FullCyclePartsProduced)
		select @Machine,
				@DateStart, 
				@DateEnd, 
				ProductionTime, 
				counter, 
				OrderNumber, 
				SinglePartTargetCount, 
				WorkingTimeInMinutes,
				TimeToProducePartsInMinutes, 
				TimeForProducedParts, 
				ProcessingTime,
				SetupTime,
				isnull(ShiftFactorInPercent,0),
				isnull(PlannedNumberOfWorkers,0),
				ProcessNumber,
				FullCyclePartsProduced
			from GetCVSProductionTargetFunction1V2(@Machine, @DateStart, @DateEnd);  
	delete from TEMP_SmartKPICVSProductionTarget where LineThingName = @Machine and StartTime = @DateStart and EndTime = @DateEnd;
	WAITFOR DELAY '00:00:01';
	insert into TEMP_SmartKPICVSProductionTarget (LineThingName, StartTime, EndTime, Target, SumPlannedNumberOfWorkers, ShiftFactorInPercent)
		select LineThingName, StartTime, EndTime, count(*), 
			case count(*) when 0 then 0 else round(sum(SumPlannedNumberOfWorkers)/count(*),2) end, 
			case count(*) when 0 then 0 else round(sum(ShiftFactorInPercent)/count(*),2) end 
			from TEMP_SmartKPICVSProductionTargetDetail
			where LineThingName = @Machine and StartTime = @DateStart and EndTime = @DateEnd
			group by LineThingName, StartTime, EndTime;

END;
GO
