--------------------------------------------------------------
--------------------------------------------------------------
print '-- EncryptUserData';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'EncryptUserData') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE EncryptUserData  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE EncryptUserData
AS
BEGIN
	IF NOT EXISTS
	(SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = 'tmp_Staff_message')
	create table tmp_Staff_message 
			(Id bigint not null IDENTITY(1,1) PRIMARY KEY, 
			message varchar(max));


	insert into tmp_Staff_message (message)
	select distinct [Message] from [smartKPIMachineMessageData] 
	where [MessageType1] = 'STAFF'
	and [MessageType2] = 'Operator'
	and  [Message] not like '%='
	and  [Message] not like 'User_%';


	update [smartKPIMachineMessageData]
	set [Message] = (select 'User_'+convert(varchar,Id) from tmp_Staff_message where message = [Message])
	where [MessageType1] = 'STAFF'
	and [MessageType2] = 'Operator'
	and  [Message] in (select message from tmp_Staff_message);


	drop table tmp_Staff_message; 

END;
GO

exec EncryptUserData;

go
