--------------------------------------------------------------
--------------------------------------------------------------
print '-- RunIndexCheckAndDefragmentation';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'RunIndexCheckAndDefragmentation') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE RunIndexCheckAndDefragmentation AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE [dbo].[RunIndexCheckAndDefragmentation]
AS
BEGIN
SET IMPLICIT_TRANSACTIONS OFF;	
	DECLARE @commands TABLE (id INT IDENTITY(1,1), command NVARCHAR(MAX));
	DECLARE @IndexesQuantity INT;
	
	BEGIN TRY 
		IF NOT exists(SELECT Machine from smartKPIKepwareConnectorPointer where Machine='IsIndexDefragmentationRunning')
			insert into smartKPIKepwareConnectorPointer (Machine, UpdatedId) VALUES ('IsIndexDefragmentationRunning',0)

		IF exists(SELECT Machine from smartKPIKepwareConnectorPointer where Machine='IsIndexDefragmentationRunning' and UpdatedId=0)
		BEGIN
			UPDATE smartKPIKepwareConnectorPointer SET LastRun=getutcdate(), UpdatedId=1 WHERE Machine='IsIndexDefragmentationRunning';
			insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'Process Started' );
			WITH HighFragmentedIndexes (avg_fragmentation_in_percent, page_count, Command)
			AS
			(
				SELECT 
					indexstats.avg_fragmentation_in_percent,
					indexstats.page_count,
					'ALTER INDEX [' + dbindexes.[name] + '] ON [' 
					+ dbschemas.[name] + '].[' + dbtables.[name] + '] REBUILD' AS Command
				FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) AS indexstats
				INNER JOIN sys.tables dbtables ON dbtables.[object_id] = indexstats.[object_id]
				INNER JOIN sys.schemas dbschemas ON dbtables.[schema_id] = dbschemas.[schema_id]
				INNER JOIN sys.indexes AS dbindexes 
					ON dbindexes.[object_id] = indexstats.[object_id]
					AND indexstats.index_id = dbindexes.index_id
				WHERE indexstats.database_id = DB_ID()
					AND indexstats.avg_fragmentation_in_percent > 30
					AND dbindexes.[type_desc] <> 'HEAP'  -- optional: skip heaps with no indexes
			)
			INSERT INTO @commands (command)
			SELECT Command FROM HighFragmentedIndexes
			ORDER BY avg_fragmentation_in_percent DESC;
			-- count quantity of indexes 
			SELECT @IndexesQuantity =count(*) from @commands ;
			insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'Found : ' + CAST(ISNULL(@IndexesQuantity, 0) AS NVARCHAR) + ' indexes for REBUILD' );
			-- start index REBUILD processing 

			DECLARE @current_command NVARCHAR(MAX);
			DECLARE command_cursor CURSOR FOR
			SELECT command FROM @commands;
			OPEN command_cursor;
			FETCH NEXT FROM command_cursor INTO @current_command;
			WHILE @@FETCH_STATUS = 0
			BEGIN
				insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'Starting execution of command: ' +  @current_command);
				 EXEC sp_executesql @current_command;
				insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'End of command: ' +  @current_command + ' execution.');
				WAITFOR DELAY '00:00:05'; 
				FETCH NEXT FROM command_cursor INTO @current_command;
			END;
			CLOSE command_cursor;
			DEALLOCATE command_cursor;

			DELETE FROM @commands;
			-- continue with REORGANIZE
			insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'Process for REBUILD finished' );
			WITH LowFragmentedIndexes (avg_fragmentation_in_percent, page_count, Command)
			AS
			(
				SELECT 
					indexstats.avg_fragmentation_in_percent,
					indexstats.page_count,
					'ALTER INDEX [' + dbindexes.[name] + '] ON [' 
					+ dbschemas.[name] + '].[' + dbtables.[name] + '] REORGANIZE' AS Command
				FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) AS indexstats
				INNER JOIN sys.tables dbtables ON dbtables.[object_id] = indexstats.[object_id]
				INNER JOIN sys.schemas dbschemas ON dbtables.[schema_id] = dbschemas.[schema_id]
				INNER JOIN sys.indexes AS dbindexes 
					ON dbindexes.[object_id] = indexstats.[object_id]
					AND indexstats.index_id = dbindexes.index_id
				WHERE indexstats.database_id = DB_ID()
					AND indexstats.avg_fragmentation_in_percent > 5
					AND dbindexes.[type_desc] <> 'HEAP'  -- optional: skip heaps with no indexes
			)
			INSERT INTO @commands (command)
			SELECT Command FROM LowFragmentedIndexes
			ORDER BY avg_fragmentation_in_percent DESC;
			-- count quantity of indexes 
			SELECT @IndexesQuantity =count(*) from @commands ;
			insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'Found : ' + CAST(ISNULL(@IndexesQuantity, 0) AS NVARCHAR) + ' indexes for REORGANIZE' );
			-- start index REBUILD processing 
			DECLARE command_cursor CURSOR FOR
			SELECT command
			FROM @commands;
			OPEN command_cursor;
			FETCH NEXT FROM command_cursor INTO @current_command;
			WHILE @@FETCH_STATUS = 0
			BEGIN
				insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'Starting execution of command: ' +  @current_command);
				 EXEC sp_executesql @current_command;
				insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'End of command: ' +  @current_command + ' execution.');
				WAITFOR DELAY '00:00:05'; 
				FETCH NEXT FROM command_cursor INTO @current_command;
			END;
			CLOSE command_cursor;
			DEALLOCATE command_cursor;
			insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',0,'Process for REORGANIZE finished' );
			UPDATE smartKPIKepwareConnectorPointer SET Machine='IsIndexDefragmentationRunning', UpdatedId=0 WHERE Machine='IsIndexDefragmentationRunning';
	END
	END TRY
	BEGIN CATCH
	   insert into smartKPIJobLogger (Job, LogLevel, LogText) VALUES ('IndexDefragmentation',2,'An error occurred! '+ERROR_MESSAGE());
	   UPDATE smartKPIKepwareConnectorPointer SET Machine='IsIndexDefragmentationRunning', UpdatedId=0 WHERE Machine='IsIndexDefragmentationRunning';
	END CATCH
END;
GO