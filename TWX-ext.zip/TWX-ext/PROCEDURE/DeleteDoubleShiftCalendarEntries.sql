--------------------------------------------------------------
--------------------------------------------------------------
print '-- DeleteDoubleShiftCalendarEntries';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'DeleteDoubleShiftCalendarEntries') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE DeleteDoubleShiftCalendarEntries  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE DeleteDoubleShiftCalendarEntries
AS
BEGIN

	delete x from 
	(SELECT *, DupRank = ROW_NUMBER() OVER (
				  PARTITION BY [Plant]
		  ,[Machine]
		  ,[StartTime]
		  ,[EndTime]
		  ,[Qualifier]
		  ,[Name]
		  ,[Machine_Full_Name]
		  ,[Utilization]
				  ORDER BY (SELECT NULL)
				)
	  FROM [shiftCalendar]) x
		  where x.DupRank > 1;
END;
GO