-- =============================================
-- Author: Martin Flassak
-- Create date: 03/2024
-- Description: Goes through all time slots (weeks/months), machines and different offsets to trigger KPI calculation
-- Parameters:
-- @daysBack int - number of days back to calculate, current week/month is always calculated!
-- Returns: nothing
-- =============================================

create or alter procedure CalculateWeekMonthKPIs @daysBack int
as
begin

	set nocount on;

    declare @startDayForCalculationAsDateTime datetime2 = DATEFROMPARTS(datepart(year,getutcdate()), datepart(month,getutcdate()), datepart(day,getutcdate()));
    declare @counter int;
    declare @device varchar(255);
    declare @calendarWeek table (dayUtc datetime2, dayUtcWithOffset datetime2);
    declare @calendarMonth table (dayUtc datetime2, dayUtcWithOffset datetime2);
    declare @calendarStartTime datetime2;
    declare @calendarEndTime datetime2;
    declare @calendarGroupBy1 int;
    declare @calendarGroupBy2 int;
    declare @currentMonth int;
    declare @offset int;
    declare @deviceListCursor cursor;
    declare @offsetListCursor cursor;
    declare @CalendarCursor cursor;
	declare @DeleteArchivedDataTimeInMonths int;
	declare @maxCalculationStartDate dateTime2;
    declare @deviceList table 
        (plant varchar(255)
        ,area varchar(255)
        ,machine varchar(255)
        ,station varchar(255)
        ,type varchar(255)
        ,offset int
        );

	select 
        @DeleteArchivedDataTimeInMonths = FloatValue 
    from 
        smartKPIMachineKeyValueData 
    where 
        PropertyKey = 'DeleteArchivedDataTimeInMonths' 
        and Machine = 'DB'
    ;
	
    set 
        @maxCalculationStartDate = dateadd(day,1,dateadd(month,-1 * @DeleteArchivedDataTimeInMonths,getutcdate()));


	print 'maxCalculationStartDate';
	print @maxCalculationStartDate;



	set datefirst 1 ;  
    

--set max number of days backward in relation to archiving date
    if (@daysBack > datediff(day,@maxCalculationStartDate,@startDayForCalculationAsDateTime))
    begin
        set @daysBack = datediff(day,@maxCalculationStartDate,@startDayForCalculationAsDateTime);
    end
    
    
--Get List of Plants/Machines/Stations
    insert into @deviceList (plant,area,machine,station,type,offset)
        select 
            plant
            ,area
            ,machine
            ,station
            ,type
            ,isnull(offset,0) 
        from 
            dbo.GetDeviceListForAreasMachinesStations();

-- *********************************************************  Internal calendar  *********************************************************
-- defining weeks
    set @counter = 1;
    while (datepart(dw,dateadd(day,@counter,@startDayForCalculationAsDateTime))!= 7)
    BEGIN
        insert into @calendarWeek (dayUtc) values (dateadd(day,@counter,@startDayForCalculationAsDateTime))
        set @counter = @counter + 1;
    END

    set @counter = 0;
    while (@counter < @daysBack)
    BEGIN
        insert into @calendarWeek (dayUtc) values (dateadd(day,-@counter,@startDayForCalculationAsDateTime))
        set @counter = @counter + 1;
    END

    while (datepart(dw,dateadd(day,-@counter,@startDayForCalculationAsDateTime))!= 7)
    BEGIN
        insert into @calendarWeek (dayUtc) values (dateadd(day,-@counter,@startDayForCalculationAsDateTime))
        set @counter = @counter + 1;
    END

-- defining months
    set @counter = 1;
    while (datepart(day,dateadd(day,@counter,@startDayForCalculationAsDateTime)) != 1)
    BEGIN
        insert into @calendarMonth (dayUtc) values (dateadd(day,@counter,@startDayForCalculationAsDateTime))
        set @counter = @counter + 1;
    END

    set @counter = 0;
    while (@counter < @daysBack)
    BEGIN
        insert into @calendarMonth (dayUtc) values (dateadd(day,-@counter,@startDayForCalculationAsDateTime))
        set @counter = @counter + 1;
    END

    set @currentMonth = month(dateadd(day,-@counter,@startDayForCalculationAsDateTime));
    while (datepart(month,dateadd(day,-@counter,@startDayForCalculationAsDateTime)) = @currentMonth)
    BEGIN
        insert into @calendarMonth (dayUtc) values (dateadd(day,-@counter,@startDayForCalculationAsDateTime))
        set @counter = @counter + 1;
    END

--Loop over different offset times
    set 
        @offsetListCursor = cursor for 
    select distinct
        offset
    from 
        @deviceList 
    where 
        type in ('KBLocalMachineThingTemplate', 'KBLocalStationThingTemplate')
    ;

    print '************************ Loop over different offset times ************************' 
    open @offsetListCursor;
        fetch next 
        from @offsetListCursor 
        into 
            @offset

        while @@fetch_status = 0
        begin;
            print 'START offsetListCursor --------------'
            print getutcdate()
            print '-------------------------------------'
            print @offset;

            --updatiing internal calendar with time offset
            update 
                @calendarWeek 
            set 
                dayUtcWithOffset = dbo.GetUTCTimeFromLocalTime(dateadd(minute,@offset,dayUtc))
            ;
            
            update 
                @calendarMonth 
            set 
                dayUtcWithOffset = dbo.GetUTCTimeFromLocalTime(dateadd(minute,@offset,dayUtc))
            ;

            --Loop over devices
            set 
                @deviceListCursor = cursor for 
            select
                machine
            from 
                @deviceList
            where 
                type = 'KBLocalMachineThingTemplate'
                and offset = @offset
            union select 
                station
            from 
                @deviceList
            where 
                type = 'KBLocalStationThingTemplate'
                and offset = @offset
            ;

            print '************************ Loop over device List ************************' 
            open @deviceListCursor;
                fetch next 
                from @deviceListCursor 
                into 
                    @device
                ;

                while @@fetch_status = 0
                begin;
                    print 'START deviceListCursor --------------'
                    print getutcdate()
                    print '-------------------------------------'
                    print @device;

                    --Loop over calendar week
                    set 
                        @CalendarCursor = cursor for 
                    select 
                        min(dayUtcWithOffset)
                        ,dbo.GetUTCTimeFromLocalTime(dateadd(minute,@offset,dateadd(day,7,min(dayUtc))))
                        ,datediff(day,'1969-12-29', dayUtc)/7
                        ,0
                    from 
                        @calendarWeek
                    group by 
                        datediff(day,'1969-12-29', dayUtc)/7
                    order by 
                        1,2
                    ;

                    print '************************ Loop over calendar week ************************' 
                    open @CalendarCursor;
                        fetch next 
                        from @CalendarCursor 
                        into 
                            @calendarStartTime
                            ,@calendarEndTime 
                            ,@calendarGroupBy1
                            ,@calendarGroupBy2
                        ;

                        while @@fetch_status = 0
                        begin;
                            print 'START CalendarCursor week -----------'
                            print getutcdate()
                            print '-------------------------------------'
                            print @calendarStartTime;
                            print @calendarEndTime;
                            
                            EXECUTE CalculateSummedUpKPIs @StartDate = @calendarStartTime, @EndDate = @calendarEndTime, @Machine = @device, @KPITimeBase = 'week' 


                            print 'END CalendarCursor week -------------'
                            print getutcdate()
                            print '-------------------------------------'
                            
                            fetch next 
                            from @CalendarCursor 
                            into 
                                @calendarStartTime
                                ,@calendarEndTime 
                                ,@calendarGroupBy1
                                ,@calendarGroupBy2
                            ;
                            end;
                        close @CalendarCursor;
                    deallocate @CalendarCursor;

                    --Loop over calendar month
                    set 
                        @CalendarCursor = cursor for 
                    select 
                        min(dayUtcWithOffset)
                        ,dbo.GetUTCTimeFromLocalTime
                            (dateadd
                                (minute
                                ,@offset
                                ,dateadd
                                    (month
                                    ,1
                                    ,min(dayUtc)
                                    )
                                )
                            )
                        ,DATEPART
                            (month
                            ,dayUtc
                            )
                        ,DATEPART
                            (year
                            ,dayUtc
                            )  
                    from 
                        @calendarMonth
                    group by 
                        DATEPART
                            (month
                            ,dayUtc
                            )
                        ,DATEPART
                            (year
                            ,dayUtc
                            )
                            order by 1,2
                        ;

                    print '************************ Loop over calendar month ************************' 
                    open @CalendarCursor;
                        fetch next 
                        from @CalendarCursor 
                        into 
                            @calendarStartTime
                            ,@calendarEndTime 
                            ,@calendarGroupBy1
                            ,@calendarGroupBy2
                        ;

                        while @@fetch_status = 0
                        begin;
                            print 'START CalendarCursor month ----------'
                            print getutcdate()
                            print '-------------------------------------'
                            print @calendarStartTime;
                            print @calendarEndTime;

                            EXECUTE CalculateSummedUpKPIs @StartDate = @calendarStartTime, @EndDate = @calendarEndTime, @Machine = @device, @KPITimeBase = 'month' 

                            print 'END CalendarCursor month ------------'
                            print getutcdate()
                            print '-------------------------------------'
                            
                            fetch next 
                            from @CalendarCursor 
                            into 
                                @calendarStartTime
                                ,@calendarEndTime 
                                ,@calendarGroupBy1
                                ,@calendarGroupBy2
                            ;
                        end;
                        close @CalendarCursor;
                    deallocate @CalendarCursor;

                    print 'END deviceListCursor-----------------'
                    print getutcdate()
                    print '-------------------------------------'
                    
                    fetch next 
                    from @deviceListCursor 
                    into 
                        @device
                    ;
                    end;
                close @deviceListCursor;
            deallocate @deviceListCursor;




            print 'END offsetListCursor ----------------'
            print getutcdate()
            print '-------------------------------------'
            
            fetch next 
            from 
                @offsetListCursor 
            into 
                @offset
            ;
        end;
        close @offsetListCursor;
    deallocate @offsetListCursor;

END;

GO

--exec dbo.CalculateWeekMonthKPIs @daysBack=0;
--exec dbo.CalculateWeekMonthKPIs @daysBack=1;
-- select distinct KPIName from smartKPIValues where KPIName not like 'CVS: KPI planned working time %' order by 1