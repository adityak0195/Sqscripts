--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetPartsToConfirmRail';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPartsToConfirmRail') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetPartsToConfirmRail  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetPartsToConfirmRail
AS
BEGIN
	SET NOCOUNT ON


declare @table TABLE ( 
	Id bigint,
	OrderNumber varchar(255), 
	SAPOperationNumber varchar(255), 
	numberOfParts int, 
	isPartOK bit, 
	Machine1 varchar(255),
	SAPPlantId varchar(255),
	JSON varchar(max),
	EmployeeID varchar(255));

	DECLARE @getorders cursor;
	DECLARE @Id bigint;
	DECLARE @jsonstring varchar(max);
	DECLARE @EmployeeID varchar(255);

	insert into @table (Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, Machine1, JSON)  
  	select smartKPI.Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, smartKPI.Machine, JSON  
	  from smartKPI, smartKPIMachineKeyValueData plant, smartKPIMachineKeyValueData division
	  where confirmToSAP = 1
	  and confirmedToSAP = 0
	  and smartKPI.Machine != Station
      and smartKPI.Machine != 'KBTruckSAPServer'
      and smartKPI.Machine = plant.Machine
      and division.Machine = plant.TextValue
	  and plant.PropertyKey = 'KBPlantThing'
	  and division.PropertyKey = 'KBDivisionThing'
      and division.TextValue = 'KBRailDivisionThing'
      and isnull(SAPOperationNumber,'') != ''
	  and isnull(OrderNumber,'') != ''
	  order by ProductionTime;
 
	  
	SET @getorders = CURSOR for select Id from @table;
	OPEN @getorders;
		FETCH NEXT FROM @getorders into @Id
		WHILE @@FETCH_STATUS = 0
		BEGIN;

			select @jsonstring=JSON from @table where Id = @Id;
		
			select @EmployeeID=jsondata.EmployeeID 
				from OPENJSON(@jsonstring, N'$.rows')
					WITH(EmployeeID varchar(255) N'$.EmployeeID') as jsondata;
			update @table set EmployeeID  = @EmployeeID
				where Id = @Id; 


			FETCH NEXT FROM @getorders into @Id;
		END;
	CLOSE @getorders;
	DEALLOCATE @getorders;

  
	update @table set SAPPlantId = (SELECT md2.TextValue
		FROM [smartKPIMachineKeyValueData] md1, [smartKPIMachineKeyValueData] md2
		where md1.Machine = Machine1
		COLLATE database_default
		and md1.PropertyKey = 'KBPlantThing'
		and md1.TextValue = md2.Machine
		COLLATE database_default
		and md2.PropertyKey = 'SAPPlantId');

	select Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, Machine1 as Machine, SAPPlantId, EmployeeID
	from @table
	where isnull(SAPPlantId,'') != '';

  
END;
GO
