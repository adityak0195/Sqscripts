--------------------------------------------------------------
--------------------------------------------------------------
print '-- PreparePartsToConfirmTruck';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PreparePartsToConfirmTruck') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE PreparePartsToConfirmTruck  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE PreparePartsToConfirmTruck
AS
BEGIN
	SET NOCOUNT ON


declare @table TABLE ( 
	Id bigint,
	OrderNumber varchar(255), 
	PartNumber varchar(255), 
	SAPOperationNumber varchar(255), 
	numberOfParts int, 
	isPartOK bit, 
	MachineName varchar(255),
	StationName varchar(255),
	PlantName varchar(255),
	DivisionName varchar(255),
	SAPPlantId varchar(255),
	JSON varchar(max), --newColumn
	GroupID varchar(255), --newColumn
	EmployeeID varchar(255));

	DECLARE @getorders cursor;
	DECLARE @Id bigint;
	DECLARE @jsonstring varchar(max);
	DECLARE @EmployeeID varchar(255);
    DECLARE @now DATETIME2 = GETUTCDATE();
	DECLARE @isPartOK bit;

	--new part for groupId
	DECLARE @getGroupId cursor;
	DECLARE @GroupID varchar(255);
	--end of new part for groupId

	insert into @table (Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, MachineName, StationName, JSON)  
  	select Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, Machine, Station, JSON
	  from smartKPI
	  where confirmToSAP = 1
	  and confirmedToSAP = 0
	  and NULLIF(SAPOperationNumber, '') IS NOT NULL
	  and NULLIF(OrderNumber, '') IS NOT NULL
	  and Machine != 'KBTruckSAPServer'
	  and Machine != Station;   

    update @table set PlantName = plant.TextValue
      from smartKPIMachineKeyValueData plant
      where MachineName = plant.Machine
	  and plant.PropertyKey = 'KBPlantThing';

    update @table set DivisionName = division.TextValue
      from smartKPIMachineKeyValueData division
      where PlantName = division.Machine
	  and division.PropertyKey = 'KBDivisionThing';	

    delete from @table where DivisionName != 'KBTruckDivisionThing';

	update @table set SAPPlantId = (SELECT TOP 1 md.TextValue
		FROM smartKPIMachineKeyValueData md
		where  PlantName = md.Machine
		and md.PropertyKey = 'SAPPlantId');

	--new part for groupId start 
	SET @getGroupId = CURSOR for select Id from @table;
	OPEN @getGroupId;

	FETCH NEXT FROM @getGroupId into @Id
	WHILE @@FETCH_STATUS = 0
	BEGIN;

	select @jsonstring=JSON from @table where Id = @Id;	
		select @GroupID=jsondata.GroupID 
			from OPENJSON(@jsonstring, N'$.rows')
				WITH(GroupID varchar(255) N'$.GroupID') as jsondata;
		update @table set GroupID  = @GroupID
			where Id = @Id; 

	FETCH NEXT FROM @getGroupId into @Id;
	END;
	CLOSE @getGroupId;
	DEALLOCATE @getGroupId;
	--new part for groupId end  


    insert into smartKPI ([Machine],[ProductionTime],[isPartOK],[confirmToSAP],[SAPOperationNumber],[OrderNumber],[numberOfParts],[Station], JSON)
    select 'KBTruckSAPServer', DATEADD(ms, convert(int,isPartOK), @now) , isPartOK, 1, SAPOperationNumber, OrderNumber, sum(numberOfParts), SAPPlantId+' - '+convert(varchar,isPartOK)+' - '+OrderNumber+' - '+SAPOperationNumber,
	JSON_MODIFY(
        JSON_MODIFY(
            '{"dataShape":{"fieldDefinitions":{"smartKPI":{"name":"EmployeeID","baseType":"STRING"},"GroupID":{"name":"GroupID","baseType":"STRING"}}},"rows":[{"EmployeeID":""}]}',
            '$.rows[0].GroupID',
            GroupID
        ),
        '$.rows[0].EmployeeID',
        ''
    ) AS JSON    
	from @table
    where isnull(SAPPlantId,'') != ''
    group by isPartOK, SAPOperationNumber, OrderNumber, SAPPlantId, GroupID;


	update smartKPI   
	set confirmedToSAP = 1,  
	SAPconfirmationResult = 'SAP Confirmation at '   + convert(varchar, DATEADD(ms, convert(int,isPartOK), @now), 126)
	where Id in (select Id from @table)

  
END;
GO
