--------------------------------------------------------------
--------------------------------------------------------------
print '-- MergeOrder';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'MergeOrder') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE MergeOrder  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE MergeOrder
	@isProductionStarted bit,
	@OrderNumber varchar(255),
	@System varchar(255),
	@PlantId varchar(255)
AS
BEGIN;
	INSERT into smartKPIOrderData ([OrderNumber], [System], [isProductionStarted])  
	select @OrderNumber, @System, ISNULL(@isProductionStarted, 0)
	where not exists (select 'ok' from smartKPIOrderData where OrderNumber = convert(varchar(255), @OrderNumber) and System = convert(varchar(255), @System)); 

	UPDATE smartKPIOrderData
		set [isProductionStarted] = ISNULL(@isProductionStarted, 0),
			[UpdateTime] = GETDATE(),
			[UTCUpdateTime] = GETUTCDATE(),
			[PlantId] = @PlantId
			where OrderNumber = convert(varchar(255), @OrderNumber) and System = convert(varchar(255), @System);

END;
GO

