--------------------------------------------------------------
--------------------------------------------------------------
print '-- CalulateKPIsForSingleMachine';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateKPIsForSingleMachine') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE CalulateKPIsForSingleMachine  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE CalulateKPIsForSingleMachine
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Machine varchar(255)
AS
BEGIN;

	Declare @CVS_DMS_Day_Offset_in_Minutes int;
	declare @StartDateOffsetForSingleMachine datetime2 = @StartDate;
	declare @EndDateOffsetForSingleMachine datetime2 = @EndDate;
	declare @table table (Machine varchar(255), KPIName varchar(255), KPICalculationBase varchar(255), KPIDateTime datetime2, KPIDateTimeEnd datetime2, KPIFloatValue float);
	declare @division varchar(255);

	BEGIN TRY
	
        declare @DeleteArchivedDataTimeInMonths int;
        declare @DeleteArchivedProcessDataTimeInMonths int;

		select @DeleteArchivedDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedDataTimeInMonths' and [Machine] = 'DB';
		select @DeleteArchivedProcessDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedProcessDataTimeInMonths' and [Machine] = 'DB';


		declare @deleteDate dateTime2 = dateadd(month,-1 * @DeleteArchivedDataTimeInMonths,getutcdate());
		declare @deleteDateForProcessAndMachineData dateTime2 = dateadd(month,-1 * @DeleteArchivedProcessDataTimeInMonths,getutcdate());

        if (@StartDate >= @deleteDate and  @StartDate >= @deleteDateForProcessAndMachineData)
        BEGIN

			SELECT @division=TextValue
				FROM [smartKPIMachineKeyValueData]
				where Machine = (select [TextValue] FROM [smartKPIMachineKeyValueData]
				where Machine = @Machine
				and PropertyKey = 'KBPlantThing') COLLATE database_default
				and PropertyKey = 'KBDivisionThing';

			if @division = 'KBTruckDivisionThing'
			BEGIN

				if @CalculationBase = 'shift'
				BEGIN
					insert into [smartKPIMachineMessageData] ([Machine]
															  ,[MessageTime]
															  ,[MessageType1]
															  ,[MessageType2]
															  ,[Message]
															  ,[description])
						select Machine, @EndDateOffsetForSingleMachine, 'STAFF', 'Operator Logout', 'Logout', 'Auto log out end of shift'
							from [smartKPIMachineKeyValueData]
							where TextValue = @Machine
							and PropertyKey = 'KBLocalLineThing'
							and not exists (select 'ok' from smartKPIMachineMessageData
								where smartKPIMachineMessageData.Machine = smartKPIMachineKeyValueData.Machine
								and MessageTime = @EndDateOffsetForSingleMachine
								and MessageType1 = 'STAFF'
								and MessageType2 = 'Operator Logout'
								and Message = 'Logout'
								and description = 'Auto log out end of shift');
				END;
			
				if @CalculationBase = 'month'
				BEGIN 
					--DECLARE @MainStation varchar(255);
					--SELECT @MainStation=[TextValue]
					--	FROM [smartKPIMachineKeyValueData]
					--	where PropertyKey = 'MainStationForLineStatus'
					--	and Machine = @Machine;

					insert into  @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue) 
					select Machine,'CVS: MTBF', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(MTBF,0) from GetMaintenanceKPIs (@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine,@Machine,1);

					insert into  @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue) 
					select Machine,'CVS: MTTR', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(MTTR,0) from GetMaintenanceKPIs (@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine,@Machine,1);

					insert into  @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue) 
					select Machine,'CVS: MRT', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(MRT,0) from GetMaintenanceKPIs (@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine,@Machine, 1);

				END;


				if @CalculationBase = 'year'
				BEGIN 
					--DECLARE @MainStation varchar(255);
					--SELECT @MainStation=[TextValue]
					--	FROM [smartKPIMachineKeyValueData]
					--	where PropertyKey = 'MainStationForLineStatus'
					--	and Machine = @Machine;

					insert into  @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue) 
					select Machine,'CVS: MTBF', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(MTBF,0) from GetMaintenanceKPIs (@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine,@Machine,1);

					insert into  @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue) 
					select Machine,'CVS: MTTR', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(MTTR,0) from GetMaintenanceKPIs (@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine,@Machine,1);

					insert into  @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue) 
					select Machine,'CVS: MRT', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(MRT,0) from GetMaintenanceKPIs (@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine,@Machine, 1);

				END;
			
				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select Machine, KPIName, 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(KPIFloatValue,0) from dbo.GetKPIsTruckWorker(@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, @Machine);
			END;
			ELSE if @division = 'KBRailDivisionThing'
			BEGIN
				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue)
					select Machine, KPIName, 'GetCIPKPIsRailWorker', @StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, isnull(KPIFloatValue,0) from dbo.GetCIPKPIsRailWorker(@StartDateOffsetForSingleMachine,@EndDateOffsetForSingleMachine, @Machine);
			END;

			WAITFOR DELAY '00:00:01';  
			delete from [smartKPIValues] where KPIDateTime = @StartDateOffsetForSingleMachine and KPIDateTimeEnd = @EndDateOffsetForSingleMachine and Machine = @Machine;
			WAITFOR DELAY '00:00:01';  
			insert into [smartKPIValues] (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue, KPITimeBase)
				select Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue, @CalculationBase from @table;

		END;
	END TRY  
	BEGIN CATCH  
		set @CVS_DMS_Day_Offset_in_Minutes = 0;
	END CATCH 


END;
GO
