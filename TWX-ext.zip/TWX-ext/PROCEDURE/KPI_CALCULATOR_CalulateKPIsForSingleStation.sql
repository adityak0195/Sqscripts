--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalulateKPIsForSingleStation';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalulateKPIsForSingleStation') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleStation  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_CalulateKPIsForSingleStation
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Machine varchar(255),
	@Station varchar(255)
AS
BEGIN;
    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


    exec CalulateKPIsForSingleStation 
        @StartDate,
        @EndDate,
        @CalculationBase,
        @Machine,
        @Station;
END;
GO

