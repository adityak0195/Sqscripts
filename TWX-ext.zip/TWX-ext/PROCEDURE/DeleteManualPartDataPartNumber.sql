--------------------------------------------------------------
--------------------------------------------------------------
print '-- DeleteManualPartDataPartNumber';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'DeleteManualPartDataPartNumber') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE DeleteManualPartDataPartNumber  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE DeleteManualPartDataPartNumber
@PartNumberToDelete varchar(255)
AS
BEGIN

  declare @timestamp datetime2 = getutcdate();
  
  update [smartKPIOrderData] 
  set System = System + '_deleted_'+convert(varchar,@timestamp)
  where System = 'ManualPartData' 
  and OrderNumber = @PartNumberToDelete;

  update [smartKPIOrderKeyValueData] 
  set System = System + '_deleted_'+convert(varchar,@timestamp)
  where System = 'ManualPartData' 
  and OrderNumber = @PartNumberToDelete
  
END;
GO