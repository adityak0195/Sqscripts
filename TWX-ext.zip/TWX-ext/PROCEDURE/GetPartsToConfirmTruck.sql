--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetPartsToConfirmTruck';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPartsToConfirmTruck') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetPartsToConfirmTruck  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetPartsToConfirmTruck
AS
BEGIN
	SET NOCOUNT ON


declare @table TABLE ( 
	Id bigint,
	OrderNumber varchar(255), 
	PartNumber varchar(255), 
	SAPOperationNumber varchar(255), 
	numberOfParts int, 
	isPartOK bit, 
	Machine1 varchar(255),
	SAPPlantId varchar(255),
	JSON varchar(max),
	EmployeeID varchar(255));


	insert into @table (Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, Machine1, JSON, SAPPlantId)  
	select Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, Machine, JSON, Station
	  from [smartKPI] 
	  where confirmToSAP = 1
	  and confirmedToSAP = 0
	  and Machine = 'KBTruckSAPServer'
	  order by ProductionTime;


	select Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, Machine1 as Machine, SUBSTRING (SAPPlantId, 1, CHARINDEX (' -', SAPPlantId)-1) as SAPPlantId, JSON, EmployeeID
	from @table;


	

  
END;
GO
