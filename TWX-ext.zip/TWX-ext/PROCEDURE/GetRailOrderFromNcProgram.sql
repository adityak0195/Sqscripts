--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetRailOrderFromNcProgram';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetRailOrderFromNcProgram') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetRailOrderFromNcProgram  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetRailOrderFromNcProgram
@NcProgram varchar(255)
AS
BEGIN
	SET NOCOUNT ON

		DECLARE @table table (OrderNumber varchar(255), 
			Operation varchar(255), 
			LatestScheduledStartExecution datetime2,
			MaterialNumber varchar(255),
			NcProgram varchar(255),
			ConfirmationNumber varchar(255),
			MachineLoadingTime float,
			MachineLoadingTimeUnit varchar(255),
			MachineLoadingTimeInSec float,
			MachineTime float,
			MachineTimeUnit varchar(255),
			MachineTimeInSec float,
			BaseQuantity float)


		if @NcProgram = '3TD19101R02_V01_MPF'
			set @NcProgram = 'KNCHIR20452';
		if @NcProgram = '3TD19103R01_MPF'
			set @NcProgram = 'KNCHIR20455';
		if @NcProgram = '3TD19103R02_MPF'
			set @NcProgram = 'KNCHIR20453';
		if @NcProgram = 'TD15090R63_REV1_V01_MPF'
			set @NcProgram = 'KNCHIR20450';
		if @NcProgram = 'TD15090R65_V01_MPF'
			set @NcProgram = 'KNCHIR20451';
		if @NcProgram = 'TD19863R01_V01_MPF'
			set @NcProgram = 'KNCHIR20452';
		if @NcProgram = '3T190159P41_MPF'
			set @NcProgram = 'KNCHIR20449';
		if @NcProgram = '3T190159P42_MPF'
			set @NcProgram = 'KNCHIR20448';
		if @NcProgram = 'TD12072R01_V04_MPF'
			set @NcProgram = 'KNCHIR20430';
		if @NcProgram = 'TD12072R02_V01_MPF'
			set @NcProgram = 'KNCHIR20431';

			
		insert into @table 
			(OrderNumber, 
			Operation, 
			LatestScheduledStartExecution,
			MaterialNumber,
			NcProgram,
			ConfirmationNumber,
			MachineLoadingTime,
			MachineLoadingTimeUnit,
			MachineLoadingTimeInSec,
			MachineTime,
			MachineTimeUnit,
			MachineTimeInSec,
			BaseQuantity)
  		select top(1)
			o1.OrderNumber, 
			o1.Operation, 
			o2.DateTimeValue as LatestScheduledStartExecution,
			o3.TextValue as MaterialNumber,
			@NcProgram as NcProgram,
			o7.TextValue as ConfirmationNumber,
			o4.FloatValue as MachineLoadingTime,
			o4.TextValue as MachineLoadingTimeUnit,
			MachineLoadingTimeInSec =  CASE o4.TextValue
										WHEN 'SEC' THEN o4.FloatValue
										WHEN 'MIN' THEN o4.FloatValue * 60
										WHEN 'DAY' THEN o4.FloatValue * 24 * 60 * 60
										ELSE 0		 
									END,
			o5.FloatValue as MachineTime,
			o5.TextValue as MachineTimeUnit,
			MachineTimeInSec =  CASE o5.TextValue
										WHEN 'SEC' THEN o5.FloatValue
										WHEN 'MIN' THEN o5.FloatValue * 60
										WHEN 'DAY' THEN o5.FloatValue * 24 * 60 * 60
										ELSE 0		 
									END,
			o6.FloatValue as BaseQuantity
		from [smartKPIOrderKeyValueData] o1, [smartKPIOrderKeyValueData] o2, [smartKPIOrderKeyValueData] o3, [smartKPIOrderKeyValueData] o4, [smartKPIOrderKeyValueData] o5, [smartKPIOrderKeyValueData] o6, [smartKPIOrderKeyValueData] o7
			where o1.OrderNumber = o2.OrderNumber
			and o1.OrderNumber = o3.OrderNumber
			and o1.OrderNumber = o4.OrderNumber
			and o1.OrderNumber = o5.OrderNumber
			and o1.OrderNumber = o6.OrderNumber
			and o1.OrderNumber = o7.OrderNumber
			and o1.Operation = o2.Operation
			and o2.Operation != ''
			and o1.Operation = o4.Operation
			and o4.Operation != ''
			and o1.Operation = o5.Operation
			and o5.Operation != ''
			and o1.Operation = o6.Operation
			and o6.Operation != ''
			and o1.Operation = o7.Operation
			and o7.Operation != ''
			and o3.Operation = ''
			and o1.PropertyKey1 like 'NC-Program-%'
			and o2.PropertyKey1 = 'LatestScheduledStartExecution'
			and o3.PropertyKey1 = 'MaterialNumber'
			and o4.PropertyKey1 = 'MachineLoadingTime'
			and o5.PropertyKey1 = 'MachineTime'
			and o6.PropertyKey1 = 'BaseQuantity'
			and o7.PropertyKey1 = 'ConfirmationNumber'
			and o1.TextValue1 = @NcProgram
			and o2.DateTimeValue > getutcdate()
		order by o2.DateTimeValue;

	if (select count(*) from @table) = 0
		insert into @table 
			(OrderNumber, 
			Operation, 
			LatestScheduledStartExecution,
			MaterialNumber,
			NcProgram,
			ConfirmationNumber,
			MachineLoadingTime,
			MachineLoadingTimeUnit,
			MachineLoadingTimeInSec,
			MachineTime,
			MachineTimeUnit,
			MachineTimeInSec,
			BaseQuantity)
		values ('NC-program not found', '0000', getutcdate(), '-', @NcProgram, '-', 0, 'MIN', 0, 0, 'MIN', 0, 1);
		
	select * from @table;
END;

GO

-- exec GetRailOrderFromNcProgram @NcProgram='KNV003711V00';

