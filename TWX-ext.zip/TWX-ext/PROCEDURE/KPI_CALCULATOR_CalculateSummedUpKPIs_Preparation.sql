--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalculateSummedUpKPIs_Preparation';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalculateSummedUpKPIs_Preparation') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalculateSummedUpKPIs_Preparation  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_CalculateSummedUpKPIs_Preparation
	@Id varchar(255)
AS
BEGIN;

    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


    declare @query varchar(max);
    declare @inputDataTableName  varchar(255) = 'TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_IN_'+@Id;
    declare @outputDataTableName varchar(255) = 'TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_OUT_'+@Id;

    set @query  = 'CREATE TABLE '+@inputDataTableName; 
    set @query += ' (';
	set @query += '    [Machine] [varchar](255) NOT NULL, ';
	set @query += '    [KPIName] [varchar](255) NOT NULL, ';
	set @query += '    [KPICalculationBase] [varchar](255) NOT NULL, ';
	set @query += '    [KPIDateTime] [datetime2](7) NOT NULL, ';
	set @query += '    [KPIFloatValue] [float] NOT NULL, ';
	set @query += '    [KPIDateTimeEnd] [datetime2](7) NOT NULL, ';
	set @query += '    [KPITimeBase] [varchar](255) NOT NULL ';
    set @query += ' )';
    EXEC(@query);    

    set @query  = 'CREATE TABLE '+@outputDataTableName; 
    set @query += ' (';
	set @query += '    [KPIName] [varchar](255) NULL, ';
	set @query += '    [KPICalculationBase] [varchar](255) NULL, ';
	set @query += '    [floatValue] float NULL ';
    set @query += ' )';
    EXEC(@query);    

END;
GO


