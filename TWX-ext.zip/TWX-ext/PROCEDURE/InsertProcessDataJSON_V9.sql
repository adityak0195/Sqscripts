--------------------------------------------------------------
--------------------------------------------------------------
print '-- InsertProcessDataJSON_V9';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertProcessDataJSON_V9') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE InsertProcessDataJSON_V9  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE InsertProcessDataJSON_V9
	@JSON_String varchar(max),
	@Machine varchar(255)
AS
BEGIN;
	--PRINT ('Start');
	--PRINT ('JSON_String = ' + @JSON_String);
	
	DECLARE @rowcounter  int = 0;
	DECLARE @JSON_row varchar(max);
	Declare @JSON CURSOR;
	
	DECLARE @PartNumber varchar(255);
	DECLARE @SerialNumber varchar(255);
	DECLARE @ValueName varchar(255);
	DECLARE @ProcessValue float;
	DECLARE @LowerLimit float;
	DECLARE @OrderNumber varchar(255);
	DECLARE @Unit varchar(255);
	DECLARE @UpperLimit float;
	DECLARE @ProductionDateTime DateTime2;
	DECLARE @Description varchar(255);
	DECLARE @Comment varchar(255);
	DECLARE @TrackingNumber varchar(255);
	DECLARE @LocalMachine varchar(255);
	
	declare @timeconversion1 int; 
	declare @timeconversion2 int; 
	
	
	SET @JSON = CURSOR FOR SELECT value FROM OPENJSON(@JSON_String, '$.rows');
	OPEN @JSON;
		FETCH NEXT FROM @JSON into @JSON_row;
			
		WHILE @@FETCH_STATUS = 0
		BEGIN;
		--PRINT ('JSON_row = ' + @JSON_row);

		SET @PartNumber = RTRIM(JSON_VALUE(@JSON_row,'$.PartNumber'));		
		SET @SerialNumber = RTRIM(JSON_VALUE(@JSON_row,'$.SerialNumber'));
		SET @ValueName = JSON_VALUE(@JSON_row,'$.ShortName');
		SET @ProcessValue = convert(float, replace(JSON_VALUE(@JSON_row,'$.Value'),',','.'));
		SET @LowerLimit = convert(float, replace(JSON_VALUE(@JSON_row,'$.LowerLimit'),',','.'));
		SET @OrderNumber = RTRIM(JSON_VALUE(@JSON_row,'$.OrderNumber'));
		SET @Unit = JSON_VALUE(@JSON_row,'$.Unit');
		SET @UpperLimit = convert(float, replace(JSON_VALUE(@JSON_row,'$.UpperLimit'),',','.'));
		SET @ProductionDateTime = DATEADD (second , convert(bigint, JSON_VALUE(@JSON_row,'$.DateTime'))/1000 , convert(DateTime2, DATEFROMPARTS(1970,1,1)));
		SET @Description = JSON_VALUE(@JSON_row,'$.Description');
		SET @Comment = JSON_VALUE(@JSON_row,'$.Identifier');
		SET @TrackingNumber = JSON_VALUE(@JSON_row,'$.TrackingNumber');
		SET @LocalMachine = JSON_VALUE(@JSON_row,'$.LocalStation');
		
		SET @timeconversion1 = convert(int, convert(bigint, JSON_VALUE(@JSON_row,'$.DateTime'))%60000);
		SET @timeconversion2 = convert(int, convert(bigint, JSON_VALUE(@JSON_row,'$.DateTime'))/60000);
		SET @ProductionDateTime = dateadd (millisecond, @timeconversion1, DATEADD(minute, @timeconversion2, convert(DateTime2, DATEFROMPARTS(1970,1,1))))
		
		IF (@LocalMachine is null or @LocalMachine = '')
		BEGIN
			SET @LocalMachine = @Machine;
		END;

		--PRINT (@PartNumber);
		--PRINT (@SerialNumber);
		--PRINT (@ValueName);
		--PRINT (@ProcessValue);
		--PRINT (@LowerLimit);
		--PRINT (@OrderNumber);
		--PRINT (@Unit);
		--PRINT (@UpperLimit);
		--PRINT (@ProductionDateTime);
		--PRINT (@Machine);
		--PRINT (@Description);
		--PRINT (@Comment);
		--PRINT (@TrackingNumber);
		
		
		INSERT into smartKPIProcessFloatData (	[Machine]
						  ,[ProductionTime]
						  ,[ProcesDataType]
						  ,[ProcesData]
						  ,[SerialNumber]
						  ,[PartNumber]
						  ,[OrderNumber]
						  ,[ProcesDataLSL]
						  ,[ProcesDataUSL]
						  ,[Unit]
						  ,[description]
						  ,[comment]
						  ,[TrackingNumber])  
			select distinct @LocalMachine, @ProductionDateTime, @ValueName, @ProcessValue, @SerialNumber, @PartNumber, @OrderNumber, 
			   @LowerLimit, @UpperLimit, @Unit, substring(@Description,1,255), substring(@Comment,1,255),
			   @TrackingNumber 
			   where not exists (select 'ok' from smartKPIProcessFloatData 
									where Machine = @LocalMachine 
									and ProductionTime = @ProductionDateTime 
									and ProcesDataType =  @ValueName);
		

		FETCH NEXT FROM @JSON into @JSON_row;
		END;
	CLOSE @JSON;
	DEALLOCATE @JSON;
END;


GO
