--------------------------------------------------------------
--------------------------------------------------------------
print '-- FillManualPartDataPropertyKeys';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'FillManualPartDataPropertyKeys') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE FillManualPartDataPropertyKeys  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE FillManualPartDataPropertyKeys
AS
BEGIN

	DECLARE @partNumber varchar(255);
	Declare @partNumbers CURSOR;


	SET @partNumbers = CURSOR FOR select OrderNumber
	    FROM [smartKPIOrderData]
		where System like 'ManualPartData' COLLATE database_default;


		OPEN @partNumbers;
			FETCH NEXT FROM @partNumbers into @partNumber;
		
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				

				insert into [smartKPIOrderKeyValueData]
				([PropertyKey]
					,[FloatValue]
					,[TextValue]
					,[DateTimeValue]
					,[isFloatValue]
					,[isTextValue]
					,[isDateTimeValue]
					,[System]
					,[OrderNumber]
					,[UpdateTime]
					,[UTCUpdateTime]
					,[PlantId]
					,[PropertyKey1]
					,[Operation]
					,[TextValue1])
					select propertyKey
					,NULL
					,''
					,NULL
					,0
					,1
					,0
					,'ManualPartData'
					,@partNumber
					,getdate()
					,GETUTCDATE()
					,NULL
					,propertyKey
					,''
					,'' from
					(select OrderNumber as propertyKey
						FROM [smartKPIOrderData]
						where System like 'ManualPartDataTemplate'
						except
					select PropertyKey
						FROM [smartKPIOrderKeyValueData]
						where System like 'ManualPartData'
						and OrderNumber = @partNumber)x;

				FETCH NEXT FROM @partNumbers into @partNumber;
			END;
		CLOSE @partNumbers;
		DEALLOCATE @partNumbers;


END;
GO
