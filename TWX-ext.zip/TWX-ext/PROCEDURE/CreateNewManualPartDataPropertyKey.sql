--------------------------------------------------------------
--------------------------------------------------------------
print '-- CreateNewManualPartDataPropertyKey';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CreateNewManualPartDataPropertyKey') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE CreateNewManualPartDataPropertyKey  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE CreateNewManualPartDataPropertyKey
@NewPropertyKey varchar(255),
@NewPropertyKeyDescription varchar(255)
AS
BEGIN

	if not exists (select 'ok' from [smartKPIOrderData] where [System] = 'ManualPartDataTemplate' and [OrderNumber] = @NewPropertyKey)
	BEGIN

		insert into [smartKPIOrderData]   ([System]      ,[OrderNumber]      ,[isProductionStarted]      ,[UpdateTime]      ,[isCAPSProductionFinalized]      ,[isCAPSDataUpdated]      ,[UTCCreationTime]      ,[isCAPSOrderError]      ,[CAPSOrderError]      ,[PlantId])
			  values ('ManualPartDataTemplate'      ,@NewPropertyKey      ,0      ,getdate()      ,0      ,1      ,GETUTCDATE()      ,0      ,NULL      ,NULL);

		insert into [smartKPIOrderKeyValueData]  ([PropertyKey]      ,[FloatValue]      ,[TextValue]      ,[DateTimeValue]      ,[isFloatValue]      ,[isTextValue]      ,[isDateTimeValue]      ,[System]      ,[OrderNumber]      ,[UpdateTime]      ,[UTCUpdateTime]      ,[PlantId]      ,[PropertyKey1]      ,[Operation]      ,[TextValue1])
			  values ('Description'      ,NULL      ,@NewPropertyKeyDescription      ,NULL      ,0      ,1      ,0      ,'ManualPartDataTemplate'      ,@NewPropertyKey     ,getdate()      ,GETUTCDATE()      ,NULL      ,'Description'      ,''      ,@NewPropertyKeyDescription);

	END;

	EXEC FillManualPartDataPropertyKeys;
END;
GO