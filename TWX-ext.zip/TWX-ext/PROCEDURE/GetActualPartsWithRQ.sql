--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetActualPartsWithRQ';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetActualPartsWithRQ') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetActualPartsWithRQ  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetActualPartsWithRQ
	@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@Machine varchar(255)
AS
BEGIN

	DECLARE @resulttable table (Label varchar(255), OptionalProductionDate datetime2, OptionalDiffInMinutesLastPartProduced int, OK int, NOK int, KPI float );
	DECLARE @kpitable table ( 
		Machine varchar(255), 
		KPIName varchar(255), 
		KPICalculationBase varchar(255), 
		KPIDateTime DateTime2,  
		KPIDateTimeEndOfCalculation DateTime2,
		KPIFloatValue float);


	declare @CalculationPeriodInMinutes bigint = DATEDIFF_BIG(minute, @StartDateTime, @EndDateTime);

	insert into @kpitable ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue] 
			from dbo.GetUtilizationOee2Truck1(@StartDateTime,@CalculationPeriodInMinutes,1,'flex', 'GetKPIsTruck', @Machine);

	insert into @resulttable (Label, OptionalProductionDate)
	select top(1) PartNumber, ProductionTime
			FROM [smartKPI]
		where ProductionTime between @StartDateTime and @EndDateTime
			and Machine = convert(varchar(255), @Machine)
			order by ProductionTime desc;
	if (select count(*) from @resulttable) = 0
		insert into @resulttable (Label, OptionalProductionDate) values ('-', DATEFROMPARTS(1970,1,1));

	update @resulttable set OK = KPIFloatValue from @kpitable where KPIName = 'OutputIO';
	update @resulttable set NOK = KPIFloatValue from @kpitable where KPIName = 'OutputNIO';
	update @resulttable set NOK = NOK + KPIFloatValue from @kpitable where KPIName = 'CVS: Retests';
	update @resulttable set KPI = round(KPIFloatValue,1) from @kpitable where KPIName = 'RQ';
	update @resulttable set OptionalDiffInMinutesLastPartProduced = DATEDIFF(minute, isnull(OptionalProductionDate,DATEFROMPARTS(1970,1,1)), getutcdate());

	select * from @resulttable;
	
END;

GO


--declare @dt1 as DateTime2 = '2019-11-07 02:00:00.000';
--declare @dt2 as DateTime2 = '2019-11-08 02:00:00.000';

--EXECUTE GetKPITruck @StartDateTime = @dt1, @EndDateTime = @dt2, @Machine = 'KBBUD10424-NBH170MachineThing';  
--GO
