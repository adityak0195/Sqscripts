--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_CalculateSummedUpKPIs_Execution';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_CalculateSummedUpKPIs_Execution') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE KPI_CALCULATOR_CalculateSummedUpKPIs_Execution  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE KPI_CALCULATOR_CalculateSummedUpKPIs_Execution
	@Id varchar(255),
    @Machine varchar(255), 
    @StartDate datetime2, 
    @EndDate datetime2, 
    @KPITimeBase varchar(255)
AS
BEGIN;

    --This procedure is externally called by the KPI-CALCULATOR trigger
    --https://wiki.corp.knorr-bremse.com/display/Iniot/KPI+Calculation+trigger


	set nocount on;
    declare @query varchar(max);
    declare @inputDataTableName  varchar(255) = 'TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_IN_'+@Id;
    declare @outputDataTableName varchar(255) = 'TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_OUT_'+@Id;


-- *********************************************************  Sum of values  *********************************************************
	set @query  = 'insert into '+@outputDataTableName;
    set @query += '    (KPIName                                                                                                               ';
    set @query += '    ,KPICalculationBase                                                                                                    ';
    set @query += '    ,floatValue                                                                                                            ';
    set @query += '    )                                                                                                                      ';
    set @query += 'SELECT                                                                                                                     ';
    set @query += '    KPIName                                                                                                                ';
    set @query += '    ,KPICalculationBase                                                                                                    ';
    set @query += '    ,round(sum(KPIFloatValue),2) as sumValue                                                                               ';
    set @query += 'FROM                                                                                                                       ';
    set @query += ' '+@inputDataTableName+' ';
    set @query += 'where KPIName not like ''CVS: KPI planned working time%''                                                                  ';
    set @query += '    and KPIName not in (''CVS: APO shift factor in percent'', ''CVS: Average Changeover time from operator screen [min]'') ';
    set @query += 'group by                                                                                                                   ';
    set @query += '    KPIName                                                                                                                ';
    set @query += '    ,KPICalculationBase                                                                                                    ';
    EXEC(@query);   

-- *********************************************************  Avg of values  *********************************************************
	set @query  = 'insert into '+@outputDataTableName;
    set @query += '    (KPIName                                                                                                           ';
    set @query += '    ,KPICalculationBase                                                                                                ';
    set @query += '    ,floatValue                                                                                                        ';
    set @query += '    )                                                                                                                  ';
    set @query += 'SELECT                                                                                                                 ';
    set @query += '    KPIName                                                                                                            ';
    set @query += '    ,KPICalculationBase                                                                                                ';
    set @query += '    ,round(avg(KPIFloatValue),2) as avgValue                                                                           ';
    set @query += 'FROM                                                                                                                   ';
    set @query += ' '+@inputDataTableName+' ';
    set @query += 'where   KPIName not like ''CVS: KPI planned working time%''                                                            ';
    set @query += '    and KPIName in (''CVS: APO shift factor in percent'', ''CVS: Average Changeover time from operator screen [min]'') ';
    set @query += 'group by                                                                                                               ';
    set @query += '    KPIName                                                                                                            ';
    set @query += '    ,KPICalculationBase                                                                                                ';
    EXEC(@query);   



-- *********************************************************  GetRVSRQ  *********************************************************
	set @query  = 'with                                                     ';
    set @query += '    OutputIO as                                          ';
    set @query += '        (select                                          ';
    set @query += '            KPIName as KPINameIO                         ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseIO  ';
    set @query += '            ,floatValue as valueIO                       ';
    set @query += '        from                                             ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                            ';
    set @query += '            KPIName = ''OutputIO''                         ';
    set @query += '        )                                                ';
    set @query += '    ,OutputNIO as                                        ';
    set @query += '        (select                                          ';
    set @query += '            KPIName as KPINameNIO                        ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseNIO ';
    set @query += '            ,floatValue as valueNIO                      ';
    set @query += '        from                                             ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                            ';
    set @query += '            KPIName = ''OutputNIO''                        ';
    set @query += '        )                                                ';
	set @query += 'update                                                   ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                      ';
    set @query += '    floatValue = dbo.GetRVSRQ(IO.valueIO,NIO.valueNIO)   ';
    set @query += 'from                                                     ';
    set @query += '    OutputIO as IO                                       ';
    set @query += '    ,OutputNIO as NIO                                    ';
    set @query += 'where                                                    ';
    set @query += '    KPICalculationBase = IO.KPICalculationBaseIO         ';
    set @query += '    and KPICalculationBase = NIO.KPICalculationBaseNIO   ';
    set @query += '    and KPIName = ''RQ''                                   ';
    set @query += '    and KPICalculationBase = ''GetCIPKPIsRailWorker''      ';
    EXEC(@query);   

-- *********************************************************  GetCVSRQ  *********************************************************
	set @query  = 'with                                                                      ';
    set @query += '    OutputIO as                                                           ';
    set @query += '        (select                                                           ';
    set @query += '            KPIName as KPINameIO                                          ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseIO                   ';
    set @query += '            ,floatValue as valueIO                                        ';
    set @query += '        from                                                              ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                             ';
    set @query += '            KPIName = ''OutputIO''                                          ';
    set @query += '        )                                                                 ';
    set @query += '    ,OutputNIO as                                                         ';
    set @query += '        (select                                                           ';
    set @query += '            KPIName as KPINameNIO                                         ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseNIO                  ';
    set @query += '            ,floatValue as valueNIO                                       ';
    set @query += '        from                                                              ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                             ';
    set @query += '            KPIName = ''OutputNIO''                                         ';
    set @query += '        )                                                                 ';
    set @query += '    ,Retest as                                                            ';
    set @query += '        (select                                                           ';
    set @query += '            KPIName as KPINameRetest                                      ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseRetest               ';
    set @query += '            ,floatValue as valueRetest                                    ';
    set @query += '        from                                                              ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                             ';
    set @query += '            KPIName = ''CVS: Retests''                                      ';
    set @query += '        )                                                                 ';
	set @query += 'update                                                                    ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                                       ';
    set @query += '    floatValue = dbo.GetCVSRQ(IO.valueIO,NIO.valueNIO,Retest.valueRetest) ';
    set @query += 'from                                                                      ';
    set @query += '    OutputIO as IO                                                        ';
    set @query += '    ,OutputNIO as NIO                                                     ';
    set @query += '    ,Retest                                                               ';
    set @query += 'where                                                                     ';
    set @query += '    KPICalculationBase = IO.KPICalculationBaseIO                          ';
    set @query += '    and KPICalculationBase = NIO.KPICalculationBaseNIO                    ';
    set @query += '    and KPICalculationBase = Retest.KPICalculationBaseRetest              ';
    set @query += '    and KPIName = ''RQ''                                                    ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                         ';
    EXEC(@query);   
    
                                                                            
                                                                            
-- *********************************************************  GetCVSDLP3  *********************************************************
	set @query  = 'with                                                                    ';
    set @query += '    Kbph as                                                             ';
    set @query += '        (select                                                         ';
    set @query += '            KPIName as KPINameKbph                                      ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseKbph               ';
    set @query += '            ,floatValue as valueKbph                                    ';
    set @query += '        from                                                            ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                           ';
    set @query += '            KPIName = ''CVS DLP3: KB paid hours''                         ';
    set @query += '        )                                                               ';
    set @query += '    ,Cph as                                                             ';
    set @query += '        (select                                                         ';
    set @query += '            KPIName as KPINameCph                                       ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseCph                ';
    set @query += '            ,floatValue as valueCph                                     ';
    set @query += '        from                                                            ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                           ';
    set @query += '            KPIName = ''CVS DLP3: Customer paid hours''                   ';
    set @query += '        )                                                               ';
	set @query += 'update                                                                  ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                                     ';
    set @query += '    floatValue = dbo.GetCVSDLP3(Kbph.valueKbph,Cph.valueCph)            ';
    set @query += 'from                                                                    ';
    set @query += '    Cph                                                                 ';
    set @query += '    ,Kbph                                                               ';
    set @query += 'where                                                                   ';
    set @query += '    KPICalculationBase = Kbph.KPICalculationBaseKbph                    ';
    set @query += '    and KPICalculationBase = Cph.KPICalculationBaseCph                  ';
    set @query += '    and KPIName = ''CVS DLP3: Ratio (Customer paid hours/KB paid hours)'' ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                       ';
    EXEC(@query);   
    
                                                                            
-- *********************************************************  GetCVSDlp1 (Actual)  *********************************************************
	set @query  = 'with                                                                ';
    set @query += '    OutputIO as                                                     ';
    set @query += '        (select                                                     ';
    set @query += '            KPIName as KPINameIO                                    ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseIO             ';
    set @query += '            ,floatValue as valueIO                                  ';
    set @query += '        from                                                        ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                       ';
    set @query += '            KPIName = ''OutputIO''                                    ';
    set @query += '        )                                                           ';
    set @query += '    ,TimeInShift as                                                 ';
    set @query += '        (select                                                     ';
    set @query += '            KPIName as KPINameTime                                  ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTime           ';
    set @query += '            ,floatValue as valueTime                                ';
    set @query += '        from                                                        ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                       ';
    set @query += '            KPIName = ''CVS: Sum of login times at line''             ';
    set @query += '        )                                                           ';
	set @query += 'update                                                              ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                                 ';
    set @query += '    floatValue = dbo.GetCVSDlp1(IO.valueIO,TimeInShift.valueTime,1) ';
    set @query += 'from                                                                ';
    set @query += '    OutputIO as IO                                                  ';
    set @query += '    ,TimeInShift                                                    ';
    set @query += 'where                                                               ';
    set @query += '    KPICalculationBase = IO.KPICalculationBaseIO                    ';
    set @query += '    and KPICalculationBase = TimeInShift.KPICalculationBaseTime     ';
    set @query += '    and KPIName = ''CVS DLP1: Actual''                                ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                   ';
    EXEC(@query);   
                                                                            


-- *********************************************************  GetCVSDlp1 (Target)  *********************************************************
	set @query  = 'with                                                                                         ';
    set @query += '    Target as                                                                                ';
    set @query += '        (select                                                                              ';
    set @query += '            KPIName as KPINameTarget                                                         ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTarget                                  ';
    set @query += '            ,floatValue as valueTarget                                                       ';
    set @query += '        from                                                                                 ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                                                ';
    set @query += '            KPIName = ''CVS DLP1: Calculated Production Target''                               ';
    set @query += '        )                                                                                    ';
    set @query += '    ,TimeInShift as                                                                          ';
    set @query += '        (select                                                                              ';
    set @query += '            KPIName as KPINameTime                                                           ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTime                                    ';
    set @query += '            ,floatValue as valueTime                                                         ';
    set @query += '        from                                                                                 ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                                                ';
    set @query += '            KPIName = ''CVS DLP1: Time in seconds within shift(s)''                            ';
    set @query += '        )                                                                                    ';
    set @query += '    ,Worker as                                                                               ';
    set @query += '        (select                                                                              ';
    set @query += '            KPIName as KPINameWorker                                                         ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseWorker                                  ';
    set @query += '            ,floatValue as valueWorker                                                       ';
    set @query += '        from                                                                                 ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                                                ';
    set @query += '            KPIName = ''CVS: Planned number of workers from SAP''                              ';
    set @query += '        )                                                                                    ';
	set @query += 'update                                                                                       ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                                                          ';
    set @query += '    floatValue = dbo.GetCVSDlp1(Target.valueTarget,TimeInShift.valueTime,Worker.valueWorker) ';
    set @query += 'from                                                                                         ';
    set @query += '    Target                                                                                   ';
    set @query += '    ,TimeInShift                                                                             ';
    set @query += '    ,Worker                                                                                  ';
    set @query += 'where                                                                                        ';
    set @query += '    KPICalculationBase = Target.KPICalculationBaseTarget                                     ';
    set @query += '    and KPICalculationBase = Worker.KPICalculationBaseWorker                                 ';
    set @query += '    and KPICalculationBase = TimeInShift.KPICalculationBaseTime                              ';
    set @query += '    and KPIName = ''CVS DLP1: Calculated Target''                                              ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                                            ';
    EXEC(@query);   


-- *********************************************************  GetCVSDlp1Ratio  *********************************************************
	set @query  = 'with                                                                        ';
    set @query += '    Actual as                                                               ';
    set @query += '        (select                                                             ';
    set @query += '            KPIName as KPINameActual                                        ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseActual                 ';
    set @query += '            ,floatValue as valueActual                                      ';
    set @query += '        from                                                                ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                               ';
    set @query += '            KPIName = ''CVS DLP1: Actual''                                    ';
    set @query += '        )                                                                   ';
    set @query += '    ,Target as                                                              ';
    set @query += '        (select                                                             ';
    set @query += '            KPIName as KPINameTarget                                        ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTarget                 ';
    set @query += '            ,floatValue as valueTarget                                      ';
    set @query += '        from                                                                ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                               ';
    set @query += '            KPIName = ''CVS DLP1: Calculated Target''                         ';
    set @query += '        )                                                                   ';
	set @query += 'update                                                                      ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                                         ';
    set @query += '    floatValue = dbo.GetCVSDlp1Ratio(Actual.valueActual,Target.valueTarget) ';
    set @query += 'from                                                                        ';
    set @query += '    Actual                                                                  ';
    set @query += '    ,Target                                                                 ';
    set @query += 'where                                                                       ';
    set @query += '    KPICalculationBase = Actual.KPICalculationBaseActual                    ';
    set @query += '    and KPICalculationBase = Target.KPICalculationBaseTarget                ';
    set @query += '    and KPIName = ''CVS DLP1: Ratio (Actual/Calculated Target)''              ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                           ';
    EXEC(@query);   


-- *********************************************************  GetCVSUtilization  *********************************************************
	set @query  = 'with                                                                            ';
    set @query += '    Tgmax as                                                                    ';
    set @query += '        (select                                                                 ';
    set @query += '            KPIName as KPINameTgmax                                             ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTgmax                      ';
    set @query += '            ,floatValue as valueTgmax                                           ';
    set @query += '        from                                                                    ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                                   ';
    set @query += '            KPIName = ''CVS: Sum tgmax times for IO parts in seconds''            ';
    set @query += '        )                                                                       ';
    set @query += '    ,TimeBase as                                                                ';
    set @query += '        (select                                                                 ';
    set @query += '            KPIName as KPINameTimeBase                                          ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTimeBase                   ';
    set @query += '            ,floatValue as valueTimeBase                                        ';
    set @query += '        from                                                                    ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                                   ';
    set @query += '            KPIName = ''CVS: Time base for utilization in seconds''               ';
    set @query += '        )                                                                       ';
	set @query += 'update                                                                          ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                                             ';
    set @query += '    floatValue = dbo.GetCVSUtilization(Tgmax.valueTgmax,TimeBase.valueTimeBase) ';
    set @query += 'from                                                                            ';
    set @query += '    Tgmax                                                                       ';
    set @query += '    ,TimeBase                                                                   ';
    set @query += 'where                                                                           ';
    set @query += '    KPICalculationBase = Tgmax.KPICalculationBaseTgmax                          ';
    set @query += '    and KPICalculationBase = TimeBase.KPICalculationBaseTimeBase                ';
    set @query += '    and KPIName = ''CVS: Utilization''                                            ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                               ';
    EXEC(@query);   



-- *********************************************************  GetCVSOEE  *********************************************************
	set @query  = 'with                                                                                      ';
    set @query += '    Tgmax as                                                                              ';
    set @query += '        (select                                                                           ';
    set @query += '            KPIName as KPINameTgmax                                                       ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTgmax                                ';
    set @query += '            ,floatValue as valueTgmax                                                     ';
    set @query += '        from                                                                              ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                                             ';
    set @query += '            KPIName = ''CVS: Sum tgmax times for IO parts in seconds''                      ';
    set @query += '        )                                                                                 ';
    set @query += '    ,TimeBase as                                                                          ';
    set @query += '        (select                                                                           ';
    set @query += '            KPIName as KPINameTimeBase                                                    ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseTimeBase                             ';
    set @query += '            ,floatValue as valueTimeBase                                                  ';
    set @query += '        from                                                                              ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                                             ';
    set @query += '            KPIName = ''CVS: Planned working time in seconds (from start to end of shift)'' ';
    set @query += '        )                                                                                 ';
	set @query += 'update                                                                                    ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                                                       ';
    set @query += '    floatValue = dbo.GetCVSOEE(Tgmax.valueTgmax,TimeBase.valueTimeBase)                   ';
    set @query += 'from                                                                                      ';
    set @query += '    Tgmax                                                                                 ';
    set @query += '    ,TimeBase                                                                             ';
    set @query += 'where                                                                                     ';
    set @query += '    KPICalculationBase = Tgmax.KPICalculationBaseTgmax                                    ';
    set @query += '    and KPICalculationBase = TimeBase.KPICalculationBaseTimeBase                          ';
    set @query += '    and KPIName = ''CVS: OEE (Version 2)''                                                  ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                                         ';
    EXEC(@query);   



-- *********************************************************  CVS DLP1: Local Target  *********************************************************
	set @query  = 'with                                                             ';
    set @query += '    Worker as                                                    ';
    set @query += '        (select                                                  ';
    set @query += '            KPIName as KPINameWorker                             ';
    set @query += '            ,KPICalculationBase as KPICalculationBaseWorker      ';
    set @query += '            ,floatValue as valueWorker                           ';
    set @query += '        from                                                     ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += '        where                                                    ';
    set @query += '            KPIName = ''CVS: Planned number of workers from SAP''  ';
    set @query += '        )                                                        ';
    set @query += '    ,MachineKeyValueData as                                      ';
    set @query += '        (select                                                  ';
    set @query += '            PropertySubKey1                                      ';
    set @query += '            ,FloatValue                                          ';
    set @query += '        from                                                     ';
    set @query += '            smartKPIMachineKeyValueData                          ';
    set @query += '        where                                                    ';
    set @query += '            PropertyKey = ''DLP1''                                 ';
    set @query += '            and Machine = '''+@Machine+'''';
    set @query += '        )                                                        ';
	set @query += 'update                                                           ';
    set @query += ' '+@outputDataTableName+' ';
    set @query += 'set                                                              ';
    set @query += '    floatValue = MachineKeyValueData.FloatValue                  ';
    set @query += 'from                                                             ';
    set @query += '    MachineKeyValueData                                          ';
    set @query += '    ,Worker                                                      ';
    set @query += 'where                                                            ';
    set @query += '    KPICalculationBase = Worker.KPICalculationBaseWorker         ';
    set @query += '    and KPIName = ''CVS DLP1: Local Target''                       ';
    set @query += '    and KPICalculationBase = ''GetKPIsTruckWorker''                ';
    set @query += '    and MachineKeyValueData.PropertySubKey1 = Worker.valueWorker ';
    EXEC(@query);   




-- ******************************************************************************************************************************************
-- *********************************************************  Final update of KPIs  *********************************************************
-- ******************************************************************************************************************************************
    set @query  = 'delete smartKPIValues                                             ';
    set @query += '    from smartKPIValues, '+@outputDataTableName+' dt                      ';
    set @query += '    where smartKPIValues.Machine = '''+@Machine+'''';
    set @query += '    and smartKPIValues.KPITimeBase = '''+@KPITimeBase+'''';
    set @query += '    and smartKPIValues.KPIName = dt.KPIName                       ';
    set @query += '    and smartKPIValues.KPICalculationBase = dt.KPICalculationBase ';
    set @query += '    and smartKPIValues.KPIDateTime = convert(datetime2,'''+convert(varchar,@StartDate)+''')';
    set @query += '    and smartKPIValues.KPIDateTimeEnd = convert(datetime2,'''+convert(varchar,@EndDate)+''')';
    EXEC(@query);   

    set @query  = 'insert into smartKPIValues (Machine,KPITimeBase,KPIName,KPICalculationBase,KPIDateTime,KPIDateTimeEnd,KPIFloatValue) ';
    set @query += 'select '''+@Machine+''','''+@KPITimeBase+''',KPIName,KPICalculationBase,convert(datetime2,'''+convert(varchar,@StartDate)+'''),convert(datetime2,'''+convert(varchar,@EndDate)+'''),floatValue from '+@outputDataTableName;
    EXEC(@query);   




END;
GO
