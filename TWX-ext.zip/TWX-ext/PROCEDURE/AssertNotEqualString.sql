--------------------------------------------------------------
--------------------------------------------------------------
print '-- AssertNotEqualString';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'AssertNotEqualString') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE AssertNotEqualString  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE AssertNotEqualString
	@value varchar(max),
	@targetvalue varchar(max),
	@messagetext varchar(255) = ''
AS
BEGIN

	SET NOCOUNT ON;

	if  (@value = @targetvalue	)
	BEGIN
		declare @text varchar(max) =  @messagetext +': '+ cast (@value as varchar) + ' = ' + cast (@targetvalue as varchar);
		RAISERROR (@text, -- Message text.
					   16, -- Severity.
					   1 -- State.
					   );
	END;
END;
GO