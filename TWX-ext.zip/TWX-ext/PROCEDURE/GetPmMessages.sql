--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetPmMessages';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPmMessages') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetPmMessages  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetPmMessages
AS
BEGIN
	SET NOCOUNT ON

SELECT [Id]
      ,[description]
  FROM [smartKPIMachineStatusData]
  where StatusType = 'SAP PM'
  and SubStatus = 'Created';

  
END;

GO