--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetKPITruck';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetKPITruck') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetKPITruck  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetKPITruck
	@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@Machine varchar(255)
AS
BEGIN
	declare @dummy int;
	SET NOCOUNT ON


	select @StartDateTime as StartDateTime,
			@EndDateTime as EndDateTime, 
			Machine, 
			KPIName, 
			KPICalculationBase, 
			KPIDateTime,  
			KPIDateTimeEndOfCalculation,
			KPIFloatValue, 
			[KPIName] as Label, 
			ROUND([KPIFloatValue],2) as KPI 
		from GetKPIsTruck(@StartDateTime, @EndDateTime, @Machine);  
END;

GO