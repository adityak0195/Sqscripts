--------------------------------------------------------------
--------------------------------------------------------------
print '-- AssertIsNotNullInt';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'AssertIsNotNullInt') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE AssertIsNotNullInt  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE AssertIsNotNullInt
	@value int,
	@messagetext varchar(255) = ''
AS
BEGIN

	SET NOCOUNT ON;

	if  (@value is null	)
	BEGIN
		declare @text varchar(max) =  @messagetext +': @value is null';
		RAISERROR (@text, -- Message text.
					   16, -- Severity.
					   1 -- State.
					   );
	END;
END;
GO
