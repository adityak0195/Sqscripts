--------------------------------------------------------------
--------------------------------------------------------------
print '-- FillTEMPSmartKPIFullShift';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'FillTEMPSmartKPIFullShift') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE FillTEMPSmartKPIFullShift  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE FillTEMPSmartKPIFullShift
	@FullInit bit = 0,
	@TestInit bit = 0
AS
BEGIN
	SET NOCOUNT ON
	
	exec DeleteDoubleShiftCalendarEntries;
	
	Declare @SAPMachine varchar(255);
	DECLARE @Now datetime2 = dateadd(day,-1,getutcdate());

	insert into [smartKPIJobLogger] ([Job],[LogLevel],[LogText]) values ('FillTEMPSmartKPIFullShift', 0, 'Start: @FullInit = '+convert(varchar,@FullInit));
	
	if (@FullInit = 1 AND @TestInit = 0)
		truncate table TEMP_SmartKPIFullShift;
	-- else
		-- delete from TEMP_SmartKPIFullShift where CurrentStartTime > @Now;
	if (@FullInit = 1 AND @TestInit = 1)
		delete from TEMP_SmartKPIFullShift where Machine = 'TESTMACHINE'
		delete from TEMP_SmartKPIFullShift where Machine = 'TESTMACHINE1'
		
	Declare @getMachines CURSOR;
	Declare @Machine varchar(255);
	DECLARE @CurrentName varchar(255);
	DECLARE @CurrentStartTime datetime2;
	DECLARE @MinStartTime datetime2;
	DECLARE @MaxStartTime datetime2;
	DECLARE @CurrentEndTime datetime2;

	if (@TestInit = 0)
		SET @getMachines = CURSOR for select a.Machine as Machine from smartKPIMachineKeyValueData a 
			inner join
			(Select Machine from smartKPIMachineKeyValueData where PropertyKey='isActive' and FloatValue=1) b
			on a.Machine=b.Machine
			where TextValue = 'KBLocalMachineThingTemplate' order by 1;
	else
		SET @getMachines = CURSOR for select 'TESTMACHINE' as Machine
			 Union all
			 select 'TESTMACHINE1' as Machine; 
			
			
	OPEN @getMachines;
		FETCH NEXT FROM @getMachines into @Machine
		WHILE @@FETCH_STATUS = 0
		BEGIN;

			SELECT @SAPMachine=[TextValue]
			  FROM [smartKPIMachineKeyValueData]
			  where Machine = @Machine
			  and PropertyKey = 'SAPWorkcenterNumber';
			if (@FullInit = 0)  
				 delete from TEMP_SmartKPIFullShift where Machine=@Machine and CurrentStartTime > @Now;
			WAITFOR DELAY '00:00:01';  
			if (@FullInit = 1)
				select @MaxStartTime=max(StartTime), @MinStartTime=min(StartTime) from shiftCalendar where Machine = @SAPMachine and Qualifier = 'W';
			else
				select @MaxStartTime=max(StartTime), @MinStartTime=min(StartTime) from shiftCalendar where Machine = @SAPMachine and StartTime > @Now and Qualifier = 'W';

			set @CurrentStartTime = @MinStartTime;
			if (@FullInit = 0)
				set @MinStartTime = @Now;
				
			WHILE @CurrentStartTime <= @MaxStartTime
			BEGIN
				select @CurrentName=CurrentName, @CurrentStartTime=CurrentStartTime, @CurrentEndTime=CurrentEndTime from GetFullShiftFunction (@Machine, @CurrentStartTime);  
				--print (convert(varchar, @CurrentStartTime)+' - '+convert(varchar, @CurrentEndTime)+' - '+@Machine);
				insert into TEMP_SmartKPIFullShift (Machine, CurrentName, CurrentStartTime, CurrentEndTime)
				select @Machine, @CurrentName, @CurrentStartTime, @CurrentEndTime where @CurrentStartTime >= @MinStartTime;

				if @CurrentStartTime >= @MinStartTime
					exec CalulateTarget @Machine=@Machine, @DateStart=@CurrentStartTime, @DateEnd=@CurrentEndTime;

				select @CurrentStartTime=min(StartTime) from shiftCalendar where Machine = @SAPMachine and StartTime >= @CurrentEndTime and Qualifier = 'W';
				
			END;

			WAITFOR DELAY '00:00:01';  
			FETCH NEXT FROM @getMachines into @Machine;
		END;
	CLOSE @getMachines;
	DEALLOCATE @getMachines;
	
	delete from TEMP_SmartKPIFullShift
	where CurrentEndTime < CurrentStartTime;

	insert into [smartKPIJobLogger] ([Job],[LogLevel],[LogText]) values ('FillTEMPSmartKPIFullShift', 0, 'End: @FullInit = '+convert(varchar,@FullInit));
	
END;

GO
