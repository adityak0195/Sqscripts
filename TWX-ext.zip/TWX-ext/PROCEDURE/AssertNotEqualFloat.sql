--------------------------------------------------------------
--------------------------------------------------------------
print '-- AssertNotEqualFloat';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'AssertNotEqualFloat') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE AssertNotEqualFloat  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE AssertNotEqualFloat
	@value float,
	@targetvalue float,
	@messagetext varchar(255) = ''
AS
BEGIN

	SET NOCOUNT ON;

	if  (@value = @targetvalue	)
	BEGIN
		declare @text varchar(max) =  @messagetext +': '+ cast (@value as varchar) + ' = ' + cast (@targetvalue as varchar);
		RAISERROR (@text, -- Message text.
					   16, -- Severity.
					   1 -- State.
					   );
	END;
END;
GO