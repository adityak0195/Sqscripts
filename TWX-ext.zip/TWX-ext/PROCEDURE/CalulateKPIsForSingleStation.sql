--------------------------------------------------------------
--------------------------------------------------------------
print '-- CalulateKPIsForSingleStation';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateKPIsForSingleStation') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE CalulateKPIsForSingleStation  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE CalulateKPIsForSingleStation
	@StartDate as DateTime2,
	@EndDate as DateTime2,
	@CalculationBase varchar(255),
	@Machine varchar(255),
	@Station varchar(255)
AS
BEGIN;
Declare @CVS_DMS_Day_Offset_in_Minutes int;
	declare @StartDateOffsetForSingleMachine datetime2 = @StartDate;
	declare @EndDateOffsetForSingleMachine datetime2 = @EndDate;
	declare @table table (Machine varchar(255), KPIName varchar(255), KPICalculationBase varchar(255), KPIDateTime datetime2, KPIDateTimeEnd datetime2, KPIFloatValue float);
	declare @division varchar(255);
	declare @CalculationPeriodInMinutes bigint = DATEDIFF_BIG(minute, @StartDate, @EndDate);
	declare @IsOperatorInputScreenUsedForThisStation bit;
	BEGIN TRY
	
        declare @DeleteArchivedDataTimeInMonths int;
        declare @DeleteArchivedProcessDataTimeInMonths int;
		
		select @IsOperatorInputScreenUsedForThisStation =[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'IsOperatorInputScreenUsedForThisStation' and [Machine] = @Station;
		select @DeleteArchivedDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedDataTimeInMonths' and [Machine] = 'DB';
		select @DeleteArchivedProcessDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedProcessDataTimeInMonths' and [Machine] = 'DB';

		declare @deleteDate dateTime2 = dateadd(month,-1 * @DeleteArchivedDataTimeInMonths,getutcdate());
		declare @deleteDateForProcessAndMachineData dateTime2 = dateadd(month,-1 * @DeleteArchivedProcessDataTimeInMonths,getutcdate());

        if (@StartDate >= @deleteDate and  @StartDate >= @deleteDateForProcessAndMachineData)
        BEGIN

			SELECT @division=TextValue
				FROM [smartKPIMachineKeyValueData]
				where Machine = (select [TextValue] FROM [smartKPIMachineKeyValueData]
				where Machine = @Machine
				and PropertyKey = 'KBPlantThing') COLLATE database_default
				and PropertyKey = 'KBDivisionThing';

			if @division = 'KBTruckDivisionThing'
			BEGIN
			-- Downtimes calculation start
			if @IsOperatorInputScreenUsedForThisStation=1
				BEGIN
				if @CalculationPeriodInMinutes<1441
				  BEGIN
					insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue) 
	 				  select @Station, 'CVS: '+StatusType+ ' [sec]', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine, @EndDateOffsetForSingleMachine, isnull(TimeSumInSeconds,0)  
						from GetDowntimeStatistic(@StartDateOffsetForSingleMachine, @EndDateOffsetForSingleMachine, @Machine, @Station);
					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEnd, KPIFloatValue) 
					  select @Station, 'CVS: '+StatusType+ ' [count]', 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine, @EndDateOffsetForSingleMachine,isnull(Occurrences,0)  
						from GetDowntimeStatistic(@StartDateOffsetForSingleMachine, @EndDateOffsetForSingleMachine, @Machine, @Station) where Occurrences is not null;
				  END
				ELSE
				  BEGIN
					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEnd, [KPIFloatValue])
					  SELECT Machine, KPIName, 'GetKPIsTruckWorker', @StartDateOffsetForSingleMachine, @EndDateOffsetForSingleMachine, SUM([KPIFloatValue]) 
					  FROM [smartKPIValues] where Machine=@Station and KPIDateTime >=@StartDateOffsetForSingleMachine and KPIDateTimeEnd<=@EndDateOffsetForSingleMachine  and KPIName like 'CVS: L%'  and KPITimeBase='day' and [KPICalculationBase]='GetKPIsTruckWorker'
					  group by Machine, KPIName order by KPIName
				  END
				END
				  -- Downtimes calculation end
			END;
			
			delete from [smartKPIValues] where KPIDateTime = @StartDateOffsetForSingleMachine and KPIDateTimeEnd = @EndDateOffsetForSingleMachine and Machine = @Station;
			WAITFOR DELAY '00:00:01';  
			insert into [smartKPIValues] (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue, KPITimeBase)
				select Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEnd, KPIFloatValue, @CalculationBase from @table;

		END;
	END TRY  
	BEGIN CATCH  
		set @CVS_DMS_Day_Offset_in_Minutes = 0;
	END CATCH 

END;
GO

