--------------------------------------------------------------
--------------------------------------------------------------
print '-- MergeOrderKeyValue';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'MergeOrderKeyValue') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE MergeOrderKeyValue  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE MergeOrderKeyValue
	@DateTimeValue DATETIME2,
	@FloatValue float,
	@isDateTimeValue bit,
	@isFloatValue bit,
	@isTextValue bit,
	@Key varchar(255),
	@OrderNumber varchar(255),
	@PlantId varchar(255),
	@System varchar(255),
	@TextValue varchar(max),
	@Key1 varchar(255) = NULL,
	@Key2 varchar(255) = ''
AS
BEGIN;

	if not exists (select 'ok' from [smartKPIOrderKeyValueData]
				  where OrderNumber = @OrderNumber
				  and PropertyKey = 'MaterialNumber'
				) and @Key = 'MaterialNumber'
	BEGIN
		-- Manual Part Data Handling
		insert into [smartKPIOrderKeyValueData]
		([PropertyKey]
			  ,[FloatValue]
			  ,[TextValue]
			  ,[DateTimeValue]
			  ,[isFloatValue]
			  ,[isTextValue]
			  ,[isDateTimeValue]
			  ,[System]
			  ,[OrderNumber]
			  ,[UpdateTime]
			  ,[UTCUpdateTime]
			  ,[PlantId]
			  ,[PropertyKey1]
			  ,[Operation]
			  ,[TextValue1])
		SELECT [PropertyKey]
			  ,[FloatValue]
			  ,[TextValue]
			  ,[DateTimeValue]
			  ,[isFloatValue]
			  ,[isTextValue]
			  ,[isDateTimeValue]
			  ,@System
			  ,@OrderNumber
			  ,getdate()
			  ,getutcdate()
			  ,@PlantId
			  ,[PropertyKey1]
			  ,[Operation]
			  ,[TextValue1]
		  FROM [smartKPIOrderKeyValueData]
		  where System = 'ManualPartData'
		  and OrderNumber = @TextValue		
	End



	if @Key1 is NULL
		BEGIN

			merge into smartKPIOrderKeyValueData 
			using 
				(select 
					@Key as PropertyKey, 
					@FloatValue as FloatValue ,
					@TextValue as TextValue, 
					case @TextValue when  NULL then NULL else substring(@TextValue,1,254) end as TextValue1, 
					@DateTimeValue as DateTimeValue, 
					ISNULL(@isFloatValue, 0) as isFloatValue, 
					ISNULL(@isTextValue, 0) as isTextValue, 
					ISNULL(@isDateTimeValue, 0) as isDateTimeValue, 
					@System as System, 
					@OrderNumber as OrderNumber, 
					GETDATE() as UpdateTime,
					case when (SUBSTRING(@Key, CASE when (DATALENGTH(@Key) > 4) then DATALENGTH(@Key)-4 else 0 end,1) = '-') then SUBSTRING(@Key,1,DATALENGTH(@Key)-5)
						else @Key
						end as PropertyKey1,
					case when (SUBSTRING(@Key, CASE when (DATALENGTH(@Key) > 4) then DATALENGTH(@Key)-4 else 0 end,1) = '-') then SUBSTRING(@Key,DATALENGTH(@Key)-3,4)
						else ''
						end as Operation,
					@PlantId as PlantId,
					getUtcdate() as UTCUpdateTime) 
				as source
			on smartKPIOrderKeyValueData.PropertyKey = source.PropertyKey
			and smartKPIOrderKeyValueData.System = source.System
			and smartKPIOrderKeyValueData.OrderNumber = source.OrderNumber
			when matched then
			  update  
				set [FloatValue] = source.FloatValue
				   ,[TextValue] = source.TextValue
				   ,[TextValue1] = source.TextValue1
				   ,[DateTimeValue] = source.DateTimeValue
				   ,[isFloatValue] = source.isFloatValue
				   ,[isTextValue] = source.isTextValue
				   ,[isDateTimeValue] = source.isDateTimeValue
				   ,[UpdateTime] = source.UpdateTime
				   ,[UTCUpdateTime] = source.UTCUpdateTime
				   ,[PropertyKey1] = source.PropertyKey1
				   ,[Operation] = source.Operation
				   ,[PlantId] = source.PlantId
			when not matched then	
				insert   
				(	PropertyKey, 
					System, 
					OrderNumber, 
					FloatValue,
					TextValue, 
					TextValue1, 
					DateTimeValue, 
					isFloatValue, 
					isTextValue, 
					isDateTimeValue, 
					UpdateTime,
					UTCUpdateTime,
					PropertyKey1,
					Operation,
					PlantId) values 
				(	source.PropertyKey, 
					source.System, 
					source.OrderNumber, 
					source.FloatValue, 
					source.TextValue, 
					source.TextValue1, 
					source.DateTimeValue, 
					source.isFloatValue, 
					source.isTextValue, 
					source.isDateTimeValue, 
					source.UpdateTime,
					source.UTCUpdateTime,
					source.PropertyKey1,
					source.Operation,
					source.PlantId ); 


--			INSERT into smartKPIOrderKeyValueData ([PropertyKey]
--				   ,[FloatValue]
--				   ,[TextValue]
--				   ,[TextValue1]
--				   ,[DateTimeValue]
--				   ,[isFloatValue]
--				   ,[isTextValue]
--				   ,[isDateTimeValue]
--				   ,[System]
--				   ,[OrderNumber]
--				   ,[UpdateTime]
--				   ,[PropertyKey1]
--				   ,[Operation])  
--			select @Key, @FloatValue, @TextValue, case @TextValue when  NULL then NULL else substring(@TextValue,1,254) end, @DateTimeValue, 
--					ISNULL(@isFloatValue, 0), ISNULL(@isTextValue, 0), ISNULL(@isDateTimeValue, 0), 
--					@System, @OrderNumber, GETDATE(),
--					case when (SUBSTRING(@Key, CASE when (DATALENGTH(@Key) > 4) then DATALENGTH(@Key)-4 else 0 end,1) = '-') then SUBSTRING(@Key,1,DATALENGTH(@Key)-5)
--						else @Key
--						end,
--					case when (SUBSTRING(@Key, CASE when (DATALENGTH(@Key) > 4) then DATALENGTH(@Key)-4 else 0 end,1) = '-') then SUBSTRING(@Key,DATALENGTH(@Key)-3,4)
--						else ''
--						end
--					where not exists (select 'ok' from smartKPIOrderKeyValueData  
--						where PropertyKey = @Key
--						and System = @System
--						and OrderNumber = @OrderNumber); 
--
--			UPDATE smartKPIOrderKeyValueData
--				set [FloatValue] = @FloatValue
--				   ,[TextValue] = @TextValue
--				   ,[TextValue1] = case @TextValue when  NULL then NULL else substring(@TextValue,1,254) end
--				   ,[DateTimeValue] = @DateTimeValue
--				   ,[isFloatValue] = ISNULL(@isFloatValue, 0)
--				   ,[isTextValue] = ISNULL(@isTextValue, 0)
--				   ,[isDateTimeValue] = ISNULL(@isDateTimeValue, 0)
--				   ,[UpdateTime] = GETDATE()
--				   ,[UTCUpdateTime] = getUtcdate()
--				   ,[PlantId] = @PlantId
--				where PropertyKey = @Key
--						and System = @System
--						and OrderNumber = @OrderNumber;
			END;
		ELSE
		BEGIN
			INSERT into smartKPIOrderKeyValueData ([PropertyKey]
				   ,[FloatValue]
				   ,[TextValue]
				   ,[TextValue1]
				   ,[DateTimeValue]
				   ,[isFloatValue]
				   ,[isTextValue]
				   ,[isDateTimeValue]
				   ,[System]
				   ,[OrderNumber]
				   ,[UpdateTime]
				   ,[PropertyKey1]
				   ,[Operation],
				   [PlantId],
				   [UTCUpdateTime])  
			select @Key, @FloatValue, @TextValue, case @TextValue when  NULL then NULL else substring(@TextValue,1,254) end, @DateTimeValue, 
					ISNULL(@isFloatValue, 0), ISNULL(@isTextValue, 0), ISNULL(@isDateTimeValue, 0), 
					@System, @OrderNumber, GETDATE(),
					@Key1,@Key2, @PlantId, getUtcdate()
					where not exists (select 'ok' from smartKPIOrderKeyValueData  
						where PropertyKey = @Key
						and System = @System
						and OrderNumber = @OrderNumber); 

			if @Key not in ('FastemsUpdateOrder','FastemsRemovedOrder', 'FastemsNewOrder') 
				or (select isnull(TextValue,'-') from [smartKPIOrderKeyValueData]
													where OrderNumber = @OrderNumber
													and System = @System
													and PropertyKey in ('FastemsUpdateOrder','FastemsRemovedOrder', 'FastemsNewOrder')
													and isTextValue = 1
													and Operation = @Key2
													and PropertyKey = @Key) <> @TextValue
				or (select 'ok' from [smartKPIOrderKeyValueData]
													where OrderNumber = @OrderNumber
													and System = @System
													and PropertyKey in ('FastemsUpdateOrder','FastemsRemovedOrder', 'FastemsNewOrder')
													and isTextValue = 1
													and Operation != @Key2
													and PropertyKey = @Key) = 'ok'
				or (select isnull(FloatValue,0) from [smartKPIOrderKeyValueData]
													where OrderNumber = @OrderNumber
													and System = @System
													and PropertyKey in ('FastemsUpdateOrder')
													and isFloatValue = 1
													and Operation = @Key2
													and PropertyKey = @Key) <> @FloatValue
				or ((select isnull(PropertyKey1,'-') from [smartKPIOrderKeyValueData]
													where OrderNumber = @OrderNumber
													and System = @System
													and PropertyKey in ('FastemsUpdateOrder','FastemsRemovedOrder', 'FastemsNewOrder')
													and Operation = @Key2
													and PropertyKey = @Key) = 'unsent' and @Key1 = 'sent')
				UPDATE smartKPIOrderKeyValueData
					set [FloatValue] = @FloatValue
					   ,[TextValue] = @TextValue
					   ,[TextValue1] = case @TextValue when  NULL then NULL else substring(@TextValue,1,254) end
					   ,[DateTimeValue] = @DateTimeValue
					   ,[isFloatValue] = ISNULL(@isFloatValue, 0)
					   ,[isTextValue] = ISNULL(@isTextValue, 0)
					   ,[isDateTimeValue] = ISNULL(@isDateTimeValue, 0)
					   ,[UpdateTime] = GETDATE()
					   ,[UTCUpdateTime] = getUtcdate()
					   ,[PlantId] = @PlantId
					   ,[PropertyKey1] = @Key1
					   ,[Operation] = @Key2
					where PropertyKey = @Key
							and System = @System
							and OrderNumber = @OrderNumber;
		END;
					
		IF @Key LIKE 'Line%' 
			IF (@TextValue in (
								SELECT DISTINCT TextValue
									FROM smartKPIMachineKeyValueData
									WHERE PropertyKey = 'SAPWorkcenterNumber'
										AND Machine like '%StationThing'
										AND TextValue != ''
										AND TextValue is not NULL
							  )
				)
				UPDATE smartKPIOrderData
					SET [isCAPSDataUpdated] = 1,
						[isCAPSOrderError] = 0,
						[UpdateTime] = GETDATE(),
						[UTCUpdateTime] = getUtcdate()
					WHERE OrderNumber = @OrderNumber and System = @System;
END;
GO

