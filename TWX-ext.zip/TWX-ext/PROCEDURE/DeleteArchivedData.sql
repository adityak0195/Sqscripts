--------------------------------------------------------------
--------------------------------------------------------------
print '-- DeleteArchivedData';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'DeleteArchivedData') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE DeleteArchivedData  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE DeleteArchivedData
@isInfoOnly int = 1
AS
BEGIN
	declare @linesNotPrepared int;
	declare @linesTransfered int;
	declare @linesToTransfer int;
	declare @linesDeleted int;
	declare @totalLines int;
	declare @pointer bigint;
	declare @tableName varchar(255);
	declare @rowsToDeleteWithinOneCycle int = 1000;
	
	declare @DeleteArchivedDataTimeInMonths int;
	declare @DeleteArchivedProcessDataTimeInMonths int;
	
	select @DeleteArchivedDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedDataTimeInMonths' and [Machine] = 'DB';
	select @DeleteArchivedProcessDataTimeInMonths=[FloatValue] from [smartKPIMachineKeyValueData] where [PropertyKey] = 'DeleteArchivedProcessDataTimeInMonths' and [Machine] = 'DB';


	declare @deleteDate dateTime2 = dateadd(month,-1 * @DeleteArchivedDataTimeInMonths,getutcdate());
	declare @deleteDateForProcessAndMachineData dateTime2 = dateadd(month,-1 * @DeleteArchivedProcessDataTimeInMonths,getutcdate());
	
	
	
	
	
	
  --*******************************************************************************************************************************************
--	delete from TEMP_SmartKPICVSProductionTarget 
--	where UTCCreationTime < dateadd(month,-1*@DeleteArchivedDataTimeInMonths,GETUTCDATE()) ;
--	delete from TEMP_SmartKPICVSProductionTargetDetail 
--	where UTCCreationTime < dateadd(month,-1*@DeleteArchivedDataTimeInMonths,GETUTCDATE()) ;
  --*******************************************************************************************************************************************
	
	if (@isInfoOnly!=1)
	BEGIN
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData','start, @isInfoOnly='+cast(@isInfoOnly as varchar(10)));	
	END;


	print 'Date till data will be deleted: '+convert(varchar,@deleteDate);
	print 'Date till process and machine data will be deleted: '+convert(varchar,@deleteDateForProcessAndMachineData);
	--*******************************************************************************************************************************************
	print 'check null values';
	--*******************************************************************************************************************************************
	while ((select top (1) Id from smartKPIMachineFloatData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIMachineFloatData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIMachineFloatData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIMachineStringData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIMachineStringData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIMachineStringData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPI where modification_id is null) is not null)
	BEGIN
		print 'smartKPI';
		update top(@rowsToDeleteWithinOneCycle) smartKPI set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIMachineStatusData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIMachineStatusData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIMachineStatusData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIMachineMessageData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIMachineMessageData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIMachineMessageData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from shiftCalendar where modification_id is null) is not null)
	BEGIN
		print 'shiftCalendar';
		update top(@rowsToDeleteWithinOneCycle) shiftCalendar set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIProcessDateTimeData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIProcessDateTimeData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIProcessDateTimeData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIProcessFloatData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIProcessFloatData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIProcessFloatData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIProcessStringData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIProcessStringData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIProcessStringData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIOrderKeyValueData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIOrderKeyValueData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIOrderKeyValueData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;
	while ((select top (1) Id from smartKPIOrderData where modification_id is null) is not null)
	BEGIN
		print 'smartKPIOrderData';
		update top(@rowsToDeleteWithinOneCycle) smartKPIOrderData set move_to_history = move_to_history where modification_id is null;
		WAITFOR DELAY '00:00:01';
	END;


	--*******************************************************************************************************************************************
	print 'TEMP tables';
	--*******************************************************************************************************************************************
	WHILE ((select top(1) EndTime 
				from TEMP_SmartKPICVSProductionTarget
				where EndTime < @deleteDate) is not null)
	BEGIN
		delete top (@rowsToDeleteWithinOneCycle) from TEMP_SmartKPICVSProductionTarget where EndTime < @deleteDate;
		WAITFOR DELAY '00:00:01';
	END;
	
	WHILE ((select top(1) EndTime 
				from TEMP_SmartKPICVSProductionTargetDetail
				where EndTime < @deleteDate) is not null)
	BEGIN
		delete top (@rowsToDeleteWithinOneCycle) from TEMP_SmartKPICVSProductionTargetDetail where EndTime < @deleteDate;
		WAITFOR DELAY '00:00:01';
	END;

	WHILE ((select top(1) CurrentEndTime 
				from TEMP_SmartKPIFullShift
				where CurrentEndTime < @deleteDate) is not null)
	BEGIN
		delete top (@rowsToDeleteWithinOneCycle) from TEMP_SmartKPIFullShift where CurrentEndTime < @deleteDate and Machine != 'TESTMACHINE';
		WAITFOR DELAY '00:00:01';
	END;	
	
	
	
	--*******************************************************************************************************************************************
	print 'start delete';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIMachineStringData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIMachineStringData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIMachineStringData
					where modification_id <= @pointer
					and MachineTime < @deleteDateForProcessAndMachineData
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIMachineStringData
				where modification_id <= @pointer
				and MachineTime < @deleteDateForProcessAndMachineData
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineStringData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIMachineStringData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineStringData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;

	END;
	
	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIMachineStringData;
		select @linesTransfered=count(*) from smartKPIMachineStringData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIMachineStringData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIMachineStringData
		where modification_id <= @pointer
		and MachineTime < @deleteDateForProcessAndMachineData;
		select @linesNotPrepared=count(*) from smartKPIMachineStringData where modification_id is null;
		
		
		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIMachineFloatData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIMachineFloatData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIMachineFloatData
					where modification_id <= @pointer
					and MachineTime < @deleteDateForProcessAndMachineData
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIMachineFloatData
				where modification_id <= @pointer
				and MachineTime < @deleteDateForProcessAndMachineData
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineFloatData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIMachineFloatData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineFloatData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;

	END;
	
	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIMachineFloatData;
		select @linesTransfered=count(*) from smartKPIMachineFloatData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIMachineFloatData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIMachineFloatData
		where modification_id <= @pointer
		and MachineTime < @deleteDateForProcessAndMachineData;
		select @linesNotPrepared=count(*) from smartKPIMachineFloatData where modification_id is null;
		
		
		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPI';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPI_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPI
					where modification_id <= @pointer
					and ProductionTime < @deleteDate
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPI
				where modification_id <= @pointer
				and ProductionTime < @deleteDate
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPI 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPI
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPI 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;
	
	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPI;
		select @linesTransfered=count(*) from smartKPI
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPI
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPI
		where modification_id <= @pointer
		and ProductionTime < @deleteDate;
		select @linesNotPrepared=count(*) from smartKPI where modification_id is null;
		
		
		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIValues';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIValues_V1'

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIValues;
		select @linesTransfered=count(*) from smartKPIValues
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIValues
		where modification_id > @pointer;
		select @linesNotPrepared=count(*) from smartKPIValues where modification_id is null;
		--select @linesDeleted=count(*) from smartKPIValues
		--where modification_id <= @pointer
		--and KPIDateTimeEnd < @deleteDate;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		--print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  --insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIMachineStatusData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIMachineStatusData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIMachineStatusData
					where modification_id <= @pointer
					and StatusTime < @deleteDate
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIMachineStatusData 
				where modification_id <= @pointer
				and StatusTime < @deleteDate
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineStatusData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIMachineStatusData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineStatusData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIMachineStatusData;
		select @linesTransfered=count(*) from smartKPIMachineStatusData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIMachineStatusData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIMachineStatusData
		where modification_id <= @pointer
		and StatusTime < @deleteDate;
		select @linesNotPrepared=count(*) from smartKPIMachineStatusData where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIMachineMessageData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIMachineMessageData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIMachineMessageData
					where modification_id <= @pointer
					and MessageTime < @deleteDate
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIMachineMessageData 
				where modification_id <= @pointer
				and MessageTime < @deleteDate
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineMessageData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIMachineMessageData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIMachineMessageData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIMachineMessageData;
		select @linesTransfered=count(*) from smartKPIMachineMessageData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIMachineMessageData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIMachineMessageData
		where modification_id <= @pointer
		and MessageTime < @deleteDate;
		select @linesNotPrepared=count(*) from smartKPIMachineMessageData where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'shiftCalendar';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_shiftCalendar_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from shiftCalendar
					where modification_id <= @pointer
					and EndTime < @deleteDate
					and Machine not in ('SAPTESTMACHINE', 'SAPTESTMACHINE1')
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from shiftCalendar 
				where modification_id <= @pointer
				and EndTime < @deleteDate
				and Machine not in ('SAPTESTMACHINE', 'SAPTESTMACHINE1')
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from shiftCalendar 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from shiftCalendar
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from shiftCalendar 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from shiftCalendar;
		select @linesTransfered=count(*) from shiftCalendar
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from shiftCalendar
		where modification_id > @pointer;
		select @linesDeleted=count(*) from shiftCalendar
		where modification_id <= @pointer
		and EndTime < @deleteDate;
		select @linesNotPrepared=count(*) from shiftCalendar where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIMachineKeyValueData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIMachineKeyValueData_V1'

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIMachineKeyValueData;
		select @linesTransfered=count(*) from smartKPIMachineKeyValueData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIMachineKeyValueData
		where modification_id > @pointer;
		select @linesNotPrepared=count(*) from smartKPIMachineKeyValueData where modification_id is null;
		--select @linesDeleted=count(*) from smartKPIMachineKeyValueData
		--where modification_id <= @pointer
		--and ProductionTime < @deleteDate;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		--print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  --insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIProcessDateTimeData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIProcessDateTimeData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIProcessDateTimeData
					where modification_id <= @pointer
					and ProductionTime < @deleteDateForProcessAndMachineData
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIProcessDateTimeData 
				where modification_id <= @pointer
				and ProductionTime < @deleteDateForProcessAndMachineData
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIProcessDateTimeData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIProcessDateTimeData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIProcessDateTimeData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIProcessDateTimeData;
		select @linesTransfered=count(*) from smartKPIProcessDateTimeData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIProcessDateTimeData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIProcessDateTimeData
		where modification_id <= @pointer
		and ProductionTime < @deleteDateForProcessAndMachineData;
		select @linesNotPrepared=count(*) from smartKPIProcessDateTimeData where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIProcessFloatData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIProcessFloatData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIProcessFloatData
					where modification_id <= @pointer
					and ProductionTime < @deleteDateForProcessAndMachineData
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIProcessFloatData 
				where modification_id <= @pointer
				and ProductionTime < @deleteDateForProcessAndMachineData
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIProcessFloatData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIProcessFloatData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIProcessFloatData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIProcessFloatData;
		select @linesTransfered=count(*) from smartKPIProcessFloatData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIProcessFloatData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIProcessFloatData
		where modification_id <= @pointer
		and ProductionTime < @deleteDateForProcessAndMachineData;
		select @linesNotPrepared=count(*) from smartKPIProcessFloatData where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIProcessStringData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIProcessStringData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIProcessStringData
					where modification_id <= @pointer
					and ProductionTime < @deleteDateForProcessAndMachineData
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIProcessStringData 
				where modification_id <= @pointer
				and ProductionTime < @deleteDateForProcessAndMachineData
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIProcessStringData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIProcessStringData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIProcessStringData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIProcessStringData;
		select @linesTransfered=count(*) from smartKPIProcessStringData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIProcessStringData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIProcessStringData
		where modification_id <= @pointer
		and ProductionTime < @deleteDateForProcessAndMachineData;
		select @linesNotPrepared=count(*) from smartKPIProcessStringData where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIOrderKeyValueData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIOrderKeyValueData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIOrderKeyValueData
					where modification_id <= @pointer
					and UTCUpdateTime < @deleteDate
					and System not in ('ManualPartDataTemplate', 'ManualPartData')
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIOrderKeyValueData 
				where modification_id <= @pointer
				and UTCUpdateTime < @deleteDate
				and System not in ('ManualPartDataTemplate', 'ManualPartData')
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIOrderKeyValueData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIOrderKeyValueData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIOrderKeyValueData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIOrderKeyValueData;
		select @linesTransfered=count(*) from smartKPIOrderKeyValueData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIOrderKeyValueData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIOrderKeyValueData
		where modification_id <= @pointer
		and UTCUpdateTime < @deleteDate;
		select @linesNotPrepared=count(*) from smartKPIOrderKeyValueData where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************
	set @tableName = 'smartKPIOrderData';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;
	select @pointer=UpdatedId from [smartKPIKepwareConnectorPointer] where Machine = 'KBAzureBlobStorageExportTable_smartKPIOrderData_V1'

	if (@isInfoOnly!=1)
	BEGIN
		WHILE ((select top(1) Id 
					from smartKPIOrderData
					where modification_id <= @pointer
					and UTCUpdateTime < @deleteDate
					and System not in ('ManualPartDataTemplate', 'ManualPartData')
					and move_to_history = 0) is not null)
		BEGIN
			with CTE AS
			(select top (@rowsToDeleteWithinOneCycle) *
				from smartKPIOrderData 
				where modification_id <= @pointer
				and UTCUpdateTime < @deleteDate
				and System not in ('ManualPartDataTemplate', 'ManualPartData')
				and move_to_history = 0)
			update CTE set move_to_history = 1;
			WAITFOR DELAY '00:00:01';
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIOrderData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
		
		WHILE ((select top(1) Id 
					from smartKPIOrderData
					where move_to_history = 1) is not null)
		BEGIN
			delete top (@rowsToDeleteWithinOneCycle) from smartKPIOrderData 
				where move_to_history = 1;
			WAITFOR DELAY '00:00:01';
		END;
	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from smartKPIOrderData;
		select @linesTransfered=count(*) from smartKPIOrderData
		where modification_id <= @pointer;
		select @linesToTransfer=count(*) from smartKPIOrderData
		where modification_id > @pointer;
		select @linesDeleted=count(*) from smartKPIOrderData
		where modification_id <= @pointer
		and UTCUpdateTime < @deleteDate;
		select @linesNotPrepared=count(*) from smartKPIOrderData where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Current Pointer value: '+convert(varchar,@pointer);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		print 'Lines transfered: '+convert(varchar,@linesTransfered);
		print 'Lines to transfer: '+convert(varchar,@linesToTransfer);
		print 'Lines to be deleted: '+convert(varchar,@linesDeleted);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines transfered', @linesTransfered, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to transfer', @linesToTransfer, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines to be deleted', @linesDeleted, 'data rows');
		END;
	END;
	print '************************************************************************';
	--*******************************************************************************************************************************************

	set @tableName = 'SYSTEM_deletedEntries';
	print @tableName;
	if (@isInfoOnly!=1)
	BEGIN
		WAITFOR DELAY '00:00:01';
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData',@tableName);	
	END;

	if (@isInfoOnly!=2)
	BEGIN
		select @totalLines=count(*) from SYSTEM_deletedEntries;
		select @linesNotPrepared=count(*) from SYSTEM_deletedEntries where modification_id is null;

		print '************************************************************************';
		print @tableName;
		print 'Total Lines: '+convert(varchar,@totalLines);
		print 'Lines not prepared: '+convert(varchar,@linesNotPrepared);
		if (@isInfoOnly=0)
		BEGIN
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Total Lines', @totalLines, 'data rows');
			  insert into [smartKPIMachineFloatData] ([Machine],[MachineTime],[MachineDataType],[MachineData],[Unit]) values ('KBThingWorxAzureBlobStorageExportSchedulerThing', getutcdate(), @tableName+' Lines not prepared', @linesNotPrepared, 'data rows');
		END;
	END;

	if (@isInfoOnly!=1)
	BEGIN
		insert into smartKPIJobLogger([Job], [LogText]) values ('DeleteArchivedData','end, @isInfoOnly=0');	
	END;
END;
go

--exec DeleteArchivedData
