--------------------------------------------------------------
--------------------------------------------------------------
print '-- CheckFastemsOrder';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CheckFastemsOrder') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE CheckFastemsOrder  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE CheckFastemsOrder
	@SapThing varchar(255),
	@OrderNumber varchar(255),
	@SAPPlantId varchar(255)
AS
BEGIN

	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--This procedure is used for sending orders directly to KBB fastems machines. 
	--Do changes only with confirmation from :
	--Nacke, Mathias
	--Koordinator SCM BE
	--R/BEP22 Logistik BE
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************

	DECLARE @xml varchar(max);
	DECLARE @now datetime2 = getdate();
	DECLARE @CurrentWorkcenter varchar(255);
	DECLARE @CurrentWorkcenterTwx varchar(255);
	DECLARE @IsFastemsNewOrderAlreadySent varchar(255);
	DECLARE @IsFastemsDeleteOrderAlreadySent varchar(255);
	DECLARE @MachineToWhichLastTelegramWasSent varchar(255);
	DECLARE @DateTimeWhenLastTelegramWasSent datetime2;
	DECLARE @LastTelegramWhichWasSent varchar(max);
	DECLARE @MachineToWhichLastNewUpdateTelegramWasSent varchar(255);
	DECLARE @DateTimeWhenLastNewUpdateTelegramWasSent datetime2;
	DECLARE @LastNewUpdateTelegramWhichWasSent varchar(max);
	DECLARE @Tagb varchar(5);
    declare @amountFromOrders integer;

	if @SapThing = 'KBRailSAPServer' and @SAPPlantId = '0203'
	BEGIN
		--Was already an order sent to fastems?
		select @IsFastemsNewOrderAlreadySent=PropertyKey from [smartKPIOrderKeyValueData] where PropertyKey = 'FastemsNewOrder' and OrderNumber = @OrderNumber and System = @SapThing;

		if (@IsFastemsNewOrderAlreadySent is not null)
		BEGIN
			--To which machine and when was already an order sent to fastems?
			select top(1) @MachineToWhichLastTelegramWasSent=Operation, @DateTimeWhenLastTelegramWasSent=DateTimeValue, @LastTelegramWhichWasSent=TextValue from [smartKPIOrderKeyValueData] 
				where PropertyKey in ('FastemsNewOrder', 'FastemsRemovedOrder', 'UpdatedOrders')
				and OrderNumber = @OrderNumber
				and System = @SapThing
				order by DateTimeValue desc;

			select top(1) @MachineToWhichLastNewUpdateTelegramWasSent=Operation, @DateTimeWhenLastNewUpdateTelegramWasSent=DateTimeValue, @LastNewUpdateTelegramWhichWasSent=TextValue from [smartKPIOrderKeyValueData] 
				where PropertyKey in ('FastemsNewOrder', 'UpdatedOrders')
				and OrderNumber = @OrderNumber
				and System = @SapThing
				order by DateTimeValue desc;

			if (@MachineToWhichLastTelegramWasSent is not null)
			BEGIN
				--Was the sent order deleted?
				select top(1) @IsFastemsDeleteOrderAlreadySent='deleted' from [smartKPIOrderKeyValueData] 
					where PropertyKey = 'FastemsRemovedOrder'
					and OrderNumber = @OrderNumber
					and Operation = @MachineToWhichLastTelegramWasSent
					and DateTimeValue > @DateTimeWhenLastTelegramWasSent
					and System = @SapThing;		
			END
		END

		--What is the assigned work center for that order?
		select top(1) @CurrentWorkcenter=TextValue, 
				@CurrentWorkcenterTwx=case 
					when TextValue='S3448341' then 'KBKBB1989HELLERFastemsServerStationThing' 
					when TextValue='S3448342' then 'KBKBB1990HELLERFastemsServerStationThing' 
					when TextValue='S3448343' then 'KBKBB1992HELLERFastemsServerStationThing' 
					when TextValue='S3448344' then 'KBKBB1993HELLERFastemsServerStationThing' 
					when TextValue='S3448345' then 'KBKBB1994HELLERFastemsServerStationThing' 
					else '' 
				end
			from [smartKPIOrderKeyValueData]	
			where OrderNumber = @OrderNumber 
			and PropertyKey1 = 'Line'
			and TextValue in ('S3448341', 'S3448342', 'S3448343', 'S3448344', 'S3448345')
			and PlantId = @SAPPlantId
			and System = @SapThing;

		if @CurrentWorkcenter is not null
		BEGIN
			-- Assigned work center is a fastems machine!
			
			
			select @amountFromOrders = convert(integer,FloatValue) 
				from smartKPIOrderKeyValueData
				where OrderNumber = @OrderNumber
				and PropertyKey = 'TotalOrderQuantity';

			select @Tagb='TAGB' from [smartKPIOrderKeyValueData]
				where PropertyKey = 'Head-Status'
				and OrderNumber = @OrderNumber
				and TextValue like '%I0045%'
				and TextValue not like '%I0009%';
				  
			if (@IsFastemsNewOrderAlreadySent is null AND @Tagb is null)
			BEGIN
				--Send FastemsNewOrder to machine
				--Test Case: FA freigeben
				set @now = getdate();
				select @xml=dbo.GetOrderDataForFastems(@OrderNumber , @CurrentWorkcenter, 'NewOrders');
				exec dbo.MergeOrderKeyValue
					@DateTimeValue = @now,
					@FloatValue = @amountFromOrders,
					@isDateTimeValue = 1,
					@isFloatValue = 1,
					@isTextValue = 1,
					@Key = 'FastemsNewOrder',
					@OrderNumber = @OrderNumber ,
					@PlantId = @SAPPlantId,
					@System = @SapThing,
					@TextValue = @xml,
					@Key1 = 'unsent',
					@Key2 = @CurrentWorkcenter;

				insert into [smartKPIMachineMessageData] ([Machine]
					  ,[MessageTime]
					  ,[MessageType1]
					  ,[MessageType2]
					  ,[Message]
					  ,[description])
				values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @CurrentWorkcenter,'New order number ('+@OrderNumber+'): sending "NewOrders" message! ('+@xml+')' , 'Info from SAP transfer');
			END;
			ELSE
			BEGIN
				if isnull(@MachineToWhichLastNewUpdateTelegramWasSent,'') != @CurrentWorkcenter
				BEGIN
					-- Privious workcenter different to current (but both fastems)
					--Test Case: FA auf eine andere Maschine umplanen
					--Test Case: Auf eine andere Maschine umplanen nach Teilrückgemeldung  FA
					set @now = getdate();
					select @xml=dbo.GetOrderDataForFastems(@OrderNumber , @CurrentWorkcenter, 'RemovedOrders');
					if (@xml = 'Order already fulfilled')
					BEGIN
						insert into [smartKPIMachineMessageData] ([Machine]
							  ,[MessageTime]
							  ,[MessageType1]
							  ,[MessageType2]
							  ,[Message]
							  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @MachineToWhichLastNewUpdateTelegramWasSent,'Order changed to other Fastems machine, order number ('+@OrderNumber+'): But order already fulfilled!' , 'Info from SAP transfer');
					END
					ELSE
					BEGIN
						exec dbo.MergeOrderKeyValue
							@DateTimeValue = @now,
							@FloatValue = @amountFromOrders,
							@isDateTimeValue = 1,
							@isFloatValue = 1,
							@isTextValue = 1,
							@Key = 'FastemsRemovedOrder',
							@OrderNumber = @OrderNumber ,
							@PlantId = @SAPPlantId,
							@System = @SapThing,
							@TextValue = @xml,
							@Key1 = 'unsent',
							@Key2 = @MachineToWhichLastNewUpdateTelegramWasSent;

						insert into [smartKPIMachineMessageData] ([Machine]
							  ,[MessageTime]
							  ,[MessageType1]
							  ,[MessageType2]
							  ,[Message]
							  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @MachineToWhichLastNewUpdateTelegramWasSent,'Order changed to other Fastems machine, order number ('+@OrderNumber+'): sending "OrderDelete" message! ('+@xml+')' , 'Info from SAP transfer');
						
						if (@Tagb is null)
						BEGIN

							set @now = getdate();
							select @xml=dbo.GetOrderDataForFastems(@OrderNumber , @CurrentWorkcenter, 'NewOrders');
							exec dbo.MergeOrderKeyValue
								@DateTimeValue = @now,
								@FloatValue = @amountFromOrders,
								@isDateTimeValue = 1,
								@isFloatValue = 1,
								@isTextValue = 1,
								@Key = 'FastemsNewOrder',
								@OrderNumber = @OrderNumber ,
								@PlantId = @SAPPlantId,
								@System = @SapThing,
								@TextValue = @xml,
								@Key1 = 'unsent',
								@Key2 = @CurrentWorkcenter;

							insert into [smartKPIMachineMessageData] ([Machine]
								  ,[MessageTime]
								  ,[MessageType1]
								  ,[MessageType2]
								  ,[Message]
								  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @CurrentWorkcenter,'New order number ('+@OrderNumber+'): sending "NewOrders" message! ('+@xml+')' , 'Info from SAP transfer');
						END
					END
				End
				ELSE if (@Tagb is null)
				BEGIN
					--same fastems machine
					--Test Case: FA Termin ändern
					--Test Case: FA Stückzahl ändern
					--Test Case: Teilrückmeldung
					set @now = getdate();
					select @xml=dbo.GetOrderDataForFastems(@OrderNumber , @CurrentWorkcenter, 'UpdatedOrders');
					if @LastNewUpdateTelegramWhichWasSent = replace(@xml,'UpdatedOrders','NewOrders') OR @LastNewUpdateTelegramWhichWasSent = @xml
					BEGIN
						-- no relevant data change
						insert into [smartKPIMachineMessageData] ([Machine]
							  ,[MessageTime]
							  ,[MessageType1]
							  ,[MessageType2]
							  ,[Message]
							  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @CurrentWorkcenter,'Existing order number ('+@OrderNumber+'): "OrderChange" message not sent because no relevant data change ('+@xml+')' , 'Info from SAP transfer');
					End
					ELSE
					BEGIN
						-- relevant data change
						exec dbo.MergeOrderKeyValue
							@DateTimeValue = @now,
							@FloatValue = @amountFromOrders,
							@isDateTimeValue = 1,
							@isFloatValue = 1,
							@isTextValue = 1,
							@Key = 'FastemsUpdateOrder',
							@OrderNumber = @OrderNumber ,
							@PlantId = @SAPPlantId,
							@System = @SapThing,
							@TextValue = @xml,
							@Key1 = 'unsent',
							@Key2 = @CurrentWorkcenter;

						insert into [smartKPIMachineMessageData] ([Machine]
							  ,[MessageTime]
							  ,[MessageType1]
							  ,[MessageType2]
							  ,[Message]
							  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @CurrentWorkcenter,'Existing order number ('+@OrderNumber+'): sending "OrderChange" message! ('+@xml+')' , 'Info from SAP transfer');
					END
				End
				ELSE
					BEGIN
					--same fastems machine but with order status TAGB
					--Test Case: FA TABG setzten
					set @now = getdate();
					select @xml=dbo.GetOrderDataForFastems(@OrderNumber , @CurrentWorkcenter, 'RemovedOrders');
					if @LastTelegramWhichWasSent = @xml
					BEGIN
						-- no relevant data change
						insert into [smartKPIMachineMessageData] ([Machine]
							  ,[MessageTime]
							  ,[MessageType1]
							  ,[MessageType2]
							  ,[Message]
							  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @CurrentWorkcenter,'Existing order number ('+@OrderNumber+'): "OrderDelete" message not sent because no relevant data change ('+@xml+')' , 'Info from SAP transfer');
					End
					ELSE IF (@xml = 'Order already fulfilled')
					BEGIN
						insert into [smartKPIMachineMessageData] ([Machine]
							  ,[MessageTime]
							  ,[MessageType1]
							  ,[MessageType2]
							  ,[Message]
							  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @CurrentWorkcenter,'Existing order number ('+@OrderNumber+'): But order already fulfilled!' , 'Info from SAP transfer');
					END
					ELSE
					BEGIN
						-- relevant data change
						exec dbo.MergeOrderKeyValue
							@DateTimeValue = @now,
							@FloatValue = @amountFromOrders,
							@isDateTimeValue = 1,
							@isFloatValue = 1,
							@isTextValue = 1,
							@Key = 'FastemsRemovedOrder',
							@OrderNumber = @OrderNumber ,
							@PlantId = @SAPPlantId,
							@System = @SapThing,
							@TextValue = @xml,
							@Key1 = 'unsent',
							@Key2 = @CurrentWorkcenter;

						insert into [smartKPIMachineMessageData] ([Machine]
							  ,[MessageTime]
							  ,[MessageType1]
							  ,[MessageType2]
							  ,[Message]
							  ,[description])
							values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @CurrentWorkcenter,'Existing order number ('+@OrderNumber+'): sending "OrderDelete" message! ('+@xml+')' , 'Info from SAP transfer');
					END
				END;
			END;
		END;
		ELSE
		BEGIN
			--Currently no fastems machine
			if isnull(@IsFastemsDeleteOrderAlreadySent,'') != 'deleted' and isnull(@MachineToWhichLastTelegramWasSent,'') != ''
			BEGIN
				-- Not yet an detete order sent
				set @now = getdate();
				select @xml=dbo.GetOrderDataForFastems(@OrderNumber , @CurrentWorkcenter, 'RemovedOrders');
				exec dbo.MergeOrderKeyValue
					@DateTimeValue = @now,
					@FloatValue = NULL,
					@isDateTimeValue = 1,
					@isFloatValue = 0,
					@isTextValue = 1,
					@Key = 'FastemsRemovedOrder',
					@OrderNumber = @OrderNumber ,
					@PlantId = @SAPPlantId,
					@System = @SapThing,
					@TextValue = @xml,
					@Key1 = 'unsent',
					@Key2 = @MachineToWhichLastTelegramWasSent;

				insert into [smartKPIMachineMessageData] ([Machine]
					  ,[MessageTime]
					  ,[MessageType1]
					  ,[MessageType2]
					  ,[Message]
					  ,[description])
					values (@CurrentWorkcenterTwx, getdate(), 'FASTEMS-IN', @MachineToWhichLastTelegramWasSent,'Order changed to non Fastems machine, order number ('+@OrderNumber+'): sending "OrderDelete" message! ('+@xml+')' , 'Info from SAP transfer');
			END
		END
	END;
END;

GO

