--------------------------------------------------------------
--------------------------------------------------------------
print '-- FillTEMPSmartKPIFullShiftForMachine';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'FillTEMPSmartKPIFullShiftForMachine') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE FillTEMPSmartKPIFullShiftForMachine  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE [FillTEMPSmartKPIFullShiftForMachine]
	@Machine varchar(255)
AS
BEGIN
	SET NOCOUNT ON
	
	Declare @SAPMachine varchar(255);
	DECLARE @Now datetime2 = dateadd(day,-1,getutcdate());

	insert into [smartKPIJobLogger] ([Job],[LogLevel],[LogText]) values ('FillTEMPSmartKPIFullShiftForMachine', 0, 'Start for Machine = '+@Machine);
	
	Declare @getMachines CURSOR;
	DECLARE @CurrentName varchar(255);
	DECLARE @CurrentStartTime datetime2;
	DECLARE @MinStartTime datetime2;
	DECLARE @MaxStartTime datetime2;
	DECLARE @CurrentEndTime datetime2;

	BEGIN;

			SELECT @SAPMachine=[TextValue]
			  FROM [smartKPIMachineKeyValueData]
			  where Machine = @Machine
			  and PropertyKey = 'SAPWorkcenterNumber';
			delete from TEMP_SmartKPIFullShift where Machine=@Machine and CurrentStartTime > @Now;
			WAITFOR DELAY '00:00:01';  
			select @MaxStartTime=max(StartTime), @MinStartTime=min(StartTime) from shiftCalendar where Machine = @SAPMachine and StartTime > @Now and Qualifier = 'W';

			set @CurrentStartTime = @MinStartTime;
			set @MinStartTime = @Now;
				
			WHILE @CurrentStartTime <= @MaxStartTime
			BEGIN
				select @CurrentName=CurrentName, @CurrentStartTime=CurrentStartTime, @CurrentEndTime=CurrentEndTime from GetFullShiftFunction (@Machine, @CurrentStartTime);  
				insert into TEMP_SmartKPIFullShift (Machine, CurrentName, CurrentStartTime, CurrentEndTime)
				select @Machine, @CurrentName, @CurrentStartTime, @CurrentEndTime where @CurrentStartTime >= @MinStartTime;

				if @CurrentStartTime >= @MinStartTime
					exec CalulateTarget @Machine=@Machine, @DateStart=@CurrentStartTime, @DateEnd=@CurrentEndTime;

				select @CurrentStartTime=min(StartTime) from shiftCalendar where Machine = @SAPMachine and StartTime >= @CurrentEndTime and Qualifier = 'W';
				
			END;
		END;
	
	insert into [smartKPIJobLogger] ([Job],[LogLevel],[LogText]) values ('FillTEMPSmartKPIFullShiftForMachine', 0, 'End for Machine = '+@Machine);
	
END;

GO

