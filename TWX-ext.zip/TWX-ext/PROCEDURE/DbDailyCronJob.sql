--------------------------------------------------------------
--------------------------------------------------------------
print '-- DbDailyCronJob';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'DbDailyCronJob') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE DbDailyCronJob  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE DbDailyCronJob
AS
BEGIN

	SET NOCOUNT ON;

	exec DeleteArchivedData @isInfoOnly = 0;
	

END;
GO
