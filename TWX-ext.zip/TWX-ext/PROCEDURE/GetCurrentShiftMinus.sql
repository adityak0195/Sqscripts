--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCurrentShiftMinus';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCurrentShiftMinus') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetCurrentShiftMinus  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetCurrentShiftMinus
	@Machine varchar(255),
	@ShiftStart DateTime2,
	@MinusIterations int
AS
BEGIN

	DECLARE @table table (CurrentName varchar(255), CurrentStartTime datetime2, CurrentEndTime datetime2);

	if (@MinusIterations = 0)
		insert into @table (CurrentName, CurrentStartTime, CurrentEndTime)
			select CurrentName, CurrentStartTime, CurrentEndTime from GetCurrentShiftFunction (@Machine, @ShiftStart);  
	else
		insert into @table 
			exec GetFullShiftMinus @Machine=@Machine, @ShiftStart=@ShiftStart, @MinusIterations=@MinusIterations;


	select CurrentName, CurrentStartTime, CurrentEndTime from @table;  
	
END;

GO