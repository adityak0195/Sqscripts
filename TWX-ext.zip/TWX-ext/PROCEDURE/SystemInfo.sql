--------------------------------------------------------------
--------------------------------------------------------------
print '-- SystemInfo';
--------------------------------------------------------------
--------------------------------------------------------------


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'SystemInfo') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE SystemInfo  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE SystemInfo
AS
BEGIN

	select server, type, count, comment from (
	SELECT '1' as orderkey, @@SERVERNAME as server, 'Plants' as type, count (Machine) as count, '' as comment
	  FROM [smartKPIMachineKeyValueData]
	  where TextValue = 'KBLocalPlantThingTemplate'
	  COLLATE database_default
	union
	SELECT '2' as orderkey, @@SERVERNAME as server, 'Areas' as type, count (distinct Machine) as count, ''
	  FROM [smartKPIMachineKeyValueData]
	  where TextValue = 'KBLocalAreaThingTemplate'
	  COLLATE database_default
	union
	SELECT '3' as orderkey, @@SERVERNAME as server, 'Machines' as type, count (distinct Machine) as count, ''
	  FROM [smartKPIMachineKeyValueData]
	  where TextValue = 'KBLocalMachineThingTemplate'
	  COLLATE database_default
	union
	SELECT '4' as orderkey, @@SERVERNAME as server, 'Stations' as type, count (distinct Machine) as count, ''
	  FROM [smartKPIMachineKeyValueData]
	  where TextValue = 'KBLocalStationThingTemplate'
	  COLLATE database_default
	union
	SELECT '6', @@SERVERNAME, System, count(distinct [UserId]), ''
	  FROM [smartKPIUserData]
	  where [isUserActive] = 1
	  group by System
	union
	select '5', @@SERVERNAME, 'Process Data Stations', count(distinct Machine), 'Total entries: '+convert(varchar, count(*))
	from V_smartKPIProcessData
	union
	select '98', @@SERVERNAME, 'DB-Table Version', null, [TextValue] 
	from [smartKPIMachineKeyValueData] 
	where Machine = 'DatabaseVersionFromDBScript' 
	COLLATE database_default
	and [PropertyKey] = 'DatabaseVersionFromDBScript'
	COLLATE database_default
	union
	select '99', @@SERVERNAME, 'DB-Function Version', null, [TextValue] 
	from [smartKPIMachineKeyValueData] 
	where Machine = 'DatabaseVersionFromDBScript' 
	COLLATE database_default
	and [PropertyKey] = 'FunctionVersionFromDBScript'
	COLLATE database_default
	) x order by orderkey;
END;
GO