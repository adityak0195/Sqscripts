--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCurrentShift';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCurrentShift') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetCurrentShift  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetCurrentShift
	@Machine varchar(255),
	@ShiftStart DateTime2
AS
BEGIN
	SET NOCOUNT ON


	EXECUTE GetCurrentShiftMinus @Machine = @Machine, @ShiftStart = @ShiftStart, @MinusIterations=0;  	
END;


GO