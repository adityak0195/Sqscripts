-- =============================================
-- Author: Martin Flassak
-- Create date: 03/2024
-- Description: Calculates the summed up KPIs out of the dily ones and updates the numbers in the smartKPIValues table
-- Parameters:
-- @StartDate,datetime2 starting date/time for the calculation
-- @EndDate,datetime2 ending date/time for the calculation
-- @Machine,varchar(255) - Machine/Station to calculate
-- @KPITimeBase,varchar(255) - Time based used for inserting data in smartKPIValues table
-- Returns: nothing
-- =============================================

create or alter procedure CalculateSummedUpKPIs @StartDate datetime2, @EndDate datetime2, @Machine varchar(255), @KPITimeBase varchar(255) 
as
begin

	set nocount on;

    declare @startDayForCalculationAsDateTime datetime2 = DATEFROMPARTS(datepart(year,getutcdate()), datepart(month,getutcdate()), datepart(day,getutcdate()));
    declare @counter int;
	declare @DeleteArchivedDataTimeInMonths int;
	declare @maxCalculationStartDate dateTime2;
	declare @dataTable table 
        (KPIName varchar(255)
        ,KPICalculationBase varchar(255)
        ,floatValue float
        );

	select 
        @DeleteArchivedDataTimeInMonths = FloatValue 
    from 
        smartKPIMachineKeyValueData 
    where 
        PropertyKey = 'DeleteArchivedDataTimeInMonths' 
        and Machine = 'DB'
    ;
	
    set 
        @maxCalculationStartDate = dateadd(day,1,dateadd(month,-1 * @DeleteArchivedDataTimeInMonths,getutcdate()));


	print 'maxCalculationStartDate';
	print @maxCalculationStartDate;



-- *********************************************************  Sum of values  *********************************************************
	insert into @dataTable 
        (KPIName
        ,KPICalculationBase
        ,floatValue
        )
    SELECT 
        KPIName
        ,KPICalculationBase
        ,round(sum(KPIFloatValue),2) as sumValue
    FROM 
        smartKPIValues
    where 
        KPITimeBase = 'day'
        and KPIName not like 'CVS: KPI planned working time%'
        and KPIName not in ('CVS: APO shift factor in percent', 'CVS: Average Changeover time from operator screen [min]')
        and Machine = @Machine
        and KPIDateTime >= @StartDate
        and KPIDateTimeEnd <= @EndDate
    group by 
        KPIName
        ,KPICalculationBase
    ;

-- *********************************************************  Avg of values  *********************************************************
	insert into @dataTable 
        (KPIName
        ,KPICalculationBase
        ,floatValue
        )
    SELECT 
        KPIName
        ,KPICalculationBase
        ,round(avg(KPIFloatValue),2) as avgValue
    FROM 
        smartKPIValues
    where 
        KPITimeBase = 'day'
        and KPIName not like 'CVS: KPI planned working time%'
        and KPIName in ('CVS: APO shift factor in percent', 'CVS: Average Changeover time from operator screen [min]')
        and Machine = @Machine
        and KPIDateTime >= @StartDate
        and KPIDateTimeEnd <= @EndDate
    group by 
        KPIName
        ,KPICalculationBase
    ;






-- *********************************************************  GetRVSRQ  *********************************************************
	with 
        OutputIO as 
            (select 
                KPIName as KPINameIO
                ,KPICalculationBase as KPICalculationBaseIO
                ,floatValue as valueIO
            from 
                @dataTable 
            where 
                KPIName = 'OutputIO'
            )
        ,OutputNIO as 
            (select 
                KPIName as KPINameNIO
                ,KPICalculationBase as KPICalculationBaseNIO
                ,floatValue as valueNIO
            from 
                @dataTable 
            where 
                KPIName = 'OutputNIO'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetRVSRQ(IO.valueIO,NIO.valueNIO)
    from 
        OutputIO as IO
        ,OutputNIO as NIO
    where 
        KPICalculationBase = IO.KPICalculationBaseIO
        and KPICalculationBase = NIO.KPICalculationBaseNIO
        and KPIName = 'RQ'
        and KPICalculationBase = 'GetCIPKPIsRailWorker'
    ;

-- *********************************************************  GetCVSRQ  *********************************************************
	with 
        OutputIO as 
            (select 
                KPIName as KPINameIO
                ,KPICalculationBase as KPICalculationBaseIO
                ,floatValue as valueIO
            from 
                @dataTable 
            where 
                KPIName = 'OutputIO'
            )
        ,OutputNIO as 
            (select 
                KPIName as KPINameNIO
                ,KPICalculationBase as KPICalculationBaseNIO
                ,floatValue as valueNIO
            from 
                @dataTable 
            where 
                KPIName = 'OutputNIO'
            )
        ,Retest as 
            (select 
                KPIName as KPINameRetest
                ,KPICalculationBase as KPICalculationBaseRetest
                ,floatValue as valueRetest
            from 
                @dataTable 
            where 
                KPIName = 'CVS: Retests'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetCVSRQ(IO.valueIO,NIO.valueNIO,Retest.valueRetest)
    from 
        OutputIO as IO
        ,OutputNIO as NIO
        ,Retest
    where 
        KPICalculationBase = IO.KPICalculationBaseIO
        and KPICalculationBase = NIO.KPICalculationBaseNIO
        and KPICalculationBase = Retest.KPICalculationBaseRetest
        and KPIName = 'RQ'
        and KPICalculationBase = 'GetKPIsTruckWorker'
    ;

-- *********************************************************  GetCVSDLP3  *********************************************************
	with 
        Kbph as 
            (select 
                KPIName as KPINameKbph
                ,KPICalculationBase as KPICalculationBaseKbph
                ,floatValue as valueKbph
            from 
                @dataTable 
            where 
                KPIName = 'CVS DLP3: KB paid hours'
            )
        ,Cph as 
            (select 
                KPIName as KPINameCph
                ,KPICalculationBase as KPICalculationBaseCph
                ,floatValue as valueCph
            from 
                @dataTable 
            where 
                KPIName = 'CVS DLP3: Customer paid hours'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetCVSDLP3(Kbph.valueKbph,Cph.valueCph)
    from 
        Cph
        ,Kbph
    where 
        KPICalculationBase = Kbph.KPICalculationBaseKbph
        and KPICalculationBase = Cph.KPICalculationBaseCph
        and KPIName = 'CVS DLP3: Ratio (Customer paid hours/KB paid hours)'
        and KPICalculationBase = 'GetKPIsTruckWorker'
    ;



-- *********************************************************  GetCVSDlp1 (Actual)  *********************************************************
	with 
        OutputIO as 
            (select 
                KPIName as KPINameIO
                ,KPICalculationBase as KPICalculationBaseIO
                ,floatValue as valueIO
            from 
                @dataTable 
            where 
                KPIName = 'OutputIO'
            )
        ,TimeInShift as 
            (select 
                KPIName as KPINameTime
                ,KPICalculationBase as KPICalculationBaseTime
                ,floatValue as valueTime
            from 
                @dataTable 
            where 
                KPIName = 'CVS: Sum of login times at line'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetCVSDlp1(IO.valueIO,TimeInShift.valueTime,1)
    from 
        OutputIO as IO
        ,TimeInShift
    where 
        KPICalculationBase = IO.KPICalculationBaseIO
        and KPICalculationBase = TimeInShift.KPICalculationBaseTime
        and KPIName = 'CVS DLP1: Actual'
        and KPICalculationBase = 'GetKPIsTruckWorker'
    ;

-- *********************************************************  GetCVSDlp1 (Target)  *********************************************************
	with 
        Target as 
            (select 
                KPIName as KPINameTarget
                ,KPICalculationBase as KPICalculationBaseTarget
                ,floatValue as valueTarget
            from 
                @dataTable 
            where 
                KPIName = 'CVS DLP1: Calculated Production Target'
            )
        ,TimeInShift as 
            (select 
                KPIName as KPINameTime
                ,KPICalculationBase as KPICalculationBaseTime
                ,floatValue as valueTime
            from 
                @dataTable 
            where 
                KPIName = 'CVS DLP1: Time in seconds within shift(s)'
            )
        ,Worker as 
            (select 
                KPIName as KPINameWorker
                ,KPICalculationBase as KPICalculationBaseWorker
                ,floatValue as valueWorker
            from 
                @dataTable 
            where 
                KPIName = 'CVS: Planned number of workers from SAP'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetCVSDlp1(Target.valueTarget,TimeInShift.valueTime,Worker.valueWorker)
    from 
        Target
        ,TimeInShift
        ,Worker
    where 
        KPICalculationBase = Target.KPICalculationBaseTarget
        and KPICalculationBase = Worker.KPICalculationBaseWorker
        and KPICalculationBase = TimeInShift.KPICalculationBaseTime
        and KPIName = 'CVS DLP1: Calculated Target'
        and KPICalculationBase = 'GetKPIsTruckWorker'
    ;

-- *********************************************************  GetCVSDlp1Ratio  *********************************************************
	with 
        Actual as 
            (select 
                KPIName as KPINameActual
                ,KPICalculationBase as KPICalculationBaseActual
                ,floatValue as valueActual
            from 
                @dataTable 
            where 
                KPIName = 'CVS DLP1: Actual'
            )
        ,Target as 
            (select 
                KPIName as KPINameTarget
                ,KPICalculationBase as KPICalculationBaseTarget
                ,floatValue as valueTarget
            from 
                @dataTable 
            where 
                KPIName = 'CVS DLP1: Calculated Target'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetCVSDlp1Ratio(Actual.valueActual,Target.valueTarget)
    from 
        Actual
        ,Target
    where 
        KPICalculationBase = Actual.KPICalculationBaseActual
        and KPICalculationBase = Target.KPICalculationBaseTarget
        and KPIName = 'CVS DLP1: Ratio (Actual/Calculated Target)'
        and KPICalculationBase = 'GetKPIsTruckWorker'
    ;


-- *********************************************************  GetCVSUtilization  *********************************************************
	with 
        Tgmax as 
            (select 
                KPIName as KPINameTgmax
                ,KPICalculationBase as KPICalculationBaseTgmax
                ,floatValue as valueTgmax
            from 
                @dataTable 
            where 
                KPIName = 'CVS: Sum tgmax times for IO parts in seconds'
            )
        ,TimeBase as 
            (select 
                KPIName as KPINameTimeBase
                ,KPICalculationBase as KPICalculationBaseTimeBase
                ,floatValue as valueTimeBase
            from 
                @dataTable 
            where 
                KPIName = 'CVS: Time base for utilization in seconds'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetCVSUtilization(Tgmax.valueTgmax,TimeBase.valueTimeBase)
    from 
        Tgmax
        ,TimeBase
    where 
        KPICalculationBase = Tgmax.KPICalculationBaseTgmax
        and KPICalculationBase = TimeBase.KPICalculationBaseTimeBase
        and KPIName = 'CVS: Utilization'
        and KPICalculationBase = 'GetKPIsTruckWorker'
    ;

-- *********************************************************  GetCVSOEE  *********************************************************
	with 
        Tgmax as 
            (select 
                KPIName as KPINameTgmax
                ,KPICalculationBase as KPICalculationBaseTgmax
                ,floatValue as valueTgmax
            from 
                @dataTable 
            where 
                KPIName = 'CVS: Sum tgmax times for IO parts in seconds'
            )
        ,TimeBase as 
            (select 
                KPIName as KPINameTimeBase
                ,KPICalculationBase as KPICalculationBaseTimeBase
                ,floatValue as valueTimeBase
            from 
                @dataTable 
            where 
                KPIName = 'CVS: Planned working time in seconds (from start to end of shift)'
            )
	update 
        @dataTable 
    set 
        floatValue = dbo.GetCVSOEE(Tgmax.valueTgmax,TimeBase.valueTimeBase)
    from 
        Tgmax
        ,TimeBase
    where 
        KPICalculationBase = Tgmax.KPICalculationBaseTgmax
        and KPICalculationBase = TimeBase.KPICalculationBaseTimeBase
        and KPIName = 'CVS: OEE (Version 2)'
        and KPICalculationBase = 'GetKPIsTruckWorker'
    ;

-- *********************************************************  CVS DLP1: Local Target  *********************************************************
	with 
        Worker as 
            (select 
                KPIName as KPINameWorker
                ,KPICalculationBase as KPICalculationBaseWorker
                ,floatValue as valueWorker
            from 
                @dataTable
            where 
                KPIName = 'CVS: Planned number of workers from SAP'
            )
        ,MachineKeyValueData as 
            (select 
                PropertySubKey1
                ,FloatValue
            from 
                smartKPIMachineKeyValueData
            where 
                PropertyKey = 'DLP1'
                and Machine = @Machine
            )
	update 
        @dataTable
    set 
        floatValue = MachineKeyValueData.FloatValue
    from 
        MachineKeyValueData
        ,Worker
    where 
        KPICalculationBase = Worker.KPICalculationBaseWorker
        and KPIName = 'CVS DLP1: Local Target'
        and KPICalculationBase = 'GetKPIsTruckWorker'
        and MachineKeyValueData.PropertySubKey1 = Worker.valueWorker
    ;


    delete smartKPIValues
        from smartKPIValues, @dataTable dt
        where smartKPIValues.Machine = @Machine
        and smartKPIValues.KPITimeBase = @KPITimeBase
        and smartKPIValues.KPIName = dt.KPIName
        and smartKPIValues.KPICalculationBase = dt.KPICalculationBase
        and smartKPIValues.KPIDateTime = @StartDate
        and smartKPIValues.KPIDateTimeEnd = @EndDate;

--    delete from smartKPIValues
--    where Machine +','+ KPITimeBase +','+ KPIName +','+ KPICalculationBase +','+ cast(KPIDateTime as varchar(255)) +','+ cast(KPIDateTimeEnd as varchar(255)) in
--    (select @Machine +','+ @KPITimeBase +','+ KPIName +','+ KPICalculationBase +','+ cast(@StartDate as varchar(255)) +','+ cast(@EndDate as varchar(255)) from @dataTable);

    insert into smartKPIValues (Machine,KPITimeBase,KPIName,KPICalculationBase,KPIDateTime,KPIDateTimeEnd,KPIFloatValue)
    select @Machine,@KPITimeBase,KPIName,KPICalculationBase,@StartDate,@EndDate,floatValue from @dataTable;



END;

GO

