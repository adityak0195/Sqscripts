--------------------------------------------------------------
--------------------------------------------------------------
print '-- StartIndexRebuild';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'StartIndexRebuild') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE StartIndexRebuild  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE StartIndexRebuild
	@IndexName varchar(255),
	@TableName varchar(255)
AS
BEGIN
	SET NOCOUNT ON
	declare @command varchar(200);
	set @command = 'ALTER INDEX ' + @IndexName + ' ON ' + @TableName + ' REBUILD';
	exec(@command);
END;
GO