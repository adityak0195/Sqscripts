--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetFullShiftMinus';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetFullShiftMinus') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetFullShiftMinus  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE GetFullShiftMinus
	@Machine varchar(255),
	@ShiftStart DateTime2,
	@MinusIterations int,
	@UtcTimeOffset int = null
AS
BEGIN
	SET NOCOUNT ON
	
	DECLARE @CurrentName varchar(255);
	DECLARE @CurrentStartTime datetime2;
	DECLARE @CurrentEndTime datetime2;
	
	set @MinusIterations = @MinusIterations + 1;
	
	select @ShiftStart=min(CurrentStartTime) from
		(select CurrentStartTime from TEMP_SmartKPIFullShift
		where @ShiftStart >= CurrentStartTime
		and CurrentEndTime > @ShiftStart
		and Machine = @Machine
		union select min(CurrentStartTime) as CurrentStartTime from TEMP_SmartKPIFullShift
		 where CurrentStartTime >= @ShiftStart 
		 and Machine = @Machine
		 union select max(CurrentStartTime) as CurrentStartTime from TEMP_SmartKPIFullShift
		 where CurrentStartTime <= @ShiftStart 
		 and Machine = @Machine)x;
	 
	select @CurrentName=CurrentName, @CurrentStartTime=CurrentStartTime, @CurrentEndTime=CurrentEndTime from
	(select top(1) CurrentName, CurrentStartTime, CurrentEndTime from
	(select top(@MinusIterations) * from TEMP_SmartKPIFullShift 
	where Machine = @Machine
	and CurrentStartTime <= @ShiftStart
	order by CurrentStartTime desc) x
	order by CurrentStartTime) y

	select @CurrentName as CurrentName, @CurrentStartTime as CurrentStartTime, @CurrentEndTime as CurrentEndTime;  
	
END;

GO