--------------------------------------------------------------
--------------------------------------------------------------
print '-- DBSmartKpiLogger';
--------------------------------------------------------------
--------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'DBSmartKpiLogger') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE DBSmartKpiLogger  AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE DBSmartKpiLogger
	@Text varchar(1024),
	@LogLevel int,
	@ProcName varchar(255)
AS
BEGIN
	Declare @SystemLogLevel int;

	insert into smartKPIJobController (Job) 
	select (@ProcName) 
		where not exists (select Job from smartKPIJobController where Job = @ProcName);

	select @SystemLogLevel=LogLevel from smartKPIJobController where Job = @ProcName;
	
	IF (@SystemLogLevel <= @LogLevel)
	BEGIN
		insert into smartKPIJobLogger (Job, LogLevel, LogText)
		values (@ProcName, @LogLevel, left(@Text,1024));
	END;
END;

GO

--	insert into smartKPIJobController (Job) 
--	select ('test') 
--		where not exists (select Job from smartKPIJobController where Job = 'test');
--EXECUTE DBSmartKpiLogger @Text = 'abc', @LogLevel = 0, @ProcName = 'test';  
--GO 