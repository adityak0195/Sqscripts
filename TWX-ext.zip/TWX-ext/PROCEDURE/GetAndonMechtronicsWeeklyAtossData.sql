--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetAndonMechtronicsWeeklyAtossData';
--------------------------------------------------------------
--------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetAndonMechtronicsWeeklyAtossData') AND type in (N'P', N'PC'))
exec('CREATE PROCEDURE GetAndonMechtronicsWeeklyAtossData  AS BEGIN SET NOCOUNT ON; END')
GO

Alter PROCEDURE GetAndonMechtronicsWeeklyAtossData 
	-- Add the parameters for the stored procedure here
	@machine  varchar(255)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

			select Machine,KPICalculationBase,KPIDateTime,KPIDateTimeEnd,KPITimeBase,CVS_DLP1_Actual, CVS_Atoss_Target as Target,
				RQ, OutputIO, datepart(weekday,dateadd(hh,12,KPIDateTime)) as weekday from
				( SELECT Machine
				,replace(replace(KPIName,' ','_'),':','') as KPINameNew
				,KPICalculationBase
				,KPIDateTime
				,KPIFloatValue
				,KPIDateTimeEnd
				,KPITimeBase
				FROM smartKPIValues
				where KPIName in ('CVS DLP1: Actual', 'RQ', 'OutputIO')
				and KPITimeBase in ('day','week')
				and (KPIDateTime between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate())))
				or KPIDateTimeEnd between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate()))))
				and KPICalculationBase = 'GetKPIsTruckWorker'
				and Machine = @machine
			union
				SELECT Machine
				,replace(replace(KPIName,' ','_'),':','') as KPINameNew
				,KPICalculationBase
				,KPIDateTime
				,KPIFloatValue
				,KPIDateTimeEnd
				,KPITimeBase
				FROM smartKPIValues
				where KPIName in ('CVS: Atoss Target')
				and KPITimeBase in ('week')
				and (KPIDateTime between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate())))
				or KPIDateTimeEnd between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate()))))
				and KPICalculationBase = 'GetKPIsTruckWorker'
				and Machine = @machine
			union
				SELECT Machine
				,replace(replace(KPIName,' ','_'),':','') as KPINameNew
				,KPICalculationBase
				,dateadd(day,y.x,KPIDateTime)
				,0
				,dateadd(day,y.x,KPIDateTimeEnd)
				,KPITimeBase
				FROM smartKPIValues, (select x from (values(-1),(-2),(-3),(-4),(-5),(-6),(-7),(1),(2),(3),(4),(5),(6),(7)) as a(x))y
				where KPIName in ('CVS DLP1: Actual', 'RQ', 'OutputIO')
				and (dateadd(day,y.x,KPIDateTime) between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate())))
				or dateadd(day,y.x,KPIDateTimeEnd) between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate()))))
				and KPICalculationBase = 'GetKPIsTruckWorker'
				and KPITimeBase = 'day'
				and y.x < 9-datepart(dw, getdate())
				and Machine = @machine
			union
				SELECT Machine
				,replace(replace(KPIName,' ','_'),':','') as KPINameNew
				,KPICalculationBase
				,dateadd(day,y.x,KPIDateTime)
				,dbo.GetCVSProductionTargetFromAtoss(Machine, dateadd(day,y.x,KPIDateTime), dateadd(day,y.x,KPIDateTimeEnd))
				,dateadd(day,y.x,KPIDateTimeEnd)
				,KPITimeBase
				FROM smartKPIValues, (select x from (values(-1),(-2),(-3),(-4),(-5),(-6),(-7),(1),(2),(3),(4),(5),(6),(7)) as a(x))y
				where KPIName in ('CVS: Atoss Target')
				and (dateadd(day,y.x,KPIDateTime) between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate())))
				or dateadd(day,y.x,KPIDateTimeEnd) between dateadd(day, 2-datepart(dw, getdate()), CONVERT(datetime2,getdate()))
				and dateadd(ms,-1,dateadd(day, 9-datepart(dw, getdate()), CONVERT(datetime2,getdate()))))
				and KPICalculationBase = 'GetKPIsTruckWorker'
				and KPITimeBase = 'day'
				and y.x < 9-datepart(dw, getdate())
				and Machine = @machine

				) as a
			Pivot
			( MAX(KPIFloatValue) FOR KPINameNew in ( CVS_DLP1_Actual,CVS_Atoss_Target,RQ, OutputIO)) as piv
			order by 1,3,5
END
GO


--select * from GetCVSHourlyOutput('KBLisLaa6MachineThing', '2020-08-19', '2020-08-20')

