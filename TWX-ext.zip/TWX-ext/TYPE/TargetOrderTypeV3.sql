--------------------------------------------------------------
--------------------------------------------------------------
print '-- TargetOrderTypeV3';
--------------------------------------------------------------
--------------------------------------------------------------


IF not EXISTS (select * from sys.table_types where name = 'TargetOrderTypeV3')
create type TargetOrderTypeV3 as TABLE ( 
	OrderNumber varchar(255),
	Operation varchar(255),
	NumberOfParts int,
	PlannedStartDate datetime2,
	Suffix varchar(255)); 
GO
