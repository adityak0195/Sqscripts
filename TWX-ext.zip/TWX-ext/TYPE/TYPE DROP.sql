print 'DROP TYPE TargetOrderType;';
IF EXISTS (select * from sys.table_types where name = 'TargetOrderType')
drop type TargetOrderType; 
GO

print 'DROP TYPE TargetOrderTypeV2;';
IF EXISTS (select * from sys.table_types where name = 'TargetOrderTypeV2')
drop type TargetOrderTypeV2; 
GO
