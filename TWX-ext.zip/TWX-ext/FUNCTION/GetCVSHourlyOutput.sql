--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSHourlyOutput';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSHourlyOutput'))
drop FUNCTION GetCVSHourlyOutput;
GO
CREATE FUNCTION GetCVSHourlyOutput
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS @table TABLE (
	ProductionTimeStart datetime2, 
	ProductionTimeEnd datetime2, 
	NumberPartsOK int,  
	NumberPartsNOK int,
	Target int,
	Label varchar(255))
BEGIN;

DECLARE @targetTable TABLE(ProductionTime datetime2);
DECLARE @counter int = 0;
DECLARE @time datetime2 = DATEADD(minute, -DATEPART(minute,@StartTime),DATEADD(second, -DATEPART(second,@StartTime),DATEADD(ms, -DATEPART(ms,@StartTime),@StartTime)));
DECLARE @target int;
DECLARE @StartTimeSlot DateTime2 = @time;
DECLARE @EndTimeSlot DateTime2 = dateadd(hour,1,@time);

if (@StartTime < @EndTime)
BEGIN;
	insert into @targetTable (ProductionTime) select ProductionTime
	from GetCVSProductionTargetFunction1V2(@LineThingName, @StartTime, @EndTime);

	WHILE (dateadd(hour, @counter, @time) < @EndTime)
	BEGIN;

		set @StartTimeSlot=dateadd(hour,@counter,@time);
		set @EndTimeSlot=dateadd(hour,@counter+1,@time);
		select @target=count(*) from @targetTable where ProductionTime between @StartTimeSlot and @EndTimeSlot;
		insert into @table(ProductionTimeStart, ProductionTimeEnd, Target) values (@StartTimeSlot, @EndTimeSlot, @target);
		SET @counter = @counter + 1;
	END;

	update @table set NumberPartsOK = x.NumberParts from
		(SELECT DATEADD(minute, -DATEPART(minute,[ProductionTime]),DATEADD(second, -DATEPART(second,[ProductionTime]),DATEADD(ms, -DATEPART(ms,[ProductionTime]),[ProductionTime]))) as prodTime
			,sum([numberOfParts]) as NumberParts
		FROM [smartKPI]
		where Machine = @LineThingName
		and ProductionTime between @StartTime and @EndTime
		and [isPartOK] = 1
		group by DATEADD(minute, -DATEPART(minute,[ProductionTime]),DATEADD(second, -DATEPART(second,[ProductionTime]),DATEADD(ms, -DATEPART(ms,[ProductionTime]),[ProductionTime]))))x
		where x.prodTime = ProductionTimeStart;

	update @table set NumberPartsNOK = x.NumberParts from
		(SELECT DATEADD(minute, -DATEPART(minute,[ProductionTime]),DATEADD(second, -DATEPART(second,[ProductionTime]),DATEADD(ms, -DATEPART(ms,[ProductionTime]),[ProductionTime]))) as prodTime
			,sum([numberOfParts]) as NumberParts
		FROM [smartKPI]
		where Machine = @LineThingName
		and ProductionTime between @StartTime and @EndTime
		and [isPartOK] = 0
		group by DATEADD(minute, -DATEPART(minute,[ProductionTime]),DATEADD(second, -DATEPART(second,[ProductionTime]),DATEADD(ms, -DATEPART(ms,[ProductionTime]),[ProductionTime]))))x
		where x.prodTime = ProductionTimeStart;


	update @table set NumberPartsOK = 0 where NumberPartsOK is null;
	update @table set NumberPartsNOK = 0 where NumberPartsNOK is null;
	update @table set Target = 0 where Target is null;

	update @table set ProductionTimeStart = @StartTime where ProductionTimeStart < @StartTime;
	update @table set ProductionTimeEnd = @EndTime where ProductionTimeEnd > @EndTime;
	
	update @table set Label =  case when datepart(hour,ProductionTimeStart) < 10
								then '0'+convert(varchar(10),datepart(hour,ProductionTimeStart))
								else convert(varchar(10),datepart(hour,ProductionTimeStart))
								end 
								+ ':' +
								case when datepart(minute,ProductionTimeStart) < 10
								then '0'+convert(varchar(10),datepart(minute,ProductionTimeStart))
								else convert(varchar(10),datepart(minute,ProductionTimeStart))
								end
								+ '-' +
								case when datepart(hour,ProductionTimeEnd) < 10
								then '0'+convert(varchar(10),datepart(hour,ProductionTimeEnd))
								else convert(varchar(10),datepart(hour,ProductionTimeEnd))
								end 
								+ ':' +
								case when datepart(minute,ProductionTimeEnd) < 10
								then '0'+convert(varchar(10),datepart(minute,ProductionTimeEnd))
								else convert(varchar(10),datepart(minute,ProductionTimeEnd))
								end;
END;

return;
	
END;
GO
