--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_GetPlantsToCalculateKPIs';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_GetPlantsToCalculateKPIs'))
drop FUNCTION KPI_CALCULATOR_GetPlantsToCalculateKPIs;
GO
CREATE FUNCTION [dbo].[KPI_CALCULATOR_GetPlantsToCalculateKPIs]()
RETURNS @table TABLE (	
	plant varchar(255), 
	area varchar(255), 
	machine varchar(255), 
	module varchar(255), 
	station varchar(255), 
	type varchar(255), 
	offset float,
    serverTimeZoneDB varchar(255) 
	)
BEGIN;
	insert into @table (		
		plant,
        area,
        machine,
        module,
        station,
        type,
        offset,
        serverTimeZoneDB
		)
    select     Distinct                                                 
        isnull(planttemplate.Machine,'NULL') as plant           
        ,'NULL' as area                 
        ,'NULL' as machine                                      
        ,'NULL' as module                                                   
        ,'NULL' as station                                      
        ,isnull(planttemplate.TextValue,'NULL') as type         
        ,isnull(offset.FloatValue,0) as offset            
        ,isnull(serverTimeZoneDB.TextValue, 'Central European Standard Time') as serverTimeZoneDB                  
    from                                                        
        smartKPIMachineKeyValueData as planttemplate            
        ,smartKPIMachineKeyValueData as machine                 
        ,smartKPIMachineKeyValueData as offset
        ,smartKPIMachineKeyValueData as isActive
        ,smartKPIMachineKeyValueData as serverTimeZoneDB
    where                                                       
        planttemplate.TextValue = 'KBLocalPlantThingTemplate'   
        and machine.PropertyKey = 'KBPlantThing'                
        and machine.UpdateTime > dateadd(month,-1,getdate())    
        and planttemplate.Machine = machine.TextValue           
        and isNull(machine.TextValue,'') != ''                  
        and machine.PropertySubKey2 = 'KBLocalAreaThingTemplate'
        and offset.Machine = planttemplate.Machine              
        and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'
        and serverTimeZoneDB.Machine = 'KBTimeHelperThing'
        and serverTimeZoneDB.PropertyKey = 'ServerTimeZoneDB'
        and machine.Machine = isActive.Machine                    
        and isActive.PropertyKey = 'isActive'               
        and isActive.FloatValue = 1;      
    
return;
	
END;

GO
