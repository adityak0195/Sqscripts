--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_GetCurrentOrNextShiftToCalculateKPIs';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_GetCurrentOrNextShiftToCalculateKPIs'))
drop FUNCTION KPI_CALCULATOR_GetCurrentOrNextShiftToCalculateKPIs;
GO
CREATE FUNCTION KPI_CALCULATOR_GetCurrentOrNextShiftToCalculateKPIs(@machine varchar(255), @referenceTime datetime2)
RETURNS @table TABLE (	
	machine varchar(255), 
	shiftName varchar(255), 
	startTime datetime2, 
	endTime datetime2 
	)
BEGIN;
	insert into @table (		
		machine,
        shiftName,
        startTime,
        endTime
		)
    select top (1) Machine, CurrentName, CurrentStartTime, CurrentEndTime 
        from TEMP_SmartKPIFullShift
        where Machine = @machine
        and CurrentEndTime > @referenceTime                
        order by CurrentStartTime; 
    
return ;
	
END;

GO


