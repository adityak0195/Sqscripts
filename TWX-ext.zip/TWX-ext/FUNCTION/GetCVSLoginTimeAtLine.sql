
--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSLoginTimeAtLine';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSLoginTimeAtLine'))
drop FUNCTION GetCVSLoginTimeAtLine;
GO
CREATE FUNCTION GetCVSLoginTimeAtLine
	(@StartDate DateTime2,
	@EndDate DateTime2,
	@Station varchar(255))
RETURNS bigint
BEGIN;

	if (@EndDate > getutcdate())
		set @EndDate = getutcdate();

	DECLARE @TimeSumMilli bigint;

	
	select @TimeSumMilli=isnull(sum(LoginTimeMillis),0) from dbo.GetCVSLoginTimeAtLine1(@StartDate, @EndDate, @Station);

	return @TimeSumMilli/1000;

	--@result;
END;
GO

--select * from GetCVSLoginTimeAtLine('2017-01-01 00:00:00', '2020-01-01 00:00:00', 'KBLISLAA6DBStationThing')


