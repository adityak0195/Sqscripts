--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetAllShifts';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetAllShifts'))
drop FUNCTION GetAllShifts;
GO
CREATE FUNCTION GetAllShifts
	(@Machine varchar(255),
	@ShiftStart DateTime2,
	@ShiftEnd DateTime2)
RETURNS @table TABLE ( 
	CurrentName varchar(255),
	CurrentStartTime DateTime2,
	CurrentEndTime DateTime2)  

BEGIN

	Declare @CurrentName varchar(255);
	Declare @CurrentStartTime DateTime2;
	Declare @CurrentEndTime DateTime2;

	if (@ShiftEnd > getutcdate())
	BEGIN
		set @ShiftEnd = getutcdate();
	END;
	
	
	insert into @table (CurrentStartTime, CurrentEndTime, CurrentName)
	select CurrentStartTime, CurrentEndTime, CurrentName from TEMP_SmartKPIFullShift 
	where CurrentStartTime > @ShiftStart 
	and CurrentEndTime < @ShiftEnd
	and Machine = @Machine
	union
	select @ShiftStart, CurrentEndTime, CurrentName from TEMP_SmartKPIFullShift 
	where CurrentStartTime < @ShiftStart 
	and CurrentEndTime > @ShiftEnd
	and Machine = @Machine
	union
	select CurrentStartTime, @ShiftEnd, CurrentName from TEMP_SmartKPIFullShift 
	where CurrentStartTime < @ShiftEnd 
	and CurrentEndTime > @ShiftEnd
	and Machine = @Machine;
	

	return;
	
END;

GO

--declare @dt1 as DateTime2 = '2019-02-01 02:00:00.000';
--declare @dt2 as DateTime2 = '2019-02-07 02:00:00.000';
--select * from GetAllShifts('KBLisLaa2MachineThing', @dt1, @dt2);
