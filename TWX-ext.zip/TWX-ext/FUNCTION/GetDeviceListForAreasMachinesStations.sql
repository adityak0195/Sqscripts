-- =============================================
-- Author: Martin Flassak
-- Create date: 03/2024
-- Description: GetDeviceListForAreasMachinesStations: Creates a list of Areas, Machines, Stations with time offset definition
-- Parameters: none
--...
-- Returns: List of Areas, Machines, Stations with time offset definition
-- =============================================

create or alter function GetDeviceListForAreasMachinesStations()
returns @deviceList table 
    (plant varchar(255)
    ,area varchar(255)
    ,machine varchar(255)
    ,station varchar(255)
    ,type varchar(255)
    ,offset int
    )  
begin
        


    insert into @deviceList (plant,area,machine,station,type,offset)
--Areas will be handles separately
        select 
            planttemplate.Machine as plant
            ,machine.Machine as area
            ,null as machine
            ,null as station
            ,machine.PropertySubKey2 as type
            ,offset.FloatValue as offset 
        from 
            smartKPIMachineKeyValueData as planttemplate
            ,smartKPIMachineKeyValueData as machine
            ,smartKPIMachineKeyValueData as offset
        where 
            planttemplate.TextValue = 'KBLocalPlantThingTemplate'
            and machine.PropertyKey = 'KBPlantThing'
            and machine.UpdateTime > dateadd(month,-1,getdate())
            and planttemplate.Machine = machine.TextValue
            and isNull(machine.TextValue,'') != ''
            and machine.PropertySubKey2 = 'KBLocalAreaThingTemplate'
            and offset.Machine = planttemplate.Machine
            and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'
        union select 
            planttemplate.Machine as plant
            ,null
            ,machine.Machine
            ,null
            ,machine.PropertySubKey2
            ,offset.FloatValue
        from 
            smartKPIMachineKeyValueData planttemplate,smartKPIMachineKeyValueData machine,smartKPIMachineKeyValueData offset
        where 
            planttemplate.TextValue = 'KBLocalPlantThingTemplate'
            and machine.PropertyKey = 'KBPlantThing'
            and machine.UpdateTime > dateadd(month,-1,getdate())
            and planttemplate.Machine = machine.TextValue
            and isNull(machine.TextValue,'') != ''
            and machine.PropertySubKey2 = 'KBLocalMachineThingTemplate'
            and offset.Machine = planttemplate.Machine
            and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'
        union select 
            planttemplate.Machine
            ,null
            ,machine.Machine
            ,station.Machine
            ,station.PropertySubKey2
            ,offset.FloatValue 
        from 
            smartKPIMachineKeyValueData planttemplate,smartKPIMachineKeyValueData machine,smartKPIMachineKeyValueData station,smartKPIMachineKeyValueData offset
        where 
            planttemplate.TextValue = 'KBLocalPlantThingTemplate'
            and machine.PropertyKey = 'KBPlantThing'
            and planttemplate.Machine = machine.TextValue
            and isNull(machine.TextValue,'') != ''
            and machine.PropertySubKey2 = 'KBLocalMachineThingTemplate'
            and machine.Machine = station.TextValue
            and station.PropertyKey = 'KBLocalLineThing'
            and station.UpdateTime > dateadd(month,-1,getdate())
            and offset.Machine = planttemplate.Machine
            and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'
    ;

	return 
end;
go