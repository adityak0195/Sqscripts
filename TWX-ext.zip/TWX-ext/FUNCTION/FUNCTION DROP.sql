-------------------------------------------------------------- 
--------------------------------------------------------------
print '-- Remove old FUNCTIONs';
--------------------------------------------------------------
--------------------------------------------------------------

print 'DROP FUNCTION  GetMultiCIPKPIsRail;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetMultiCIPKPIsRail'))
DROP FUNCTION  GetMultiCIPKPIsRail;
GO

print 'drop FUNCTION GetUTCTimeFromLocalTime;';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetUTCTimeFromLocalTime'))
drop FUNCTION GetUTCTimeFromLocalTime;
GO

print 'DROP FUNCTION  GetShiftTimeInSeconds';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetShiftTimeInSeconds') AND type in (N'FN', N'PC'))
DROP FUNCTION  GetShiftTimeInSeconds;
GO

print 'DROP FUNCTION  GetCVSProductionTargetFunction1V21';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetFunction1V21'))
DROP FUNCTION  GetCVSProductionTargetFunction1V21;
GO

print 'DROP FUNCTION  GetCVSProductionTargetFunction1V3';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetFunction1V3'))
DROP FUNCTION  GetCVSProductionTargetFunction1V3;
GO

print 'DROP FUNCTION  GetWorkingTimeInSeconds1';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetWorkingTimeInSeconds1'))
DROP FUNCTION  GetWorkingTimeInSeconds1;
GO

print 'DROP FUNCTION  GetWorkingTimeInSeconds';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetWorkingTimeInSeconds') AND type in (N'FN', N'PC'))
DROP FUNCTION  GetWorkingTimeInSeconds;
GO

print 'DROP FUNCTION  GetPlannedProductionWorker';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPlannedProductionWorker'))
DROP FUNCTION  GetPlannedProductionWorker;
GO

print 'DROP FUNCTION  GetPlannedProduction';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPlannedProduction'))
DROP FUNCTION  GetPlannedProduction;
GO

print 'DROP FUNCTION  GetEfficiencyRailWorker';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetEfficiencyRailWorker'))
DROP FUNCTION  GetEfficiencyRailWorker;
GO

print 'DROP FUNCTION  GetRailRunTimeV21';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetRailRunTimeV21'))
DROP FUNCTION  GetRailRunTimeV21;
GO

print 'DROP FUNCTION  InsertProcessDataJSON';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertProcessDataJSON') AND type in (N'P', N'PC'))
DROP PROCEDURE InsertProcessDataJSON;
GO

print 'DROP FUNCTION  InsertProcessDataJSON_V8';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertProcessDataJSON_V8') AND type in (N'P', N'PC'))
DROP PROCEDURE InsertProcessDataJSON_V8;
GO

print 'DROP FUNCTION  InsertTestBenchDataJSON';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertTestBenchDataJSON') AND type in (N'P', N'PC'))
DROP PROCEDURE InsertTestBenchDataJSON;
GO

print 'DROP FUNCTION  InsertTestBenchDataJSON_V8';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertTestBenchDataJSON_V8') AND type in (N'P', N'PC'))
DROP PROCEDURE InsertTestBenchDataJSON_V8;
GO

print 'DROP FUNCTION  RebuildIndexes';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'RebuildIndexes') AND type in (N'P', N'PC'))
DROP PROCEDURE RebuildIndexes;
GO

print 'DROP FUNCTION  CalulateKPIsForAllMachine';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateKPIsForAllMachine') AND type in (N'P', N'PC'))
DROP PROCEDURE CalulateKPIsForAllMachine;
GO

print 'DROP FUNCTION  CalulateDailyKPIs';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateDailyKPIs') AND type in (N'P', N'PC'))
DROP PROCEDURE CalulateDailyKPIs;
GO

print 'DROP FUNCTION  CalulateOngoingKPIs';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CalulateOngoingKPIs') AND type in (N'P', N'PC'))
DROP PROCEDURE CalulateOngoingKPIs;
GO

print 'DROP FUNCTION  GetCVSDlp1Target';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlp1Target'))
DROP FUNCTION  GetCVSDlp1Target;
GO

print 'DROP FUNCTION  GetCVSDlp1Actual';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlp1Actual'))
DROP FUNCTION  GetCVSDlp1Actual;
GO

print 'DROP FUNCTION  GetCVSDlp3KBPaidHours';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlp3KBPaidHours'))
DROP FUNCTION  GetCVSDlp3KBPaidHours;
GO

print 'DROP FUNCTION  GetCVSDlp3';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlp3'))
DROP FUNCTION  GetCVSDlp3;
GO

print 'DROP FUNCTION  GetNewOrderDataForFastems';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetNewOrderDataForFastems'))
DROP FUNCTION  GetNewOrderDataForFastems;
GO

print 'DROP FUNCTION  GetRailRunTimeV21';
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetRailRunTimeV21'))
DROP FUNCTION  GetRailRunTimeV21;
GO