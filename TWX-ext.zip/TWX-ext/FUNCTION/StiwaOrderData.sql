--------------------------------------------------------------
--------------------------------------------------------------
print '-- StiwaOrderData';
--------------------------------------------------------------
--------------------------------------------------------------


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'StiwaOrderData'))
drop FUNCTION StiwaOrderData;
GO
create FUNCTION StiwaOrderData
	(@SAPWorkcenterNumber varchar (255),
	@PlantId  varchar (255))
RETURNS @table TABLE ( 
	OrderNumber varchar(255),
	Operation varchar(255),
	ScheduledStartDate varchar(255),
	MaterialNumber varchar(255),
	Quantity varchar(255),
	ProcessingTime int,
	SetupTime int)  

BEGIN
    insert into @table (OrderNumber, Operation, ScheduledStartDate, MaterialNumber, Quantity, ProcessingTime, SetupTime)
                        select top 100 o1.OrderNumber, o1.Operation, dbo.ConvertToStiwaTime(o2.DateTimeValue) as ScheduledStartDate, o4.TextValue as MaterialNumber, o5.FloatValue as Quantity, CASE o6.TextValue 
                                                                WHEN 'SEC' THEN o6.FloatValue  * 1000
                                                                WHEN 'MIN' THEN o6.FloatValue * 60  * 1000
                                                                WHEN 'DAY' THEN o6.FloatValue * 24 * 60 * 60  * 1000
                                                                ELSE 0 
                                                            END as ProcessingTime, CASE o7.TextValue 
                                                                WHEN 'SEC' THEN o7.FloatValue * 1000
                                                                WHEN 'MIN' THEN o7.FloatValue * 60  * 1000
                                                                WHEN 'DAY' THEN o7.FloatValue * 24 * 60 * 60  * 1000 
                                                                ELSE 0 
                                                            END as SetupTime 
                        from smartKPIOrderKeyValueData o1, smartKPIOrderKeyValueData o2, smartKPIOrderKeyValueData o3, smartKPIOrderKeyValueData o4, smartKPIOrderKeyValueData o5, smartKPIOrderKeyValueData o6, smartKPIOrderKeyValueData o7 
                        where o1.OrderNumber = o2.OrderNumber 
                        and o1.PlantId = o2.PlantId 
                        and o1.System = o2.System 
                        and o1.PropertyKey1 = 'Line' 
                        and o2.PropertyKey1 = 'ScheduledStartDate' 
                        and o1.OrderNumber = o3.OrderNumber 
                        and o1.PlantId = o3.PlantId 
                        and o1.System = o3.System 
                        and o3.PropertyKey = 'Head-Status' 
                        and o1.OrderNumber = o4.OrderNumber 
                        and o1.PlantId = o4.PlantId 
                        and o1.System = o4.System 
                        and o4.PropertyKey = 'MaterialNumber' 
                        and o1.OrderNumber = o5.OrderNumber 
                        and o1.Operation = o5.Operation 
                        and o1.PlantId = o5.PlantId 
                        and o1.System = o5.System 
                        and o5.PropertyKey1 = 'Quantity' 
                        and o1.OrderNumber = o6.OrderNumber 
                        and o1.Operation = o6.Operation 
                        and o1.PlantId = o6.PlantId 
                        and o1.System = o6.System 
                        and o6.PropertyKey1 = 'ProcessingTime' 
                        and o1.OrderNumber = o7.OrderNumber 
                        and o1.Operation = o7.Operation 
                        and o1.PlantId = o7.PlantId 
                        and o1.System = o7.System 
                        and o7.PropertyKey1 = 'SetupTime' 
                        and CHARINDEX('I0002', o3.TextValue)> 0 
                        and CHARINDEX('I0009', o3.TextValue)= 0 
                        and o1.PlantId = @PlantId 
                        and o1.TextValue1 = @SAPWorkcenterNumber;	
                        
    delete from @table where OrderNumber like '1%';
        
    return;
	
END;

GO


