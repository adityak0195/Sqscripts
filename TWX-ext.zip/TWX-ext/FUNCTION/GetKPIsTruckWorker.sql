--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetKPIsTruckWorker';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetKPIsTruckWorker'))
drop FUNCTION GetKPIsTruckWorker;
GO
CREATE FUNCTION GetKPIsTruckWorker
	(@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@machine varchar(255))
RETURNS @table TABLE ( 
	Machine varchar(255), 
	KPIName varchar(255), 
	KPICalculationBase varchar(255), 
	KPIDateTime DateTime2,  
	KPIDateTimeEndOfCalculation DateTime2,
	KPIFloatValue float)  
BEGIN;
	declare @CalculationPeriodInMinutes bigint = DATEDIFF_BIG(minute, @StartDateTime, @EndDateTime);
	DECLARE @NumberOfParallelProcesses int = 1;
	DECLARE @isMultiPalletMachine int = 0;
	DECLARE @TEMP_SmartKPICVSProductionTargetDetail table 
		(LineThingName varchar(255),
			StartTime datetime2,
			EndTime datetime2,
			ProductionTime datetime2, 
			counter int, 
			OrderNumber varchar(255), 
			SinglePartTargetCount INT, 
			WorkingTimeInMinutes float,
			TimeToProducePartsInMinutes float, 
			TimeForProducedParts float, 
			ProcessingTime float,
			SetupTime float,
			CreationTime DateTime2,
			ShiftFactorInPercent float,
			SumPlannedNumberOfWorkers float,
			ProcessNumber float,
			FullCyclePartsProduced int);

	
	SELECT @isMultiPalletMachine=isnull([FloatValue],0)
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @machine
		  and PropertyKey = 'isMultiPalletMachine';
	SELECT @NumberOfParallelProcesses=isnull([FloatValue],1)
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @machine
	  and PropertyKey = 'NumberOfParallelProcessesForMultiPalletMachine';
	  
	if (@isMultiPalletMachine = 0 or @NumberOfParallelProcesses = 1 or (@isMultiPalletMachine = 1 and @NumberOfParallelProcesses > 1 and (datediff(hour,@StartDateTime, @EndDateTime) > 24 or GETUTCDATE() not between @StartDateTime and @EndDateTime)))
		insert into @TEMP_SmartKPICVSProductionTargetDetail ([LineThingName]
		  ,[StartTime]
		  ,[EndTime]
		  ,[ProductionTime]
		  ,[counter]
		  ,[OrderNumber]
		  ,[SinglePartTargetCount]
		  ,[WorkingTimeInMinutes]
		  ,[TimeToProducePartsInMinutes]
		  ,[TimeForProducedParts]
		  ,[ProcessingTime]
		  ,[SetupTime]
		  ,[CreationTime]
		  ,[ShiftFactorInPercent]
		  ,[SumPlannedNumberOfWorkers]
		  ,[ProcessNumber],
		  FullCyclePartsProduced)
		SELECT [LineThingName]
		  ,[StartTime]
		  ,[EndTime]
		  ,[ProductionTime]
		  ,[counter]
		  ,[OrderNumber]
		  ,[SinglePartTargetCount]
		  ,[WorkingTimeInMinutes]
		  ,[TimeToProducePartsInMinutes]
		  ,[TimeForProducedParts]
		  ,[ProcessingTime]
		  ,[SetupTime]
		  ,[CreationTime]
		  ,[ShiftFactorInPercent]
		  ,[SumPlannedNumberOfWorkers]
		  ,[ProcessNumber],
		  FullCyclePartsProduced
	  FROM [TEMP_SmartKPICVSProductionTargetDetail]
			where  ProductionTime>= @StartDateTime
            and ProductionTime<= @EndDateTime
            and LineThingName = @machine;
	
	if (select count(*) from @TEMP_SmartKPICVSProductionTargetDetail) = 0
		insert into @TEMP_SmartKPICVSProductionTargetDetail ([LineThingName]
		  ,[StartTime]
		  ,[EndTime]
		  ,[ProductionTime]
		  ,[counter]
		  ,[OrderNumber]
		  ,[SinglePartTargetCount]
		  ,[WorkingTimeInMinutes]
		  ,[TimeToProducePartsInMinutes]
		  ,[TimeForProducedParts]
		  ,[ProcessingTime]
		  ,[SetupTime]
		  ,[CreationTime]
		  ,[ShiftFactorInPercent]
		  ,[SumPlannedNumberOfWorkers]
		  ,[ProcessNumber],
		  FullCyclePartsProduced)
		SELECT @machine
		  ,@StartDateTime
		  ,@EndDateTime
		  ,[ProductionTime]
		  ,[counter]
		  ,[OrderNumber]
		  ,[SinglePartTargetCount]
		  ,[WorkingTimeInMinutes]
		  ,[TimeToProducePartsInMinutes]
		  ,[TimeForProducedParts]
		  ,[ProcessingTime]
		  ,[SetupTime]
		  ,getutcdate()
		  ,[ShiftFactorInPercent]
		  ,[PlannedNumberOfWorkers]
		  ,[ProcessNumber],
		  FullCyclePartsProduced
		from GetCVSProductionTargetFunction1V2(@machine, @StartDateTime, @EndDateTime);  
	  
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue] 
			from dbo.GetUtilizationOee2Truck1(@StartDateTime,@CalculationPeriodInMinutes,1,'flex', 'GetKPIsTruck', @machine);

--- Atoss Target
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS: Atoss Target', 'flex', @StartDateTime, @EndDateTime, dbo.GetCVSProductionTargetFromAtoss(@machine, @StartDateTime, @EndDateTime);
    

--- DowntimeStatistic
	DECLARE @MainStation varchar(255);

	SELECT @MainStation=[TextValue]
		FROM [smartKPIMachineKeyValueData]
		where PropertyKey = 'MainStationForLineStatus'
		and Machine = @machine;
	if @CalculationPeriodInMinutes<1441
	  BEGIN
	    insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
	 	  select @machine, 'CVS: '+StatusType+ ' [sec]', 'flex', @StartDateTime, @EndDateTime, TimeSumInSeconds 
			from GetDowntimeStatistic(@StartDateTime, @EndDateTime, @machine, @MainStation);
	    insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		  select @machine, 'CVS: '+StatusType+ ' [count]', 'flex', @StartDateTime, @EndDateTime, Occurrences 
			from GetDowntimeStatistic(@StartDateTime, @EndDateTime, @machine, @MainStation) where Occurrences is not null;
	  END;
	ELSE
	  BEGIN
	    insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue])
		  SELECT Machine, KPIName, 'flex', @StartDateTime, @EndDateTime, SUM([KPIFloatValue]) 
		  FROM [smartKPIValues] where Machine=@machine and KPIDateTime >=@StartDateTime and KPIDateTimeEnd<=@EndDateTime  and KPIName like 'CVS: L%'  and KPITimeBase='day' and [KPICalculationBase]='GetKPIsTruckWorker'
		  group by Machine, KPIName order by KPIName
	  END;

-- GetPlannedShiftTimes (former GetMachineTimeBreakdownCVS where Plan)

	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS: Machine Time Breakdown - ' + StatusType + ' - ' + StatusNameLevel2, 'flex', @StartDateTime, @EndDateTime, TimeSumInSeconds 
            from dbo.GetPlannedShiftTimes(@StartDateTime, @EndDateTime,@machine)


---- DLP1 Start

	DECLARE @dlp1result float = 0;
	DECLARE @dlp1result1 float;
	DECLARE @dlp1result2 float;
	DECLARE @Dlp1Actualresult float = 0;
	DECLARE @Dlp1Actualresult1 float;
	DECLARE @Dlp1Actualresult2 float;
	DECLARE @Dlp1ActualEndDate datetime2 = @EndDateTime;
	DECLARE @dlp1target float;
	DECLARE @target float;
	DECLARE @SumPlannedNumberOfWorkers float;
	DECLARE @SumShifttime float;
	DECLARE @timeNow float;


	

---- DLP1 Tartget Start 
--                    Parts (Target)
--   DLP1 Tartget = --------------------------------------------------------------------------------------------------------------------------------------
--                     Nber of operator (SAP) 

	
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS: KPI planned working time start: '+convert(varchar,@StartDateTime), 'flex', @StartDateTime, @EndDateTime, 0);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS: KPI planned working time end: '+convert(varchar,@EndDateTime), 'flex', @StartDateTime, @EndDateTime, 0);
	
	select @target=count(*), @SumPlannedNumberOfWorkers=round(sum(SumPlannedNumberOfWorkers)/count(*),2) from @TEMP_SmartKPICVSProductionTargetDetail;
	
	select @SumShifttime=sum(shifttime) from
		(SELECT isnull(sum(datediff(second,@StartDateTime
			  ,[CurrentEndTime])),0) as shifttime
		  FROM [TEMP_SmartKPIFullShift]
		  where Machine  = @machine
		  and [CurrentStartTime] < @StartDateTime
		  and [CurrentEndTime] > @StartDateTime
		union
		SELECT isnull(sum(datediff(second,[CurrentStartTime]
			  ,[CurrentEndTime])),0)
		  FROM [TEMP_SmartKPIFullShift]
		  where Machine  = @machine
		  and [CurrentStartTime] >= @StartDateTime
		  and [CurrentEndTime] <= @EndDateTime
		union
		SELECT isnull(sum(datediff(second,[CurrentStartTime]
			  ,@EndDateTime)),0)
		  FROM [TEMP_SmartKPIFullShift]
		  where Machine  = @machine
		  and [CurrentStartTime] < @EndDateTime
		  and [CurrentEndTime] > @EndDateTime)x;
	
	select @timeNow=sum(shifttime) from
		(SELECT isnull(sum(datediff(second,@StartDateTime
			  ,[CurrentEndTime])),0) as shifttime
		  FROM [TEMP_SmartKPIFullShift]
		  where Machine  = @machine
		  and [CurrentStartTime] < @StartDateTime
		  and [CurrentEndTime] > @StartDateTime
		union
		SELECT isnull(sum(datediff(second,[CurrentStartTime]
			  ,[CurrentEndTime])),0)
		  FROM [TEMP_SmartKPIFullShift]
		  where Machine  = @machine
		  and [CurrentStartTime] >= @StartDateTime
		  and [CurrentEndTime] <= GETUTCDATE()
		union
		SELECT isnull(sum(datediff(second,[CurrentStartTime]
			  ,GETUTCDATE())),0)
		  FROM [TEMP_SmartKPIFullShift]
		  where Machine  = @machine
		  and [CurrentStartTime] < GETUTCDATE()
		  and [CurrentEndTime] > GETUTCDATE()
		  and GETUTCDATE() > @StartDateTime)x;

	if (@StartDateTime > GETUTCDATE())
	BEGIN
		SET @timeNow=0;
		insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
			values (@machine, 'CVS DLP1: Calculated Production Target till now', 'flex', @StartDateTime, @EndDateTime, @target);
	END;
	else if (@EndDateTime > GETUTCDATE())
	BEGIN
		insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
			select @machine, 'CVS DLP1: Calculated Production Target till now', 'flex', @StartDateTime, GETUTCDATE(), sum(FullCyclePartsProduced) 
			from @TEMP_SmartKPICVSProductionTargetDetail 
			where ProductionTime < GETUTCDATE();
	END;
	else
	BEGIN
		if @isMultiPalletMachine = 1 and @NumberOfParallelProcesses > 1
		BEGIN
			DECLARE @LatestProductionDate datetime2;
			DECLARE @CurrentProcess int;
			DECLARE @NextProcess int;
			select @LatestProductionDate=max(ProductionTime) from @TEMP_SmartKPICVSProductionTargetDetail where ProductionTime <= GETUTCDATE();
			select @CurrentProcess=ProcessNumber from @TEMP_SmartKPICVSProductionTargetDetail where ProductionTime = @LatestProductionDate;
			select top(1) @NextProcess=ProcessNumber from @TEMP_SmartKPICVSProductionTargetDetail where ProductionTime > @LatestProductionDate order by ProductionTime;
			if @NextProcess = @CurrentProcess
			BEGIN
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				select @machine, 'CVS DLP1: Calculated Production Target till now', 'flex', @StartDateTime, @EndDateTime, count(*) from @TEMP_SmartKPICVSProductionTargetDetail
					where ProductionTime <= (SELECT max(ProductionTime)
					FROM @TEMP_SmartKPICVSProductionTargetDetail
					where ProductionTime <= @LatestProductionDate
					and ProcessNumber != @CurrentProcess);
			END;
			ELSE
			BEGIN
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				select @machine, 'CVS DLP1: Calculated Production Target till now', 'flex', @StartDateTime, @EndDateTime, count(*) from @TEMP_SmartKPICVSProductionTargetDetail
					where ProductionTime <= @LatestProductionDate;
			END;
		END;
		ELSE 
		BEGIN
			insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				select @machine, 'CVS DLP1: Calculated Production Target till now', 'flex', @StartDateTime, @EndDateTime, count(*) from @TEMP_SmartKPICVSProductionTargetDetail where ProductionTime <= GETUTCDATE();
		END;
	END;


	if (@EndDateTime < GETUTCDATE())
		SET @timeNow=@SumShifttime;
	if (@timeNow < 0)
		SET @timeNow=0;

	SET @dlp1target = dbo.GetCVSDlp1(@target,@SumShifttime,@SumPlannedNumberOfWorkers);
	
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP1: Calculated Production Target', 'flex', @StartDateTime, @EndDateTime, @target);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP1: Time in seconds within shift(s)', 'flex', @StartDateTime, @EndDateTime, @SumShifttime);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP1: Time in seconds passed till now and within shift(s)', 'flex', @StartDateTime, @EndDateTime, @timeNow);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS: Planned number of workers from SAP', 'flex', @StartDateTime, @EndDateTime, @SumPlannedNumberOfWorkers);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS DLP1: Local Target', 'flex', @StartDateTime, @EndDateTime, [FloatValue]
			FROM [smartKPIMachineKeyValueData] 
			where PropertyKey='DLP1' 
			and [PropertySubKey1] = @SumPlannedNumberOfWorkers
			and Machine = @machine;
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP1: Calculated Target', 'flex', @StartDateTime, @EndDateTime, isnull(@dlp1target,0));


---- DLP1 Tartget End 


---- DLP1 Actual Start 
if (@Dlp1ActualEndDate > GETUTCDATE())
		set @Dlp1ActualEndDate = GETUTCDATE();

	select @Dlp1Actualresult1=sum(numberOfParts) from smartKPI 
		where Machine = @machine 
		and isPartOK = 1
		and ProductionTime between @StartDateTime and @Dlp1ActualEndDate

	select @Dlp1Actualresult2=convert(float, dbo.GetCVSLoginTimeAtLine(@StartDateTime, @Dlp1ActualEndDate, @MainStation));
	
	SET @Dlp1Actualresult = dbo.GetCVSDlp1(@Dlp1Actualresult1,@Dlp1Actualresult2,1);

	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS: Sum of login times at line', 'flex', @StartDateTime, @EndDateTime, @Dlp1Actualresult2);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP3: KB paid hours', 'flex', @StartDateTime, @EndDateTime, @Dlp1Actualresult2/60/60);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP1: Parts Actual', 'flex', @StartDateTime, @EndDateTime, @Dlp1Actualresult1);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP1: Actual', 'flex', @StartDateTime, @EndDateTime, @Dlp1Actualresult);

---- DLP1 Actual End


	select @dlp1result1=[KPIFloatValue] from @table where [KPIName] = 'CVS DLP1: Actual';
	select @dlp1result2=[KPIFloatValue] from @table where [KPIName] = 'CVS DLP1: Calculated Target';
	
	SET @dlp1result = dbo.GetCVSDlp1Ratio(@dlp1result1,@dlp1result2);

	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		values (@machine, 'CVS DLP1: Ratio (Actual/Calculated Target)', 'flex', @StartDateTime, @EndDateTime, isnull(@dlp1result,0));

---- DLP1 End




--- CVS: Actual number of workers at Line Start

	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, ValueName, 'flex', @StartDateTime, @EndDateTime, FloatValue from dbo.GetCVSDlp3CustomerPaidHours(@StartDateTime, @EndDateTime, @machine);
	
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS: Actual number of workers at Line', 'flex', @StartDateTime, @EndDateTime, isnull(CASE WT.KPIFloatValue
															WHEN 0 THEN 0
															ELSE LT.KPIFloatValue/WT.KPIFloatValue		 
														END,0)
			from
			(select KPIFloatValue
			from @table where KPIName = 'CVS: Planned working time in seconds (from start to end of shift)') WT,
			(select KPIFloatValue
			from @table where KPIName = 'CVS: Sum of login times at line') LT;

--- CVS: Actual number of workers at Line Start End

--- CVS DLP3: Ratio (Customer paid hours/KB paid hours) Start
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS DLP3: Ratio (Customer paid hours/KB paid hours)', 'flex', @StartDateTime, @EndDateTime, isnull(CASE KBPH.KPIFloatValue
															WHEN 0 THEN 0
															ELSE CPH.KPIFloatValue/KBPH.KPIFloatValue*100		 
														END,0)
			from
			(select KPIFloatValue
			from @table where KPIName = 'CVS DLP3: KB paid hours') KBPH,
			(select KPIFloatValue
			from @table where KPIName = 'CVS DLP3: Customer paid hours') CPH;

-- CVS DLP3: Ratio (Customer paid hours/KB paid hours) End


-- ProductionTarget Start
	
	if (@isMultiPalletMachine = 0 or @NumberOfParallelProcesses = 1 or (@isMultiPalletMachine = 1 and @NumberOfParallelProcesses > 1 and (datediff(hour,@StartDateTime, @EndDateTime) > 24 or GETUTCDATE() not between @StartDateTime and @EndDateTime)))
		insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'ProductionTarget', 'flex', @StartDateTime, @EndDateTime, count(*) from @TEMP_SmartKPICVSProductionTargetDetail;
	else
		insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'ProductionTarget', 'flex', @StartDateTime, @EndDateTime, count(*) from GetCVSProductionTargetFunction1V2(@machine, @StartDateTime, @EndDateTime);
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
	select @machine, 'CVS: APO shift factor in percent', 'flex', @StartDateTime, @EndDateTime, avg(ShiftFactorInPercent) from @TEMP_SmartKPICVSProductionTargetDetail;

-- ProductionTarget End


-- CVS: Changeovers Start
	with cte as
		  (select distinct [OrderNumber]
		  from smartKPI 
		  where ProductionTime >= @StartDateTime 
		  and ProductionTime < @EndDateTime
		  and Machine = @machine 
		  and ISNULL(OrderNumber,'')!= '')
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS: Changeovers', 'flex', @StartDateTime, @EndDateTime, CASE WHEN count(*) > 0 THEN count(*)-1 ELSE 0 END
		from cte; 
-- CVS: Changeovers End


--CVS: Average Changeover time from operator screen [min] Start
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS: Average Changeover time from operator screen [min]', 'flex', @StartDateTime, @EndDateTime, case when count.KPIFloatValue = 0 then 0 else time.KPIFloatValue/count.KPIFloatValue end from
		(select top 1 KPIFloatValue/60 as KPIFloatValue from @table where KPIName = 'CVS: Changeover [sec]') time,
		(select top 1 KPIFloatValue from @table where KPIName = 'CVS: L0/Changeover [count]') count -- and Machine = @machine and KPIDateTime = @StartDateTime and KPIDateTimeEndOfCalculation = @EndDateTime
--CVS: Average Changeover time from operator screen [min] End


-- CVS: Downtime losses [min] Start
	insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
		select @machine, 'CVS: Downtime losses [min]', 'flex', @StartDateTime, @EndDateTime, sum(KPIFloatValue)/60 
		from @table 
		where KPIName like 'CVS: L0%' and  KPIName not like 'CVS% [[]count]' and KPIName not in ('CVS: L0/Changeover [sec]', 'CVS: L0/KBMaschStatus.1.Pr [sec]') 
--CVS: Downtime losses [min] End

-- backwards compatibility Start
	update @table set [KPIName]='CVS: Main Station Downtime Statistic Changeover' where [KPIName]='CVS: Changeover [sec]'
	update @table set [KPIName]='CVS: Main Station Downtime Statistic Organisational Interruption' where [KPIName]='CVS: Organisational Interruption [sec]'
	update @table set [KPIName]='CVS: Main Station Downtime Statistic Productive' where [KPIName]='CVS: Productive [sec]'
	update @table set [KPIName]='CVS: Main Station Downtime Statistic Technical Interruption' where [KPIName]='CVS: Technical Interruption [sec]'
	update @table set [KPIName]='CVS: Main Station Downtime Statistic Unknown' where [KPIName]='CVS: Unknown [sec]'
	update @table set [KPIName]='CVS: Main Station Downtime Statistic Unplanned' where [KPIName]='CVS: Unplanned [sec]'
	update @table set [KPIName]='CVS: Main Station Downtime Statistic Quality' where [KPIName]='CVS: Quality [sec]'
-- backwards compatibility End


-- Finalization		
	update @table set KPIFloatValue = round(KPIFloatValue,1);
	return;
	END;
GO

