--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetFunction1V2Orders';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetFunction1V2Orders'))
drop FUNCTION GetCVSProductionTargetFunction1V2Orders;
GO
CREATE FUNCTION GetCVSProductionTargetFunction1V2Orders
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS @orders TABLE ( 
	OrderNumber varchar(255),
	Operation varchar(255),
	NumberOfParts int,
	PlannedStartDate datetime2,
	Suffix varchar(255)  )
BEGIN

	DECLARE @ordersInLine TargetOrderTypeV3;
	Declare @SAPTimeIdentifier varchar(255) = 'ScheduledStartDate';
	Declare @SAPServerThing varchar(255) = 'KBTruckSAPServer';
	Declare @IdentifierConfirmedParts varchar(255) = 'OKPartsConfirmed';
	Declare @IdentifierTotalQuantity varchar(255) = 'TotalOrderQuantity';
	Declare @IdentifierSetupTime varchar(255) = 'SetupTimeCO';
	Declare @IdentifierProcessingTime varchar(255) = 'ProcessingTimeCO';
	
	Declare @LastOrderNumber varchar(255);
	Declare @NumberOfPartsToProduce int;
	declare @CurrentDate datetime2 = @StartTime;
	declare @NumberOfProducedParts int;

	declare @SAPMachine varchar(255);
	declare @ordersuffix varchar(200);
	declare @Operation varchar(255);
	DECLARE @NumberOfParallelProcesses int = 1;
	DECLARE @isMultiPalletMachine int = 0;
	declare @getOrders cursor;
	DECLARE @OrderCounter int;
	Declare @MainStation varchar(255) ;
	Declare @SetupType varchar(255) ;
	declare @ordersuffixnew varchar(200) = 'added OP';


	SELECT @MainStation=[TextValue]
		FROM [smartKPIMachineKeyValueData]
		where PropertyKey = 'MainStationForLineStatus'
		and Machine = @LineThingName;

	select top(1) @SetupType=[MessageType2]
		from [smartKPIMachineMessageData]
		where Machine = @MainStation
		and MessageType1 = 'OGSMessage'
		and MessageTime < @EndTime
		order by MessageTime desc;
		
		
	SELECT @isMultiPalletMachine=[FloatValue]
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @LineThingName
		  and PropertyKey = 'isMultiPalletMachine';


	if @isMultiPalletMachine = 1
	BEGIN
		SELECT @NumberOfParallelProcesses=[FloatValue]
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @LineThingName
		  and PropertyKey = 'NumberOfParallelProcessesForMultiPalletMachine';
	END;

	SELECT @SAPMachine=[TextValue]
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @LineThingName
	  and PropertyKey = 'SAPWorkcenterNumber';

---------------------------------------------------------------------------------------------------------------------------------------------------
-- already produced parts	
---------------------------------------------------------------------------------------------------------------------------------------------------

	set @ordersuffix = '(1: already produced)';
	insert into @orders (PlannedStartDate, NumberOfParts, OrderNumber, Suffix, Operation)
		select ProductionTime, numberOfParts, isnull(REPLACE(rtrim([OrderNumber]), ' ', ''),''), @ordersuffix, isnull(REPLACE(rtrim([SAPOperationNumber]), ' ', ''),'')
		  FROM [smartKPI]
		  where Machine = @LineThingName
		  and ProductionTime >= @StartTime
		  and isPartOK = 1
		  and isnull(OrderNumber,'') != ''
		  order by ProductionTime;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- started but not finalized Orders	
---------------------------------------------------------------------------------------------------------------------------------------------------
	set @ordersuffix = '(2: started but not finalized Order)';
	
	
	select @OrderCounter=count(*) from @orders;

	if @OrderCounter > 0
	BEGIN
		insert into @orders (PlannedStartDate, OrderNumber, Suffix, Operation)
			select top(@NumberOfParallelProcesses) PlannedStartDate, OrderNumber, @ordersuffix, Operation 
				from @orders 
				where Suffix != @ordersuffix
				order by PlannedStartDate desc;
	END
	
	if @OrderCounter = 0
	BEGIN
		insert into @orders (PlannedStartDate, OrderNumber, Suffix, Operation)
			select top(@NumberOfParallelProcesses) ProductionTime, isnull(rtrim(OrderNumber),''), @ordersuffix, isnull(rtrim(SAPOperationNumber),'')
				from smartKPI 
				where ProductionTime < @StartTime 
				and Machine = @LineThingName
				order by ProductionTime desc;
	END

	select @OrderCounter=count(*) from @orders where Suffix = @ordersuffix;
	if @OrderCounter < @NumberOfParallelProcesses
	BEGIN
		insert into @orders (PlannedStartDate, OrderNumber, Suffix, Operation)
			select top(@NumberOfParallelProcesses-@OrderCounter) ProductionTime, isnull(rtrim(OrderNumber),''), @ordersuffix, isnull(rtrim(SAPOperationNumber),'')
				from smartKPI 
				where ProductionTime < @StartTime 
				and Machine = @LineThingName
				order by ProductionTime desc;
	END

	if @SetupType = 'A1/A2'
	BEGIN
		--for A1/A2 started but not finalized Order: if from privious op the last op is not jet produced insert it...
		with x1 as
		(select top(1) row_number() over (order by PlannedStartDate) as seq, * from @orders where Suffix = '(1: already produced)' order by PlannedStartDate desc),
		x2 as
		(select top(2) row_number() over (order by PlannedStartDate) as seq, * from @orders where Suffix = '(1: already produced)' order by PlannedStartDate desc),
		x3 as
		(select @ordersuffixnew as Suffix, getutcdate() as now)
		insert into @orders (OrderNumber, Operation, NumberOfParts, PlannedStartDate, Suffix)
		select x2.OrderNumber, x2.Operation, x2.NumberOfParts, x3.now, x3.Suffix from x2, x1, x3
		where x1.seq <> x2.seq
		and x1.Operation < x2.Operation
		except
		select OrderNumber, Operation, NumberOfParts, x3.now, x3.Suffix from x1, x3;

		--for A1/A2 started but not finalized Order: first entry must be lower operation
		with subrows as 
		(select row_number() over (order by Operation) as seq , OrderNumber as orn, Operation as op from @orders where Suffix = '(2: started but not finalized Order)')
		update @orders set PlannedStartDate = DATEADD(second,seq,getutcdate())
		from subrows
		where OrderNumber = subrows.orn
		and Operation = subrows.op
		and Suffix = @ordersuffix;

		SET @getOrders = CURSOR FOR 
			select 
				OrderNumber, max(Operation)
				from @orders
				where Suffix = @ordersuffix
				group by OrderNumber;
		--Loop over parts to be produced
		OPEN @getOrders;
			FETCH NEXT FROM @getOrders into @LastOrderNumber, @Operation
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				select @NumberOfProducedParts = isnull(sum(numberOfParts),0) 
					from smartKPI 
					where rtrim(OrderNumber) = @LastOrderNumber
					and isnull(REPLACE([SAPOperationNumber], ' ', ''),'') = @Operation
					and Machine = @LineThingName
					and isPartOK = 1;

					
				select @NumberOfPartsToProduce = isnull(FloatValue,1)  
					from [smartKPIOrderKeyValueData] 
					where rtrim(OrderNumber) = @LastOrderNumber
					and PropertyKey = @IdentifierTotalQuantity;

				update @orders set NumberOfParts = @NumberOfPartsToProduce-@NumberOfProducedParts
					where OrderNumber = @LastOrderNumber
					and Suffix = @ordersuffix;

			
				FETCH NEXT FROM @getOrders into @LastOrderNumber, @Operation
			END;
		CLOSE @getOrders;
		DEALLOCATE @getOrders;
		
		with parts as (select NumberOfParts as NumberOfParts1, OrderNumber as OrderNumber1 from @orders where Suffix = @ordersuffixnew)
		update @orders set NumberOfParts = NumberOfParts - NumberOfParts1 from parts where OrderNumber1 = OrderNumber and Suffix = @ordersuffix;

		update @orders set Suffix = @ordersuffix where Suffix = @ordersuffixnew;
	End
	ELSE
	BEGIN
	
		SET @getOrders = CURSOR FOR 
			select 
				OrderNumber, Operation
				from @orders
				where Suffix = @ordersuffix;

		--Loop over parts to be produced
		OPEN @getOrders;
			FETCH NEXT FROM @getOrders into @LastOrderNumber, @Operation
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				select @NumberOfProducedParts = isnull(sum(numberOfParts),0) 
					from smartKPI 
					where rtrim(OrderNumber) = @LastOrderNumber
					and isnull(REPLACE([SAPOperationNumber], ' ', ''),'') = @Operation
					and Machine = @LineThingName
					and isPartOK = 1;

					
				select @NumberOfPartsToProduce = isnull(FloatValue,1)  
					from [smartKPIOrderKeyValueData] 
					where rtrim(OrderNumber) = @LastOrderNumber
					and PropertyKey = @IdentifierTotalQuantity;

				update @orders set NumberOfParts = @NumberOfPartsToProduce-@NumberOfProducedParts
					where OrderNumber = @LastOrderNumber
					and Operation = @Operation
					and Suffix = @ordersuffix;

			
				FETCH NEXT FROM @getOrders into @LastOrderNumber, @Operation
			END;
		CLOSE @getOrders;
		DEALLOCATE @getOrders;
		if (select count(distinct OrderNumber) from @orders where Suffix = @ordersuffix) = 1
			update @orders set NumberOfParts = (select min(NumberOfParts) from @orders where Suffix = @ordersuffix) where Suffix = @ordersuffix;
	End
	

	if exists (select 'ok' from @orders where Suffix = @ordersuffix and NumberOfParts <= 0)
		delete from @orders where Suffix = @ordersuffix;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- not started Orders	
---------------------------------------------------------------------------------------------------------------------------------------------------

	insert into @ordersInLine (OrderNumber) select OrderNumber from @orders;
	
	if (select count(*) from @orders) > 0
	BEGIN
		select @CurrentDate=max(PlannedStartDate) from @orders;
	End
	ELSE
	BEGIN
		SET @CurrentDate = @StartTime;
	End

	set @ordersuffix = '(3: not started)';

	insert into @orders (PlannedStartDate, NumberOfParts, OrderNumber, Suffix, Operation)
		select 
			o5.DateTimeValue as EarliestScheduledStartExecution,
			o2.FloatValue as TotalOrderQuantity, 
			o3.OrderNumber,
			@ordersuffix, 
			o3.Operation--, 
			--o3.FloatValue as OKPartsConfirmed, 
			--o4.FloatValue as NOKPartsConfirmed, 
			--o6.DateTimeValue as LatestScheduledFinishExecution
		from [smartKPIOrderKeyValueData] o1, [smartKPIOrderKeyValueData] o2, [smartKPIOrderKeyValueData] o3, [smartKPIOrderKeyValueData] o4, [smartKPIOrderKeyValueData] o5, [smartKPIOrderKeyValueData] o6
			where o1.OrderNumber = o2.OrderNumber
			and o1.OrderNumber = o3.OrderNumber
			and o1.OrderNumber = o4.OrderNumber
			and o1.OrderNumber = o5.OrderNumber
			and o1.OrderNumber = o6.OrderNumber
			and o1.Operation = o3.Operation
			and o3.Operation != ''
			and o2.Operation = ''
			and o1.Operation = o4.Operation
			and o4.Operation != ''
			and o1.Operation = o5.Operation
			and o5.Operation != ''
			and o1.Operation = o6.Operation
			and o5.Operation != ''
			and o1.TextValue1 = @SAPMachine
			and o1.PropertyKey1 = 'Line'
			and o2.PropertyKey1 = 'TotalOrderQuantity'
			and o3.PropertyKey1 = 'OKPartsConfirmed'
			and o4.PropertyKey1 = 'NOKPartsConfirmed'
			and o5.PropertyKey1 = 'EarliestScheduledStartExecution'
			and o6.PropertyKey1 = 'LatestScheduledFinishExecution'
			and o3.FloatValue + o4.FloatValue < o2.FloatValue * .9
			and o6.DateTimeValue > @CurrentDate
			and o3.OrderNumber COLLATE database_default not in (select OrderNumber from @ordersInLine)
		order by o5.DateTimeValue;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- fill up with last order if not enough ones available	
---------------------------------------------------------------------------------------------------------------------------------------------------


	set @ordersuffix = '(4: no order available)';
	insert into @orders (PlannedStartDate, NumberOfParts, OrderNumber, Suffix, Operation)
	select top (1) PlannedStartDate, 100000, OrderNumber, @ordersuffix, Operation from @orders order by Suffix desc, PlannedStartDate desc;



	RETURN;
	
END;
GO


--declare @sdt as DateTime2 = '2020-08-19 00:00:00.000';
--declare @edt as DateTime2 = '2020-08-20 00:00:00.000';
--select * from GetCVSProductionTargetFunction1V2('KBLisLaa6MachineThing', @sdt, @edt);  
--GO
