--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetOutputKPIDataLast30Days';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetOutputKPIDataLast30Days'))
drop FUNCTION GetOutputKPIDataLast30Days;
GO
CREATE FUNCTION [dbo].[GetOutputKPIDataLast30Days] 
(
	@machine varchar(255),
	@date1 datetime2,
	@date2 datetime2
)
RETURNS @table Table (
	KPIDateTime datetime2,
	KPIFloatValue int,
	KPIFloatValue1 int
)
AS
BEGIN
	insert into @table(KPIDateTime, KPIFloatValue, KPIFloatValue1)	
		select IO.KPIDateTime, isnull(IO.KPIValue,0) as KPIFloatValue, isnull(NIO.KPIValue,0) as KPIFloatValue1 from 
			(select x.[KPIDateTime] as [KPIDateTime], sum(x.[KPIValue]) as [KPIValue] from (
				select dateadd(day, DATEDIFF(day,0,ProductionTime),0) as [KPIDateTime], sum(numberOfParts) as [KPIValue] 
				from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 1 
				group by dateadd(day, DATEDIFF(day,0,ProductionTime),0)
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-0,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-1,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-2,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-3,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-4,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-5,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-6,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-7,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-8,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-9,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-10,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-11,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-12,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-13,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-14,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-15,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-16,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-17,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-18,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-19,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-20,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-21,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-22,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-23,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-24,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-25,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-26,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-27,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-28,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-29,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-30,0),0)x
			group by [KPIDateTime]) as IO,
			(select x.[KPIDateTime] as [KPIDateTime], sum(x.[KPIValue]) as [KPIValue] from (
				select dateadd(day, DATEDIFF(day,0,ProductionTime),0) as [KPIDateTime], sum(numberOfParts) as [KPIValue] 
				from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 0 
				group by dateadd(day, DATEDIFF(day,0,ProductionTime),0)
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-0,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-1,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-2,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-3,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-4,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-5,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-6,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-7,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-8,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-9,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-10,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-11,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-12,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-13,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-14,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-15,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-16,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-17,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-18,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-19,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-20,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-21,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-22,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-23,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-24,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-25,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-26,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-27,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-28,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-29,0),0
				union select dateadd(day, DATEDIFF(day,0,GETUTCDATE())-30,0),0)x
			group by [KPIDateTime]) as NIO
		where NIO.[KPIDateTime] = IO.[KPIDateTime]
		order by IO.[KPIDateTime];

RETURN 
END
GO
