--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetUtilizationOee2Truck';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetUtilizationOee2Truck'))
drop FUNCTION GetUtilizationOee2Truck;
GO
CREATE FUNCTION GetUtilizationOee2Truck
	(@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@machine varchar(255))
RETURNS @table TABLE ( KPIOee float, KPIUtilization float, KPIPartsIO int, KPIPartsNIO int, KPIRQ float	)  
BEGIN;


	Declare @StartDatePerCalculationCycle DateTime2;
	Declare @EndDatePerCalculationCycle DateTime2;
	Declare @KPIOee float;
	Declare @KPIUtilization float;
	Declare @KPIRQ float;
	Declare @getMachines CURSOR;
	Declare @machineName varchar(255);
	Declare @timeBaseOee float;
	Declare @timeBaseUtilization float;
	Declare @KPIPartsIO int;
	Declare @KPIPartsNIO int;
	Declare @KPIsumTgmax float;
	Declare @KPIpt float;
	Declare @SAPWorkcenterNumber varchar(255);
	DECLARE @MainStation varchar(255);
	DECLARE @UseMainStationForCalculation bit;

	SELECT @MainStation=[TextValue]
		FROM [smartKPIMachineKeyValueData]
		where PropertyKey = 'MainStationForLineStatus'
		and Machine = @machine;

	SELECT @UseMainStationForCalculation=convert(bit, isnull([FloatValue],0))
		FROM [smartKPIMachineKeyValueData]
		where PropertyKey = 'Use_MainStationForLineStatus_ForPartCounting'
		and Machine = @machine;
	if (@UseMainStationForCalculation is null)
		SET @UseMainStationForCalculation = 0;
	
	
	set @StartDatePerCalculationCycle = datetimefromparts(
		DATEPART(year, @StartDateTime),
		DATEPART(month, @StartDateTime),
		DATEPART(day, @StartDateTime),
		DATEPART(hour, @StartDateTime),
		DATEPART(minute, @StartDateTime),
		0,0);

	set @EndDatePerCalculationCycle = @EndDateTime;
	if (@EndDatePerCalculationCycle > getutcdate())
		set @EndDatePerCalculationCycle = getutcdate();



	SET @getMachines = CURSOR FOR 
		SELECT Machine, [TextValue]
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @machine
		  and PropertyKey = 'SAPWorkcenterNumber'
		  and [TextValue] is not null
		  and [TextValue] != '';


	OPEN @getMachines;
		FETCH NEXT FROM @getMachines into @machineName, @SAPWorkcenterNumber
		WHILE @@FETCH_STATUS = 0
		BEGIN;

			if (@UseMainStationForCalculation=1)
			BEGIN
			
				select @KPIsumTgmax=isnull(sum(y.times),0) from
				(SELECT isNull(x.tgMaxTimeInSec,0)*[smartKPI].numberOfParts as times
					FROM [smartKPI] 
					cross apply GetSAPTimePerPart([smartKPI].[OrderNumber]) as x
					where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
					and Machine = @MainStation
					and x.OperationNumber = [smartKPI].SAPOperationNumber  COLLATE database_default
					and isPartOK = 1)y;					

				SELECT @KPIPartsIO=sum(numberOfParts)
					FROM [smartKPI]
					where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
					and Machine = @MainStation
					and isPartOK = 1;

				SELECT @KPIPartsNIO=sum(numberOfParts)
					FROM [smartKPI]
					where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
					and Machine = @MainStation
					and isPartOK = 0;
			END
			ELSE
			BEGIN
				select @KPIsumTgmax=isnull(sum(y.times),0) from
				(SELECT isNull(x.tgMaxTimeInSec,0)*[smartKPI].numberOfParts as times
					FROM [smartKPI] 
					cross apply GetSAPTimePerPartPerMachine([smartKPI].[OrderNumber], @machineName) as x
					where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
					and Machine = @machineName
					and isPartOK = 1)y;					

				SELECT @KPIPartsIO=sum(numberOfParts)
					FROM [smartKPI]
					where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
					and Machine = @machineName
					and isPartOK = 1;

				SELECT @KPIPartsNIO=sum(numberOfParts)
					FROM [smartKPI]
					where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
					and Machine = @machineName
					and isPartOK = 0;
			END
			
				
			select @KPIpt=dbo.GetWorkingTimeCVSInSeconds(@machineName, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle);			
			
			select @timeBaseUtilization = dbo.GetCalendarTimeCVSInSeconds(@StartDatePerCalculationCycle, @EndDatePerCalculationCycle);
			set @timeBaseOee = @KPIpt;
					
			set @KPIUtilization = 0.0;
			IF ((@timeBaseUtilization) > 0.0)
			BEGIN
				set @KPIUtilization = convert(float,@KPIsumTgmax) / convert(float,@timeBaseUtilization) * 100.0;
			END;
			set @KPIOee = 0.0;
			IF ((@timeBaseOee) > 0.0)
			BEGIN
				set @KPIOee = convert(float,@KPIsumTgmax) / convert(float,@timeBaseOee) * 100.0;
			END;

			if (@KPIUtilization is null)
				set @KPIUtilization = 0;
			if (@KPIOee is null)
				set @KPIOee = 0;
			
			set @KPIRQ = 0.0;
			if ((@KPIPartsIO + @KPIPartsNIO) > 0)
				set @KPIRQ = convert(float,@KPIPartsIO) / (convert(float,@KPIPartsIO) + convert(float,@KPIPartsNIO)) * 100.0;
			
			insert into @table (KPIOee, KPIUtilization, KPIPartsIO, KPIPartsNIO, KPIRQ) values (round(@KPIOee,2), round(@KPIUtilization,2), @KPIPartsIO, @KPIPartsNIO, round(@KPIRQ,2));

			FETCH NEXT FROM @getMachines into @machineName, @SAPWorkcenterNumber;
		END;
	CLOSE @getMachines;
	DEALLOCATE @getMachines;
	RETURN;
END;

GO
