--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetForOrdersFunction1V2ForAssembly';
--------------------------------------------------------------
--------------------------------------------------------------


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetForOrdersFunction1V2ForAssembly'))
drop FUNCTION GetCVSProductionTargetForOrdersFunction1V2ForAssembly;
GO
CREATE FUNCTION GetCVSProductionTargetForOrdersFunction1V2ForAssembly
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2,
	@orders TargetOrderTypeV3 READONLY)
RETURNS @table TABLE ( 
	ProductionTime DateTime2, 
	counter int, 
	OrderNumber varchar(255), 
	SinglePartTargetCount INT, 
	WorkingTimeInMinutes float,
	TimeToProducePartsInMinutes float, 
	TimeForProducedParts float, 
	ProcessingTime float,
	SetupTime float,
	PlannedNumberOfWorkers float,
	ShiftFactorInPercent float,
	ParallelProcessing varchar(1000),
	ProcessNumber int,
	FullCyclePartsProduced int)  

BEGIN

	Declare @getOrders CURSOR;
	Declare @getProcesses CURSOR;
	declare @TimeForProducedPartsInSeconds float = 0.0;
	declare @OrderOutputSuffix varchar(200);
	declare @ShiftFactorInPercent float;
	declare @SAPMachine varchar(255);
	declare @CurrentDate datetime2 = @StartTime;
	Declare @ProcessingTime float;
	Declare @SetupTime float = 0.0;
	declare @PlannedNumberOfWorkersCO float;
	Declare @OrderNumber varchar(255);
	Declare @LastOrderNumber varchar(255) = '';
	Declare @TimeCompletlyFilled Bit = 0;
	DECLARE @SinglePartTargetCount INT = 0;
	DECLARE @SinglePartOrderTargetCount INT = 0;
	Declare @OrderTime DateTime2;
	Declare @NumberOfPartsToProduce int;
	Declare @NumberOfProducedParts int;
	declare @dateWorkStart datetime2;
	declare @dateWorkEnd datetime2;
	declare @WorkIdentifier int;
	declare @dateBreakStart datetime2;
	declare @dateBreakEnd datetime2;
	declare @BreakIdentifier int;
	DECLARE @PartTargetCount INT = 0;
	DECLARE @LastPartProduced datetime2;
	DECLARE @ParallelProcessingLog varchar(1000) = 'fixed';
	DECLARE @shiftCalendar table (StartTime datetime2, EndTime datetime2, Qualifier varchar(10), Utilization float);
	DECLARE @OrderChange bit = 0;
	declare @counter int;


	-- Get SAP Workcenter number
	SELECT @SAPMachine=[TextValue]
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @LineThingName
	  and PropertyKey = 'SAPWorkcenterNumber';

	-- Get related part of shift calendar to reduce selections to shiftCalendar table
	insert into @shiftCalendar (StartTime, EndTime, Qualifier, Utilization)
		select StartTime, EndTime, Qualifier, Utilization
		from shiftCalendar
		where Machine = @SAPMachine
		and (StartTime >= @StartTime and EndTime <= @EndTime
			or StartTime <= @StartTime and EndTime >= @StartTime
			or StartTime <= @EndTime and EndTime >= @EndTime
			or StartTime <= @StartTime and EndTime >= @EndTime);

	--Prepare processes
	select top(1)
		@OrderTime=PlannedStartDate
	from @orders
	order by Suffix, PlannedStartDate;

	select top(1) 
		@LastOrderNumber=isnull(REPLACE([OrderNumber], ' ', ''),'')
		from smartKPI
		where Machine = @LineThingName
		and isPartOK = 1
		and ProductionTime < @OrderTime
		order by ProductionTime desc;


	select @ProcessingTime=isNull(ProcessingTimeInSecCO,0) / 60,	
			@SetupTime = isNull(SetupTimeInSecCO,0) / 60, 
			@PlannedNumberOfWorkersCO = isNull(PlannedNumberOfWorkersCO,0)
		from GetSAPTimePerPartPerMachine(@LastOrderNumber, @LineThingName)

	--define cursor for part production
	SET @getOrders = CURSOR FOR 
		select 
			PlannedStartDate,
			NumberOfParts, 
			OrderNumber,
			Suffix 
		from @orders
		order by Suffix, PlannedStartDate;

	--Loop over parts to be produced
	OPEN @getOrders;
		FETCH NEXT FROM @getOrders into @OrderTime, @NumberOfPartsToProduce, @OrderNumber, @OrderOutputSuffix
		WHILE @@FETCH_STATUS = 0
		BEGIN;
		
			
			set @OrderChange = 0;
			--is new Order?

			if @LastOrderNumber != @OrderNumber
			BEGIN
				select @ProcessingTime=isNull(ProcessingTimeInSecCO,0) / 60, 
						@PlannedNumberOfWorkersCO=isNull(PlannedNumberOfWorkersCO,0),  
						@SetupTime = isNull(SetupTimeInSecCO,0) / 60
					from GetSAPTimePerPartPerMachine(@OrderNumber, @LineThingName);

				set @OrderChange = 1;
			END;
			-- get shift factor
			select @ShiftFactorInPercent=ShiftFactorInPercent from
				(select top(1) Utilization/100 as ShiftFactorInPercent
				from @shiftCalendar 
				where StartTime >= @CurrentDate
				and Qualifier = 'W'
				order by StartTime)x;			
			if @ShiftFactorInPercent is null
				select @ShiftFactorInPercent=ShiftFactorInPercent from
					(select top(1) Utilization/100 as ShiftFactorInPercent
					from shiftCalendar 
					where StartTime >= @CurrentDate
					and Qualifier = 'W'
					and Machine = @SAPMachine
					order by StartTime)x;			
			if @ShiftFactorInPercent is null
				set @ShiftFactorInPercent = 1;


			if (@ShiftFactorInPercent>0 and @ProcessingTime>0)
			BEGIN

			--Add Setup Time for new order
				if (@CurrentDate < @EndTime)
					BEGIN
						if (@ShiftFactorInPercent = 0)
							set @ShiftFactorInPercent = 0.0000001;
						if (@OrderChange = 1)
							SET @TimeForProducedPartsInSeconds = @TimeForProducedPartsInSeconds + @SetupTime*60/ @ShiftFactorInPercent;
					END;
				else
					BEGIN
						SET @TimeCompletlyFilled = 1;
						BREAK;
					END;

				set @SinglePartTargetCount = 0;
				if (@OrderChange = 1)
					set @SinglePartOrderTargetCount = 0;
				--Add Processing Time
				WHILE @SinglePartOrderTargetCount < @NumberOfPartsToProduce and @TimeCompletlyFilled = 0
				BEGIN
					set @CurrentDate = dateadd(second, convert(int,@TimeForProducedPartsInSeconds), @StartTime);
					
					if (select count(*) from @shiftCalendar where StartTime <= @CurrentDate and EndTime >= @CurrentDate) = 0
						or (select count(*) from @shiftCalendar where StartTime <= @CurrentDate and EndTime >= @CurrentDate and Qualifier != 'W') > 0
					BEGIN
						select @dateWorkStart=min(StartTime) from
							(--W-shift start without any others
							select StartTime from @shiftCalendar s1 
							where StartTime >= @CurrentDate
							and Qualifier = 'W'
							and not exists (select 'ok' from @shiftCalendar s2 
								where s1.StartTime >= s2.StartTime 
								and s1.StartTime < s2.EndTime
								and Qualifier != 'W')
							--W-shifts where other ends
							union
							select EndTime from @shiftCalendar s1 
							where EndTime > @CurrentDate
							and Qualifier != 'W'
							and exists (select 'ok' from @shiftCalendar s2 
								where s1.EndTime > s2.StartTime 
								and s1.EndTime < s2.EndTime
								and Qualifier = 'W'))x;
	
						SET @TimeForProducedPartsInSeconds = @TimeForProducedPartsInSeconds + DATEDIFF(second, @CurrentDate, @dateWorkStart);
						SET @CurrentDate = @dateWorkStart;
					End
					
					select @ShiftFactorInPercent=ShiftFactorInPercent from
						(select top(1) Utilization/100 as ShiftFactorInPercent
						from @shiftCalendar 
						where StartTime >= @CurrentDate
						and Qualifier = 'W'
						order by StartTime)x;			
					if @ShiftFactorInPercent is null
						select @ShiftFactorInPercent=ShiftFactorInPercent from
							(select top(1) Utilization/100 as ShiftFactorInPercent
							from shiftCalendar 
							where StartTime >= @CurrentDate
							and Qualifier = 'W'
							and Machine = @SAPMachine
							order by StartTime)x;			
					if @ShiftFactorInPercent is null
						set @ShiftFactorInPercent = 1;

					if (@ShiftFactorInPercent = 0)
						set @ShiftFactorInPercent = 0.0000001;


					set @counter = 0;
					set @CurrentDate = dateadd(second, convert(int,@TimeForProducedPartsInSeconds), @StartTime);
					if (@CurrentDate < @EndTime)
						BEGIN
							SET @TimeForProducedPartsInSeconds = @TimeForProducedPartsInSeconds + @ProcessingTime*60 / @ShiftFactorInPercent;
							SET @SinglePartTargetCount = @SinglePartTargetCount + 1;
							SET @SinglePartOrderTargetCount = @SinglePartOrderTargetCount + 1;
							SET @PartTargetCount = @PartTargetCount + 1;
							set @ParallelProcessingLog='O:'+@OrderNumber+ ' OC:'+convert(varchar,@OrderChange)+ ' T:'+convert(varchar,@NumberOfPartsToProduce)+ ' A:'+convert(varchar,@SinglePartOrderTargetCount)+ ' PT:'+convert(varchar,@ProcessingTime)+ ' ST:'+convert(varchar,@SetupTime)+ ' W:'+convert(varchar,@PlannedNumberOfWorkersCO)

							
							insert into @table (FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, SetupTime, PlannedNumberOfWorkers, ParallelProcessing, ProcessNumber) 
								values (1, @ShiftFactorInPercent*100,dateadd(second, convert(int,@TimeForProducedPartsInSeconds), @StartTime), @PartTargetCount, @TimeForProducedPartsInSeconds/60, @ProcessingTime/ @ShiftFactorInPercent, @SinglePartOrderTargetCount, @OrderNumber+ ' '+@OrderOutputSuffix, @SetupTime/ @ShiftFactorInPercent, @PlannedNumberOfWorkersCO, @ParallelProcessingLog, 0);
						END;
					else
						BEGIN
							SET @TimeCompletlyFilled = 1;
							BREAK;
						END;
					set @counter = @counter + 1;
					if @TimeCompletlyFilled = 1
						BREAK;
				END;			
				set @SinglePartOrderTargetCount=0;
			END;
			SET @LastOrderNumber = @OrderNumber;
		
			FETCH NEXT FROM @getOrders into @OrderTime, @NumberOfPartsToProduce, @OrderNumber, @OrderOutputSuffix
		END;
	CLOSE @getOrders;
	DEALLOCATE @getOrders;
	return
END
GO

