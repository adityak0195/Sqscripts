--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetFunction1V2';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetFunction1V2'))
drop FUNCTION GetCVSProductionTargetFunction1V2;
GO
CREATE FUNCTION GetCVSProductionTargetFunction1V2
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS @table TABLE ( 
	ProductionTime DateTime2, 
	counter int, 
	OrderNumber varchar(255), 
	SinglePartTargetCount INT, 
	WorkingTimeInMinutes float,
	TimeToProducePartsInMinutes float, 
	TimeForProducedParts float, 
	ProcessingTime float,
	SetupTime float,
	PlannedNumberOfWorkers float,
	ShiftFactorInPercent float,
	ParallelProcessing varchar(1000),
	ProcessNumber int,
	FullCyclePartsProduced int)  

BEGIN

	declare @orders TargetOrderTypeV3;
	
	insert into @orders (OrderNumber, Operation, NumberOfParts, PlannedStartDate, Suffix)
	select OrderNumber, Operation, NumberOfParts, PlannedStartDate, Suffix from GetCVSProductionTargetFunction1V2Orders(@LineThingName, @StartTime, @EndTime);

	insert into @table (FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, PlannedNumberOfWorkers,WorkingTimeInMinutes, TimeToProducePartsInMinutes, SetupTime, ParallelProcessing, ProcessNumber) 
		select FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, PlannedNumberOfWorkers ,WorkingTimeInMinutes, TimeToProducePartsInMinutes, SetupTime, ParallelProcessing, ProcessNumber
			from dbo.GetCVSProductionTargetForOrdersFunction1V2(@LineThingName, @StartTime, @EndTime, @orders);  

	RETURN;
	
END;
GO