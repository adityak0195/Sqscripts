--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetOrderDataForFastems';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetOrderDataForFastems'))
DROP FUNCTION  GetOrderDataForFastems;
GO
CREATE FUNCTION GetOrderDataForFastems
	(@OrderNumber varchar(255),
	@Machine varchar(255),
	@XMLtype varchar(100))
RETURNS varchar(max)
BEGIN;

	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--This procedure is used for sending orders directly to KBB fastems machines. 
	--Do changes only with confirmation from :
	--Nacke, Mathias
	--Koordinator SCM BE
	--R/BEP22 Logistik BE
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************
	--********************************************************************************************************************************************************************************

	DECLARE @XML varchar(max) = '';
	Declare @operation varchar(255);
	Declare @partnumber varchar(255);
	Declare @partname varchar(max);
	Declare @quantityHeader float;
	Declare @quantityOperation float;
	Declare @quantityOperationOK float;
	Declare @quantityOperationNOK float;
	Declare @quantityOperationToProduce float;
	Declare @dueDate datetime2;
	Declare @startDate datetime2;
    declare @amountFromNewOrUpdatedOrdersSentWithLastXML integer;
    declare @amountFromOrdersNoticedWithLastXMLCreation integer;
	declare @startAmountFromNewOrUpdatedOrders integer;
	declare @endAmountFromNewOrUpdatedOrders integer;
	declare @XMLFromLastNewOrUpdateOrders varchar(max);

	DECLARE @table TABLE (OperationNumber varchar(255), machine varchar(255));

	--get all operations from SAP Order
	insert into @table (OperationNumber)
	SELECT TextValue
	  FROM smartKPIOrderKeyValueData
	  where OrderNumber = @OrderNumber
	  and PropertyKey1 = 'Operation'
	  and isnull(Operation,'') != '';

	--get related machine for all operations
	update @table set machine = TextValue 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'Line-'+OperationNumber
		COLLATE database_default;

	if (@XMLtype != 'RemovedOrders')
	BEGIN
		delete from @table where machine <> @Machine;
	END;

	select @operation=max(OperationNumber) from @table;
	
	--Get number of parts to produce priviously sent
	select top(1) @XMLFromLastNewOrUpdateOrders=TextValue, @amountFromOrdersNoticedWithLastXMLCreation=convert(integer,[FloatValue]) from [smartKPIOrderKeyValueData] 
		where PropertyKey in ('FastemsNewOrder', 'FastemsUpdateOrder')
		and OrderNumber = @OrderNumber
		and Operation = @Machine
		order by DateTimeValue desc
	
	--MaterialNumber
	select @partnumber = TextValue 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'MaterialNumber';
	
	--MaterialDescription
	select @partname = TextValue 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'MaterialDescription';
	
	--TotalOrderQuantity
	select @quantityHeader = FloatValue 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'TotalOrderQuantity';
	
	--quantityOperation
	select @quantityOperation = isnull(FloatValue,@quantityHeader) 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'Quantity-'+@operation;
	
	--OKPartsConfirmed
	select @quantityOperationOK = isnull(FloatValue,0) 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'OKPartsConfirmed-'+@operation;
	
	--NOKPartsConfirmed
	select @quantityOperationNOK = isnull(FloatValue,0) 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'NOKPartsConfirmed-'+@operation;

	select @dueDate = DateTimeValue 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'LatestScheduledStartTeardown-'+@operation;
	
	--LatestScheduledStartTeardown
	select @startDate = DateTimeValue 
		from smartKPIOrderKeyValueData
		where OrderNumber = @OrderNumber
		and PropertyKey = 'LatestScheduledStartExecution-'+@operation;
	
	--still open to produce
	set @quantityOperationToProduce = @quantityOperation-@quantityOperationOK-@quantityOperationNOK;
		
	if (select count(*) from @table)	> 0
	BEGIN

		set @XML = @XML+'<Order>';
		set @XML = @XML+'<OrderNbr>'+@OrderNumber+'</OrderNbr>';
		set @XML = @XML+'<ItemID>'+@partnumber+'</ItemID>';
		
		if (@XMLtype != 'RemovedOrders')
		BEGIN
			if (@XMLtype = 'UpdatedOrders')
			BEGIN
				--if no XML sent before use quantity from Operation
				set @XMLFromLastNewOrUpdateOrders=isnull(@XMLFromLastNewOrUpdateOrders,'<Amount>'+convert(varchar,@quantityOperation)+'</Amount>')
				--parse amount from last XML sent
				set @startAmountFromNewOrUpdatedOrders = CHARINDEX('<Amount>',@XMLFromLastNewOrUpdateOrders)+8;
				set @endAmountFromNewOrUpdatedOrders = CHARINDEX('</Amount>',@XMLFromLastNewOrUpdateOrders);
				set @amountFromNewOrUpdatedOrdersSentWithLastXML = convert(integer,substring(@XMLFromLastNewOrUpdateOrders,@startAmountFromNewOrUpdatedOrders,@endAmountFromNewOrUpdatedOrders-@startAmountFromNewOrUpdatedOrders));
				--amountFromNewOrUpdatedOrders: amount of parts which were sent with last FastemsNewOrder or UpdatedOrders
				--amountFromOrders: TotalOrderQuantity from SAP Order
				if (@amountFromOrdersNoticedWithLastXMLCreation <> @amountFromNewOrUpdatedOrdersSentWithLastXML)
				BEGIN
					set @XML = @XML+'<Amount>'+convert(varchar(255),@amountFromNewOrUpdatedOrdersSentWithLastXML)+'</Amount>';
				END
				else
				BEGIN
					set @XML = @XML+'<Amount>'+convert(varchar(255),@quantityOperation)+'</Amount>';
				END
			END
			else
			BEGIN
				--FastemsNewOrder
				--Normally the amount of parts from order but in case of this order was started on an other machine and then switched parts can be already be produced
				--@quantityOperationToProduce = @quantityOperation-@quantityOperationOK-@quantityOperationNOK
				set @XML = @XML+'<Amount>'+convert(varchar(255),@quantityOperationToProduce)+'</Amount>';
			END
				
			set @XML = @XML+'<DueDate>'+FORMAT(dbo.GetLocalTimeFromUTCTime(@dueDate), 'dd.MM.yyyy HH:mm')+'</DueDate>';
			set @XML = @XML+'<Info>'+@partname+'</Info>';
			
			if (@XMLtype != 'UpdatedOrders')
			BEGIN
				set @XML = @XML+'<OrderStatus>Planned</OrderStatus>';
			END;
			set @XML = @XML+'<EarliestStart>'+FORMAT(dbo.GetLocalTimeFromUTCTime(@startDate), 'dd.MM.yyyy HH:mm')+'</EarliestStart>';
		END
		ELSE
		BEGIN
			set @XML = @XML+'<Info>'+@partname+' -- AUFTRAG GELOESCHT!</Info>';
			set @XML = @XML+'<OrderStatus>Planned</OrderStatus>';
		END


		set @XML = @XML+'</Order>'


		if (@XMLtype != 'RemovedOrders')
		BEGIN
			set @XML = '<Orders><'+@XMLtype+'>'+@XML+'</'+@XMLtype+'></Orders>';
		END
		ELSE
		BEGIN
			-- do not sent if Soll=Istmenge
			if (@quantityOperationOK+@quantityOperationNOK>=@quantityOperation)
				set @XML = 'Order already fulfilled';
			else
				set @XML = '<Orders><UpdatedOrders>'+@XML+'</UpdatedOrders></Orders>';
		END
	end
	ELSE
	begin
		set @XML='-';
	END;
return @XML;
	
END;

GO

