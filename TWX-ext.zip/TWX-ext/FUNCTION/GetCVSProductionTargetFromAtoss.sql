--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetFromAtoss';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetFromAtoss'))
drop FUNCTION GetCVSProductionTargetFromAtoss;
GO
CREATE FUNCTION GetCVSProductionTargetFromAtoss
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS int
BEGIN

	  declare @startdate datetime2 = @StartTime;
	  declare @enddate datetime2 = @EndTime;
	  declare @Machine varchar(255) = @LineThingName;
	  declare @PerformanceIndicator float;
	  declare @ShiftFactor float;
	  declare @NextPerformanceIndicator float;
	  declare @NextShiftFactor float;
	  declare @Nextstartdate datetime2;
	  Declare @atoss CURSOR;
	  declare @Timediff int;
	  declare @PartsToProduce int = 0;



	  select top(1) @PerformanceIndicator=convert(float,replace(isnull(Message,0),',','.')) 
		from [smartKPIMachineMessageData]
		where Machine = @Machine
		and MessageType1 = 'Atoss'
		and MessageType2 = 'PerformanceIndicator'
		and MessageTime < @startdate
		order by MessageTime desc
	  select top(1) @ShiftFactor=convert(float,replace(isnull(Message,0),',','.')) 
		from [smartKPIMachineMessageData]
		where Machine = @Machine
		and MessageType1 = 'Atoss'
		and MessageType2 = 'ShiftFactor'
		and MessageTime < @startdate
		order by MessageTime desc

	  SET @atoss = CURSOR FOR select PerformanceIndicator.MessageTime, convert(float,replace(isnull(PerformanceIndicator.Message,0),',','.')) as PerformanceIndicator, convert(float,replace(isnull(ShiftFactor.Message,0),',','.')) as ShiftFactor from 
		(SELECT MessageTime, Message
		  FROM [smartKPIMachineMessageData]
		  where MessageType1 = 'Atoss'
		  and Machine = @Machine
		  and MessageType2 = 'PerformanceIndicator'
		  and MessageTime >= @startdate
		  and MessageTime < @enddate) PerformanceIndicator,
		(SELECT MessageTime, Message
		  FROM [smartKPIMachineMessageData]
		  where MessageType1 = 'Atoss'
		  and Machine = @Machine
		  and MessageType2 = 'ShiftFactor'
		  and MessageTime >= @startdate
		  and MessageTime < @enddate) ShiftFactor
		where ShiftFactor.MessageTime = PerformanceIndicator.MessageTime
		order by ShiftFactor.MessageTime;

			OPEN @atoss;
				FETCH NEXT FROM @atoss into @Nextstartdate, @NextPerformanceIndicator, @NextShiftFactor;
		
				WHILE @@FETCH_STATUS = 0
				BEGIN;

					set @Timediff = datediff(second,@startdate, @Nextstartdate);
					set @PartsToProduce = @PartsToProduce + (@PerformanceIndicator * @ShiftFactor * @Timediff / 100)

					--print ('Timeslot '+convert(varchar,@startdate)+' to ' +convert(varchar,@Nextstartdate));
					--print ('@PerformanceIndicator: '+convert(varchar,@PerformanceIndicator));
					--print ('@ShiftFactor: '+convert(varchar,@ShiftFactor));
					--print ('@Timediff: '+convert(varchar,@Timediff));
					--print ('@PartsToProduce: '+convert(varchar,@PartsToProduce/60/60));

					set @startdate = @Nextstartdate;
					set @PerformanceIndicator = @NextPerformanceIndicator;
					set @ShiftFactor = @NextShiftFactor;

					FETCH NEXT FROM @atoss into @Nextstartdate, @NextPerformanceIndicator, @NextShiftFactor;
				END;
			CLOSE @atoss;
			DEALLOCATE @atoss;

			set @Nextstartdate = @enddate;
			set @Timediff = datediff(second,@startdate, @Nextstartdate);
			set @PartsToProduce = @PartsToProduce + (@PerformanceIndicator * @ShiftFactor * @Timediff / 100)


			--print ('Timeslot '+convert(varchar,@startdate)+' to ' +convert(varchar,@Nextstartdate));
			--print ('@PerformanceIndicator: '+convert(varchar,@PerformanceIndicator));
			--print ('@ShiftFactor: '+convert(varchar,@ShiftFactor));
			--print ('@Timediff: '+convert(varchar,@Timediff));
			--print ('@PartsToProduce: '+convert(varchar,@PartsToProduce/60/60));

			return isnull(@PartsToProduce/60/60,0);
END;
go



	  --declare @StartTime datetime2 = '2022-04-26 05:30';
	  --declare @EndTime datetime2 = '2022-04-26 14:00';
	  --declare @LineThingName varchar(255) = 'KBALDDF4.1MachineThing';

	  --select dbo.GetCVSProductionTargetFromAtoss(@LineThingName, @StartTime, @EndTime)

