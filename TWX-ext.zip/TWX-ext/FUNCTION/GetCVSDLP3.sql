-- =============================================
-- Author: Martin Flassak
-- Create date: 03/2024
-- Description: GetCVSDLP3: calculates the CLP3 for CVS
-- Parameters:
-- @KbPaidHours, int - Kb Paid Hours
-- @CustomerPaidHours, int - Customer Paid Hours
--...
-- Returns: float, Value of DLP3 as % (0-100)
-- =============================================

create or alter function GetCVSDLP3
	(@KbPaidHours int
    ,@CustomerPaidHours int
    )
returns float
begin
--Check input variables for null values
    set 
        @KbPaidHours = isnull(@KbPaidHours,0);
    set 
        @CustomerPaidHours = isnull(@CustomerPaidHours,0);
        


--DECLARATIONS
	declare @dlp3result float = 0.0;


--do calculation, if denominator is zero value is set to 0
	if (@KbPaidHours > 0)
		set 
            @dlp3result = convert(float,@CustomerPaidHours)/convert(float,@KbPaidHours)*100;

--return rounded value	
	return 
        round(@dlp3result,2);
end;
go