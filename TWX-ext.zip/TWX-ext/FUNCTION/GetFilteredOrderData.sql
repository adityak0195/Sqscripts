--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetFilteredOrderData';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetFilteredOrderData'))
drop FUNCTION GetFilteredOrderData;
GO
CREATE FUNCTION [dbo].[GetFilteredOrderData]
	(@SAPWorkcenterNumber varchar (255),
	@DaysAgo int
	)
RETURNS @table TABLE ( 
	TextValue varchar(255),
	OrderNumber varchar(255),
	Operation varchar(255),
	PlantId varchar(255),
	TotalOrderQuantity int,
	OKPartsConfirmed int, 
	ToBeProduced int, 
	ScheduledStartDate datetime2,
	EarliestScheduledStartProcessing datetime2,
	LatestScheduledFinishExecution datetime2
	)  

BEGIN
    insert into @table (TextValue, OrderNumber, Operation, PlantId, TotalOrderQuantity ,OKPartsConfirmed, ToBeProduced, ScheduledStartDate,EarliestScheduledStartProcessing, LatestScheduledFinishExecution)

                       

    select top 100 o6.TextValue, o1.OrderNumber, o1.Operation, o1.PlantId, o7.FloatValue, o8.FloatValue, o7.FloatValue - o8.FloatValue as ToBeProduced, o2.DateTimeValue as ScheduledStartDate, o4.DateTimeValue as EarliestScheduledStartProcessing, o5.DateTimeValue as LatestScheduledFinishExecution
           from smartKPIOrderKeyValueData o1, smartKPIOrderKeyValueData o2, smartKPIOrderKeyValueData o3, smartKPIOrderKeyValueData o4, smartKPIOrderKeyValueData o5, smartKPIOrderKeyValueData o6, smartKPIOrderKeyValueData o7,  smartKPIOrderKeyValueData o8
           where 
		   o1.OrderNumber = o2.OrderNumber		
			and o1.PropertyKey1 = 'Line'

			and o2.PropertyKey1 = 'ScheduledStartDate' 
						and o2.DateTimeValue > DATEADD(DAY, -@DaysAgo, GETUTCDATE())
						 
						and o1.OrderNumber = o3.OrderNumber 
						and o1.Operation = o3.Operation 
						and o3.PropertyKey1 = 'Status'

						and o1.OrderNumber = o4.OrderNumber 
						and o1.Operation = o4.Operation 
                        and o4.PropertyKey = 'EarliestScheduledStartProcessing-' + o4.Operation		
						
						and o1.OrderNumber = o5.OrderNumber 
						and o1.Operation = o5.Operation 
                        and o5.PropertyKey = 'LatestScheduledFinishExecution-' + o5.Operation		
						
						and o1.OrderNumber = o6.OrderNumber 
                        and o6.PropertyKey = 'MaterialNumber' 

						and o1.OrderNumber = o7.OrderNumber 
                        and o7.PropertyKey = 'TotalOrderQuantity' 

						and o1.OrderNumber = o8.OrderNumber 
						and o1.Operation = o8.Operation 
                        and o8.PropertyKey = 'OKPartsConfirmed-' + o8.Operation	

						and CHARINDEX('I0002', o3.TextValue)> 0 
						  and o1.TextValue1 = @SAPWorkcenterNumber

ORDER BY LatestScheduledFinishExecution ASC;
	
        
    return;
	
END;

GO

