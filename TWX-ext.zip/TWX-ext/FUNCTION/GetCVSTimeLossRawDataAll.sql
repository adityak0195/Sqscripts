--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSTimeLossRawDataAll';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSTimeLossRawDataAll'))
drop FUNCTION GetCVSTimeLossRawDataAll;
GO
CREATE FUNCTION GetCVSTimeLossRawDataAll
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2, 
	@Part varchar(255))
RETURNS @table TABLE (	
	StatusTime datetime2, 
	StatusTimeStart datetime2, 
	StatusTimeEnd datetime2, 
	Duration_in_sec int,  
	DurationAveragePerOrder_in_sec int,  
	Duration_in_min float, 
	isProduction int, 
	isShift int, 
	StatusLevel1 varchar(255), 
	StatusLevel1Local Nvarchar(max), 
	StatusLevel2 varchar(255), 
	StatusLevel2Local Nvarchar(max), 
	StatusType varchar(255),
	OrderNumber varchar(255),
	PartNumber varchar(255),
	isPartOK int,
	SerialNumber varchar(255),
	ScrapReason varchar(255),					  
	tgMaxTimeInSec float,
	ProcessingTimeInSec float,
	ProcessingTimeInSecCO float,
	ProcessingTimeInSecAPO float,
	tgMaxTimeInSecTotal float,
	ProcessingTimeInSecTotal float,
	ProcessingTimeInSecCOTotal float,
	ProcessingTimeInSecAPOTotal float,
	PlannedNumberOfWorkers float,
	NumberOfParts int)
BEGIN;

	DECLARE @MainStation varchar(255);
	SELECT @MainStation=[TextValue]
		FROM [smartKPIMachineKeyValueData]
		where PropertyKey = 'MainStationForLineStatus'
		and Machine = @LineThingName;

	DECLARE @Language varchar(255);
	select @Language=[TextValue] from [smartKPIMachineKeyValueData] 
		where Machine = 'KBMesKitHelperUser' 
		and PropertyKey = 'language';
  
DECLARE @WCN varchar(255);
	select @WCN=TextValue from [smartKPIMachineKeyValueData] 
		where Machine =  @LineThingName
		and PropertyKey = 'SAPWorkcenterNumber';

if (@Part in ('All', 'Operator Screen'))
BEGIN
	insert into @table (StatusTime, StatusLevel1, StatusLevel2, StatusType)
			SELECT StatusTime1 as StatusTime,StatusLevel1,StatusLevel2,StatusType
				FROM
				(SELECT top(1) @StartTime as StatusTime1
					,[Status] as StatusLevel1
					,[SubStatus] as StatusLevel2
					,'Operator Screen' as StatusType
					FROM [smartKPIMachineStatusData]
					where Machine = convert(varchar(255), @MainStation)
					and StatusTime < @StartTime
					and StatusType = 'Operator Screen'
					order by [StatusTime] desc) x;

	insert into @table (StatusTime, StatusLevel1, StatusLevel2, StatusType)
				SELECT [StatusTime] as StatusTime
					,[Status] as StatusLevel1
					,[SubStatus] as StatusLevel2
					,'Operator Screen' as StatusType
					FROM [smartKPIMachineStatusData]
					where Machine = convert(varchar(255), @MainStation)
					and StatusTime between @StartTime and @EndTime
					and StatusType = 'Operator Screen';
END;

if (@Part in ('All', 'Shift Calendar'))
insert into @table (StatusTime, StatusLevel1, StatusLevel2, StatusType)
			SELECT [StartTime]
				,[Qualifier]
				,'start'
				,'Shift Calendar'
				FROM [shiftCalendar]
				where Machine = convert(varchar(255), @LineThingName)
				and [StartTime] between @StartTime and @EndTime;

if (@Part in ('All', 'Shift Calendar'))
insert into @table (StatusTime, StatusLevel1, StatusLevel2, StatusType)
			SELECT [EndTime]
				,[Qualifier]
				,'end'
				,'Shift Calendar'
				FROM [shiftCalendar]
				where Machine = convert(varchar(255), @LineThingName)
				and [EndTime] between @StartTime and @EndTime		;

if (@Part in ('All', 'Part', 'Part5', 'Part10'))
insert into @table (StatusTime, StatusLevel1, StatusLevel2, StatusType, OrderNumber, PartNumber, isPartOK, SerialNumber, ScrapReason, NumberOfParts)
			select ProductionTime, OrderNumber+', '+PartNumber+', '+SerialNumber, '-', 'Part', OrderNumber, PartNumber, isPartOK, SerialNumber, ScrapReason, numberOfParts from smartKPI with (NOLOCK)
				where ProductionTime between @StartTime and @EndTime
				and Machine = convert(varchar(255), @LineThingName);

if (@Part in ('Order'))
BEGIN
	insert into @table (StatusTime, StatusType, StatusLevel1, OrderNumber, PartNumber)
				select top(1) @StartTime, 'Order', OrderNumber+', '+PartNumber, OrderNumber, PartNumber from smartKPI with (NOLOCK)
					where ProductionTime < @StartTime
					and Machine = convert(varchar(255), @LineThingName)
					order by ProductionTime desc;

	insert into @table (StatusTime, StatusType, StatusLevel1, OrderNumber, PartNumber)
				select min(ProductionTime), 'Order', OrderNumber+', '+PartNumber, OrderNumber, PartNumber from smartKPI with (NOLOCK)
					where ProductionTime between @StartTime and @EndTime
					and Machine = convert(varchar(255), @LineThingName)
					and OrderNumber != (select top(1) OrderNumber from smartKPI 
					where ProductionTime < @StartTime
					and Machine = convert(varchar(255), @LineThingName)
					order by ProductionTime desc)
					group by OrderNumber, PartNumber;
END;

if (@Part in ('All', 'Operator Screen'))
insert into @table ( StatusTime, StatusLevel1, StatusLevel2, StatusType)
			SELECT  smartKPIMachineMessageData.MessageTime, [MessageType2], [Message], convert(varchar(255),[TimeLossInSec])
			FROM [smartKPIMachineMessageData], [smartKPIOperatorInputMachineDefinition]
			where [Status] = [Message] COLLATE database_default
			and [smartKPIMachineMessageData].Machine = convert(varchar(255), @MainStation)
			and ([smartKPIOperatorInputMachineDefinition].Machine = convert(varchar(255), @MainStation) or [smartKPIOperatorInputMachineDefinition].Machine = 'all')
			and MessageType1 = 'Operator Screen'
			and [MessageTime] between @StartTime and @EndTime;



update @table set isProduction = 1 where StatusLevel2 = 'KBMaschStatus.2.Productive.Start' and StatusType = 'Operator Screen';
update @table set isProduction = 0 where StatusLevel2 != 'KBMaschStatus.2.Productive.Start' and StatusType = 'Operator Screen';
update @table set isShift = 1 where StatusLevel2 = 'start' and StatusType = 'Shift Calendar' and StatusLevel1 = 'W';
update @table set isShift = 0 where StatusLevel2 = 'end' and StatusType = 'Shift Calendar' and StatusLevel1 = 'W';


update @table set StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedBreak' where StatusLevel1 = 'B' and StatusType = 'Shift Calendar';
update @table set StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedWorkingTime' where StatusLevel1 = 'W' and StatusType = 'Shift Calendar';
update @table set StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeM' where StatusLevel1 = 'M' and StatusType = 'Shift Calendar';
update @table set StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeP' where StatusLevel1 = 'P' and StatusType = 'Shift Calendar';
update @table set StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.UnplannedDowntimeD' where StatusLevel1 = 'D' and StatusType = 'Shift Calendar';

update @table set StatusLevel1Local = [TextValue] 
	from [smartKPIMachineKeyValueData] 
	where Machine = @Language
	and PropertyKey = StatusLevel1
	COLLATE database_default
	and StatusType != 'Part';


update @table set StatusLevel2Local = [TextValue] 
	from [smartKPIMachineKeyValueData] 
	where Machine = @Language
	and PropertyKey = StatusLevel2
	COLLATE database_default
	and StatusType != 'Part';
			

update @table set StatusLevel1Local = (select [TextValue] 
	from [smartKPIMachineKeyValueData] 
	where Machine = 'DefaultLanguage'
	and PropertyKey = StatusLevel1
	COLLATE database_default)
	where  StatusLevel1Local is null
	and StatusType != 'Part';

update @table set StatusLevel2Local = (select [TextValue] 
	from [smartKPIMachineKeyValueData] 
	where Machine = 'DefaultLanguage'
	and PropertyKey = StatusLevel2
	COLLATE database_default)
	where  StatusLevel2Local is null
	and StatusType != 'Part';				

update @table set StatusLevel2Local = 'Start'
	where StatusLevel2 like '%.Start'
	and StatusLevel2Local is null;

update @table set StatusLevel2Local = 'End'
	where StatusLevel2 = 'End'
	and StatusLevel2Local is null;

update @table set StatusLevel2Local = StatusLevel2
	where StatusLevel2Local is null;


if (DATEDIFF(day,@StartTime,@EndTime) <= 14)
BEGIN;

	update @table set StatusTimeStart = StatusTime;


	DECLARE @tablecursor CURSOR;
	DECLARE @StatusTimeStart datetime2;
	DECLARE @StatusType varchar(255);
	DECLARE @OrderNumber varchar(255);
	DECLARE @isProduction int;
	DECLARE @isShift int;
	DECLARE @isLastProduction int;
	DECLARE @isLastShift int;
	DECLARE @isLastProductionDate datetime2;
	DECLARE @isLastShiftDate datetime2;
	DECLARE @tgMaxTimeInSec float;

	SET @tablecursor = CURSOR FOR SELECT StatusType, StatusTime, isProduction, isShift, OrderNumber, tgMaxTimeInSec from @table order by StatusTime;

	OPEN @tablecursor;
		FETCH NEXT FROM @tablecursor into @StatusType, @StatusTimeStart, @isProduction, @isShift, @OrderNumber, @tgMaxTimeInSec 

		WHILE @@FETCH_STATUS = 0
		BEGIN;

			update @table
				set StatusTimeEnd =  (select top(1) t2.StatusTime 
					from @table as t2 
					where t2.StatusTime > @StatusTimeStart 
					and t2.StatusType = @StatusType
					order by StatusTime)
				where StatusTime = @StatusTimeStart 
					and StatusType = @StatusType
					and StatusType in ('Operator Screen');
		--START OF CHANGE 1
			--this fix provides StatusTimeEnd according to specified StatusLevel1

			update @table
					set StatusTimeEnd = (select top(1) t2.StatusTime 
					from @table as t2 
					where t2.StatusTime > @StatusTimeStart 	
					and t2.StatusType = @StatusType
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedWorkingTime'
					order by StatusTime)
				where 
				StatusTime = @StatusTimeStart 
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedWorkingTime'
					and StatusType = @StatusType
					and StatusLevel2 = 'start'
					and StatusType in ('Shift Calendar');	
						
				update @table
						set StatusTimeEnd = (select top(1) t2.StatusTime 
					from @table as t2 
					where t2.StatusTime > @StatusTimeStart 	
					and t2.StatusType = @StatusType
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeP'
					order by StatusTime)
				where 
				StatusTime = @StatusTimeStart 
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeP'
					and 
					StatusType = @StatusType
					and StatusLevel2 = 'start'
					and StatusType in ('Shift Calendar');


					update @table
						set StatusTimeEnd = (select top(1) t2.StatusTime 
					from @table as t2 
					where t2.StatusTime > @StatusTimeStart 	
					and t2.StatusType = @StatusType
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedBreak'
					order by StatusTime)
				where 
				StatusTime = @StatusTimeStart 
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedBreak'
					and 
					StatusType = @StatusType
					and StatusLevel2 = 'start'
					and StatusType in ('Shift Calendar');


			update @table
						set StatusTimeEnd = (select top(1) t2.StatusTime 
					from @table as t2 
					where t2.StatusTime > @StatusTimeStart 	
					and t2.StatusType = @StatusType
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeM'
					order by StatusTime)
				where 
				StatusTime = @StatusTimeStart 
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeM'
					and 
					StatusType = @StatusType
					and StatusLevel2 = 'start'
					and StatusType in ('Shift Calendar');

					
			update @table
						set StatusTimeEnd = (select top(1) t2.StatusTime 
					from @table as t2 
					where t2.StatusTime > @StatusTimeStart 	
					and t2.StatusType = @StatusType
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.UnplannedDowntimeD'
					order by StatusTime)
				where 
				StatusTime = @StatusTimeStart 
					and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.UnplannedDowntimeD'
					and 
					StatusType = @StatusType
					and StatusLevel2 = 'start'
					and StatusType in ('Shift Calendar');
			

			--END OF CHANGE 1, BUT SEE LATER A SECOND CHANGE					  

			update @table
				set StatusTimeEnd = StatusTime
				where StatusTime = @StatusTimeStart 
					and StatusType = @StatusType
					and StatusType in ('Part');
			update @table
				set StatusTimeStart =  (select top(1) t2.StatusTime 
					from @table as t2 
					where t2.StatusTime < @StatusTimeStart 
					and t2.StatusType = @StatusType
					order by StatusTime desc)
				where StatusTime = @StatusTimeStart 
					and StatusType = @StatusType
					and StatusType in ('Part');

			update @table set 
				tgMaxTimeInSec = ST.tgMaxTimeInSec,
				ProcessingTimeInSec = ST.ProcessingTimeInSec,
				ProcessingTimeInSecCO = ST.ProcessingTimeInSecCO,
				ProcessingTimeInSecAPO = ST.ProcessingTimeInSecAPO,
				PlannedNumberOfWorkers = ST.PlannedNumberOfWorkers,
				tgMaxTimeInSecTotal = ST.tgMaxTimeInSec * NumberOfParts,
				ProcessingTimeInSecTotal = ST.ProcessingTimeInSec * NumberOfParts,
				ProcessingTimeInSecCOTotal = ST.ProcessingTimeInSecCO * NumberOfParts,
				ProcessingTimeInSecAPOTotal = ST.ProcessingTimeInSecAPO * NumberOfParts
			from GetSAPTimePerPart(@OrderNumber) as ST
			where OrderNumber = @OrderNumber
			and @tgMaxTimeInSec is null
			and SAPMachine=@WCN		  
			and StatusType in ('Part');

			update @table set isProduction = 1
				where StatusTime < @StatusTimeStart
				and isProduction is NULL
				and @isProduction = 0;

			update @table set isProduction = 0
				where StatusTime < @StatusTimeStart
				and isProduction is NULL
				and @isProduction = 1;

			update @table set isShift = 1
				where StatusTime < @StatusTimeStart
				and isShift is NULL
				and @isShift = 0;

			update @table set isShift = 0
				where StatusTime < @StatusTimeStart
				and isShift is NULL
				and @isShift = 1;

			if (@isShift is not null)
			BEGIN
				set @isLastShift = @isShift;
				set @isLastShiftDate = @StatusTimeStart;
			END;

			if (@isProduction is not null)
			BEGIN
				set @isLastProduction = @isProduction;
				set @isLastProductionDate = @StatusTimeStart;
			END;

			FETCH NEXT FROM @tablecursor into @StatusType, @StatusTimeStart, @isProduction, @isShift, @OrderNumber, @tgMaxTimeInSec
		END;
	CLOSE @tablecursor;
	DEALLOCATE @tablecursor;

	update @table set isShift = @isLastShift
		where StatusTime >= @isLastShiftDate
		and isShift is NULL;

	update @table set isProduction = @isLastProduction
		where StatusTime >= @isLastProductionDate
		and isProduction is NULL;


	update @table set StatusTimeStart = (select max(ProductionTime) from smartKPI where ProductionTime < @StartTime and Machine = convert(varchar(255), @LineThingName)) where StatusTimeStart is null and StatusType in ('Part');
	update @table set StatusTimeEnd = @EndTime where StatusTimeEnd is null and StatusType in ('Operator Screen', 'Shift Calendar', 'Part');
	update @table set StatusTimeEnd = dateadd(second, convert(int, StatusType), StatusTimeStart) where StatusTimeEnd is null and StatusType not in ('Operator Screen', 'Shift Calendar', 'Part', 'Order');

	--SECOND CHANGE: start
	--fix in case of the same StartTime Planned for P and W
	update @table set StatusTimeStart = (
		select top(1) StatusTimeEnd from @table
		where StatusType = 'Shift Calendar' 
		and StatusLevel2 = 'start' 
		and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeP'
		) 
		where StatusType = 'Shift Calendar' 
		and StatusLevel2 = 'start' 
		and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedWorkingTime' 
		and StatusTimeStart = (select top(1) StatusTimeStart from @table 
		where StatusType = 'Shift Calendar' 
		and StatusLevel1 = 'KBLocalSmartKPITimeLossesMashup.PlannedDowntimeP'
		and StatusLevel2 = 'start')

	--SECOND CHANGE: end		 
	update @table set Duration_in_sec = DATEDIFF(second, StatusTimeStart, StatusTimeEnd);
	update @table set Duration_in_min = CAST(CAST(Duration_in_sec as float )/60 as numeric(9,2));

	if (@Part = 'Part5')
		delete from @table 
			where StatusType = 'Part'
			and Duration_in_sec > ProcessingTimeInSecAPOTotal * 5;

	if (@Part = 'Part10')
		delete from @table 
			where StatusType = 'Part'
			and Duration_in_sec > ProcessingTimeInSecAPOTotal * 10;


	SET @tablecursor = CURSOR FOR SELECT OrderNumber from @table;

	OPEN @tablecursor;
		FETCH NEXT FROM @tablecursor into @OrderNumber 

		WHILE @@FETCH_STATUS = 0
		BEGIN;

			update @table
				set DurationAveragePerOrder_in_sec =  (select AVG(t2.Duration_in_sec) 
					from @table as t2 
					where t2.OrderNumber =  @OrderNumber
					and t2.StatusType = 'Part')
				where OrderNumber =  @OrderNumber
					and StatusType = 'Part';

			FETCH NEXT FROM @tablecursor into @OrderNumber
		END;
	CLOSE @tablecursor;
	DEALLOCATE @tablecursor;


END;



return;
	
END;

GO

