
--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetUTCTimeFromLocalTime';
--------------------------------------------------------------
--------------------------------------------------------------


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetUTCTimeFromLocalTime'))
drop FUNCTION GetUTCTimeFromLocalTime;
GO
CREATE FUNCTION GetUTCTimeFromLocalTime
	(@dateTime DateTime2)
RETURNS datetime2
BEGIN
	declare @timezone varchar(255);
	select top(1) @timezone=timezone from 
		(SELECT isnull([TextValue],'Central European Standard Time') as timezone, 1 as id
			FROM [smartKPIMachineKeyValueData]
		where Machine = 'KBTimeHelperThing'
		and PropertyKey = 'ServerTimeZoneDB'
		union select 'Central European Standard Time',2)x
	order by id;
	
	return dateadd(minute,DATEDIFF(minute, @dateTime AT TIME ZONE 'UTC', @dateTime AT TIME ZONE @timezone),@dateTime);
END;
go