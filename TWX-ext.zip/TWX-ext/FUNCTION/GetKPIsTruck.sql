--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetKPIsTruck';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetKPIsTruck'))
drop FUNCTION GetKPIsTruck;
GO
CREATE FUNCTION GetKPIsTruck
	(@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@machine varchar(255))
RETURNS @table TABLE ( 
	Machine varchar(255), 
	KPIName varchar(255), 
	KPICalculationBase varchar(255), 
	KPIDateTime DateTime2,  
	KPIDateTimeEndOfCalculation DateTime2,
	KPIFloatValue float)  
BEGIN;
	insert into @table (Machine, 
	KPIName, 
	KPICalculationBase, 
	KPIDateTime,  
	KPIDateTimeEndOfCalculation,
	KPIFloatValue) select Machine, 
	KPIName, 
	KPICalculationBase, 
	KPIDateTime,  
	KPIDateTimeEnd,
	KPIFloatValue from smartKPIValues
	where Machine = @machine
	and KPIDateTime between dateadd(minute,-1, @StartDateTime) and dateadd(minute,1,@StartDateTime)
	and KPIDateTimeEnd between dateadd(minute,-1, @EndDateTime) and dateadd(minute,1,@EndDateTime)
	and KPICalculationBase = 'GetKPIsTruckWorker';
/*
	if (select count(*) from @table) = 0
		insert into @table (Machine, 
		KPIName, 
		KPICalculationBase, 
		KPIDateTime,  
		KPIDateTimeEndOfCalculation,
		KPIFloatValue) select Machine, 
		KPIName, 
		KPICalculationBase, 
		KPIDateTime,  
		KPIDateTimeEndOfCalculation,
		KPIFloatValue from GetKPIsTruckWorker(@StartDateTime,
		@EndDateTime,
		@machine);
*/
return;
END;
GO

--declare @dt1 as DateTime2 = datetimefromparts(2019,7,2,0,0,0,0);
--declare @dt2 as DateTime2 = datetimefromparts(2019,7,2,12,0,0,0);
--select * from dbo.GetKPIsTruck(@dt1,@dt2, 'KBLisLaa6MachineThing');
