--------------------------------------------------------------
--------------------------------------------------------------
print '-- split_string';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'split_string'))
drop FUNCTION split_string;
GO
CREATE FUNCTION split_string
(
    @string_value NVARCHAR(MAX),
    @delimiter_character CHAR(1)
)
RETURNS @result_set TABLE(splited_data NVARCHAR(MAX),place INT
)
BEGIN
    DECLARE @start_position INT,
            @ending_position INT,
			@position INT
    SELECT @start_position = 1,@position=1,
            @ending_position = CHARINDEX(@delimiter_character, @string_value)
    WHILE @start_position < LEN(@string_value) + 1
            BEGIN
        IF @ending_position = 0 
           SET @ending_position = LEN(@string_value) + 1
        INSERT INTO @result_set (splited_data, place) 
		VALUES(SUBSTRING(@string_value, @start_position, @ending_position - @start_position), @position)
        SET @position=@position+1
		SET @start_position = @ending_position + 1
        SET @ending_position = CHARINDEX(@delimiter_character, @string_value, @start_position)
    END
    RETURN
END

go