--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSUsersLoginListAtLine';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSUsersLoginListAtLine'))
drop FUNCTION GetCVSUsersLoginListAtLine;
GO
CREATE FUNCTION [GetCVSUsersLoginListAtLine]
	(@StartDate DateTime2,
	@EndDate DateTime2,
	@Station varchar(255))
RETURNS @table table 
			(isLoggedIn Bit,
			userId varchar(255),
			LastLogin datetime2,
			LastLogout datetime2,
			LoginTimeMillis bigint)
BEGIN;

	DECLARE @LastReset datetime2;
	DECLARE @LastLogout datetime2;
	DECLARE @MessageTime datetime2;
	DECLARE @Message varchar(255);
	DECLARE @LoginMessages cursor;
	DECLARE @LoginStatus bit;
	
	select @LastReset=isnull(max([MessageTime]),'1970-01-01'),@LastLogout=isnull(max([MessageTime]),'1970-01-01')
		from [smartKPIMachineMessageData]
		where MessageType1 = 'STAFF'
		and MessageType2 = 'Operator Logout'
		and Machine = @Station
		and Message = 'Logout'
		and MessageTime <= @StartDate;	  
	
	SET @LoginMessages = CURSOR for 
	SELECT [Message], MessageTime
	  FROM [smartKPIMachineMessageData]
	  where MessageType1 = 'STAFF'
	  and Machine = @Station
	  and MessageTime > @LastReset
	  and MessageTime < @EndDate
	  order by MessageTime;

	OPEN @LoginMessages;
		FETCH NEXT FROM @LoginMessages into @Message, @MessageTime
		WHILE @@FETCH_STATUS = 0
		BEGIN;
			if (@Message = 'Logout')
			BEGIN
				update @table set 
					isLoggedIn = 0,
					LoginTimeMillis = LoginTimeMillis + datediff_big(ms, LastLogin, @MessageTime)
				where isLoggedIn = 1;
			END;
			ELSE
			BEGIN
		
				insert into @table (isLoggedIn, userId, LastLogout, LoginTimeMillis)
					select 0,@Message, @LastLogout, 0 where not exists (select 'ok' from @table where userId = @Message);
					
				select @LoginStatus = 1 - isLoggedIn from @table where userId = @Message;
					
				update @table set 
					isLoggedIn = @LoginStatus
				where userId = @Message;

				update @table set 
					LastLogin = @StartDate
				where userId = @Message
				and @MessageTime <= @StartDate
				and @LoginStatus = 1;

				update @table set 
					LastLogin = @MessageTime
				where userId = @Message
				and @MessageTime > @StartDate
				and @LoginStatus = 1;

				update @table set 
					LoginTimeMillis = LoginTimeMillis + datediff_big(ms, LastLogin, @MessageTime),
					LastLogout = @MessageTime
				where userId = @Message
				and @LoginStatus = 0
				and @MessageTime > @StartDate;
			END;
			FETCH NEXT FROM @LoginMessages into @Message, @MessageTime;
		END;
	CLOSE @LoginMessages;
	DEALLOCATE @LoginMessages;

	update @table set 
		LoginTimeMillis = LoginTimeMillis + datediff_big(ms, LastLogin, @EndDate)
	where isLoggedIn = 1;
	
	return;

END;
GO
