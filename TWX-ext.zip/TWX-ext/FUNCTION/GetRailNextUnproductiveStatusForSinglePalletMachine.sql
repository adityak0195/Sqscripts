--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetRailNextUnproductiveStatusForSinglePalletMachine';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetRailNextUnproductiveStatusForSinglePalletMachine'))
drop FUNCTION GetRailNextUnproductiveStatusForSinglePalletMachine;
GO
CREATE FUNCTION GetRailNextUnproductiveStatusForSinglePalletMachine
(@station varchar(255))
returns varchar(255)
BEGIN

DECLARE @LastProductionTime datetime2;
DECLARE @getKPIs cursor;
DECLARE @StatusTime datetime2;
DECLARE @SubStatus varchar(255);
DECLARE @TriggerState varchar(255) = 'ON';
DECLARE @counter int = 0;
DECLARE @result varchar(255) = '-';

SELECT TOP (1) @LastProductionTime=[ProductionTime]
		  FROM [smartKPI]
		  where Station = @station
		  order by ProductionTime desc;

SET @getKPIs = CURSOR FOR select StatusTime, SubStatus from [smartKPIMachineStatusData]
  where Status = 'NC_PROGRAM_RUNNING'
  and Machine = @station
  and StatusTime >= @LastProductionTime
  order by StatusTime;


	OPEN @getKPIs;
		FETCH NEXT FROM @getKPIs into @StatusTime, @SubStatus;
		WHILE @@FETCH_STATUS = 0
		BEGIN;

			if (@SubStatus = 'OFF')
				set @counter = @counter + 1;
			if (@TriggerState <> @SubStatus and @TriggerState = 'ON')
			BEGIN
				set @TriggerState = @SubStatus;
				if (@counter = 1)
					set @result = 'KBMaschStatus.1.PieceChange';
				else
					set @result = 'KBMaschStatus.1.OI.AutoSet';
			END;

			if   'ok' = (select 'ok' from [smartKPIMachineStatusData] 
							where description = 'OIV2' 
							and StatusType = 'Operator Screen' 
							and Status in ('KBMaschStatus.1.PieceChange', 'KBMaschStatus.1.OI.AutoSet')
							and StatusTime = @StatusTime
							and Machine = @station)
					set @result = '-';

			if (@SubStatus = 'ON')
				set @TriggerState = @SubStatus;

		FETCH NEXT FROM @getKPIs into @StatusTime, @SubStatus;
		END;
	CLOSE @getKPIs;
	DEALLOCATE @getKPIs;

	return @result;

end;
go
