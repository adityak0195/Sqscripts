--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_GetLastShiftToCalculateKPIs';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_GetLastShiftToCalculateKPIs'))
drop FUNCTION KPI_CALCULATOR_GetLastShiftToCalculateKPIs;
GO
CREATE FUNCTION KPI_CALCULATOR_GetLastShiftToCalculateKPIs(@machine varchar(255), @referenceTime datetime2)
RETURNS @table TABLE (	
	machine varchar(255), 
	shiftName varchar(255), 
	startTime datetime2, 
	endTime datetime2 
	)
BEGIN;
	insert into @table (		
		machine,
        shiftName,
        startTime,
        endTime
		)
    select top (1) Machine, CurrentName, CurrentStartTime, CurrentEndTime 
        from TEMP_SmartKPIFullShift
        where Machine = @machine
        and CurrentEndTime < @referenceTime                
        order by CurrentStartTime desc;
    
return ;
	
END;

GO


