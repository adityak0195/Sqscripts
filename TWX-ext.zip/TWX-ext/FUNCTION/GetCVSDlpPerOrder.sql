--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSDlpPerOrder';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlpPerOrder'))
drop FUNCTION GetCVSDlpPerOrder;
GO
CREATE FUNCTION GetCVSDlpPerOrder
	(@StartDate DateTime2,
	@EndDate DateTime2,
	@machine varchar(255))
RETURNS @table TABLE (
	OrderNumber varchar(255),
	PartNumber varchar(255),
	NumberOfParts int,
	StartDate datetime2,
	EndDate datetime2,
	ProcessingTimeInSecCO float,
	WorkingTimeInSeconds float,
	Dlp3CustomerPaidHours float,
	Dlp3KBPaidHours float,
	Dlp3 float,
	LoginTimeAtLine float,
	Dlp1Target float,
	Dlp1Actual float,
	Dlp1 float)
BEGIN;


	insert into @table (
			OrderNumber, 
			PartNumber, 
			NumberOfParts, 
			ProcessingTimeInSecCO, 
			WorkingTimeInSeconds,
			StartDate,
			EndDate)
	select 	OrderNumber, 
			PartNumber, 
			round(sum(NumberOfParts),2), 
			round(sum(ProcessingTimeInSecCO),2), 
			round(sum(WorkingTimeInSeconds),2),
			min(ProductionTimeStart),
			max(ProductionTimeEnd)
		from GetCVSDlpRawDataExtended(@StartDate, @EndDate, @machine)
		group by OrderNumber, PartNumber;
		
	DECLARE @MainStation varchar(255);
	SELECT @MainStation=[TextValue]
		FROM [smartKPIMachineKeyValueData]
		where PropertyKey = 'MainStationForLineStatus'
		and Machine = @machine;
	
	DECLARE @StartDateCursor DateTime2;
	DECLARE @EndDateCursor DateTime2;
	DECLARE @tablecursor CURSOR;
	DECLARE @dlpTable TABLE (ValueName varchar(255), FloatValue float);
	
	SET @tablecursor = CURSOR FOR SELECT StartDate, EndDate from @table;

	OPEN @tablecursor;
		FETCH NEXT FROM @tablecursor into @StartDateCursor, @EndDateCursor

		WHILE @@FETCH_STATUS = 0
		BEGIN;
			delete from @dlpTable;
			insert into @dlpTable (ValueName, FloatValue)
				select KPIName, KPIFloatValue from dbo.GetKPIsTruckWorker(@StartDateCursor, @EndDateCursor, @machine)

			update @table set Dlp1Target = round(FloatValue,2) from @dlpTable where ValueName = 'CVS DLP1: Calculated Target' and StartDate = @StartDateCursor and EndDate = @EndDateCursor;
			update @table set Dlp1Actual = round(FloatValue,2) from @dlpTable where ValueName = 'CVS DLP1: Actual' and StartDate = @StartDateCursor and EndDate = @EndDateCursor;
			update @table set Dlp1 = round(FloatValue,2) from @dlpTable where ValueName = 'CVS DLP1: Ratio (Actual/Calculated Target)' and StartDate = @StartDateCursor and EndDate = @EndDateCursor;
			
			update @table set Dlp3CustomerPaidHours = round(FloatValue,2) from @dlpTable where ValueName = 'CVS DLP3: Customer paid hours' and StartDate = @StartDateCursor and EndDate = @EndDateCursor;
			update @table set Dlp3KBPaidHours = round(FloatValue,2) from @dlpTable where ValueName = 'CVS DLP3: KB paid hours' and StartDate = @StartDateCursor and EndDate = @EndDateCursor;
			update @table set Dlp3 = round(FloatValue,2) from @dlpTable where ValueName = 'CVS DLP3: Ratio (Customer paid hours/KB paid hours)' and StartDate = @StartDateCursor and EndDate = @EndDateCursor;
			update @table set LoginTimeAtLine = round(FloatValue,2) from @dlpTable where ValueName = 'CVS: Sum of login times at line' and StartDate = @StartDateCursor and EndDate = @EndDateCursor;

			FETCH NEXT FROM @tablecursor into @StartDateCursor, @EndDateCursor
		END;
	CLOSE @tablecursor;
	DEALLOCATE @tablecursor;
	
		

	return;
END;
GO

--select * from dbo.GetCVSDlpPerOrder('2019-11-01 00:00:00', '2019-11-05 00:00:00', 'KBLisLaa6MachineThing')
