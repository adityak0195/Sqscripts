--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetForOrdersFunction1V2ForMachining';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetForOrdersFunction1V2ForMachining'))
drop FUNCTION GetCVSProductionTargetForOrdersFunction1V2ForMachining;
GO
CREATE FUNCTION GetCVSProductionTargetForOrdersFunction1V2ForMachining
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2,
	@orders TargetOrderTypeV3 READONLY)
RETURNS @table TABLE ( 
	ProductionTime DateTime2, 
	counter int, 
	OrderNumber varchar(255), 
	SinglePartTargetCount INT, 
	WorkingTimeInMinutes float,
	TimeToProducePartsInMinutes float, 
	TimeForProducedParts float, 
	ProcessingTime float,
	SetupTime float,
	PlannedNumberOfWorkers float,
	ShiftFactorInPercent float,
	ParallelProcessing varchar(1000),
	ProcessNumber int,
	FullCyclePartsProduced int)  

BEGIN

	declare @op1 varchar(255);
	declare @op2 varchar(255);
	declare @date1 datetime2;
	Declare @getOrders CURSOR;
	Declare @getProcesses CURSOR;
	declare @TimeForProducedPartsInSeconds float = 0.0;
	declare @OrderOutputSuffix varchar(200);
	declare @ShiftFactorInPercent float;
	declare @SAPMachine varchar(255);
	declare @CurrentDate datetime2 = @StartTime;
	Declare @ProcessingTime float;
	Declare @SetupTime float = 0.0;
	declare @PlannedNumberOfWorkersCO float;
	Declare @OrderNumber varchar(255);
	Declare @LastOrderNumber varchar(255) = '';
	Declare @TimeCompletlyFilled Bit = 0;
	DECLARE @SinglePartTargetCount INT = 0;
	DECLARE @SinglePartOrderTargetCount INT = 0;
	Declare @OrderTime DateTime2;
	Declare @NumberOfPartsToProduce int;
	Declare @NumberOfProducedParts int;
	declare @dateWorkStart datetime2;
	declare @dateWorkEnd datetime2;
	declare @WorkIdentifier int;
	declare @dateBreakStart datetime2;
	declare @dateBreakEnd datetime2;
	declare @BreakIdentifier int;
	DECLARE @PartTargetCount INT = 0;
	DECLARE @LastPartProduced datetime2;
	DECLARE @PP_OrderNumber  varchar(255);
	DECLARE @PP_Operation varchar(255); 
	DECLARE @PP_ProcessNumber int;
	DECLARE @ParallelProcessing table 
		(PP_OrderNumber  varchar(255), 
		PP_Operation varchar(255), 
		PP_PartNumber varchar(255), 
		PP_ProcessNumber int, 
		PP_Target int, 
		PP_Actual int,
		PP_ProcessingTime float,
		PP_SetupTime float,
		PP_PlannedNumberOfWorkersCO float,
		PP_PartsPerCycle int,
		PP_SinglePartOrderTargetCount int
	);
	DECLARE @NumberOfParallelProcesses int = 1;
	DECLARE @Operation varchar(255);
	DECLARE @ParallelProcessingLog varchar(1000) = 'fixed';
	DECLARE @shiftCalendar table (StartTime datetime2, EndTime datetime2, Qualifier varchar(10), Utilization float);
	DECLARE @RunningProcess int = 1;
	DECLARE @OrderChange bit = 0;
	DECLARE @PartsPerCycle int;
	declare @counter int;
	Declare @OrderNumber1 varchar(255);
	Declare @Operation1 varchar(255);
	DECLARE @jsonstring varchar(max);
	DECLARE @setupType varchar(255);
	DECLARE @MainStation varchar(255);
	DECLARE @PartNumber varchar(255);
	DECLARE @FullCyclePartsProduced int;
	DECLARE @distinctOperations int;

	SELECT @MainStation=[TextValue]
		FROM [smartKPIMachineKeyValueData]
		where PropertyKey = 'MainStationForLineStatus'
		and Machine = @LineThingName;

	SELECT @NumberOfParallelProcesses=[FloatValue]
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @LineThingName
	  and PropertyKey = 'NumberOfParallelProcessesForMultiPalletMachine';



	-- Get SAP Workcenter number
	SELECT @SAPMachine=[TextValue]
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @LineThingName
	  and PropertyKey = 'SAPWorkcenterNumber';

	-- Get related part of shift calendar to reduce selections to shiftCalendar table
	insert into @shiftCalendar (StartTime, EndTime, Qualifier, Utilization)
		select StartTime, EndTime, Qualifier, Utilization
		from shiftCalendar
		where Machine = @SAPMachine
		and (StartTime >= @StartTime and EndTime <= @EndTime
			or StartTime <= @StartTime and EndTime >= @StartTime
			or StartTime <= @EndTime and EndTime >= @EndTime
			or StartTime <= @StartTime and EndTime >= @EndTime);

	--Prepare processes
	select top(1)
		@OrderTime=PlannedStartDate
	from @orders
	order by Suffix, PlannedStartDate;

	--Get order/operation currently running on machine (OGS data)
	select top(1) @jsonstring = [Message], @setupType = [MessageType2]
		from [smartKPIMachineMessageData]
		where Machine = @MainStation
		and MessageType1 = 'OGSMessage'
		and MessageTime < @OrderTime
		order by MessageTime desc;

	insert into @ParallelProcessing (PP_OrderNumber, PP_Operation, PP_PartNumber, PP_ProcessNumber, PP_Target, PP_Actual, PP_ProcessingTime,	PP_SetupTime, PP_PlannedNumberOfWorkersCO, PP_SinglePartOrderTargetCount, PP_PartsPerCycle)
		select jsondata.AssignedOrder, 
			jsondata.AssignedOperation,
			jsondata.PartNumber,
			1,
			0, 
			0, 
			0,
			0,
			0,
			0,
			jsondata.FixtureCavityQTY
			from OPENJSON(@jsonstring, N'$.rows')
				WITH(
					AssignedOrder varchar(255) N'$.AssignedOrder',
					PartNumber varchar(255) N'$.PartNumber',
					CurrentWorkplace varchar(255) N'$.CurrentWorkplace',
					Workplace varchar(255) N'$.Workplace',
					AssignedOperation varchar(255) N'$.AssignedOperation',
					FixtureCavityQTY int N'$.FixtureCavityQTY'
				) as jsondata
		where jsondata.Workplace = jsondata.CurrentWorkplace;
	insert into @ParallelProcessing (PP_OrderNumber, PP_Operation, PP_PartNumber, PP_ProcessNumber, PP_Target, PP_Actual, PP_ProcessingTime,	PP_SetupTime, PP_PlannedNumberOfWorkersCO, PP_SinglePartOrderTargetCount, PP_PartsPerCycle)
		select jsondata.AssignedOrder, 
			jsondata.AssignedOperation,
			jsondata.PartNumber,
			2,
			0, 
			0, 
			0,
			0,
			0,
			0,
			jsondata.FixtureCavityQTY
			from OPENJSON(@jsonstring, N'$.rows')
				WITH(
					AssignedOrder varchar(255) N'$.AssignedOrder',
					PartNumber varchar(255) N'$.PartNumber',
					CurrentWorkplace varchar(255) N'$.CurrentWorkplace',
					Workplace varchar(255) N'$.Workplace',
					AssignedOperation varchar(255) N'$.AssignedOperation',
					FixtureCavityQTY int N'$.FixtureCavityQTY'
				) as jsondata
		where jsondata.Workplace != jsondata.CurrentWorkplace;

	--Get order/operation which were produced last before current time slot to see if order change has to be calculated before first piece
	if (select count(*) from @ParallelProcessing) = 0
	BEGIN
		set @setupType = '-';
		insert into @ParallelProcessing (PP_OrderNumber, PP_Operation, PP_ProcessNumber, PP_Target, PP_Actual, PP_ProcessingTime,	PP_SetupTime, PP_PlannedNumberOfWorkersCO, PP_SinglePartOrderTargetCount)
		select top(@NumberOfParallelProcesses) 
			isnull(REPLACE([OrderNumber], ' ', ''),''), 
			isnull(REPLACE([SAPOperationNumber], ' ', ''),''), 
			ROW_NUMBER() OVER(order by ProductionTime desc), 
			0, 
			0, 
			0,
			0,
			0,
			0
			from smartKPI
			where Machine = @LineThingName
			and isPartOK = 1
			and ProductionTime < @OrderTime
			order by ProductionTime desc;
	END;

	Update @ParallelProcessing 
		set PP_Actual= (select sum(numberOfParts) 
		from smartKPI
		where PP_OrderNumber = OrderNumber
		COLLATE database_default
		and PP_Operation = SAPOperationNumber
		COLLATE database_default
		and Machine = @LineThingName);
	
	select @distinctOperations = count(distinct PP_Operation) from @ParallelProcessing;

	update @ParallelProcessing set PP_ProcessNumber = @NumberOfParallelProcesses + 1 - PP_ProcessNumber;
		
		
	SET @getProcesses = CURSOR FOR 
		select 
			PP_ProcessNumber, PP_OrderNumber, PP_Operation 
		from @ParallelProcessing;

	--Loop over parts to be produced
	OPEN @getProcesses;
		FETCH NEXT FROM @getProcesses into @counter, @OrderNumber1, @Operation1
		WHILE @@FETCH_STATUS = 0
		BEGIN;
			select @SetupTime = CASE TextValue
											WHEN 'SEC' THEN [FloatValue] / 60
											WHEN 'MIN' THEN [FloatValue] 
											WHEN 'DAY' THEN [FloatValue] * 24 * 60
											ELSE 0		 
										END 
					  FROM [smartKPIOrderKeyValueData]
					  where OrderNumber = @OrderNumber1
					  and Operation = @Operation1
					  and PropertyKey1 = 'SetupTimeCO'
					  COLLATE database_default; 		
			
			
			select @ProcessingTime = CASE TextValue
											WHEN 'SEC' THEN [FloatValue] / 60
											WHEN 'MIN' THEN [FloatValue] 
											WHEN 'DAY' THEN [FloatValue] * 24 * 60
											ELSE 0		 
										END 
					  FROM [smartKPIOrderKeyValueData]
					  where OrderNumber = @OrderNumber1
					  and Operation = @Operation1
					  and PropertyKey1 = 'ProcessingTimeCO'
					  COLLATE database_default; 		
			
			
			select @PlannedNumberOfWorkersCO = FloatValue
					  FROM [smartKPIOrderKeyValueData]
					  where OrderNumber = @OrderNumber1
					  and Operation = @Operation1
					  and PropertyKey1 = 'PlannedNumberOfWorkers'
					  COLLATE database_default; 	


			update @ParallelProcessing 
				set PP_ProcessingTime = @ProcessingTime,
				PP_SetupTime = @SetupTime,
				PP_PlannedNumberOfWorkersCO = @PlannedNumberOfWorkersCO
				where PP_OrderNumber = @OrderNumber1
				and PP_Operation = @Operation1;

			set @PartsPerCycle = 1;
			
			--get Part number and parts per cycle if no OGS data found (with OGS this data is already available)
			if @setupType = '-'
			BEGIN
				select @PartNumber=TextValue from smartKPIOrderKeyValueData
						where OrderNumber = @OrderNumber1
						and PropertyKey = 'MaterialNumber';
				

				update @ParallelProcessing set PP_PartNumber = @PartNumber 
						where PP_ProcessNumber = @counter;
				
				select @PartsPerCycle=isnull(ROUND(avg(numberOfParts),0),1) from smartKPI 
					where Machine = @LineThingName
					and PartNumber = @PartNumber
					and SAPOperationNumber = @Operation1
					and isPartOK = 1
					and numberOfParts > 1;

				if @PartsPerCycle = 1
					select @PartsPerCycle=isnull(ROUND(avg(numberOfParts),0),1) from smartKPI 
						where Machine = @LineThingName
						and PartNumber = @PartNumber
						and isPartOK = 1
						and numberOfParts > 1;

				update @ParallelProcessing set PP_PartsPerCycle = @PartsPerCycle where PP_ProcessNumber = @counter;
			END;
		
			FETCH NEXT FROM @getProcesses into @counter, @OrderNumber1, @Operation1
		END;
	CLOSE @getProcesses;
	DEALLOCATE @getProcesses;

	select @ProcessingTime=PP_ProcessingTime, 
			@PlannedNumberOfWorkersCO=PP_PlannedNumberOfWorkersCO,  
			@SetupTime = PP_SetupTime,
			@PartsPerCycle = PP_PartsPerCycle,
			@PartNumber = PP_PartNumber
		from @ParallelProcessing
		where PP_ProcessNumber = @RunningProcess;



	if @setupType = 'A1/A2'
	BEGIN
		select top(1) @op1=Operation, @date1=PlannedStartDate from @orders where Suffix = '(1: already produced)' order by PlannedStartDate desc;
		select top(1) @op2=Operation from @orders where PlannedStartDate<@date1 and Suffix = '(1: already produced)' order by PlannedStartDate desc;
	END;



	--define cursor for part production
	SET @getOrders = CURSOR FOR 
		select 
			PlannedStartDate,
			NumberOfParts, 
			OrderNumber,
			Operation,
			Suffix 
		from @orders
		order by Suffix, PlannedStartDate;
		
		
	if @setupType = 'A1/A2' 
			and (select 'change' from
			(select PP_Operation from @ParallelProcessing where PP_ProcessNumber = 1) op1,
			(select PP_Operation from @ParallelProcessing where PP_ProcessNumber = 2) op2
			where op1.PP_Operation > op2.PP_Operation) = 'change'
		BEGIN
			update @ParallelProcessing set PP_ProcessNumber = @NumberOfParallelProcesses + 1 - PP_ProcessNumber;
			select @ProcessingTime=PP_ProcessingTime, 
					@PlannedNumberOfWorkersCO=PP_PlannedNumberOfWorkersCO,  
					@SetupTime = PP_SetupTime,
					@PartsPerCycle = PP_PartsPerCycle,
					@PartNumber = PP_PartNumber
				from @ParallelProcessing
				where PP_ProcessNumber = @RunningProcess;			
		END											


	--Loop over parts to be produced
	OPEN @getOrders;
		FETCH NEXT FROM @getOrders into @OrderTime, @NumberOfPartsToProduce, @OrderNumber, @Operation, @OrderOutputSuffix
		WHILE @@FETCH_STATUS = 0
		BEGIN
		
			if @setupType = 'A1/A2' and @op2 > @op1 and @OrderTime=@date1 and @OrderOutputSuffix = '(1: already produced)'
			BEGIN
				set @OrderOutputSuffix = 'Skip...';
			END;
			ELSE
			BEGIN
				if (select count(*) from @ParallelProcessing where PP_ProcessNumber != @RunningProcess) > 1
				BEGIN
					break;
				END;

				if @PartTargetCount = 0 and (select PP_OrderNumber+PP_Operation from @ParallelProcessing where PP_ProcessNumber != @RunningProcess) = @OrderNumber+@Operation
				BEGIN
					update @ParallelProcessing set PP_ProcessNumber = @NumberOfParallelProcesses + 1 - PP_ProcessNumber;

					select @ProcessingTime=PP_ProcessingTime, 
							@PlannedNumberOfWorkersCO=PP_PlannedNumberOfWorkersCO,  
							@SetupTime = PP_SetupTime,
							@PartsPerCycle = PP_PartsPerCycle,
							@PartNumber = PP_PartNumber
						from @ParallelProcessing
						where PP_ProcessNumber = @RunningProcess;				
				END											
				
				set @OrderChange = 0;
				--is new part/Operation?
				if (select PP_OrderNumber+PP_Operation from @ParallelProcessing where PP_ProcessNumber = @RunningProcess) != @OrderNumber+@Operation
				BEGIN
					--Order Change!
					select @PartNumber=TextValue from smartKPIOrderKeyValueData
							where OrderNumber = @OrderNumber
							and PropertyKey = 'MaterialNumber';
					
					select top(1) @setupType = [MessageType2]
						from [smartKPIMachineMessageData]
						where Machine = @MainStation
						and MessageType1 = 'OGSMessage'
						and MessageTime <= @OrderTime
						order by MessageTime desc;

					if (select PP_PartNumber from @ParallelProcessing where PP_ProcessNumber = @RunningProcess) != @PartNumber
					BEGIN
						set @PartsPerCycle = 1;
						select @PartsPerCycle=isnull(ROUND(avg(numberOfParts),0),1) from smartKPI 
							where Machine = @LineThingName
							and PartNumber = @PartNumber
							and SAPOperationNumber = @Operation
							and isPartOK = 1
							and numberOfParts > 1;
								
						if @PartsPerCycle = 1
							select @PartsPerCycle=isnull(ROUND(avg(numberOfParts),0),1) from smartKPI 
								where Machine = @LineThingName
								and PartNumber = @PartNumber
								and isPartOK = 1
								and numberOfParts > 1;
					END;
				END;

				if @PartsPerCycle > 1 and @NumberOfPartsToProduce = 0 and @OrderOutputSuffix = '(1: already produced)'
				BEGIN
					select top(1) 
						@PartsPerCycle=jsondata.FixtureCavityQTY
						from smartKPIMachineMessageData
						cross apply OPENJSON([Message], N'$.rows')
							WITH(
								AssignedOrder varchar(255) N'$.AssignedOrder',
								PartNumber varchar(255) N'$.PartNumber',
								CurrentWorkplace varchar(255) N'$.CurrentWorkplace',
								Workplace varchar(255) N'$.Workplace',
								AssignedOperation varchar(255) N'$.AssignedOperation',
								FixtureCavityQTY int N'$.FixtureCavityQTY'
							) as jsondata
					where Machine = @MainStation
					and MessageTime >= @StartTime
					and MessageTime <=@EndTime
					and MessageType1 = 'OGSMessage'
					and jsondata.Workplace = jsondata.CurrentWorkplace
					and jsondata.AssignedOrder = @OrderNumber
					and jsondata.AssignedOperation = @Operation
					order by MessageTime desc;
					
					set @NumberOfPartsToProduce = @PartsPerCycle;
				END
				
				
				if @PartsPerCycle > 1
				BEGIN
					if (select PP_OrderNumber+PP_Operation from @ParallelProcessing where PP_ProcessNumber = @RunningProcess) != @OrderNumber+@Operation
					BEGIN
						select @SetupTime = CASE TextValue
														WHEN 'SEC' THEN [FloatValue] / 60
														WHEN 'MIN' THEN [FloatValue] 
														WHEN 'DAY' THEN [FloatValue] * 24 * 60
														ELSE 0		 
													END 
								  FROM [smartKPIOrderKeyValueData]
								  where OrderNumber = @OrderNumber
								  and Operation = @Operation
								  and PropertyKey1 = 'SetupTimeCO'
								  COLLATE database_default; 		
						
						
						select @ProcessingTime = CASE TextValue
														WHEN 'SEC' THEN [FloatValue] / 60
														WHEN 'MIN' THEN [FloatValue] 
														WHEN 'DAY' THEN [FloatValue] * 24 * 60 
														ELSE 0		 
													END 
								  FROM [smartKPIOrderKeyValueData]
								  where OrderNumber = @OrderNumber
								  and Operation = @Operation
								  and PropertyKey1 = 'ProcessingTimeCO'
								  COLLATE database_default; 		
						
						
						select @PlannedNumberOfWorkersCO = FloatValue
								  FROM [smartKPIOrderKeyValueData]
								  where OrderNumber = @OrderNumber
								  and Operation = @Operation
								  and PropertyKey1 = 'PlannedNumberOfWorkers'
								  COLLATE database_default; 	

						if (select PP_PartNumber from @ParallelProcessing where PP_ProcessNumber = @RunningProcess) != @PartNumber
							set @OrderChange = 1;

						update @ParallelProcessing 
							set PP_OrderNumber = @OrderNumber,
							PP_Operation = @Operation,
							PP_ProcessingTime = @ProcessingTime,
							PP_SetupTime = @SetupTime,
							PP_PlannedNumberOfWorkersCO = @PlannedNumberOfWorkersCO,
							PP_SinglePartOrderTargetCount = 0,
							PP_PartNumber = @PartNumber
							where PP_ProcessNumber = @RunningProcess;
					END;
					update @ParallelProcessing 
						set PP_Target = @NumberOfPartsToProduce,
						PP_Actual = 0,
						PP_PartsPerCycle = @PartsPerCycle
						where PP_ProcessNumber = @RunningProcess;
					-- get shift factor
					select @ShiftFactorInPercent=ShiftFactorInPercent from
						(select top(1) Utilization/100 as ShiftFactorInPercent
						from @shiftCalendar 
						where StartTime >= @CurrentDate
						and Qualifier = 'W'
						order by StartTime)x;			
					if @ShiftFactorInPercent is null
						select @ShiftFactorInPercent=ShiftFactorInPercent from
							(select top(1) Utilization/100 as ShiftFactorInPercent
							from shiftCalendar 
							where StartTime >= @CurrentDate
							and Qualifier = 'W'
							and Machine = @SAPMachine
							order by StartTime)x;			
					if @ShiftFactorInPercent is null
						set @ShiftFactorInPercent = 1;




					if (@ShiftFactorInPercent>0 and @ProcessingTime>0)
					BEGIN

					--Add Setup Time for new order
						if (@CurrentDate < @EndTime)
							BEGIN
								if (@ShiftFactorInPercent = 0)
									set @ShiftFactorInPercent = 0.0000001;
								if (@OrderChange = 1)
									SET @TimeForProducedPartsInSeconds = @TimeForProducedPartsInSeconds + @SetupTime*60/ @ShiftFactorInPercent;
							END;
						else
							BEGIN
								SET @TimeCompletlyFilled = 1;
								BREAK;
							END;

						set @SinglePartTargetCount = 0;
						if (@OrderChange = 1)
							set @SinglePartOrderTargetCount = 0;
						--Add Processing Time
						WHILE @SinglePartTargetCount < @NumberOfPartsToProduce and @TimeCompletlyFilled = 0
						BEGIN
							set @CurrentDate = dateadd(second, convert(int,@TimeForProducedPartsInSeconds), @StartTime);
							
							if (select count(*) from @shiftCalendar where StartTime <= @CurrentDate and EndTime >= @CurrentDate) = 0
								or (select count(*) from @shiftCalendar where StartTime <= @CurrentDate and EndTime >= @CurrentDate and Qualifier != 'W') > 0
							BEGIN
								select @dateWorkStart=min(StartTime) from
									(--W-shift start without any others
									select StartTime from @shiftCalendar s1 
									where StartTime >= @CurrentDate
									and Qualifier = 'W'
									and not exists (select 'ok' from @shiftCalendar s2 
										where s1.StartTime >= s2.StartTime 
										and s1.StartTime < s2.EndTime
										and Qualifier != 'W')
									--W-shifts where other ends
									union
									select EndTime from @shiftCalendar s1 
									where EndTime > @CurrentDate
									and Qualifier != 'W'
									and exists (select 'ok' from @shiftCalendar s2 
										where s1.EndTime > s2.StartTime 
										and s1.EndTime < s2.EndTime
										and Qualifier = 'W'))x;
			
								SET @TimeForProducedPartsInSeconds = @TimeForProducedPartsInSeconds + DATEDIFF(second, @CurrentDate, @dateWorkStart);
								SET @CurrentDate = @dateWorkStart;
							End
							
							select @ShiftFactorInPercent=ShiftFactorInPercent from
								(select top(1) Utilization/100 as ShiftFactorInPercent
								from @shiftCalendar 
								where StartTime >= @CurrentDate
								and Qualifier = 'W'
								order by StartTime)x;			
							if @ShiftFactorInPercent is null
								select @ShiftFactorInPercent=ShiftFactorInPercent from
									(select top(1) Utilization/100 as ShiftFactorInPercent
									from shiftCalendar 
									where StartTime >= @CurrentDate
									and Qualifier = 'W'
									and Machine = @SAPMachine
									order by StartTime)x;			
							if @ShiftFactorInPercent is null
								set @ShiftFactorInPercent = 1;

							if (@ShiftFactorInPercent = 0)
								set @ShiftFactorInPercent = 0.0000001;


							--End of cycle already out of time slot?
							if dateadd(second, convert(int,@TimeForProducedPartsInSeconds)+(@PartsPerCycle*@ProcessingTime*60/@ShiftFactorInPercent), @StartTime) > @EndTime
							BEGIN
								SET @TimeCompletlyFilled = 1;
							END
							ELSE
							BEGIN
								if @setupType = '-' or (@setupType = 'A1/A2' and @distinctOperations != 1) or (@setupType = 'A1/A1' and @distinctOperations = 1) or @setupType = 'A/B'
								BEGIN
									set @counter = 0;
									WHILE @counter < @PartsPerCycle
									BEGIN
										set @CurrentDate = dateadd(second, convert(int,@TimeForProducedPartsInSeconds), @StartTime);
										if (@CurrentDate < @EndTime)
											BEGIN
												SET @TimeForProducedPartsInSeconds = @TimeForProducedPartsInSeconds + @ProcessingTime*60 / @ShiftFactorInPercent;
												SET @SinglePartTargetCount = @SinglePartTargetCount + 1;
												SET @SinglePartOrderTargetCount = @SinglePartOrderTargetCount + 1;
												SET @PartTargetCount = @PartTargetCount + 1;
												Update @ParallelProcessing 
													set PP_Actual=@SinglePartTargetCount, PP_SinglePartOrderTargetCount = @SinglePartOrderTargetCount
													--where PP_ProcessNumber = @RunningProcess;
													where PP_OrderNumber+PP_Operation = @OrderNumber+@Operation;
												if @setupType = '-' 
													or (@setupType = 'A1/A2' and (select top(1) PP_Operation from @ParallelProcessing order by PP_Operation desc) = @Operation)
													or @setupType = 'A1/A1' 
													or @setupType = 'A/B'
												BEGIN
													select @ParallelProcessingLog='O:'+PP_OrderNumber+ ' OP:'+PP_Operation+ ' P:'+PP_PartNumber+ ' PN:'+convert(varchar,PP_ProcessNumber)+ ' OC:'+convert(varchar,@OrderChange)+ ' T:'+convert(varchar,PP_Target)+ ' A:'+convert(varchar,PP_Actual)+ ' PT:'+convert(varchar,PP_ProcessingTime)+ ' ST:'+convert(varchar,PP_SetupTime)+ ' W:'+convert(varchar,PP_PlannedNumberOfWorkersCO)+ ' PPC:'+convert(varchar,PP_PartsPerCycle)
														from @ParallelProcessing where PP_ProcessNumber = @RunningProcess;
													
													if (@counter+1 < @PartsPerCycle)
														set @FullCyclePartsProduced	= 0;
													else
														set @FullCyclePartsProduced	= @PartsPerCycle;
														
													insert into @table (FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, SetupTime, PlannedNumberOfWorkers, ParallelProcessing, ProcessNumber) 
														values (@FullCyclePartsProduced, @ShiftFactorInPercent*100,dateadd(second, convert(int,@TimeForProducedPartsInSeconds), @StartTime), @PartTargetCount, @TimeForProducedPartsInSeconds/60, @ProcessingTime/ @ShiftFactorInPercent, @SinglePartOrderTargetCount, @OrderNumber+ ' '+@Operation+ ' '+@OrderOutputSuffix, @SetupTime/ @ShiftFactorInPercent, @PlannedNumberOfWorkersCO, @ParallelProcessingLog, @RunningProcess);
												END;
											END;
										else
											BEGIN
												SET @TimeCompletlyFilled = 1;
												BREAK;
											END;
										set @counter = @counter + 1;
									END;
								END;
								ELSE
								BEGIN
									SET @TimeCompletlyFilled = 1;
									BREAK;
								END;
							END;
							if @TimeCompletlyFilled = 1
								BREAK;

							--switch process for every production cycle
							SET @RunningProcess = @RunningProcess + 1;
							if @RunningProcess > @NumberOfParallelProcesses
								set @RunningProcess = 1;

							select @ProcessingTime=PP_ProcessingTime, 
									@PlannedNumberOfWorkersCO=PP_PlannedNumberOfWorkersCO,  
									@SetupTime = PP_SetupTime,
									@OrderNumber = PP_OrderNumber,
									@Operation = PP_Operation,
									@NumberOfPartsToProduce = PP_Target,
									@SinglePartTargetCount = PP_Actual,
									@PartsPerCycle = PP_PartsPerCycle,
									@SinglePartOrderTargetCount = PP_SinglePartOrderTargetCount,
									@PartNumber = PP_PartNumber
								from @ParallelProcessing
								where PP_ProcessNumber = @RunningProcess;
						END;			
					
					END;
				END;
				SET @LastOrderNumber = @OrderNumber;
			END;
			FETCH NEXT FROM @getOrders into @OrderTime, @NumberOfPartsToProduce, @OrderNumber, @Operation, @OrderOutputSuffix
		END;
	CLOSE @getOrders;
	DEALLOCATE @getOrders;
	return
END
GO
