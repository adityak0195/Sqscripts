--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSUsersLoggedInListAtLine';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSUsersLoggedInListAtLine'))
drop FUNCTION GetCVSUsersLoggedInListAtLine;
GO
CREATE FUNCTION GetCVSUsersLoggedInListAtLine
	(@Station varchar(255))
RETURNS @table table 
		(isLoggedIn Bit,
		userId varchar(255))

BEGIN

	DECLARE @LastReset datetime2;
	DECLARE @UserId varchar(255);
	DECLARE @LoginMessages cursor;
	DECLARE @numberOfUsers int;
	
	select @LastReset=isnull(max([MessageTime]),'1970-01-01')
		from [smartKPIMachineMessageData]
		where MessageType1 = 'STAFF'
		and MessageType2 = 'Operator Logout'
		and Machine = @Station
		and Message = 'Logout'  and  MessageTime<=GETUTCDATE();	  
	
	SET @LoginMessages = CURSOR for 
	SELECT [Message]
	  FROM [smartKPIMachineMessageData]
	  where MessageType1 = 'STAFF'
	  and MessageType2 = 'Operator'
	  and Machine = @Station
	  and MessageTime > @LastReset
	  order by MessageTime;

	OPEN @LoginMessages;
		FETCH NEXT FROM @LoginMessages into @UserId
		WHILE @@FETCH_STATUS = 0
		BEGIN;
			insert into @table (isLoggedIn, userId)
				select 0,@UserId where not exists (select 'ok' from @table where userId = @UserId);
			update @table set isLoggedIn = 1 - isLoggedIn where userId = @UserId;
			
			FETCH NEXT FROM @LoginMessages into @UserId;
		END;
	CLOSE @LoginMessages;
	DEALLOCATE @LoginMessages;
	return;

END;
GO
