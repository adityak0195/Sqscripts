--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSOEE';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSOEE'))
drop FUNCTION GetCVSOEE;
GO
CREATE FUNCTION GetCVSOEE
	(@KPIsumTgmaxIO int,
	@timeBaseOee int)
RETURNS float
BEGIN
	declare @KPIOee float = 0.0;
	IF ((@timeBaseOee) > 0.0)
	BEGIN
		set @KPIOee = convert(float,@KPIsumTgmaxIO) / convert(float,@timeBaseOee) * 100.0;
	END;

	if (@KPIOee is null)
		set @KPIOee = 0;
	
	return round(@KPIOee,2);
END;
go
