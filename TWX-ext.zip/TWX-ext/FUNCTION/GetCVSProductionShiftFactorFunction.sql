--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionShiftFactorFunction';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionShiftFactorFunction'))
drop FUNCTION GetCVSProductionShiftFactorFunction;
GO
CREATE FUNCTION GetCVSProductionShiftFactorFunction
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS @returntable table (ShiftFactorInPercent float, TargetCount int, ShiftFactorVar float, ShiftFactorAsterisk varchar(5))  

BEGIN

	DECLARE @table table (ShiftFactorInPercent float);
	
	insert into @table (ShiftFactorInPercent) select isnull(ShiftFactorInPercent,0) from GetCVSProductionTargetFunction1V2(	@LineThingName,
																	@StartTime,
																	@EndTime);
	
	insert into @returntable 
		(ShiftFactorInPercent, TargetCount, ShiftFactorVar, ShiftFactorAsterisk) 
		select case count(*) when 0 then 0 else round(sum(ShiftFactorInPercent)/count(*),2) end, count(*), var(ShiftFactorInPercent), case when var(ShiftFactorInPercent)<0.1 then '' else '*' end from @table;

	RETURN;

END;

GO

--declare @sdt as DateTime2 = '2019-02-19 06:00:00.000';
--declare @edt as DateTime2 = '2019-02-19 13:30:00.000';
--select * from GetCVSProductionShiftFactorFunction('KBLisLaa2MachineThing', @sdt, @edt);  
