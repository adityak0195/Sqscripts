--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetProcessDataAsLines';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetProcessDataAsLines'))
drop FUNCTION GetProcessDataAsLines;
GO
CREATE FUNCTION GetProcessDataAsLines
	(@Id bigint,
	@isProcessDataFloat bit,
	@isProcessDataString bit,
	@isProcessDataDateTime bit)
RETURNS @table TABLE ( 
	LineName varchar(255),
	LineValue varchar(max))  

BEGIN

		DECLARE @DTCreationTime datetime2;
		DECLARE @DTMachine varchar(255);
		DECLARE @DTProcesDataType varchar(255);
		DECLARE @DTProcesDataType2 varchar(255);
		DECLARE @DTProductionTime datetime2;
		DECLARE @DTProcesData datetime2;
		DECLARE @DTSerialNumber varchar;
		DECLARE @DTPartNumber varchar(255);
		DECLARE @DTOrderNumber varchar(255);
		DECLARE @DTTrackingNumber varchar(255);
		DECLARE @DTPartNumberRevision varchar(255);
		DECLARE @DTIdentifier varchar(255);
		DECLARE @DTProcesDataTargetValue datetime2;
		DECLARE @DTdescription varchar(255);
		DECLARE @DTcomment varchar(255);
		DECLARE @DTisUpdated bit;

		DECLARE @SCreationTime datetime2;
		DECLARE @SMachine varchar(255);
		DECLARE @SProcesDataType varchar(255);
		DECLARE @SProcesDataType2 varchar(255);
		DECLARE @SProductionTime datetime2;
		DECLARE @SProcesData varchar(max);
		DECLARE @SSerialNumber varchar;
		DECLARE @SPartNumber varchar(255);
		DECLARE @SOrderNumber varchar(255);
		DECLARE @STrackingNumber varchar(255);
		DECLARE @SPartNumberRevision varchar(255);
		DECLARE @SIdentifier varchar(255);
		DECLARE @SProcesDataTargetValue varchar(max);
		DECLARE @Sdescription varchar(255);
		DECLARE @Scomment varchar(255);
		DECLARE @SisUpdated bit;

		DECLARE @FCreationTime datetime2;
		DECLARE @FMachine varchar(255);
		DECLARE @FProcesDataType varchar(255);
		DECLARE @FProcesDataType2 varchar(255);
		DECLARE @FProductionTime datetime2;
		DECLARE @FProcesData float;
		DECLARE @FSerialNumber varchar;
		DECLARE @FPartNumber varchar(255);
		DECLARE @FOrderNumber varchar(255);
		DECLARE @FTrackingNumber varchar(255);
		DECLARE @FPartNumberRevision varchar(255);
		DECLARE @FIdentifier varchar(255);
		DECLARE @FProcesDataTargetValue float;
		DECLARE @Fdescription varchar(255);
		DECLARE @Fcomment varchar(255);
		DECLARE @FisUpdated bit;


		DECLARE @FProcesDataLSL float;
		DECLARE @FProcesDataUSL float;
		DECLARE @FUnit varchar(255);
		DECLARE @FProcesDataPrecision varchar(255);
		DECLARE @FProcesDataLowerLimitName varchar(255);
		DECLARE @FProcesDataUpperLimitName varchar(255);
		DECLARE @FProcesDataTolerancePos varchar(255);
		DECLARE @FProcesDataToleranceNeg varchar(255);
		DECLARE @FProcesDataTolerancePosFloat float;
		DECLARE @FProcesDataToleranceNegFloat float;
		DECLARE @FProcessDataTargetValueTolUnit varchar(255);

	if (@isProcessDataFloat = 1)
	BEGIN

		SELECT @FCreationTime=[UTCCreationTime]
			  ,@FMachine=[Machine]
			  ,@FProcesDataType=[ProcesDataType]
			  ,@FProcesDataType2=[ProcesDataType2]
			  ,@FProductionTime=[ProductionTime]
			  ,@FProcesData=[ProcesData]
			  ,@FSerialNumber=[SerialNumber]
			  ,@FPartNumber=[PartNumber]
			  ,@FOrderNumber=[OrderNumber]
			  ,@FTrackingNumber=[TrackingNumber]
			  ,@FPartNumberRevision=[PartNumberRevision]
			  ,@FIdentifier=[Identifier]
			  ,@FProcesDataTargetValue=[ProcesDataTargetValue]
			  ,@Fdescription=[description]
			  ,@Fcomment=[comment]
			  ,@FisUpdated=[isUpdated]
			  ,@FProcesDataLSL=[ProcesDataLSL]
			  ,@FProcesDataUSL=[ProcesDataUSL]
			  ,@FUnit=[Unit]
			  ,@FProcesDataPrecision=[ProcesDataPrecision]
			  ,@FProcesDataLowerLimitName=[ProcesDataLowerLimitName]
			  ,@FProcesDataUpperLimitName=[ProcesDataUpperLimitName]
			  ,@FProcesDataTolerancePos=[ProcesDataTolerancePos]
			  ,@FProcesDataToleranceNeg=[ProcesDataToleranceNeg]
			  ,@FProcesDataTolerancePosFloat=[ProcesDataTolerancePosFloat]
			  ,@FProcesDataToleranceNegFloat=[ProcesDataToleranceNegFloat]
			  ,@FProcessDataTargetValueTolUnit=[ProcessDataTargetValueTolUnit]
		  FROM [dbo].[smartKPIProcessFloatData]
		  where Id = @Id;
		 
		 insert into @table (LineName, LineValue) values ('Id', convert(varchar(max),@Id));
		 insert into @table (LineName, LineValue) values ('CreationTime', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@FCreationTime)));
		 insert into @table (LineName, LineValue) values ('Machine', convert(varchar(max),@FMachine));
		 insert into @table (LineName, LineValue) values ('ProcesDataType', convert(varchar(max),@FProcesDataType));
		 insert into @table (LineName, LineValue) values ('ProcesDataType2', convert(varchar(max),@FProcesDataType2));
		 insert into @table (LineName, LineValue) values ('ProductionTime', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@FProductionTime)));
		 insert into @table (LineName, LineValue) values ('OrderNumber', convert(varchar(max),@FOrderNumber));
		 insert into @table (LineName, LineValue) values ('PartNumber', convert(varchar(max),@FPartNumber));
		 insert into @table (LineName, LineValue) values ('PartNumberRevision', convert(varchar(max),@FPartNumberRevision));
		 insert into @table (LineName, LineValue) values ('SerialNumber', convert(varchar(max),@FSerialNumber));
		 insert into @table (LineName, LineValue) values ('TrackingNumber', convert(varchar(max),@FTrackingNumber));
		 insert into @table (LineName, LineValue) values ('isProcessDataFloat', convert(varchar(max),@isProcessDataFloat));
		 insert into @table (LineName, LineValue) values ('ProcesData', convert(varchar(max),@FProcesData));
		 insert into @table (LineName, LineValue) values ('ProcesDataTargetValue', convert(varchar(max),@FProcesDataTargetValue));
		 insert into @table (LineName, LineValue) values ('Identifier', convert(varchar(max),@FIdentifier));
		 insert into @table (LineName, LineValue) values ('Description', convert(varchar(max),@Fdescription));
		 insert into @table (LineName, LineValue) values ('Comment', convert(varchar(max),@Fcomment));
		 insert into @table (LineName, LineValue) values ('isUpdated', convert(varchar(max),@SisUpdated));

		 insert into @table (LineName, LineValue) values ('ProcesDataLSL', convert(varchar(max),@FProcesDataLSL));
		 insert into @table (LineName, LineValue) values ('ProcesDataUSL', convert(varchar(max),@FProcesDataUSL));
		 insert into @table (LineName, LineValue) values ('Unit', convert(varchar(max),@FUnit));
		 insert into @table (LineName, LineValue) values ('ProcesDataPrecision', convert(varchar(max),@FProcesDataPrecision));
		 insert into @table (LineName, LineValue) values ('ProcesDataLowerLimitName', convert(varchar(max),@FProcesDataLowerLimitName));
		 insert into @table (LineName, LineValue) values ('ProcesDataUpperLimitName', convert(varchar(max),@FProcesDataUpperLimitName));
		 insert into @table (LineName, LineValue) values ('ProcesDataTolerancePos', convert(varchar(max),@FProcesDataTolerancePos));
		 insert into @table (LineName, LineValue) values ('ProcesDataToleranceNeg', convert(varchar(max),@FProcesDataToleranceNeg));
		 insert into @table (LineName, LineValue) values ('ProcesDataTolerancePosFloat', convert(varchar(max),@FProcesDataTolerancePosFloat));
		 insert into @table (LineName, LineValue) values ('ProcesDataToleranceNegFloat', convert(varchar(max),@FProcesDataToleranceNegFloat));
		 insert into @table (LineName, LineValue) values ('ProcessDataTargetValueTolUnit', convert(varchar(max),@FProcessDataTargetValueTolUnit));

	END;

	if (@isProcessDataString = 1)
	BEGIN

		SELECT @SCreationTime=[UTCCreationTime]
			  ,@SMachine=[Machine]
			  ,@SProcesDataType=[ProcesDataType]
			  ,@SProcesDataType2=[ProcesDataType2]
			  ,@SProductionTime=[ProductionTime]
			  ,@SProcesData=[ProcesData]
			  ,@SSerialNumber=[SerialNumber]
			  ,@SPartNumber=[PartNumber]
			  ,@SOrderNumber=[OrderNumber]
			  ,@STrackingNumber=[TrackingNumber]
			  ,@SPartNumberRevision=[PartNumberRevision]
			  ,@SIdentifier=[Identifier]
			  ,@SProcesDataTargetValue=[ProcesDataTargetValue]
			  ,@Sdescription=[description]
			  ,@Scomment=[comment]
			  ,@SisUpdated=[isUpdated]
		  FROM [dbo].[smartKPIProcessStringData]
		  where Id = @Id;
		 
		 insert into @table (LineName, LineValue) values ('Id', convert(varchar(max),@Id));
		 insert into @table (LineName, LineValue) values ('CreationTime', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@SCreationTime)));
		 insert into @table (LineName, LineValue) values ('Machine', convert(varchar(max),@SMachine));
		 insert into @table (LineName, LineValue) values ('ProcesDataType', convert(varchar(max),@SProcesDataType));
		 insert into @table (LineName, LineValue) values ('ProcesDataType2', convert(varchar(max),@SProcesDataType2));
		 insert into @table (LineName, LineValue) values ('ProductionTime', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@SProductionTime)));
		 insert into @table (LineName, LineValue) values ('OrderNumber', convert(varchar(max),@SOrderNumber));
		 insert into @table (LineName, LineValue) values ('PartNumber', convert(varchar(max),@SPartNumber));
		 insert into @table (LineName, LineValue) values ('PartNumberRevision', convert(varchar(max),@SPartNumberRevision));
		 insert into @table (LineName, LineValue) values ('SerialNumber', convert(varchar(max),@SSerialNumber));
		 insert into @table (LineName, LineValue) values ('TrackingNumber', convert(varchar(max),@STrackingNumber));
		 insert into @table (LineName, LineValue) values ('isProcessDataString', convert(varchar(max),@isProcessDataString));
		 insert into @table (LineName, LineValue) values ('ProcesData', convert(varchar(max),@SProcesData));
		 insert into @table (LineName, LineValue) values ('ProcesDataTargetValue', convert(varchar(max),@SProcesDataTargetValue));
		 insert into @table (LineName, LineValue) values ('Identifier', convert(varchar(max),@SIdentifier));
		 insert into @table (LineName, LineValue) values ('Description', convert(varchar(max),@Sdescription));
		 insert into @table (LineName, LineValue) values ('Comment', convert(varchar(max),@Scomment));
		 insert into @table (LineName, LineValue) values ('isUpdated', convert(varchar(max),@SisUpdated));
	END;

	if (@isProcessDataDateTime = 1)
	BEGIN

		SELECT @DTCreationTime=[UTCCreationTime]
			  ,@DTMachine=[Machine]
			  ,@DTProcesDataType=[ProcesDataType]
			  ,@DTProcesDataType2=[ProcesDataType2]
			  ,@DTProductionTime=[ProductionTime]
			  ,@DTProcesData=[ProcesData]
			  ,@DTSerialNumber=[SerialNumber]
			  ,@DTPartNumber=[PartNumber]
			  ,@DTOrderNumber=[OrderNumber]
			  ,@DTTrackingNumber=[TrackingNumber]
			  ,@DTPartNumberRevision=[PartNumberRevision]
			  ,@DTIdentifier=[Identifier]
			  ,@DTProcesDataTargetValue=[ProcesDataTargetValue]
			  ,@DTdescription=[description]
			  ,@DTcomment=[comment]
			  ,@DTisUpdated=[isUpdated]
		  FROM [dbo].[smartKPIProcessDateTimeData]
		  where Id = @Id;
		 
		 insert into @table (LineName, LineValue) values ('Id', convert(varchar(max),@Id));
		 insert into @table (LineName, LineValue) values ('CreationTime', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@DTCreationTime)));
		 insert into @table (LineName, LineValue) values ('Machine', convert(varchar(max),@DTMachine));
		 insert into @table (LineName, LineValue) values ('ProcesDataType', convert(varchar(max),@DTProcesDataType));
		 insert into @table (LineName, LineValue) values ('ProcesDataType2', convert(varchar(max),@DTProcesDataType2));
		 insert into @table (LineName, LineValue) values ('ProductionTime', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@DTProductionTime)));
		 insert into @table (LineName, LineValue) values ('OrderNumber', convert(varchar(max),@DTOrderNumber));
		 insert into @table (LineName, LineValue) values ('PartNumber', convert(varchar(max),@DTPartNumber));
		 insert into @table (LineName, LineValue) values ('PartNumberRevision', convert(varchar(max),@DTPartNumberRevision));
		 insert into @table (LineName, LineValue) values ('SerialNumber', convert(varchar(max),@DTSerialNumber));
		 insert into @table (LineName, LineValue) values ('TrackingNumber', convert(varchar(max),@DTTrackingNumber));
		 insert into @table (LineName, LineValue) values ('isProcessDataDateTime', convert(varchar(max),@isProcessDataDateTime));
		 insert into @table (LineName, LineValue) values ('ProcesData', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@DTProcesData)));
		 insert into @table (LineName, LineValue) values ('ProcesDataTargetValue', convert(varchar(max),@DTProcesDataTargetValue));
		 insert into @table (LineName, LineValue) values ('Identifier', convert(varchar(max),@DTIdentifier));
		 insert into @table (LineName, LineValue) values ('Description', convert(varchar(max),@DTdescription));
		 insert into @table (LineName, LineValue) values ('Comment', convert(varchar(max),@DTcomment));
		 insert into @table (LineName, LineValue) values ('isUpdated', convert(varchar(max),@DTisUpdated));
	END;

	return;
	
END;

GO
