--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetMultiKPIsTruck_revised';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetMultiKPIsTruck_revised'))
drop FUNCTION GetMultiKPIsTruck_revised;
GO
CREATE FUNCTION [dbo].[GetMultiKPIsTruck_revised] 
(
	@machine varchar(255),
	@kpiName varchar(255),
	@kpitimebase varchar(255)
)
RETURNS @table TABLE ( 
	KPIDateTime datetime2, 
	KPIFloatValue float
)
	 
BEGIN
	insert into @table(KPIDateTime, KPIFloatValue)
		select top 3 
		KPIDateTime , KPIFloatValue 
		from smartKPIValues 
		where KPIName = @kpiName
		and Machine = @machine
		and KPITimeBase = @kpitimebase
		order by KPIDateTime asc
Return
END
GO