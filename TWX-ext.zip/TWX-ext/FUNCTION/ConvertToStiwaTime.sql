--------------------------------------------------------------
--------------------------------------------------------------
print '-- ConvertToStiwaTime';
--------------------------------------------------------------
--------------------------------------------------------------


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ConvertToStiwaTime'))
drop FUNCTION ConvertToStiwaTime;
GO
CREATE FUNCTION ConvertToStiwaTime
	(@Date DateTime2)
RETURNS varchar(100)  

BEGIN
	DECLARE @return varchar(100) = '';

	set @return = @return + datepart(year, @Date);
	set @return = @return + '-';
	set @return = @return + right('0'+convert(varchar,datepart(month, @Date)),2);
	set @return = @return + '-';
	set @return = @return + right('0'+convert(varchar,datepart(day, @Date)),2);
	set @return = @return + 'T';
	set @return = @return + right('0'+convert(varchar,datepart(hour, @Date)),2);
	set @return = @return + ':';
	set @return = @return + right('0'+convert(varchar,datepart(minute, @Date)),2);
	set @return = @return + ':';
	set @return = @return + right('0'+convert(varchar,datepart(second, @Date)),2);
	set @return = @return + '.';
	set @return = @return + right('000'+convert(varchar,datepart(ms, @Date)),3);
	set @return = @return + 'Z';

	return @return;
	
END;

GO

