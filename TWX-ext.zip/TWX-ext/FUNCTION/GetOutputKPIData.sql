--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetOutputKPIData';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetOutputKPIData'))
drop FUNCTION GetOutputKPIData;
GO
CREATE FUNCTION [dbo].[GetOutputKPIData] 
(
	@machine varchar(255),
	@timetype varchar(255),
	@date1 datetime2,
	@date2 datetime2,
	@date3 datetime2,
	@date4 datetime2
	
)
RETURNS @table TABLE ( 
	timebase varchar(255), 
	OK int,
	NOK int
)
	 
BEGIN
   	    IF(@timetype = 'day')
			insert into @table(timebase, OK, NOK)
				select LEFT(datename(weekday,IO.[KPIDateTime] ),3) as Label, isnull(IO.KPIValue,0) as OK, isnull(NIO.KPIValue,0) as NOK from 
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 1
					 union
					 select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 1
					 union
					 select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 1
					) as IO,
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 0
					union
					select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 0
					union
					select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 0
					) as NIO
				where NIO.[KPIDateTime] = IO.[KPIDateTime]
				order by IO.[KPIDateTime] asc;
		ELSE IF (@timetype = 'week')
		    insert into @table(timebase, OK, NOK)
				select (CONVERT(varchar(5),DATEPART ( week , IO.KPIDateTime ))+'-'+CONVERT(varchar(5),DATEPART ( year , IO.KPIDateTime ))) as Label, isnull(IO.KPIValue,0) as OK, isnull(NIO.KPIValue,0) as NOK from 
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 1
					 union
					 select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 1
					 union
					 select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 1
					) as IO,
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 0
					union
					select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 0
					union
					select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 0
					) as NIO
				where NIO.[KPIDateTime] = IO.[KPIDateTime]
				order by IO.[KPIDateTime] asc;
		ELSE IF (@timetype = 'month')
			 insert into @table(timebase, OK, NOK)
				select LEFT(datename(month,IO.KPIDateTime ),3) as Label, isnull(IO.KPIValue,0) as OK, isnull(NIO.KPIValue,0) as NOK from 
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 1
					 union
					 select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 1
					 union
					 select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 1
					) as IO,
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 0
					union
					select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 0
					union
					select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 0
					) as NIO
				where NIO.[KPIDateTime] = IO.[KPIDateTime]
				order by IO.[KPIDateTime] asc;
		ELSE IF (@timetype = 'year')
			 insert into @table(timebase, OK, NOK)
				select CONVERT(varchar(5),DATEPART ( year , IO.KPIDateTime )) as Label, isnull(IO.KPIValue,0) as OK, isnull(NIO.KPIValue,0) as NOK from 
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 1
					 union
					 select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 1
					 union
					 select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 1
					) as IO,
					(select @date1 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date1 and @date2 and isPartOK = 0
					union
					select @date2 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date2 and @date3 and isPartOK = 0
					union
					select @date3 as [KPIDateTime], sum(numberOfParts) as [KPIValue] from smartKPI where Machine = convert(varchar(255), @machine) and ProductionTime between @date3 and @date4 and isPartOK = 0
					) as NIO
				where NIO.[KPIDateTime] = IO.[KPIDateTime]
				order by IO.[KPIDateTime] asc;
Return
END
GO

