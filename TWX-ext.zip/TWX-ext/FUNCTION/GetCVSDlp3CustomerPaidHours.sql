
--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSDlp3CustomerPaidHours';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlp3CustomerPaidHours'))
drop FUNCTION GetCVSDlp3CustomerPaidHours;
GO
CREATE FUNCTION GetCVSDlp3CustomerPaidHours
	(@StartDate DateTime2,
	@EndDate DateTime2,
	@machine varchar(255))
RETURNS @table table (ValueName varchar(255), FloatValue float)
BEGIN;

	if (@EndDate > getutcdate())
		set @EndDate = getutcdate();
	DECLARE @result float;
	DECLARE @result1 float;

	

	select @result1=round(sum(ProcessingTimeInSecCO),2), @result=round(sum(ProcessingTimeInSecCO*NumberOfParts*PlannedNumberOfWorkers/60/60),2) from dbo.GetCVSDlpRawData(@StartDate, @EndDate, @machine);
	insert into @table (ValueName, FloatValue) values ('CVS DLP3: Customer paid hours', isnull(@result,0));
	insert into @table (ValueName, FloatValue) values ('CVS: Sum of processing times (CO) in seconds', isnull(@result1,0));

	return ;
END;
GO