--------------------------------------------------------------
--------------------------------------------------------------
print 'GetDLPData';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetDLPData'))
drop FUNCTION GetDLPData;
GO
CREATE FUNCTION [GetDLPData]
	(@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@Machine varchar(255))
RETURNS @table TABLE ( 
	Machine varchar(255), 
	oldTime DateTime2, 
	newTime DateTime2, 
	LabourTime float,
	Duration float,
	ActualWorkers float,
	PartNumber varchar(255), 
	DLP1 float,
	DLP1Target float,
	DLP1TargetCumulative float,
	IsWorking varchar(2)
	)  
BEGIN;

DECLARE @LastLogin datetime2;
DECLARE @LastMachine varchar(255);
DECLARE @FirstLogin datetime2;
DECLARE @FirstMachine varchar(255);
DECLARE @WCNumber varchar(255);
DECLARE @LastPN varchar(255);

SELECT TOP 1
@LastLogin=max([MessageTime]),@LastMachine=[Machine]

from [smartKPIMachineMessageData] 
	where Machine in (SELECT [Machine] FROM [smartKPIMachineKeyValueData] where [PropertyKey]='KBLocalLineThing' and [TextValue]=@Machine)
and MessageType1='STAFF' and [MessageTime] <@EndDateTime group by [Machine] 

if (@LastLogin<=@StartDateTime) SELECT @LastLogin=@StartDateTime, @FirstLogin=@LastLogin,@FirstMachine=@LastMachine
else
SELECT  TOP 1 @FirstLogin=min([MessageTime]),@FirstMachine=[Machine] from [smartKPIMachineMessageData] 
	where Machine in (SELECT [Machine] FROM [smartKPIMachineKeyValueData] where [PropertyKey]='KBLocalLineThing' and [TextValue]=@Machine)
and MessageType1='STAFF' 
and [MessageTime] >=@StartDateTime and [MessageTime] <@EndDateTime group by [Machine]

SELECT TOP 1 @WCNumber=[TextValue] FROM [smartKPIMachineKeyValueData] where [PropertyKey]='SAPWorkcenterNumber' and Machine=@Machine order by UTCCreationTime desc;

insert into @table (Machine, 
	oldTime, 
	newTime, 
	LabourTime,
	Duration,
	ActualWorkers,
	PartNumber,
	DLP1 , 
	DLP1Target 
	,DLP1TargetCumulative
	,IsWorking
	)
	

SELECT [Machine], oldTime, newTime, LabourTime, Duration,ActualWorkers, ISNULL(PartNumber,'') as PartNumber,DLP1,ROUND(DLP1Target,0) as DLP1Target
 ,ROUND(SUM(DLP1Target) OVER(ORDER BY newTime ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),0) AS DLP1TargetCumulative,
 IsWorking
FROM
(SELECT [Machine], oldTime, newTime, LabourTime, Duration,ActualWorkers,  PartNumber,DLP1, ActualWorkers*DLP1*Duration*IsWorking/3600 as DLP1Target,
IsWorking FROM
	(SELECT [Machine], oldTime, newTime, ActualWorkers*Duration as LabourTime, Duration,ActualWorkers,PartNumber,
	  ISNULL((SELECT TOP 1 [FloatValue]
		FROM [smartKPIMachineKeyValueData]
		where [Machine] =  convert(varchar(255), @Machine)
  			and [PropertyKey] = convert(varchar(255), 'DLP1')
			and [PropertySubKey1] = convert(varchar(150), d.ActualWorkers) 
			and (([PropertySubKey2] = convert(varchar(150), 'undefined') or [PropertySubKey2] is null or [PropertySubKey2] ='') or  [PropertySubKey2]=[PartNumber]) order by [PropertySubKey2] desc),0
			)  as DLP1
			,
		   IIF((SELECT top 1 [Qualifier] FROM [shiftCalendar] where  Machine=@WCNumber and [StartTime]<=oldTime and [EndTime]>=oldTime and [StartTime] <=newTime and [EndTime]>=newTime)='W',1,0) as IsWorking
		FROM
	  (select [Machine], ISNULL(oldTime,@StartDateTime) as oldTime, newTime,PartNumber
		,NULLIF((DATEDIFF_BIG(MILLISECOND, ISNULL(oldTime,@StartDateTime), newTime) / 1000),0) as Duration
		,(SELECT SUM(ActualWorkers) FROM (SELECT ISNULL((Select sum(convert(int,isLoggedIn)) from dbo.GetCVSLoginTimeAtLine1(@StartDateTime,newTime,[Machine])),0) as ActualWorkers  from 
			(SELECT [Machine] FROM [smartKPIMachineKeyValueData] where [PropertyKey]='KBLocalLineThing' and [TextValue]=@Machine) x ) y) as ActualWorkers 
		
		from	 
		(SELECT [Machine], MessageTime as newTime, lag(MessageTime,1)  OVER (ORDER BY MessageTime asc) as oldTime, 
		(Select top 1 [PartNumber] from [smartKPI] where  Machine=@Machine and ProductionTime>=@StartDateTime and ProductionTime<=MessageTime order by ProductionTime desc) as [PartNumber]
		FROM 
			((select  [Machine], MessageTime, null as PartNumber from [smartKPIMachineMessageData] where Machine in (SELECT [Machine] FROM [smartKPIMachineKeyValueData] where [PropertyKey]='KBLocalLineThing' and [TextValue]=@Machine)
				and  MessageType1='STAFF' and [MessageTime] >=@StartDateTime and [MessageTime] <@EndDateTime)
			UNION ALL
			(Select @FirstMachine,MessageTime,[PartNumber] from (SELECT DISTINCT Machine,max([ProductionTime]) as MessageTime,[PartNumber] from [smartKPI] group by Machine,[PartNumber]) a1 where  Machine=@Machine and MessageTime>=@StartDateTime  and MessageTime<=@EndDateTime)
			UNION ALL
			(Select @LastMachine,@EndDateTime,[PartNumber] from (SELECT top 1 Machine, [PartNumber] from [smartKPI] where  Machine=@Machine and ProductionTime<=@EndDateTime order by ProductionTime desc) a
			) 
			
			UNION ALL
			(SELECT @FirstMachine, [StartTime],@LastPN FROM [shiftCalendar] where [Qualifier]='W' and  Machine=@WCNumber and [StartTime]>=@StartDateTime  and [StartTime]<=@EndDateTime)
			UNION ALL
			(SELECT @FirstMachine, [EndTime],@LastPN FROM [shiftCalendar] where [Qualifier]='W' and  Machine=@WCNumber and [EndTime]>=@StartDateTime  and [EndTime]<=@EndDateTime)
			) b
			
		  group by [Machine],[MessageTime],[PartNumber]) c
	   ) d
	   
	  ) e
  ) f
 where Duration  is not null and Duration  >0
 order by newTime asc

	return;
END;
GO
