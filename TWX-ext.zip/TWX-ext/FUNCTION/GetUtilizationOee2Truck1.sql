--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetUtilizationOee2Truck1';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetUtilizationOee2Truck1'))
drop FUNCTION GetUtilizationOee2Truck1;
GO
CREATE FUNCTION GetUtilizationOee2Truck1
	(@StartDateTime DateTime2,
	@CalculationPeriodInMinutes bigint,
	@CalculateNumerOfCycles int,
	@CalculationBase varchar(255),
	@JobName varchar(255),
	@machines varchar(255))
RETURNS @table TABLE ( 
	Machine varchar(255), 
	KPIName varchar(255), 
	KPICalculationBase varchar(255), 
	KPIDateTime DateTime2,  
	KPIDateTimeEndOfCalculation DateTime2,
	KPIFloatValue float)  
BEGIN;
	Declare @StartDateTimeFromProcInput DateTime2;
	set @StartDateTimeFromProcInput = @StartDateTime;

	declare @LogText varchar(1024);


	Declare @KPINameUtilization varchar(255) = 'CVS: Utilization';
	Declare @KPINameOee varchar(255) = 'CVS: OEE (Version 2)';
	Declare @KPINameOutputIO varchar(255) = 'OutputIO';
	Declare @KPINameOutputNIO varchar(255) = 'OutputNIO';
	Declare @KPINameOutputRetest varchar(255) = 'CVS: Retests';
	Declare @KPINameSumTgmaxIO varchar(255) = 'CVS: Sum tgmax times for IO parts in seconds';
	Declare @KPINameSumTgmaxNIO varchar(255) = 'CVS: Sum tgmax times for NIO parts in seconds';
	Declare @KPINameRQ varchar(255) = 'RQ';
	Declare @KPIWorkingTime varchar(255) = 'CVS: Planned working time in seconds (from start to end of shift)';
	Declare @KPITimeBaseUtilization varchar(255) = 'CVS: Time base for utilization in seconds';


	Declare @StartDatePerCalculationCycle DateTime2;
	Declare @EndDatePerCalculationCycle DateTime2;
	Declare @EndDatePerCalculationEndCycle DateTime2;
	Declare @CurrentCycles int;
	Declare @KPIOee float;
	Declare @KPIRQ float;
	Declare @KPIUtilization float;
	Declare @getMachines CURSOR;
	Declare @machineName varchar(255);
	Declare @timeBaseOee float;
	Declare @timeBaseUtilization float;
	Declare @KPIPartsIO float;
	Declare @KPIPartsRework float;
	Declare @KPIsumTgmaxIO float;
	Declare @KPIPartsNIO float;
	Declare @KPIsumTgmaxNIO float;
	Declare @KPIpt float;
	Declare @SAPWorkcenterNumber varchar(255);
	
	DECLARE @MainStation varchar(255);
	DECLARE @UseMainStationForCalculation bit;
	DECLARE @NumberOfParallelProcesses int = 1;
	DECLARE @LatestProductionDate datetime2;
	DECLARE @CurrentProcess int;
	DECLARE @NextProcess int;
	DECLARE @TEMP_SmartKPICVSProductionTargetDetail table 
		(LineThingName varchar(255),
			StartTime datetime2,
			EndTime datetime2,
			ProductionTime datetime2, 
			counter int, 
			OrderNumber varchar(255), 
			SinglePartTargetCount INT, 
			WorkingTimeInMinutes float,
			TimeToProducePartsInMinutes float, 
			TimeForProducedParts float, 
			ProcessingTime float,
			SetupTime float,
			CreationTime DateTime2,
			ShiftFactorInPercent float,
			SumPlannedNumberOfWorkers int,
			ProcessNumber float,
			FullCyclePartsProduced int);

	set @CurrentCycles = 0;
	
	
	set @StartDatePerCalculationCycle = datetimefromparts(
		DATEPART(year, @StartDateTimeFromProcInput),
		DATEPART(month, @StartDateTimeFromProcInput),
		DATEPART(day, @StartDateTimeFromProcInput),
		DATEPART(hour, @StartDateTimeFromProcInput),
		DATEPART(minute, @StartDateTimeFromProcInput),
		0,0);

	set @EndDatePerCalculationCycle = DATEADD(minute, @CalculationPeriodInMinutes, @StartDatePerCalculationCycle);
	set @EndDatePerCalculationEndCycle = @EndDatePerCalculationCycle;
	if (@EndDatePerCalculationCycle > getutcdate())
		set @EndDatePerCalculationCycle = getutcdate();

	WHILE (@CurrentCycles<@CalculateNumerOfCycles)
	BEGIN
		SET @getMachines = CURSOR FOR 
			SELECT Machine, [TextValue]
			  FROM [smartKPIMachineKeyValueData]
			  where Machine = @machines
			  and PropertyKey = 'SAPWorkcenterNumber'
			  and [TextValue] is not null
			  and [TextValue] != '';

		OPEN @getMachines;
			FETCH NEXT FROM @getMachines into @machineName, @SAPWorkcenterNumber
			WHILE @@FETCH_STATUS = 0
			BEGIN;
			
				if (SELECT [FloatValue]
				  FROM [smartKPIMachineKeyValueData]
				  where Machine = @machineName
				  and PropertyKey = 'isMultiPalletMachine') = 1
				BEGIN
					SELECT @NumberOfParallelProcesses=isnull([FloatValue],1)
					  FROM [smartKPIMachineKeyValueData]
					  where Machine = @machineName
					  and PropertyKey = 'NumberOfParallelProcessesForMultiPalletMachine';
				END;
				SELECT @MainStation=[TextValue]
					FROM [smartKPIMachineKeyValueData]
					where PropertyKey = 'MainStationForLineStatus'
					and Machine = @machineName;

				SELECT @UseMainStationForCalculation=convert(bit, isnull([FloatValue],0))
					FROM [smartKPIMachineKeyValueData]
					where PropertyKey = 'Use_MainStationForLineStatus_ForPartCounting'
					and Machine = @machineName;



				if (@UseMainStationForCalculation=1)
				BEGIN
				
					----------------------------
					-- Adapt end time for machining

					if (@NumberOfParallelProcesses > 1 and @StartDatePerCalculationCycle < getutcdate() and @EndDatePerCalculationEndCycle > getutcdate())
					BEGIN
						SELECT @LatestProductionDate=isnull(max(ProductionTime),@StartDatePerCalculationCycle)
							FROM [smartKPI]
							where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
							and Machine = @MainStation
							and isPartOK = 1;
						set @EndDatePerCalculationCycle = @LatestProductionDate;
					END;
					
					----------------------------

					select @KPIsumTgmaxIO=isnull(sum(y.times),0) from
					(SELECT isNull(x.tgMaxTimeInSec,0)*[smartKPI].numberOfParts as times
						FROM [smartKPI] 
						cross apply GetSAPTimePerPart([smartKPI].[OrderNumber]) as x
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @MainStation
						and x.OperationNumber = [smartKPI].SAPOperationNumber  COLLATE database_default
						and isPartOK = 1)y;					

					select @KPIsumTgmaxNIO=isnull(sum(y.times),0) from
					(SELECT isNull(x.tgMaxTimeInSec,0)*[smartKPI].numberOfParts as times
						FROM [smartKPI] 
						cross apply GetSAPTimePerPart([smartKPI].[OrderNumber]) as x
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @MainStation
						and x.OperationNumber = [smartKPI].SAPOperationNumber  COLLATE database_default
						and isPartOK = 0)y;					

					SELECT @KPIPartsIO=isnull(sum(numberOfParts),0)
						FROM [smartKPI]
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @MainStation
						and isPartOK = 1;

					SELECT @KPIPartsNIO=isnull(sum(numberOfParts),0)
						FROM [smartKPI]
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @MainStation
						and isPartOK = 0;
						
  					SELECT @KPIPartsRework=isnull(sum(convert(int,Message)),0)
						FROM [smartKPIMachineMessageData]
						where [MessageTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @MainStation
						and [MessageType1] = 'RETEST';						
						
						
						
				END
				ELSE
				BEGIN
					----------------------------
					-- Adapt end time for machining

					if (@NumberOfParallelProcesses > 1 and @StartDatePerCalculationCycle < getutcdate() and @EndDatePerCalculationEndCycle > getutcdate())
					BEGIN
						SELECT @LatestProductionDate=isnull(max(ProductionTime),@StartDatePerCalculationCycle)
							FROM [smartKPI]
							where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
							and Machine = @machineName
							and isPartOK = 1
							and numberOfParts > 0;
						if dateadd(hour,1,@LatestProductionDate) > getutcdate()
							set @EndDatePerCalculationCycle = @LatestProductionDate;
					END;
					
					----------------------------
					select @KPIsumTgmaxIO=isnull(sum(y.times),0) from
					(SELECT isNull(x.tgMaxTimeInSec,0)*[smartKPI].numberOfParts as times
						FROM [smartKPI] 
						cross apply GetSAPTimePerPartPerMachine([smartKPI].[OrderNumber], @machineName) as x
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @machineName
						and isPartOK = 1)y;					

					select @KPIsumTgmaxNIO=isnull(sum(y.times),0) from
					(SELECT isNull(x.tgMaxTimeInSec,0)*[smartKPI].numberOfParts as times
						FROM [smartKPI] 
						cross apply GetSAPTimePerPartPerMachine([smartKPI].[OrderNumber], @machineName) as x
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @machineName
						and isPartOK = 0)y;					

					SELECT @KPIPartsIO=isnull(sum(numberOfParts),0)
						FROM [smartKPI]
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @machineName
						and isPartOK = 1;

					SELECT @KPIPartsNIO=isnull(sum(numberOfParts),0)
						FROM [smartKPI]
						where [ProductionTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and Machine = @machineName
						and isPartOK = 0;
						
  					SELECT @KPIPartsRework=isnull(count(Message),0)
						FROM [smartKPIMachineMessageData]
						where [MessageTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						and ([MessageType1] = 'RETEST' or ([MessageType1] = 'Operator Screen' and MessageType2 = 'KBMaschMessage.Button.Retest'))
						and [Machine] in (SELECT [Machine]
                        					FROM [dbo].[smartKPIMachineKeyValueData]
                        					WHERE PropertyKey = 'KBLocalLineThing' AND TextValue = @machineName);
				END


				--insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				--	values (@machineName, 'CVS: OEE2 planned working time start: '+convert(varchar,@StartDatePerCalculationCycle), @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, 0);
				--insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				--	values (@machineName, 'CVS: OEE2 planned working time end: '+convert(varchar,@EndDatePerCalculationCycle), @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, 0);
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameOutputIO, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIPartsIO);
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameSumTgmaxIO, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIsumTgmaxIO);

					

				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameOutputNIO, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIPartsNIO);
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameSumTgmaxNIO, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIsumTgmaxNIO);
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameOutputRetest, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIPartsRework);
					
				
				
				select @KPIpt=dbo.GetWorkingTimeCVSInSeconds(@machineName, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle);

				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPIWorkingTime, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIpt);
				
				--set @timeBaseUtilization = DATEDIFF(second, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle);
				select @timeBaseUtilization = dbo.GetCalendarTimeCVSInSeconds(@StartDatePerCalculationCycle, @EndDatePerCalculationCycle)
				
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPITimeBaseUtilization, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @timeBaseUtilization);
				set @timeBaseOee = @KPIpt;
				
				set @KPIUtilization = dbo.GetCVSUtilization(@KPIsumTgmaxIO,@timeBaseUtilization);
				set @KPIOee = dbo.GetCVSOEE(@KPIsumTgmaxIO,@timeBaseOee);
				set @KPIRQ = dbo.GetCVSRQ(@KPIPartsIO,@KPIPartsNIO,@KPIPartsRework);

				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameUtilization, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIUtilization);

				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameOee, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIOee);

				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					values (@machineName, @KPINameRQ, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @KPIRQ);

				FETCH NEXT FROM @getMachines into @machineName, @SAPWorkcenterNumber;
			END;
		CLOSE @getMachines;
		DEALLOCATE @getMachines;

		set @StartDatePerCalculationCycle = DATEADD(minute, -1* @CalculationPeriodInMinutes, @StartDatePerCalculationCycle);
		set @EndDatePerCalculationCycle = DATEADD(minute, @CalculationPeriodInMinutes, @StartDatePerCalculationCycle);
		set @EndDatePerCalculationEndCycle = @EndDatePerCalculationCycle;
		if (@EndDatePerCalculationCycle > getutcdate())
			set @EndDatePerCalculationCycle = getutcdate();
		--set @EndDatePerCalculationCycle = DATEADD(minute, -1* @CalculationPeriodInMinutes, @EndDatePerCalculationCycle);
		set @CurrentCycles = @CurrentCycles + 1;
	END;
	return;
END;

GO
