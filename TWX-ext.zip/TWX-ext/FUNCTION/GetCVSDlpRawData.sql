--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSDlpRawData';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlpRawData'))
drop FUNCTION GetCVSDlpRawData;
GO
CREATE FUNCTION GetCVSDlpRawData
	(@StartDate DateTime2,
	@EndDate DateTime2,
	@machine varchar(255))
RETURNS @table TABLE (
	ProductionTime datetime2,
	OrderNumber varchar(255),
	PartNumber varchar(255),
	NumberOfParts int,
	ProcessingTimeInSecCO float,
	PlannedNumberOfWorkers int,
	ProcessingTimeInSecCOPerWorker float
	)
BEGIN;



	insert into @table (ProductionTime, OrderNumber, PartNumber, NumberOfParts)
	select ProductionTime, OrderNumber, PartNumber, numberOfParts 
	from smartKPI
		where ProductionTime between @StartDate and @EndDate
		and Machine = @machine
		and isPartOK = 1;
		
	update @table set ProcessingTimeInSecCO = (select ProcessingTimeInSecCO from GetSAPTimePerPartPerMachine([OrderNumber], @machine));
	update @table set PlannedNumberOfWorkers = (select max(PlannedNumberOfWorkers) from GetSAPTimePerPart(OrderNumber));
	update @table set ProcessingTimeInSecCOPerWorker = 0;
	update @table set ProcessingTimeInSecCOPerWorker = ProcessingTimeInSecCO/PlannedNumberOfWorkers where PlannedNumberOfWorkers > 0;




	return;
END;
GO
