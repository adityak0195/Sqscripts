--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSUtilization';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSUtilization'))
drop FUNCTION GetCVSUtilization;
GO
CREATE FUNCTION GetCVSUtilization
	(@KPIsumTgmaxIO int,
	@timeBaseUtilization int)
RETURNS float
BEGIN
	declare @KPIUtilization float = 0.0;
	IF ((@timeBaseUtilization) > 0.0)
	BEGIN
		set @KPIUtilization = convert(float,@KPIsumTgmaxIO) / convert(float,@timeBaseUtilization) * 100.0;
	END;

	if (@KPIUtilization is null)
		set @KPIUtilization = 0;
	
	return round(@KPIUtilization,2);
END;
go
