--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetProcessDataAsLinesForTraceability';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetProcessDataAsLinesForTraceability'))
drop FUNCTION GetProcessDataAsLinesForTraceability;
GO
CREATE FUNCTION GetProcessDataAsLinesForTraceability
	(@PartNumber varchar(255),
	@SerialNumber varchar(255),
	@ProcesData varchar(255),
	@Machine varchar(255))
RETURNS @table TABLE ( 
	LineName varchar(255),
	LineValue varchar(max))  

BEGIN	

		DECLARE @FCreationTime datetime2;
		DECLARE @FMachine varchar(255);
		DECLARE @FProcesDataType varchar(255);
		DECLARE @FProcesDataType2 varchar(255);
		DECLARE @FProductionTime datetime2;
		DECLARE @FProcesData float;	
		DECLARE @FIdentifier varchar(255);
		DECLARE @FProcesDataTargetValue float;
		DECLARE @Fdescription varchar(255);
		DECLARE @Fcomment varchar(255);
		DECLARE @FisUpdated bit;
		DECLARE @FProcesDataLSL float;
		DECLARE @FProcesDataUSL float;
	

		SELECT @FCreationTime=[CreationTime]
			  ,@FMachine=[Machine]
			  ,@FProcesDataType=[ProcesDataType]
			  ,@FProcesDataType2=[ProcesDataType2]
			  ,@FProductionTime=[ProductionTime]
			  ,@FProcesData=[ProcesData]			  
			  ,@FIdentifier=[Identifier]
			  ,@FProcesDataTargetValue=[ProcesDataTargetValue]
			  ,@Fdescription=[description]
			  ,@Fcomment=[comment]			  
			  ,@FProcesDataLSL=[ProcesDataLSL]
			  ,@FProcesDataUSL=[ProcesDataUSL]
			 
		  FROM [dbo].[smartKPIProcessFloatData]
		  where PartNumber=@PartNumber 
		  and SerialNumber=@SerialNumber
		  and Machine= @Machine
		  and ProcesData= @ProcesData; 		 
		 
		 insert into @table (LineName, LineValue) values ('Machine', convert(varchar(max),@FMachine));
		 insert into @table (LineName, LineValue) values ('Measured_Item', convert(varchar(max),@FProcesDataType));
		 insert into @table (LineName, LineValue) values ('Measured_Item2', convert(varchar(max),@FProcesDataType2));
		 insert into @table (LineName, LineValue) values ('ProductionTime', convert(varchar(max),dbo.GetLocalTimeFromUTCTime(@FProductionTime))); 
		 
		 insert into @table (LineName, LineValue) values ('ProcessDataActual', convert(varchar(max),@FProcesData));		 
		 insert into @table (LineName, LineValue) values ('Further_Description', convert(varchar(max),@Fdescription));
		 insert into @table (LineName, LineValue) values ('Comment', convert(varchar(max),@Fcomment));
		 insert into @table (LineName, LineValue) values ('ProcessDataMIN', convert(varchar(max),@FProcesDataLSL));
		 insert into @table (LineName, LineValue) values ('ProcessDataMAX', convert(varchar(max),@FProcesDataUSL));
	
	return;
	
END;

GO


--select * from dbo.GetProcessDataAsLines(13,0,0,1);
--select * from dbo.GetProcessDataAsLines(22,0,1,0);
--select * from dbo.GetProcessDataAsLines(223,1,0,0);

