--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCalendarTimeCVSInSeconds';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCalendarTimeCVSInSeconds'))
drop FUNCTION GetCalendarTimeCVSInSeconds;
GO
CREATE FUNCTION  GetCalendarTimeCVSInSeconds   
( @StartDate DateTime2,
  @EndDate DateTime2
)  
RETURNS int  
	BEGIN
	
		DECLARE @CalendarTimeCVSInSeconds int;
		
		WITH cte AS (
		SELECT @StartDate as internaldate, @StartDate as startdate, CAST(CAST(DATEADD(day,1,@StartDate) as date) as datetime2) as enddate, DATEPART(dw,@StartDate) as day where @EndDate >  CAST(CAST(DATEADD(day,1,@StartDate) as date) as datetime2)
		UNION ALL
		SELECT @StartDate as internaldate, @StartDate as startdate, @EndDate as enddate, DATEPART(dw,@StartDate) as day where @EndDate <=  CAST(CAST(DATEADD(day,1,@StartDate) as date) as datetime2)
		UNION ALL
		SELECT @EndDate as internaldate, CAST(CAST(@EndDate as date) as datetime2) as startdate, @EndDate as enddate, DATEPART(dw,@EndDate) as day where @EndDate >  CAST(CAST(DATEADD(day,1,@StartDate) as date) as datetime2)
		UNION ALL
		SELECT CAST(CAST(DATEADD(day,3,startdate) as date) as datetime2) as internaldate, CAST(CAST(DATEADD(day,1,startdate) as date) as datetime2) as startdate, CAST(CAST(DATEADD(day,2,startdate) as date) as datetime2) as enddate, DATEPART(dw,CAST(DATEADD(day,1,startdate) as datetime2)) as day
		FROM cte
		WHERE internaldate < @EndDate
		)
		SELECT @CalendarTimeCVSInSeconds=isnull(sum(datediff(second, startdate, enddate)),0)
		FROM cte
		where startdate >= @StartDate
		and enddate <= @EndDate
		and DATEPART(dw,startdate) not in  (1,7)
		OPTION (MAXRECURSION 0)

	
        RETURN @CalendarTimeCVSInSeconds; 
    END;
	
	
GO	


--select dbo.GetCalendarTimeCVSInSeconds('2020-01-04 02:00','2020-01-06 10:00');

