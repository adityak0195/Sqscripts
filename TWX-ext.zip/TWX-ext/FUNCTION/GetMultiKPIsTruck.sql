--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetMultiKPIsTruck';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetMultiKPIsTruck'))
drop FUNCTION GetMultiKPIsTruck;
GO
CREATE FUNCTION GetMultiKPIsTruck
	(@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@machine varchar(255),
	@CalculationBase varchar(255))
RETURNS @table TABLE ( 
	Machine varchar(255), 
	KPIName varchar(255), 
	KPICalculationBase varchar(255), 
	KPIDateTime DateTime2,  
	KPIDateTimeEndOfCalculation DateTime2,
	KPIFloatValue float)  
BEGIN;
	declare @dt1 as DateTime2 = @StartDateTime;
	declare @dt2 as DateTime2 = @EndDateTime;
	declare @timeslot as bigint;
	declare @kpibase as varchar(255) = @CalculationBase;
	declare @jobname as varchar(255) = 'GetKPIsTruck';
	declare @NumerOfCycles as int;
	declare @counter as int;
	declare @CorrectedStartDateTime1 as DateTime2;
	declare @CorrectedStartDateTime2 as DateTime2;

	if (@CalculationBase in ('Month', 'Year'))
	BEGIN
		if (@CalculationBase = 'Month')
		BEGIN
			set @CorrectedStartDateTime1 = datetimefromparts(
							DATEPART(year, @dt2),
							DATEPART(month, @dt2), 1,0,0,0,0);
		END;
		if (@CalculationBase = 'Year')
		BEGIN
			set @CorrectedStartDateTime1 = datetimefromparts(
							DATEPART(year, @dt2),1,1,0,0,0,0);
		END;
		if (@CorrectedStartDateTime1 < @dt1)
		BEGIN
			set @timeslot = DATEDIFF_BIG(minute,@dt1,@dt2);
			--select @dt1, @dt2, @timeslot;
			if (@timeslot > 0)
			BEGIN
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
					from dbo.GetUtilizationOee2Truck1(@dt1,@timeslot,1,@kpibase, @jobname, @machine);
			END;
		END;
		else
		BEGIN
			set @timeslot = DATEDIFF_BIG(minute,@CorrectedStartDateTime1,@dt2);
			--select @CorrectedStartDateTime1, @dt2, @timeslot;
			if (@timeslot > 0)
			BEGIN
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
					from dbo.GetUtilizationOee2Truck1(@CorrectedStartDateTime1,@timeslot,1,@kpibase, @jobname, @machine);
			END;
			if (@CalculationBase = 'Month')
			BEGIN
				set @NumerOfCycles = DATEDIFF(month,  @dt1 , @CorrectedStartDateTime1)-1;
			END;
			if (@CalculationBase = 'Year')
			BEGIN
				set @NumerOfCycles = DATEDIFF(year,  @dt1 , @CorrectedStartDateTime1)-1;
			END;
			set @counter = 0;
			WHILE (@counter < @NumerOfCycles)
			BEGIN
				set @CorrectedStartDateTime2 = @CorrectedStartDateTime1;
				if (@CalculationBase = 'Month')
				BEGIN
					set @CorrectedStartDateTime1 = dateadd(month, -1, @CorrectedStartDateTime2);
				END;
				if (@CalculationBase = 'Year')
				BEGIN
					set @CorrectedStartDateTime1 = dateadd(year, -1, @CorrectedStartDateTime2);
				END;
				set @timeslot = DATEDIFF_BIG(minute,@CorrectedStartDateTime1,@CorrectedStartDateTime2);
				
				--select @CorrectedStartDateTime1, @CorrectedStartDateTime2, @timeslot;
				if (@timeslot > 0)
				BEGIN
					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
						from dbo.GetUtilizationOee2Truck1(@CorrectedStartDateTime1,@timeslot,1,@kpibase, @jobname, @machine);
				END;

				set @counter = @counter + 1;
			END;
				set @CorrectedStartDateTime2 = @CorrectedStartDateTime1;
				set @CorrectedStartDateTime1 = @dt1;
			set @timeslot = DATEDIFF_BIG(minute,@CorrectedStartDateTime1,@CorrectedStartDateTime2);
			--select @CorrectedStartDateTime1, @CorrectedStartDateTime2, @timeslot;
			if (@timeslot > 0)
			BEGIN
				insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
					select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
					from dbo.GetUtilizationOee2Truck1(@CorrectedStartDateTime1,@timeslot,1,@kpibase, @jobname, @machine);
			END;
		END;
	END;


	if (@CalculationBase in ('Quarter', 'Hour', 'Day', 'Week'))
	BEGIN

		if (@CalculationBase = 'Quarter')
		BEGIN
			set @timeslot = 15;
		END;
		if (@CalculationBase = 'Hour')
		BEGIN
			set @timeslot = 60;
		END;
		if (@CalculationBase = 'Day')
		BEGIN
			set @timeslot = 60*24;
		END;
		if (@CalculationBase = 'Week')
		BEGIN
			set @timeslot = 60*24*7;
		END;


		declare @delta11 as bigint = DATEDIFF_BIG(minute, DATEADD(minute,ROUND(DATEDIFF_BIG(minute,0,@dt2)/@timeslot,0)*@timeslot,0), @dt2);
		declare @delta12 as bigint = DATEDIFF_BIG(minute, @dt1, @dt2);
		declare @dt11 as DateTime2 = DATEADD(minute,@delta11*-1,@dt2);
		--select @dt11, @delta11, @delta12;
		if (@dt11 > @dt1 AND @delta11 > 0)
		BEGIN
			insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
				from dbo.GetUtilizationOee2Truck1(@dt11,@delta11,1,@kpibase, @jobname, @machine);
		END;
		else if (@dt11 <= @dt1 AND @delta12 > 0)
		BEGIN
			insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
				from dbo.GetUtilizationOee2Truck1(@dt1,@delta12,1,@kpibase, @jobname, @machine);
		END;

		declare @delta21 as bigint = DATEDIFF_BIG(minute,@dt11,@dt1) * -1;
		declare @delta22 as int = @delta21/@timeslot;
		declare @dt21 as DateTime2 = dateadd(minute,@timeslot*-1,@dt11);
		--select @dt21, @delta21, @delta22;
		if (@delta21 > 0)
		BEGIN
			insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
				from dbo.GetUtilizationOee2Truck1(@dt21,@timeslot,@delta22,@kpibase, @jobname, @machine);
		END;

		declare @dt31 as DateTime2 = dateadd(minute,(@timeslot*-1)*@delta22,@dt21);
		declare @delta31 as bigint = @timeslot - DATEDIFF_BIG(minute,@dt31,@dt1);
		--select @dt31, @delta31;
		if (@delta31 > 0)
		BEGIN
			insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
				select [Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]
				from dbo.GetUtilizationOee2Truck1(@dt1,@delta31,1,@kpibase, @jobname, @machine);
		END;

	END;
return;
END;
GO

