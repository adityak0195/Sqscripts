--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetDowntimeStatistic';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetDowntimeStatistic'))
drop FUNCTION GetDowntimeStatistic;
GO
CREATE FUNCTION GetDowntimeStatistic
	(@StartDateTime DateTime2,
	@EndDateTime DateTime2,
	@machine varchar(255),
	@station varchar(255))
RETURNS @table TABLE ( 
	TimeSumInSeconds int,
	StatusType varchar(255),  
	StatusName varchar(255),
	Occurrences int)
BEGIN;

	declare @machinebreakdown TABLE(
	StatusType varchar(255),
	StatusNameLevel1 varchar(255),
	StatusNameLevel2 varchar(255),
	TimeSumInMinutes float,
	TimeSumInSeconds bigint,
	Occurrences int,
	Time1 datetime2,
	Time2 datetime2)  

	insert into @machinebreakdown(StatusNameLevel1, StatusNameLevel2, StatusType, TimeSumInSeconds, TimeSumInMinutes, Occurrences) (select  StatusNameLevel1, StatusNameLevel2, StatusType, TimeSumInSeconds, TimeSumInMinutes, Occurrences  from GetMachineTimeBreakdownCVS(@machine, @station, @StartDateTime, @EndDateTime)
	where (StatusType = 'Actual' COLLATE database_default )
	or (StatusType = 'Plan' COLLATE database_default and StatusNameLevel1 = 'Unplanned' COLLATE database_default))

	/* New downtimes levels data */
	insert into @table (StatusType, StatusName,TimeSumInSeconds, Occurrences)
	select StatusType, StatusName, sum(TimeSumInSeconds) as TimeSumInSeconds,
		SUM(Occurrences) as StatusOccurrencies
	from 
	(
	 -- L0
	Select 'L0/' + SUBSTRING(StatusNameLevel2, 1, 18) COLLATE database_default as StatusType,
		SUBSTRING(StatusNameLevel2, 1, 18) COLLATE database_default  as StatusName, TimeSumInSeconds as TimeSumInSeconds, Occurrences as Occurrences
	from @machinebreakdown 
	where StatusNameLevel1 ='-'
	UNION ALL
	-- L1 
	select 'L1/' + StatusNameLevel2 COLLATE database_default as StatusType,
		StatusNameLevel2 COLLATE database_default as StatusName, TimeSumInSeconds as TimeSumInSeconds, Occurrences as Occurrences
	from @machinebreakdown
	where StatusNameLevel1 ='-'
	-- L2
	UNION ALL
	select 'L2/' + StatusNameLevel2 COLLATE database_default as StatusType,
		StatusNameLevel2 as StatusName, TimeSumInSeconds as TimeSumInSeconds, Occurrences as Occurrences
	from @machinebreakdown
	where StatusNameLevel1 !='-'
		) x
	group by StatusType,StatusName;

	/* Backwards compatibility */

	with machinebreakdownold as (select StatusType, StatusNameLevel1, case when StatusNameLevel2 = 'KBMaschStatus.1.TI.RegularChangeover' then 'Changeover' else StatusNameLevel2 end as StatusNameLevel2, TimeSumInMinutes, TimeSumInSeconds, Occurrences, Time1, Time2 
        from @machinebreakdown
	where (StatusType = 'Actual' COLLATE database_default and StatusNameLevel1 = '-' COLLATE database_default)
	or (StatusType = 'Plan' COLLATE database_default and StatusNameLevel1 = 'Unplanned' COLLATE database_default))
	insert into @table (TimeSumInSeconds, StatusType) select sum(TimeSumInSeconds) as TimeSumInSeconds, 
	case 
		when (StatusType = 'P') then 'Productive'
		when (StatusType = 'TI') then 'Technical Interruption'
		when (StatusType = 'PI') then 'Planned Interruption'
		when (StatusType = 'OI') then 'Organisational Interruption'
		else StatusType
		end COLLATE database_default as StatusType 
	from
	(select machinebreakdownold.TimeSumInSeconds as TimeSumInSeconds, [smartKPIOperatorInputMachineDefinition].[StatusType] COLLATE database_default as StatusType 
	from machinebreakdownold, [smartKPIOperatorInputMachineDefinition]
	where machinebreakdownold.StatusNameLevel2 = [smartKPIOperatorInputMachineDefinition].Status COLLATE database_default
	and [smartKPIOperatorInputMachineDefinition].Devision = 'CVS' COLLATE database_default
	union
	select TimeSumInSeconds, StatusNameLevel2 COLLATE database_default
	from machinebreakdownold
	where StatusNameLevel2 not in (
		select [smartKPIOperatorInputMachineDefinition].Status  COLLATE database_default
			from [smartKPIOperatorInputMachineDefinition]
			where [smartKPIOperatorInputMachineDefinition].Devision = 'CVS' COLLATE database_default)) x
	group by [StatusType];

	return;
END;
GO
