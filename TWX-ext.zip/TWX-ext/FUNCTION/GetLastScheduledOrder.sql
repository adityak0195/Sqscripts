--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetLastScheduledOrder';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetLastScheduledOrder'))
drop FUNCTION GetLastScheduledOrder;
GO
CREATE FUNCTION GetLastScheduledOrder
	(@SapWorkCenter varchar(255),
	 @MaterialNumber varchar(255))
RETURNS varchar(255)
BEGIN
	declare @OrderNumber varchar(255);
	select top (1) @OrderNumber=o1.OrderNumber from smartKPIOrderKeyValueData o1, smartKPIOrderKeyValueData o2, smartKPIOrderKeyValueData o3
	  where o1.OrderNumber = o2.OrderNumber
	  and o2.OrderNumber = o3.OrderNumber
	  and o1.PropertyKey1 = 'Line'
	  and o1.TextValue = @SapWorkCenter
	  and o2.PropertyKey1 = 'MaterialNumber'
	  and o2.TextValue = @MaterialNumber
	  and o3.PropertyKey1 = 'ScheduledStartDate'
	  and o3.DateTimeValue < GETUTCDATE()
	  order by o3.DateTimeValue desc
	
	return @OrderNumber;
END;
go