--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSDlp1Ratio';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlp1Ratio'))
drop FUNCTION GetCVSDlp1Ratio;
GO
CREATE FUNCTION GetCVSDlp1Ratio
	(@Actual float,
	@Target float)
RETURNS float
BEGIN
	declare @dlp1result float = 0.0;

	if (@Target > 0)
		SET @dlp1result = @Actual/@Target*100;
		
	if (@dlp1result is null)
		set @dlp1result = 0;
	
	return round(@dlp1result,2);
END;
go