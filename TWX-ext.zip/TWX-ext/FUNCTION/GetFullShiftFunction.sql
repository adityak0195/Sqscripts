--------------------------------------------------------------
--------------------------------------------------------------
print 'GetFullShiftFunction';
--------------------------------------------------------------
--------------------------------------------------------------

	
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetFullShiftFunction'))
drop FUNCTION GetFullShiftFunction;
GO
CREATE FUNCTION GetFullShiftFunction
	(@Machine varchar(255),
	@ShiftStart DateTime2)
RETURNS @table TABLE ( 
	CurrentName varchar(255),
	CurrentStartTime DateTime2,
	CurrentEndTime DateTime2)  

BEGIN

	Declare @CurrentName varchar(255);
	Declare @CurrentStartTime DateTime2;
	Declare @CurrentEndTime DateTime2;

	
	Declare @getShifts CURSOR;
	Declare @StartTime DateTime2;
	Declare @EndTime DateTime2;
	Declare @Name varchar(255);
	Declare @SAPMachine varchar(255);
	Declare @Qualifier varchar(2);
	Declare @PType varchar(1);

	SELECT @SAPMachine=[TextValue]
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @Machine
	  and PropertyKey = 'SAPWorkcenterNumber';


	SELECT top(1) @CurrentStartTime=[shiftCalendar].StartTime, @CurrentEndTime=[shiftCalendar].EndTime, @CurrentName=[shiftCalendar].Name
		  FROM [shiftCalendar]
		  where [shiftCalendar].[Machine] = @SAPMachine
		  and StartTime >= @ShiftStart
		  order by [StartTime];

	--insert into @table (CurrentName, CurrentStartTime, CurrentEndTime) values ('CurrentName: '+@CurrentName, @CurrentStartTime, @CurrentEndTime);


	if (@CurrentName is not null and @CurrentName != '')
	BEGIN
		SET @getShifts = CURSOR FOR SELECT TOP (20) 
				   [shiftCalendar].StartTime, [shiftCalendar].EndTime, [shiftCalendar].Name, [shiftCalendar].Qualifier
			  FROM [shiftCalendar]
			  where [shiftCalendar].[Machine] = @SAPMachine
			  and StartTime < @CurrentStartTime
			  and [Name] = @CurrentName
			  order by EndTime desc;

		OPEN @getShifts;
			SET @PType =0;
			FETCH NEXT FROM @getShifts into @StartTime, @EndTime, @Name, @Qualifier
		
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				if ((@StartTime < @CurrentStartTime and @EndTime >= @CurrentStartTime) and (@PType=0))
				BEGIN
					SET @CurrentStartTime = @StartTime;
					if(@Qualifier='P')
					BEGIN;
						SET @PType =1;
						SET @CurrentStartTime = @EndTime;
					END;
					--insert into @table (CurrentName, CurrentStartTime, CurrentEndTime) values ('Backward CurrentName: '+@CurrentName, @CurrentStartTime, @CurrentEndTime);
		
				END;
				FETCH NEXT FROM @getShifts into @StartTime, @EndTime, @Name, @Qualifier
			END;
		CLOSE @getShifts;
		DEALLOCATE @getShifts;

		SET @getShifts = CURSOR FOR SELECT TOP (20) 
				   [shiftCalendar].StartTime, [shiftCalendar].EndTime, [shiftCalendar].Name,[shiftCalendar].Qualifier
			  FROM [shiftCalendar]
			  where [shiftCalendar].[Machine] = @SAPMachine
			  and StartTime >= @CurrentEndTime
			  and [Name] = @CurrentName
			  order by [StartTime] asc;

		OPEN @getShifts;
			SET @PType =0;
			FETCH NEXT FROM @getShifts into @StartTime, @EndTime, @Name, @Qualifier
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				
				if ((@EndTime > @CurrentStartTime and @StartTime <= @CurrentEndTime) and (@PType=0))
				BEGIN
					SET @CurrentEndTime = @EndTime;
					if(@Qualifier='P')
					BEGIN;
						SET @PType =1;
					END;
					--insert into @table (CurrentName, CurrentStartTime, CurrentEndTime) values ('Forward CurrentName: '+@CurrentName, @CurrentStartTime, @CurrentEndTime);
		
				END;
				FETCH NEXT FROM @getShifts into @StartTime, @EndTime, @Name, @Qualifier
			END;
		CLOSE @getShifts;
		DEALLOCATE @getShifts;
	END;

	insert into @table (CurrentName, CurrentStartTime, CurrentEndTime) values (@CurrentName, @CurrentStartTime, @CurrentEndTime);
	return;
	
END;


--declare @dt as DateTime2 = '2020-01-01 00:00:00';

--select * from GetFullShiftFunction ('TESTMACHINE', @dt);  
--GO



GO
