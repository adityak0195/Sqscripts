--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetNewOrderKeyValueData';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetNewOrderKeyValueData'))
drop FUNCTION GetNewOrderKeyValueData;
GO
CREATE FUNCTION GetNewOrderKeyValueData
	(@StartDateTime DateTime2,
	@SAPPlantNumber varchar(255))
RETURNS @table TABLE ( 
	Id bigint, 
		CreationTime DateTime2 ,
		PropertyKey varchar(255),
		FloatValue float,
		TextValue varchar(max),
		DateTimeValue DateTime2,
		isFloatValue bit,
		isTextValue bit,
		isDateTimeValue bit,
		System varchar(255),
		OrderNumber varchar(255),
		UpdateTime DateTime2,
		UTCUpdateTime DateTime2,
		PropertyKey1 varchar(255),
		Operation varchar(255))  

BEGIN

	insert into @table (Id, CreationTime ,
		PropertyKey ,
		FloatValue ,
		TextValue ,
		DateTimeValue ,
		isFloatValue ,
		isTextValue ,
		isDateTimeValue,
		System ,
		OrderNumber ,
		UpdateTime,
		UTCUpdateTime,
		PropertyKey1,
		Operation		) 
	select top (5000) Id, CreationTime ,
		PropertyKey ,
		FloatValue ,
		TextValue ,
		DateTimeValue ,
		isFloatValue ,
		isTextValue ,
		isDateTimeValue,
		System ,
		OrderNumber ,
		UpdateTime,
		UTCUpdateTime,
		PropertyKey1,
		Operation
	from [smartKPIOrderKeyValueData] 
		where UTCUpdateTime >= @StartDateTime
		and PlantId = @SAPPlantNumber
		order by UTCUpdateTime;

	RETURN;
	
END;

GO
