--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetSAPTimePerPartPerMachine';
--------------------------------------------------------------
--------------------------------------------------------------


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetSAPTimePerPartPerMachine'))
drop FUNCTION GetSAPTimePerPartPerMachine;
GO
CREATE FUNCTION GetSAPTimePerPartPerMachine
	(@OrderNumber varchar(255),
	@Machine varchar(255))
--RETURNS float
RETURNS @table TABLE ( 
		SetupTimeInSec float,
		SetupTimeInSecAPO float,
		SetupTimeInSecCO float,
		TeardownTimeInSec float,
		tgMaxTimeInSec float,
		ProcessingTimeInSec float,
		ProcessingTimeInSecCO float,
		ProcessingTimeInSecAPO float,
		PlannedNumberOfWorkersCO float)
BEGIN
	declare @SAPMachine varchar(255);
	
	SELECT @SAPMachine=[TextValue]
	  FROM [smartKPIMachineKeyValueData]
	  where Machine = @Machine
	  and PropertyKey = 'SAPWorkcenterNumber';

	insert into @table (SetupTimeInSec ,
		SetupTimeInSecAPO ,
		SetupTimeInSecCO ,
		TeardownTimeInSec ,
		tgMaxTimeInSec ,
		ProcessingTimeInSec ,
		ProcessingTimeInSecCO ,
		ProcessingTimeInSecAPO,
		PlannedNumberOfWorkersCO)
	select sum(SetupTimeInSec) ,
		sum(SetupTimeInSecAPO) ,
		sum(SetupTimeInSecCO) ,
		sum(TeardownTimeInSec) ,
		sum(tgMaxTimeInSec) ,
		sum(ProcessingTimeInSec) ,
		sum(ProcessingTimeInSecCO) ,
		sum(ProcessingTimeInSecAPO),
		sum(PlannedNumberOfWorkers * ProcessingTimeInSecCO)
		from GetSAPTimePerPart(@OrderNumber) where SAPMachine = @SAPMachine;
		
	update @table set PlannedNumberOfWorkersCO = PlannedNumberOfWorkersCO/ProcessingTimeInSecCO where ProcessingTimeInSecCO > 0;
	update @table set PlannedNumberOfWorkersCO = 0 where ProcessingTimeInSecCO = 0;
	return;
END;

GO

--select * from GetSAPTimePerPartPerMachine('35153577', 'MM102288');
