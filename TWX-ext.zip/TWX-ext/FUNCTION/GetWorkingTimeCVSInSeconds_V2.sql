--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetWorkingTimeCVSInSeconds_V2';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetWorkingTimeCVSInSeconds_V2'))
drop FUNCTION GetWorkingTimeCVSInSeconds_V2;
GO


CREATE FUNCTION  [dbo].[GetWorkingTimeCVSInSeconds_V2]   
( @Machine varchar(255),
  @StartDate DateTime2,
  @EndDate DateTime2
)  
RETURNS int  
	BEGIN
	
		declare @tableWithoutDowntimes table (StartTime datetime2, EndTime datetime2, diff bigint, type varchar(255));
		declare @tableDowntimes table (StartTime datetime2, EndTime datetime2, diff bigint, type varchar(255));
		Declare @cursorDowntimes CURSOR;
		DECLARE @StartDowntime datetime2;
		DECLARE @EndDowntime datetime2;
		DECLARE @WorkingTimeCVSInSeconds int;
		declare @SAPMachine varchar(255);
		
		SELECT @SAPMachine=[TextValue]
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @Machine
		  and PropertyKey = 'SAPWorkcenterNumber';


		-- dates needed for @temp_shiftcalendar
		declare @startDateAdjusted datetime2 = dateadd(day, -2, @StartDate);
		declare @endDateAdjusted datetime2 = dateadd(day, 2, @EndDate);
          
    -- At least for short time calculation (hourly based) we are getting wrong results
    -- Adding simple use cases for those simple calculations
    
    --*********************************************************************************
    -- Start simple use cases

    -- case 1
        --within time slot
        --                    ##########     time slot
        --                        ------     shift definitions
        --                      --           shift definitions
        --                    --             shift definitions
        --                    ----------     shift definitions
    -- case 2
        --ending after
        --                    ##########     time slot
        --                        --------   shift definitions
        --                    ------------   shift definitions
    -- case 3
        --starting before
        --                    ##########     time slot
        --                --------           shift definitions
        --                --------------     shift definitions
    -- case 4
        --shift larger then time slot
        --                    ##########     time slot
        --                ----------------   shift definitions


    
		declare @shifttable table (Id int not null IDENTITY(1,1) PRIMARY KEY, StartTime datetime2, EndTime datetime2, diff bigint, type varchar(255), ident int);


		-- creating @temp_shiftcalendar that handles overlapping times 
		declare @temp_shiftcalendar table (Id int not null IDENTITY(1,1) PRIMARY KEY, Plant varchar(255), Machine varchar(255), StartTime datetime2, EndTime datetime2, Qualifier varchar(10), Name varchar(255), Machine_Full_Name varchar(255));		

		WITH downtime AS (
							SELECT TOP(100)  Id
									,[Plant]
									,[Machine]
									,[StartTime]
									,[EndTime]
									,[Qualifier]
									,[Name]
									,[Machine_Full_Name]
							FROM [shiftCalendar]
							WHERE Qualifier IN ('P', 'M', 'D')
								and [Machine] = @SAPMachine
								and StartTime >= @startDateAdjusted 
								and EndTime <= @endDateAdjusted), downtimetable as ( 
							SELECT  Id
									,[Plant]
									,[Machine]
									,[StartTime]
									,[EndTime]
									,[Qualifier]
									,[Name]
									,[Machine_Full_Name]
							FROM downtime
							UNION
							SELECT TOP(1000)
									W.Id,
									W.[Plant],
									W.[Machine],
								CASE
							WHEN EXISTS (
								SELECT 1
								FROM downtime PD
								WHERE PD.StartTime <= W.StartTime
								  AND PD.EndTime >= W.EndTime
							) THEN NULL           
							WHEN EXISTS (
								SELECT 1
								FROM downtime PD 
								WHERE PD.Qualifier = 'P'
								  AND (
									  (PD.EndTime >= W.StartTime AND PD.StartTime <= W.StartTime AND PD.EndTime <= W.EndTime) OR
									  (PD.EndTime >= W.StartTime AND PD.StartTime <= W.StartTime AND PD.EndTime >= W.EndTime)
								  )
							) THEN (
								SELECT MIN(PD.EndTime)
								FROM downtime PD
								WHERE PD.Qualifier = 'P'
								  AND PD.EndTime >= W.StartTime
								  AND PD.EndTime <= W.EndTime
								  AND PD.StartTime <= W.StartTime
							)   
							WHEN EXISTS (
								SELECT 1
								FROM downtime PD 
								WHERE PD.Qualifier = 'M'
								  AND (
									  (PD.EndTime >= W.StartTime AND PD.StartTime <= W.StartTime AND PD.EndTime <= W.EndTime) OR
									  (PD.EndTime >= W.StartTime AND PD.StartTime <= W.StartTime AND PD.EndTime >= W.EndTime)
								  )
							) THEN (
								SELECT MIN(PD.EndTime)
								FROM downtime PD
								WHERE PD.Qualifier = 'M'
								  AND PD.EndTime >= W.StartTime
								  AND PD.EndTime <= W.EndTime
								  AND PD.StartTime <= W.StartTime
							)   
							WHEN EXISTS (
								SELECT 1
								FROM downtime PD 
								WHERE PD.Qualifier = 'D'
								  AND (
									  (PD.EndTime >= W.StartTime AND PD.StartTime <= W.StartTime AND PD.EndTime <= W.EndTime) OR
									  (PD.EndTime >= W.StartTime AND PD.StartTime <= W.StartTime AND PD.EndTime >= W.EndTime)
								  )
							) THEN (
								SELECT MIN(PD.EndTime)
								FROM downtime PD
								WHERE PD.Qualifier = 'D'
								  AND PD.EndTime >= W.StartTime
								  AND PD.EndTime <= W.EndTime
								  AND PD.StartTime <= W.StartTime
							)   
							ELSE W.StartTime
							END AS StartTime,			
								CASE          
								WHEN EXISTS (
										SELECT 1
										FROM downtime PA
										WHERE PA.Qualifier = 'P'
										  AND (
											   (PA.StartTime <= W.EndTime AND PA.StartTime > W.StartTime AND PA.EndTime <= W.EndTime) 						
										  )
								) THEN (
										Select MAX(StartTime) FROM downtime PA
										WHERE PA.Qualifier = 'P'
										  AND (
											   (PA.StartTime <= W.EndTime AND PA.StartTime > W.StartTime AND PA.EndTime <= W.EndTime) 						
										  )             
									)
								WHEN EXISTS (
										SELECT 1
										FROM downtime PA
										WHERE PA.Qualifier = 'P'
										  AND (
											  (PA.StartTime <= W.EndTime AND PA.StartTime >= W.StartTime AND PA.EndTime >= W.EndTime)
										  )
								) THEN (				
										SELECT MAX(PA.StartTime)
										FROM downtime PA
										WHERE PA.Qualifier = 'P'
										  AND PA.StartTime <= W.EndTime
										  AND PA.StartTime >= W.StartTime
									)
								WHEN EXISTS (
										SELECT 1
										FROM downtime PA
										WHERE PA.Qualifier = 'M'
										  AND (
											   (PA.StartTime <= W.EndTime AND PA.StartTime > W.StartTime AND PA.EndTime <= W.EndTime) 						
										  )
								) THEN (
										Select MAX(StartTime) FROM downtime PA
										WHERE PA.Qualifier = 'M'
										  AND (
											   (PA.StartTime <= W.EndTime AND PA.StartTime > W.StartTime AND PA.EndTime <= W.EndTime) 						
										  )              
									)
								WHEN EXISTS (
										SELECT 1
										FROM downtime PA
										WHERE PA.Qualifier = 'M'
										  AND (
											  (PA.StartTime <= W.EndTime AND PA.StartTime >= W.StartTime AND PA.EndTime >= W.EndTime)
										  )
								) THEN (				
										SELECT MAX(PA.StartTime)
										FROM downtime PA
										WHERE PA.Qualifier = 'M'
										  AND PA.StartTime <= W.EndTime
										  AND PA.StartTime >= W.StartTime
									)
								WHEN EXISTS (
										SELECT 1
										FROM downtime PA
										WHERE PA.Qualifier = 'D'
										  AND (
											   (PA.StartTime <= W.EndTime AND PA.StartTime > W.StartTime AND PA.EndTime <= W.EndTime) 						
										  )
								) THEN (
										Select MAX(StartTime) FROM downtime PA
										WHERE PA.Qualifier = 'D'
										  AND (
											   (PA.StartTime <= W.EndTime AND PA.StartTime > W.StartTime AND PA.EndTime <= W.EndTime) 						
										  )              
									)
								WHEN EXISTS (
										SELECT 1
										FROM downtime PA
										WHERE PA.Qualifier = 'D'
										  AND (
											  (PA.StartTime <= W.EndTime AND PA.StartTime >= W.StartTime AND PA.EndTime >= W.EndTime)
										  )
								) THEN (				
										SELECT MAX(PA.StartTime)
										FROM downtime PA
										WHERE PA.Qualifier = 'D'
										  AND PA.StartTime <= W.EndTime
										  AND PA.StartTime >= W.StartTime
									)
									ELSE W.EndTime
								END AS EndTime,
								 W.Qualifier,
								 W.Name,        
								 W.[Machine_Full_Name]
							FROM [shiftCalendar] W
							WHERE (W.Qualifier = 'W' or W.Qualifier = 'B') 
							and W.[Machine] = @SAPMachine
							and W.StartTime >= @startDateAdjusted
							and EndTime <= @endDateAdjusted
						)
		   	 
		INSERT INTO @temp_shiftcalendar (Plant, Machine, StartTime, EndTime, Qualifier, Name, Machine_Full_Name)
		SELECT Plant, Machine, StartTime, EndTime, Qualifier, Name, Machine_Full_Name
		FROM downtimetable
		WHERE StartTime IS NOT NULL and EndTime is not NULL
		
        
        insert into @shifttable (StartTime, EndTime, diff, type, ident)
        --case 1
        select StartTime, EndTime, DATEDIFF(second, StartTime, EndTime), Qualifier, 1
			from @temp_shiftcalendar
			where StartTime >= @StartDate 
            and EndTime <= @EndDate
		
        -- case 2
        union select StartTime, @EndDate, DATEDIFF(second, StartTime, @EndDate), Qualifier, 3
			from @temp_shiftcalendar
			where StartTime >= @StartDate 
            and EndTime > @EndDate
            and StartTime < @EndDate
		
        -- case 3
        union select @StartDate, EndTime, DATEDIFF(second, @StartDate, EndTime), Qualifier, 2
			from @temp_shiftcalendar
			where StartTime < @StartDate 
            and EndTime <= @EndDate
            and EndTime > @StartDate
		
        -- case 4
        union select @StartDate, @EndDate, DATEDIFF(second, @StartDate, @EndDate), Qualifier, 4
			from @temp_shiftcalendar
			where StartTime < @StartDate 
            and EndTime > @EndDate
		
            ;
            
        --for simple cases where
        -- * no special maintenance definitions exists 'P', 'D', 'M'
        -- * no overlapping exists
        -- we simply can sum up 'W' times

        if (
            not exists (select * from @shifttable where type in ('D')) 
            AND not exists (SELECT * FROM @shifttable T1, @shifttable T2 
                where T1.Id <> T2.Id 
                AND ((T1.[StartTime] <= T2.[StartTime] AND T1.[EndTime] >= T2.[EndTime])                                        -- case 1
                    OR (T1.[StartTime] <= T2.[StartTime] AND T1.[EndTime] < T2.[EndTime] AND T1.[EndTime] > T2.[StartTime])     -- case 2
                    OR (T1.[StartTime] > T2.[StartTime] AND T1.[EndTime] >= T2.[EndTime] AND T1.[StartTime] < T2.[EndTime])     -- case 3
                    OR (T1.[StartTime] > T2.[StartTime] AND T1.[EndTime] < T2.[EndTime])                                        -- case 4
                )))
        BEGIN
            select @WorkingTimeCVSInSeconds=isnull(sum(diff),0) from @shifttable where type in ('W', 'P', 'M','B');
        END
    -- End simple use cases
    --*********************************************************************************
	
        ELSE
        BEGIN
            select @WorkingTimeCVSInSeconds=dbo.GetWorkingTimeCVSInSeconds_V1(@Machine, @StartDate, @EndDate);
        END
	
        RETURN @WorkingTimeCVSInSeconds; 
    END;
	
	
	
GO	
