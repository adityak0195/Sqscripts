--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_GetModulesToCalculateKPIs';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_GetModulesToCalculateKPIs'))
drop FUNCTION KPI_CALCULATOR_GetModulesToCalculateKPIs;
GO
CREATE FUNCTION KPI_CALCULATOR_GetModulesToCalculateKPIs()
RETURNS @table TABLE (	
	plant varchar(255), 
	area varchar(255), 
	machine varchar(255), 
	module varchar(255), 
	station varchar(255), 
	type varchar(255), 
	offset float,
    serverTimeZoneDB varchar(255)   
	)
BEGIN;
    
return;
	
END;

GO


