--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSDlpRawDataExtended';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlpRawDataExtended'))
drop FUNCTION GetCVSDlpRawDataExtended;
GO
CREATE FUNCTION GetCVSDlpRawDataExtended
	(@StartDate DateTime2,
	@EndDate DateTime2,
	@machine varchar(255))
RETURNS @table TABLE (
	ProductionTimeStart datetime2,
	ProductionTimeEnd datetime2,
	OrderNumber varchar(255),
	PartNumber varchar(255),
	NumberOfParts int,
	ProcessingTimeInSecCO float,
	PlannedNumberOfWorkers int,
	ProcessingTimeInSecCOPerWorker float,
	WorkingTimeInSeconds float
	)
BEGIN;



	insert into @table (ProductionTimeEnd, OrderNumber, PartNumber, NumberOfParts, ProcessingTimeInSecCO, PlannedNumberOfWorkers, ProcessingTimeInSecCOPerWorker)
	select ProductionTime, OrderNumber, PartNumber, NumberOfParts, ProcessingTimeInSecCO, PlannedNumberOfWorkers, ProcessingTimeInSecCOPerWorker from GetCVSDlpRawData(@StartDate, @EndDate, @machine);


	DECLARE @tablecursor CURSOR;
	DECLARE @ProductionTimeEnd datetime2;
	DECLARE @ProductionTimeStart datetime2;
	
	select @ProductionTimeEnd=min(ProductionTimeEnd) from @table;
	select @ProductionTimeStart=max(ProductionTime) from smartKPI where Machine = @machine and ProductionTime < @ProductionTimeEnd;
	update @table set ProductionTimeStart = dateadd(second,1,@ProductionTimeStart) where ProductionTimeEnd = @ProductionTimeEnd;
	

	SET @tablecursor = CURSOR FOR SELECT ProductionTimeEnd from @table where ProductionTimeStart is null;

	OPEN @tablecursor;
		FETCH NEXT FROM @tablecursor into @ProductionTimeEnd
	
		WHILE @@FETCH_STATUS = 0
		BEGIN;

			select @ProductionTimeStart=max(ProductionTimeEnd) from @table where ProductionTimeEnd < @ProductionTimeEnd;
			update @table set ProductionTimeStart = @ProductionTimeStart where ProductionTimeEnd = @ProductionTimeEnd;

			FETCH NEXT FROM @tablecursor into @ProductionTimeEnd
		END;
	CLOSE @tablecursor;
	DEALLOCATE @tablecursor;

	update @table set WorkingTimeInSeconds = dbo.GetWorkingTimeCVSInSeconds(@machine, ProductionTimeStart, ProductionTimeEnd);
	

	return;
END;
GO
--select * from dbo.GetCVSDlpRawDataExtended('2019-11-01 00:00:00', '2019-11-05 00:00:00', 'KBLisLaa6MachineThing')

