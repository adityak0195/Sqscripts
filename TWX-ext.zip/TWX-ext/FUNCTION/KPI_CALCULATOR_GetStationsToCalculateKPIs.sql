--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_GetStationsToCalculateKPIs';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_GetStationsToCalculateKPIs'))
drop FUNCTION KPI_CALCULATOR_GetStationsToCalculateKPIs;
GO
CREATE FUNCTION KPI_CALCULATOR_GetStationsToCalculateKPIs()
RETURNS @table TABLE (	
	plant varchar(255), 
	area varchar(255), 
	machine varchar(255), 
	module varchar(255), 
	station varchar(255), 
	type varchar(255), 
	offset float,
    serverTimeZoneDB varchar(255) 
	)
BEGIN;
	insert into @table (		
		plant,
        area,
        machine,
        module,
        station,
        type,
        offset,
        serverTimeZoneDB
		)
    select                                                         
        isnull(planttemplate.Machine,'NULL')                       
        ,'NULL' as area                                                 
        ,isnull(machine.Machine,'NULL')                            
        ,'NULL' as module                                                   
        ,isnull(station.Machine,'NULL')                            
        ,isnull(station.PropertySubKey2,'NULL')                    
        ,isnull(offset.FloatValue, 0)            
        ,isnull(serverTimeZoneDB.TextValue, 'Central European Standard Time') as serverTimeZoneDB                              
    from                                                           
        smartKPIMachineKeyValueData as planttemplate,                 
        smartKPIMachineKeyValueData as machine,                       
        smartKPIMachineKeyValueData as station,                       
        smartKPIMachineKeyValueData as offset,
        smartKPIMachineKeyValueData as isActive,
        smartKPIMachineKeyValueData as serverTimeZoneDB                         
    where                                                          
        planttemplate.TextValue = 'KBLocalPlantThingTemplate'      
        and machine.PropertyKey = 'KBPlantThing'                   
        and planttemplate.Machine = machine.TextValue              
        and isNull(machine.TextValue,'') != ''                     
        and machine.PropertySubKey2 = 'KBLocalMachineThingTemplate'
        and machine.Machine = station.TextValue                    
        and station.PropertyKey = 'KBLocalLineThing'               
        and station.UpdateTime > dateadd(month,-1,getdate())       
        and station.Machine = isActive.Machine                    
        and isActive.PropertyKey = 'isActive'               
        and isActive.FloatValue = 1       
        and offset.Machine = planttemplate.Machine                 
        and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'
        and serverTimeZoneDB.Machine = 'KBTimeHelperThing'
        and serverTimeZoneDB.PropertyKey = 'ServerTimeZoneDB';  
    
return;
	
END;

GO


