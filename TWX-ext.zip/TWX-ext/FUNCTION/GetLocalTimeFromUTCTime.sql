--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetLocalTimeFromUTCTime';
--------------------------------------------------------------
---

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetLocalTimeFromUTCTime'))
drop FUNCTION GetLocalTimeFromUTCTime;
GO
CREATE FUNCTION GetLocalTimeFromUTCTime
	(@dateTime DateTime2)
RETURNS datetime2
BEGIN
	declare @timezone varchar(255);
	select top(1) @timezone=timezone from 
		(SELECT isnull([TextValue],'Central European Standard Time') as timezone, 1 as id
			FROM [smartKPIMachineKeyValueData]
		where Machine = 'KBTimeHelperThing'
		and PropertyKey = 'ServerTimeZoneDB'
		union select 'Central European Standard Time',2)x
	order by id;

	return dateadd(minute,DATEDIFF(minute, @dateTime AT TIME ZONE @timezone, @dateTime AT TIME ZONE 'UTC'),@dateTime);
END;
go