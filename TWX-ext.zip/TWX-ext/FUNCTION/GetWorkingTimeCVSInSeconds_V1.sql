--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetWorkingTimeCVSInSeconds_V1';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetWorkingTimeCVSInSeconds_V1'))
drop FUNCTION GetWorkingTimeCVSInSeconds_V1;
GO
CREATE FUNCTION  [dbo].[GetWorkingTimeCVSInSeconds_V1]   
( @Machine varchar(255),
  @StartDate DateTime2,
  @EndDate DateTime2
)  
RETURNS int  
	BEGIN
	
		declare @tableWithoutDowntimes table (StartTime datetime2, EndTime datetime2, diff bigint, type varchar(255));
		declare @tableDowntimes table (StartTime datetime2, EndTime datetime2, diff bigint, type varchar(255));
		Declare @cursorDowntimes CURSOR;
		DECLARE @StartDowntime datetime2;
		DECLARE @EndDowntime datetime2;
		DECLARE @WorkingTimeCVSInSeconds int;
		declare @SAPMachine varchar(255);
		
		SELECT @SAPMachine=[TextValue]
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @Machine
		  and PropertyKey = 'SAPWorkcenterNumber';

with timePeriodsWithoutDowntimes as ( 
			select
				Id, StartTime, EndTime,
				ROW_NUMBER() over (order by StartTime, EndTime) as rn
			from shiftCalendar
			where StartTime between @StartDate and @EndDate
			and Machine = @SAPMachine
			and Qualifier != 'D'
		), cteWithoutDowntimes as (
			select Id, StartTime, EndTime, rn, 1 as GroupId
			from timePeriodsWithoutDowntimes
			where rn = 1
			union all
		select -- recursive sql query
			p2.Id,
			case
				when (p1.StartTime between p2.StartTime and p2.EndTime) then p2.StartTime
				--when (p2.StartTime between p1.StartTime and p1.EndTime) then p1.StartTime
				when (p1.StartTime < p2.StartTime and p1.EndTime > p2.EndTime) then p1.StartTime
				when (p1.StartTime > p2.StartTime and p1.EndTime < p2.EndTime) then p2.StartTime
				else p2.StartTime
			end as StartTime,
			case
				when (p1.EndTime between p2.StartTime and p2.EndTime) then p2.EndTime
				when (p2.EndTime between p1.StartTime and p1.EndTime) then p1.EndTime
				when (p1.StartTime < p2.StartTime and p1.EndTime > p2.EndTime) then p1.EndTime
				when (p1.StartTime > p2.StartTime and p1.EndTime < p2.EndTime) then p2.EndTime
				else p2.EndTime
			end as EndTime,
			p2.rn,
			case when
				(p1.StartTime between p2.StartTime and p2.EndTime) or
				--(p1.EndTime between p2.StartTime and p2.EndTime) or
				(p1.StartTime <= p2.StartTime and p1.EndTime >= p2.EndTime) or
				(p1.StartTime >= p2.StartTime and p1.EndTime <= p2.EndTime)
				then
				p1.GroupId
				else
				(p1.GroupId+1)
			end as GroupId
			from cteWithoutDowntimes p1 -- referencing CTE itself
			inner join timePeriodsWithoutDowntimes p2 on (p1.rn+1) = p2.rn
		), groupedTimesWithoutDowntimes as (
		select 
			GroupId, 
			min(case when StartTime < @StartDate then @StartDate else StartTime end) StartTime, 
			max(case when EndTime > @EndDate then @EndDate else EndTime end) EndTime, 
			DATEDIFF(second, min(case when StartTime < @StartDate then @StartDate else StartTime end), max(case when EndTime > @EndDate then @EndDate else EndTime end)) as diff,
			'Uptime' as type
		from cteWithoutDowntimes
		group by GroupId
)
		insert into @tableWithoutDowntimes (StartTime, EndTime, diff, type)
		select StartTime, EndTime, diff, type
		from groupedTimesWithoutDowntimes
		OPTION (MAXRECURSION 0);

		with timePeriodsDowntimes as ( 
			select
				Id, StartTime, EndTime,
				ROW_NUMBER() over (order by StartTime, EndTime) as rn
			from shiftCalendar
			where (StartTime between @StartDate and @EndDate or EndTime between @StartDate and @EndDate)  
			and Machine = @SAPMachine
			and Qualifier = 'D'
		), cteDowntimes as (
			select Id, StartTime, EndTime, rn, 1 as GroupId
			from timePeriodsDowntimes
			where rn = 1
			union all
		select -- recursive sql query
			p2.Id,
			case
				when (p1.StartTime between p2.StartTime and p2.EndTime) then p2.StartTime
				--when (p2.StartTime between p1.StartTime and p1.EndTime) then p1.StartTime
				when (p1.StartTime < p2.StartTime and p1.EndTime > p2.EndTime) then p1.StartTime
				when (p1.StartTime > p2.StartTime and p1.EndTime < p2.EndTime) then p2.StartTime
				else p2.StartTime
			end as StartTime,
			case
				when (p1.EndTime between p2.StartTime and p2.EndTime) then p2.EndTime
				when (p2.EndTime between p1.StartTime and p1.EndTime) then p1.EndTime
				when (p1.StartTime < p2.StartTime and p1.EndTime > p2.EndTime) then p1.EndTime
				when (p1.StartTime > p2.StartTime and p1.EndTime < p2.EndTime) then p2.EndTime
				else p2.EndTime
			end as EndTime,
			p2.rn,
			case when
				(p1.StartTime between p2.StartTime and p2.EndTime) or
				--(p1.EndTime between p2.StartTime and p2.EndTime) or
				(p1.StartTime <= p2.StartTime and p1.EndTime >= p2.EndTime) or
				(p1.StartTime >= p2.StartTime and p1.EndTime <= p2.EndTime)
				then
				p1.GroupId
				else
				(p1.GroupId+1)
			end as GroupId
			from cteDowntimes p1 -- referencing CTE itself
			inner join timePeriodsDowntimes p2 on (p1.rn+1) = p2.rn
		), groupedTimesDowntimes as (
		select 
			GroupId, 
			min(case when StartTime < @StartDate then @StartDate else StartTime end) StartTime, 
			max(case when EndTime > @EndDate then @EndDate else EndTime end) EndTime, 
			DATEDIFF(second, min(case when StartTime < @StartDate then @StartDate else StartTime end), max(case when EndTime > @EndDate then @EndDate else EndTime end)) as diff,
			'Downtime' as type
		from cteDowntimes
		group by GroupId
)
		insert into @tableDowntimes (StartTime, EndTime, diff, type)
		select StartTime, EndTime, diff, type
		from groupedTimesDowntimes
		OPTION (MAXRECURSION 0);



		SET @cursorDowntimes = CURSOR FOR
		select StartTime, EndTime from @tableDowntimes;

		OPEN @cursorDowntimes;
			FETCH NEXT FROM @cursorDowntimes into @StartDowntime, @EndDowntime;
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				delete from @tableWithoutDowntimes 
					where StartTime >= @StartDowntime 
					and EndTime <= @EndDowntime;
				update @tableWithoutDowntimes set EndTime = @StartDowntime 
					where StartTime < @StartDowntime 
					and EndTime <= @EndDowntime 
					and EndTime >  @StartDowntime;
				update @tableWithoutDowntimes set StartTime = @EndDowntime 
					where StartTime >= @StartDowntime 
					and EndTime > @EndDowntime
					and StartTime < @EndDowntime;
				insert into @tableWithoutDowntimes (StartTime, EndTime) 
					select StartTime, @StartDowntime from @tableWithoutDowntimes
					where StartTime < @StartDowntime and EndTime > @EndDowntime;
				insert into @tableWithoutDowntimes (StartTime, EndTime) 
					select @EndDowntime, EndTime from @tableWithoutDowntimes
					where StartTime < @StartDowntime and EndTime > @EndDowntime;
				delete from @tableWithoutDowntimes 
					where StartTime < @StartDowntime and EndTime > @EndDowntime;

				FETCH NEXT FROM @cursorDowntimes into @StartDowntime, @EndDowntime;
			END;
		CLOSE @cursorDowntimes;
		DEALLOCATE @cursorDowntimes;

		update @tableWithoutDowntimes set diff = DATEDIFF(second, StartTime, EndTime);
		select @WorkingTimeCVSInSeconds=isnull(sum(diff),0) from @tableWithoutDowntimes;

	
        RETURN @WorkingTimeCVSInSeconds; 
    END;
	
	
GO	
