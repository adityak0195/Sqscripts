--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetPerformanceRailWorker';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPerformanceRailWorker'))
drop FUNCTION GetPerformanceRailWorker;
GO
CREATE FUNCTION GetPerformanceRailWorker
	(@StartDateTime DateTime2,
	@CalculationPeriodInMinutes bigint,
	@CalculateNumerOfCycles int,
	@CalculationBase varchar(255),
	@JobName varchar(255),
	@machines varchar(255),
	@doTraceLogging Bit)
RETURNS @table TABLE ( 
	Machine varchar(255), 
	KPIName varchar(255), 
	KPICalculationBase varchar(255), 
	KPIDateTime DateTime2,  
	KPIDateTimeEndOfCalculation DateTime2,
	KPIFloatValue float,
	LoggingStatus varchar(512),
	LoggingData varchar(512),
	LoggingIsProductive Bit,
	LoggingIsShift Bit,
	LoggingSecondsInStatus bigint,
	LoggingSumSeconds float)  
BEGIN;
	Declare @StartDateTimeFromProcInput DateTime2;
	set @StartDateTimeFromProcInput = @StartDateTime;

	declare @LogText varchar(1024);
	--declare @logcounter int = 0;
	
	Declare @KPINameEfficiencyRail varchar(255) = 'EfficiencyRail';
	Declare @KPINameEfficiencyRailShiftAdjustedIO varchar(255) = 'EfficiencyRailShiftAdjustedIO';
	Declare @KPINameEfficiencyRailShiftAdjustedNIO varchar(255) = 'EfficiencyRailShiftAdjustedNIO';
	Declare @PerfKPIName varchar(255) = 'PerformanceRail';
	Declare @EffiKPIName varchar(255) = 'EfficiencyRail';
	Declare @KPINameShift varchar(255) = 'PerformanceRailShiftAdjusted';
	Declare @KPINameShiftProd varchar(255) = 'PerformanceRailShiftProdAdjusted';
	Declare @KPINameShiftProdIO varchar(255) = 'PerformanceRailShiftProdAdjustedIO';
	Declare @KPINameShiftProdNIO varchar(255) = 'PerformanceRailShiftProdAdjustedNIO';
	Declare @KPINameProd varchar(255) = 'PerformanceRailProdAdjusted';
	Declare @KPICalculationBase varchar(255) = 'All';
	Declare @KPINameShiftEffi varchar(255) = 'EfficiencyRailShiftAdjusted';
	Declare @KPINameIOEffi varchar(255) = 'EfficiencyRailIO';
	Declare @KPINameShiftIOEffi varchar(255) = 'EfficiencyRailShiftAdjustedIO';
	Declare @KPINameNIOEffi varchar(255) = 'EfficiencyRailNIO';
	Declare @KPINameShiftNIOEffi varchar(255) = 'EfficiencyRailShiftAdjustedNIO';
	
	Declare @KPIEfficiencyRailShiftIO float;

	Declare @numberOfRows int;
	Declare @CurrentCycles int;
	Declare @currentRow int;
	Declare @machineName varchar(255);
	Declare @getMachines CURSOR;
	Declare @getKPIs CURSOR;
	Declare @StartDatePerCalculationCycle DateTime2;
	Declare @EndDatePerCalculationCycle DateTime2;
	Declare @EndDatePerCalculationCycleFull DateTime2;
	set @CurrentCycles = 0;
	Declare @KPIDateTimeStart DateTime2;
	Declare @KPIDateTimeEnd DateTime2;
	Declare @DateDif bigint;

	Declare @KPIFloatValue float;
	Declare @LastKPIFloatValue float;
	Declare @LastProductionValue float;
	Declare @LastShiftStart DateTime2;
	Declare @LastShiftEnd DateTime2;
	Declare @LastExceptionStart DateTime2;
	Declare @LastExceptionEnd DateTime2;
	Declare @LastExceptionStartTime DateTime2;
	Declare @LastExceptionEndTime DateTime2;
	Declare @LastExceptionStartTimeAfterShift DateTime2;
	Declare @LastExceptionEndTimeAfterShift DateTime2;
	Declare @LastEndTimeShift DateTime2;
	Declare @LastStartTimeShift DateTime2;
	Declare @IsShiftRunning bit = 0;
	Declare @IsExceptionRunning bit = 0;
	Declare @IsExceptionAfterShiftExist bit = 0;
	Declare @IsProductionRunning bit = 0;
	Declare @SumKPIFloatValuePerf float;
	Declare @SumKPIFloatValueEffi float;
	Declare @SumDateDif bigint;
	Declare @ResultKPIFloatValuePerf float = 0.0;
	Declare @ResultKPIFloatValueEffi float = 0.0;
	Declare @KPIIdentifier varchar(20)

	Declare @SumDateDifShift bigint;
	Declare @SumKPIFloatValueShiftPerf float;
	Declare @ResultKPIFloatValueShiftPerf float = 0.0;
	Declare @SumKPIFloatValueShiftEffi float;
	Declare @ResultKPIFloatValueShiftEffi float = 0.0;

	Declare @SumDateDifShiftProd bigint;
	Declare @SumKPIFloatValueShiftProdPerf float;
	Declare @ResultKPIFloatValueShiftProdPerf float = 0.0;
	Declare @SumKPIFloatValueShiftProdEffi float;
	Declare @ResultKPIFloatValueShiftProdEffi float = 0.0;

	Declare @SumDateDifProd bigint;
	Declare @SumKPIFloatValueProdPerf float;
	Declare @ResultKPIFloatValueProdPerf float = 0.0;
	Declare @SumKPIFloatValueProdEffi float;
	Declare @ResultKPIFloatValueProdEffi float = 0.0;
	Declare @SAPMachine varchar(255);
	Declare @MainStation varchar(255);
	
	DECLARE @getStateDefinitions CURSOR;
	Declare @StatusName varchar(255);
	Declare @StatusValue varchar(255);
	Declare @Station varchar(255);
	DECLARE @StatusIdList varchar(max);
	DECLARE @StatusId int;
	DECLARE @productiveTable table (Id int, StatusName varchar(255), Station varchar(255));
	
	
	set @StartDatePerCalculationCycle = datetimefromparts(
		DATEPART(year, @StartDateTimeFromProcInput),
		DATEPART(month, @StartDateTimeFromProcInput),
		DATEPART(day, @StartDateTimeFromProcInput),
		DATEPART(hour, @StartDateTimeFromProcInput),
		DATEPART(minute, @StartDateTimeFromProcInput),
		0,0);

	set @EndDatePerCalculationCycle = DATEADD(minute, @CalculationPeriodInMinutes, @StartDatePerCalculationCycle);
	set @EndDatePerCalculationCycleFull = @EndDatePerCalculationCycle;
	if (@EndDatePerCalculationCycle > getutcdate())
	BEGIN
		set @EndDatePerCalculationCycle = getutcdate();
	END;


	WHILE (@CurrentCycles<@CalculateNumerOfCycles)
	BEGIN

		SET @getMachines = CURSOR FOR 
			SELECT Machine
			  FROM [smartKPIMachineKeyValueData]
			  where Machine = @machines
			  and PropertyKey = 'SAPWorkcenterNumber'
			  and [TextValue] is not null
			  and [TextValue] != '';

		OPEN @getMachines;
			FETCH NEXT FROM @getMachines into @machineName
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				set @SumKPIFloatValuePerf = 0;
				set @SumKPIFloatValueEffi = 0;
				set @SumDateDif = 0;
				set @SumKPIFloatValueShiftPerf = 0;
				set @SumKPIFloatValueShiftEffi = 0;
				set @SumDateDifShift = 0;
				set @SumKPIFloatValueProdPerf = 0;
				set @SumKPIFloatValueProdEffi = 0;
				set @SumDateDifProd = 0;
				set @SumKPIFloatValueShiftProdPerf = 0;
				set @SumKPIFloatValueShiftProdEffi = 0;
				set @SumDateDifShiftProd = 0;
				set @ResultKPIFloatValuePerf = 0;
				set @ResultKPIFloatValueEffi = 0;
				set @ResultKPIFloatValueShiftPerf = 0;
				set @ResultKPIFloatValueShiftEffi = 0;
				set @ResultKPIFloatValueProdPerf = 0;
				set @ResultKPIFloatValueProdEffi = 0;
				set @ResultKPIFloatValueShiftProdPerf = 0;
				set @ResultKPIFloatValueShiftProdEffi = 0;
				
				SET @getStateDefinitions = CURSOR for 
					SELECT StatusName, Station 
						FROM smartKPIProductiveStateDefinition 
						where Machine = @machineName 
						order by Id;

				OPEN @getStateDefinitions;
					FETCH NEXT FROM @getStateDefinitions into @StatusName, @Station;
					WHILE @@FETCH_STATUS = 0
					BEGIN;
						insert into @productiveTable (Id, StatusName, Station)
						select TOP (1) Id, @StatusName, @Station
							FROM [smartKPIMachineStatusData]
							where Status = @StatusName
							and Machine = @Station
							and StatusTime < @StartDatePerCalculationCycle
							order by StatusTime desc;
									 
						FETCH NEXT FROM @getStateDefinitions into @StatusName, @Station;
					END;
				CLOSE @getStateDefinitions;
				DEALLOCATE @getStateDefinitions;

				SELECT @MainStation=[TextValue]
					FROM [smartKPIMachineKeyValueData]
					where PropertyKey = 'MainStationForLineStatus'
					and Machine = @machineName;

				
				set @LastKPIFloatValue = (select top (1) [MachineData] from [smartKPIMachineFloatData] 
					where [Machine] = @MainStation
					and [MachineDataType] = 'PERFORMANCE' 
					and [MachineTime] < @StartDatePerCalculationCycle 
					order by [MachineTime] desc, CreationTime desc);
					
				if (@LastKPIFloatValue is null)
					set @LastKPIFloatValue = 100;
				
				set @StatusIdList = NULL;
				Select @StatusIdList=COALESCE(@StatusIdList + ', ' + convert(varchar(20), Id), convert(varchar(20), Id)) 
						From @productiveTable;
				select @IsProductionRunning=dbo.IsRailMachineProductive(@machineName, @StatusIdList);

				SELECT @SAPMachine=[TextValue]
				  FROM [smartKPIMachineKeyValueData]
				  where Machine = @machineName
				  and PropertyKey = 'SAPWorkcenterNumber';
				
				SELECT top(1) @LastShiftStart=[StartTime], @LastShiftEnd=[EndTime]  
					from [shiftCalendar]
					where [shiftCalendar].[Machine] = @SAPMachine
					and [shiftCalendar].[StartTime]  < @StartDatePerCalculationCycle
					and [Qualifier] not in ('E','E-T')
					order by [StartTime] desc;
				
				if (@LastShiftEnd is null or @LastShiftEnd < @StartDatePerCalculationCycle)
					set @IsShiftRunning = 0;
				else
					set @IsShiftRunning = 1;
				SELECT top(1) @LastExceptionStart=[StartTime], @LastExceptionEnd=[EndTime]  
				   from [shiftCalendar]
				   where [shiftCalendar].[Machine] = @SAPMachine
		           and [shiftCalendar].[StartTime]  < @StartDatePerCalculationCycle
		           and [Qualifier] = 'E'
		           order by [StartTime] desc;
		
				if (@LastExceptionEnd is null or @LastExceptionEnd <= @StartDatePerCalculationCycle)
					set @IsExceptionRunning = 0;
				else
					set @IsExceptionRunning = 1;

			    SELECT top(1) @LastExceptionStartTimeAfterShift = [StartTime], @LastExceptionEndTimeAfterShift = [EndTime]  
				   from [shiftCalendar]
				   where [shiftCalendar].[Machine] = @SAPMachine
		           and [shiftCalendar].[EndTime]  < @EndDatePerCalculationCycle 
		           and [Qualifier] = 'E'
		           order by [EndTime] desc;

				SELECT top(1) @LastStartTimeShift = [StartTime], @LastEndTimeShift = [EndTime]
				from [shiftCalendar]
				where [shiftCalendar].[Machine] = @SAPMachine  COLLATE database_default
				and [shiftCalendar].[EndTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
				and [Qualifier] = 'W'
				order by [EndTime] desc;

				if (@LastEndTimeShift is null or @LastExceptionEndTimeAfterShift is null or @LastExceptionEndTimeAfterShift >= @LastEndTimeShift)
				    set @IsExceptionAfterShiftExist = 1;
					else
					set @IsExceptionAfterShiftExist = 0;

				set @KPIDateTimeStart = @StartDatePerCalculationCycle;
				
				insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
					select Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds 
						from dbo.GetPlannedProductionRailWorker(@StartDatePerCalculationCycle,@CalculationPeriodInMinutes,1,@CalculationBase, @JobName, @machineName, @doTraceLogging);
				
				select @KPIEfficiencyRailShiftIO=[KPIFloatValue] from @table 
								where [Machine] = @machineName
								and [KPIName] = @KPINameEfficiencyRailShiftAdjustedIO 
								and [KPICalculationBase] = @CalculationBase
								and [KPIDateTime] = @StartDatePerCalculationCycle; 
				

				if (@doTraceLogging = 1)
				BEGIN
							--Machine varchar(255), 
							--KPIName varchar(255), 
							--KPICalculationBase varchar(255), 
							--KPIDateTime DateTime2,  
							--KPIDateTimeEndOfCalculation DateTime2,
							--KPIFloatValue float,
							--LoggingStatus varchar(512),
							--LoggingData varchar(512),
							--LoggingIsProductive Bit,
							--LoggingIsShift Bit,
							--LoggingSecondsInStatus bigint,
							--LoggingSumSeconds float
					--insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
					--	LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
					--	select @machineName, @KPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeStart, null,
					--		Id, StatusName+ Station, @IsProductive, @IsShiftRunning, @DateDif, @SumKPIFloatValueShift/100
					--	from @productiveTable;
					--insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
					--	LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
					--	values (@machineName, @KPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeStart, null,
					--		@StatusIdList, NULL, @IsProductive, @IsShiftRunning, @DateDif, @SumKPIFloatValueShift/100);
					insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
						LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
						select @machineName, @EffiKPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeStart, Id,
							[Status]+' ('+[Machine]+')', [SubStatus], NULL, NULL, NULL, NULL
						from [smartKPIMachineStatusData]
						where Id in (SELECT convert(int, value) FROM STRING_SPLIT(@StatusIdList, ','));
				END;

				SET @getKPIs = CURSOR FOR 
					select KPIDateTime, Id, KPIFloatValue, Identifier COLLATE database_default, Machine COLLATE database_default, Status COLLATE database_default from
						(select CreationTime, [MachineTime] KPIDateTime, 1 as Id, [MachineData] KPIFloatValue, 'Perf' COLLATE database_default as Identifier, Machine COLLATE database_default as Machine, '-' COLLATE database_default as Status from [smartKPIMachineFloatData] 
												where [Machine] = @MainStation COLLATE database_default 
												and [MachineDataType] = 'PERFORMANCE' COLLATE database_default 
												and [MachineTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						union
						select [CreationTime] CreationTime, [StatusTime] KPIDateTime, Id, -1, 'Prod' Identifier, Machine, Status from [smartKPIMachineStatusData]
												where [Machine] in (select Station COLLATE database_default from @productiveTable) 
												and [Status] in (select StatusName COLLATE database_default from @productiveTable)  
												and [StatusTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
						union
						SELECT [StartTime],[StartTime], 1, 1, 'ShiftStart', Machine, '-' 
											from [shiftCalendar]
											where [shiftCalendar].[Machine] = @SAPMachine  COLLATE database_default
											and [shiftCalendar].[StartTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
											and [Qualifier] = 'W'
						union
						SELECT [StartTime],[StartTime], 2, 2, 'ExceptionStart', Machine, '-' 
											from [shiftCalendar]
											where [shiftCalendar].[Machine] = @SAPMachine  COLLATE database_default
											and  [shiftCalendar].[StartTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
											and [Qualifier] = 'E'
					   union
					   SELECT [EndTime],[EndTime], 1, 1, 'ExceptionEnd' , Machine, '-'
											from [shiftCalendar]
											where [shiftCalendar].[Machine] = @SAPMachine  COLLATE database_default
											and  [shiftCalendar].[EndTime]  between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
											and [Qualifier] = 'E'
						union
						SELECT [EndTime],[EndTime], 0, 0, 'ShiftEnd' , Machine, '-'
											from [shiftCalendar]
											where [shiftCalendar].[Machine] = @SAPMachine  COLLATE database_default
											and [shiftCalendar].[EndTime] between @StartDatePerCalculationCycle and @EndDatePerCalculationCycle
											and [Qualifier] = 'W'
						) x
					order by KPIDateTime, CreationTime, Id, KPIFloatValue; 					


					
		
				OPEN @getKPIs;
					FETCH NEXT FROM @getKPIs into @KPIDateTimeEnd, @StatusId, @KPIFloatValue, @KPIIdentifier, @Station, @StatusName
					WHILE @@FETCH_STATUS = 0
					BEGIN;
					
						--set @logcounter = @logcounter + 1;

						if (@LastKPIFloatValue is not null)
						BEGIN
							set @DateDif = DATEDIFF_BIG(second, @KPIDateTimeStart, @KPIDateTimeEnd);
							set @SumKPIFloatValuePerf = @SumKPIFloatValuePerf + (@DateDif * @LastKPIFloatValue);
							set @SumKPIFloatValueEffi = @SumKPIFloatValueEffi + (@DateDif * 100);
							set @SumDateDif = @SumDateDif + @DateDif;
							
							if (@IsShiftRunning = 1 and @IsExceptionRunning = 0)
							BEGIN
								set @SumKPIFloatValueShiftPerf = @SumKPIFloatValueShiftPerf + (@DateDif * @LastKPIFloatValue);
								set @SumKPIFloatValueShiftEffi = @SumKPIFloatValueShiftEffi + (@DateDif * 100);
								set @SumDateDifShift = @SumDateDifShift + @DateDif;
							END;
							if (@IsProductionRunning = 1 and @IsExceptionRunning = 0)
							BEGIN
								set @SumKPIFloatValueProdPerf = @SumKPIFloatValueProdPerf + (@DateDif * @LastKPIFloatValue);
								set @SumKPIFloatValueProdEffi = @SumKPIFloatValueProdEffi + (@DateDif * 100);
								set @SumDateDifProd = @SumDateDifProd + @DateDif;
							END;
							if (@IsShiftRunning = 1 and @IsProductionRunning = 1 and @IsExceptionRunning = 0)
							BEGIN
								set @SumKPIFloatValueShiftProdPerf = @SumKPIFloatValueShiftProdPerf + (@DateDif * @LastKPIFloatValue);
								set @SumKPIFloatValueShiftProdEffi = @SumKPIFloatValueShiftProdEffi + (@DateDif * 100);
								set @SumDateDifShiftProd = @SumDateDifShiftProd + @DateDif;
							END;


							if (@doTraceLogging = 1)
							BEGIN
								insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
									LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
									values (@machineName, @PerfKPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeEnd, @LastKPIFloatValue,
										@KPIIdentifier, NULL, @IsProductionRunning, @IsShiftRunning, @DateDif, @SumKPIFloatValueShiftProdPerf/100);
								if (@KPIIdentifier = 'Prod')
									insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
										LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
										select @machineName, @EffiKPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeEnd, @StatusId,
											[Status]+' ('+[Machine]+', IsRailMachineProductive('+@machineName+', '+@StatusIdList+'))', [SubStatus], @IsProductionRunning, @IsShiftRunning, @DateDif, @SumKPIFloatValueProdEffi/100
										from [smartKPIMachineStatusData]
										where Id = @StatusId;
								if (@KPIIdentifier != 'Prod' and @KPIIdentifier != 'Perf')
									insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
										LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
										values (@machineName, @EffiKPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeEnd, @StatusId,
											@KPIIdentifier+' ('+@Station+')', NULL, @IsProductionRunning, @IsShiftRunning, @DateDif, @SumKPIFloatValueProdEffi/100);
							END;
							

							IF(@KPIIdentifier = 'ExceptionStart')
								set @IsExceptionRunning = 1;
						    
							IF(@KPIIdentifier = 'ExceptionEnd')
								set @IsExceptionRunning = 0;
								
							IF (@KPIIdentifier = 'ShiftStart' and @IsExceptionRunning = 0)
								set @IsShiftRunning = 1;
						    ELSE IF (@KPIIdentifier = 'ShiftStart'  and @IsExceptionRunning = 1)
								set @IsShiftRunning = 0;
							ELSE IF (@KPIIdentifier = 'ShiftEnd')
								set @IsShiftRunning = 0;
						    ELSE IF (@KPIIdentifier = 'ExceptionEnd' and @IsExceptionRunning = 0 and (@LastExceptionEndTimeAfterShift < @LastEndTimeShift))
								set @IsShiftRunning = 1;
						    ELSE IF (@KPIIdentifier = 'ExceptionEnd' and @IsExceptionRunning = 1)
								set @IsShiftRunning = 0;
						    ELSE IF (@KPIIdentifier = 'ExceptionStart')
								set @IsShiftRunning = 0;
							else if (@KPIIdentifier = 'Prod')
							BEGIN
								update @productiveTable set Id = @StatusId where StatusName = @StatusName and Station = @Station;
								set @StatusIdList = NULL;
								Select @StatusIdList=COALESCE(@StatusIdList + ', ' + convert(varchar(20), Id), convert(varchar(20), Id)) 
										From @productiveTable;
								select @IsProductionRunning=dbo.IsRailMachineProductive(@machineName, @StatusIdList);
							END;
							else if (@KPIIdentifier = 'Perf')
								set @LastKPIFloatValue = @KPIFloatValue;
								
							set @KPIDateTimeStart = @KPIDateTimeEnd;
						END;
						FETCH NEXT FROM @getKPIs into @KPIDateTimeEnd, @StatusId, @KPIFloatValue, @KPIIdentifier, @Station, @StatusName;
					END;
				CLOSE @getKPIs;
				DEALLOCATE @getKPIs;

				if (@LastKPIFloatValue is not null)
				BEGIN
					set @DateDif = DATEDIFF_BIG(second, @KPIDateTimeStart, @EndDatePerCalculationCycle);
					set @SumKPIFloatValuePerf = @SumKPIFloatValuePerf + (@DateDif * @LastKPIFloatValue);
					set @SumKPIFloatValueEffi = @SumKPIFloatValueEffi + (@DateDif * 100);
					set @SumDateDif = @SumDateDif + @DateDif;
					if (@IsShiftRunning = 1 and @IsExceptionRunning = 0)
					BEGIN
						set @SumKPIFloatValueShiftPerf = @SumKPIFloatValueShiftPerf + (@DateDif * @LastKPIFloatValue);
						set @SumKPIFloatValueShiftEffi = @SumKPIFloatValueShiftEffi + (@DateDif * 100);
						set @SumDateDifShift = @SumDateDifShift + @DateDif;
					END;
					if (@IsProductionRunning = 1 and @IsExceptionRunning = 0)
					BEGIN
						set @SumKPIFloatValueProdPerf = @SumKPIFloatValueProdPerf + (@DateDif * @LastKPIFloatValue);
						set @SumKPIFloatValueProdEffi = @SumKPIFloatValueProdEffi + (@DateDif * 100);
						set @SumDateDifProd = @SumDateDifProd + @DateDif;
					END;
					if (@IsShiftRunning = 1 and @IsProductionRunning = 1 and @IsExceptionRunning = 0)
					BEGIN
						set @SumKPIFloatValueShiftProdPerf = @SumKPIFloatValueShiftProdPerf + (@DateDif * @LastKPIFloatValue);
						set @SumKPIFloatValueShiftProdEffi = @SumKPIFloatValueShiftProdEffi + (@DateDif * 100);
						set @SumDateDifShiftProd = @SumDateDifShiftProd + @DateDif;
					END;
					
					IF (@SumDateDif > 0)
						set @ResultKPIFloatValuePerf = @SumKPIFloatValuePerf / @SumDateDif;
					IF (@SumDateDifShift > 0)
						set @ResultKPIFloatValueShiftPerf = @SumKPIFloatValueShiftPerf / @SumDateDifShift;
					IF (@SumDateDifProd > 0)
						set @ResultKPIFloatValueProdPerf = @SumKPIFloatValueProdPerf / @SumDateDifProd;
					IF (@SumDateDifProd > 0)
						set @ResultKPIFloatValueProdEffi = @SumKPIFloatValueProdEffi / @SumDateDif;
					IF (@SumDateDifShiftProd > 0)
						set @ResultKPIFloatValueShiftProdPerf = @SumKPIFloatValueShiftProdPerf / @SumDateDifShiftProd;
					IF (@SumDateDifShiftProd > 0)
						set @ResultKPIFloatValueShiftProdEffi = @SumKPIFloatValueShiftProdEffi / @SumDateDif;
					
					if (@doTraceLogging = 1)
					BEGIN
						insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
							LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
							values (@machineName, @PerfKPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeEnd, @LastKPIFloatValue,
								@KPIIdentifier, NULL, @IsProductionRunning, @IsShiftRunning, @DateDif, @SumKPIFloatValueShiftProdPerf/100);
						if (@KPIIdentifier = 'Prod')
							insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
								LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
								select @machineName, @EffiKPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeEnd, @StatusId,
									[Status]+' ('+[Machine]+', IsRailMachineProductive('+@machineName+', '+@StatusIdList+'))', [SubStatus], @IsProductionRunning, @IsShiftRunning, @DateDif, @SumKPIFloatValueProdEffi/100
								from [smartKPIMachineStatusData]
								where Id = @StatusId;
						if (@KPIIdentifier != 'Prod' and @KPIIdentifier != 'Perf')
							insert into @table (Machine, KPIName, KPICalculationBase, KPIDateTime, KPIDateTimeEndOfCalculation, KPIFloatValue, 
								LoggingStatus, LoggingData, LoggingIsProductive, LoggingIsShift, LoggingSecondsInStatus, LoggingSumSeconds) 
								values (@machineName, @EffiKPIName, 'TraceLogging', @KPIDateTimeStart, @KPIDateTimeEnd, @StatusId,
									@KPIIdentifier+' ('+@Station+')', NULL, @IsProductionRunning, @IsShiftRunning, @DateDif, @SumKPIFloatValueProdEffi/100);
					END;
					
					--Effi
					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @EffiKPIName, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @ResultKPIFloatValueProdEffi);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameShiftEffi, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @ResultKPIFloatValueShiftProdEffi);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameShiftIOEffi, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @SumKPIFloatValueShiftProdEffi / 100);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameShiftNIOEffi, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @SumDateDifShift - (@SumKPIFloatValueShiftProdEffi / 100));
							
					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameIOEffi, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @SumKPIFloatValueProdEffi / 100);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameNIOEffi, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @SumDateDif - (@SumKPIFloatValueProdEffi / 100));


					--Perf
					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @PerfKPIName, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @ResultKPIFloatValuePerf);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameShift, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @ResultKPIFloatValueShiftPerf);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameProd, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @ResultKPIFloatValueProdPerf);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameShiftProd, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @ResultKPIFloatValueShiftProdPerf);
							
					if (@SumKPIFloatValueShiftProdEffi is null)
						set @SumKPIFloatValueShiftProdEffi = 0;
							
					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameShiftProdIO, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, @SumKPIFloatValueShiftProdPerf / 100);

					insert into @table ([Machine], [KPIName], [KPICalculationBase], [KPIDateTime], KPIDateTimeEndOfCalculation, [KPIFloatValue]) 
						values (@machineName, @KPINameShiftProdNIO, @CalculationBase, @StartDatePerCalculationCycle, @EndDatePerCalculationCycle, (@SumKPIFloatValueShiftProdEffi / 100) - (@SumKPIFloatValueShiftProdPerf / 100));
							
				END;

				FETCH NEXT FROM @getMachines into @machineName;
			END;
		CLOSE @getMachines;
		DEALLOCATE @getMachines;

		set @StartDatePerCalculationCycle = DATEADD(minute, -1* @CalculationPeriodInMinutes, @StartDatePerCalculationCycle);
		set @EndDatePerCalculationCycleFull = DATEADD(minute, -1* @CalculationPeriodInMinutes, @EndDatePerCalculationCycleFull);
		set @EndDatePerCalculationCycle = @EndDatePerCalculationCycleFull;
		set @CurrentCycles = @CurrentCycles + 1;
	END;
	return;
END;

GO
