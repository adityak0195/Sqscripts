--------------------------------------------------------------
--------------------------------------------------------------
print '-- KPI_CALCULATOR_GetShiftsListToCalculateKPIs';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'KPI_CALCULATOR_GetShiftsListToCalculateKPIs'))
drop FUNCTION KPI_CALCULATOR_GetShiftsListToCalculateKPIs;
GO
CREATE FUNCTION KPI_CALCULATOR_GetShiftsListToCalculateKPIs(@machine varchar(255), @startTime datetime2, @endTime datetime2)
RETURNS @table TABLE (	
	machine varchar(255), 
	shiftName varchar(255), 
	startTime datetime2, 
	endTime datetime2 
	)
BEGIN;
	insert into @table (		
		machine,
        shiftName,
        startTime,
        endTime
		)
    select Machine, CurrentName, CurrentStartTime, CurrentEndTime 
        from TEMP_SmartKPIFullShift
        where Machine = @machine
        and CurrentStartTime >= @startTime
        and CurrentEndTime <= @endTime


    
return;
	
END;

GO


