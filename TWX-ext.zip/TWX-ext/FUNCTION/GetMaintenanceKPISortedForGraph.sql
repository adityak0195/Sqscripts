--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetMaintenanceKPISortedForGraph';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetMaintenanceKPISortedForGraph'))
drop FUNCTION GetMaintenanceKPISortedForGraph;
GO
CREATE FUNCTION [dbo].[GetMaintenanceKPISortedForGraph]
	(@Machine varchar(255),
	@KPITimeBase varchar(55))
RETURNS @table TABLE ( 
	MTBF varchar(10),
	MTTR varchar(10),
	MRT varchar(10),
	Time datetime2)  
BEGIN; 

declare @dt1 as datetime = dateadd(month, DATEDIFF(month,0,GETUTCDATE())-12,0);
declare @dt2 as datetime = dateadd(month, DATEDIFF(month,0,GETUTCDATE())+1,0);

insert into @table (MTBF,MTTR,MRT,Time) 

select [CVS: MTBF], [CVS: MTTR], [CVS: MRT], [KPIDateTimeEnd] as Time from (select KPIName, KPIDateTimeEnd, KPIFloatValue 
from (select  KPIName, KPIDateTimeEnd, KPIFloatValue from smartKPIValues where Machine = @Machine and KPITimeBase = @KPITimeBase 
and (KPIName = 'CVS: MTBF' or KPIName = 'CVS: MTTR' or KPIName = 'CVS: MRT') and KPIDateTimeEnd between @dt1 and @dt2) a) b 
pivot (max(KPIFloatValue) for KPIName in ([CVS: MTBF], [CVS: MTTR], [CVS: MRT])) piv; 

return;
END;
GO