--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSDlp1';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSDlp1'))
drop FUNCTION GetCVSDlp1;
GO
CREATE FUNCTION GetCVSDlp1
	(@Parts int,
	@TimeOfTheWorkersSec int,
	@Operators int)
RETURNS float
BEGIN
	declare @dlp1result float = 0.0;

	if (@Operators > 0 AND @TimeOfTheWorkersSec > 0)
		SET @dlp1result = convert(float,@Parts)/((convert(float,@TimeOfTheWorkersSec)/60/60)*convert(float,@Operators));
		
	if (@dlp1result is null)
		set @dlp1result = 0;
	
	return round(@dlp1result,2);
END;
go