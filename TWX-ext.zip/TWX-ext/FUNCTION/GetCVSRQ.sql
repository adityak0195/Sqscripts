--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSRQ';
--------------------------------------------------------------
--------------------------------------------------------------


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSRQ'))
drop FUNCTION GetCVSRQ;
GO
CREATE FUNCTION GetCVSRQ
	(@KPIPartsIO int,
	@KPIPartsNIO int,
	@KPIPartsRework int)
RETURNS float
BEGIN
	declare @KPIRQ float = 0.0;
	IF ((@KPIPartsNIO + @KPIPartsIO + @KPIPartsRework) > 0)
	BEGIN
		set @KPIRQ = convert(float,@KPIPartsIO) / convert(float,@KPIPartsIO + @KPIPartsNIO + @KPIPartsRework) * 100.0;
	END;
	
	return round(@KPIRQ,2);
END;
go