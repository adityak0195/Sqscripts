--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetForOrdersFunction1V2';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetForOrdersFunction1V2'))
drop FUNCTION GetCVSProductionTargetForOrdersFunction1V2;
GO
CREATE FUNCTION GetCVSProductionTargetForOrdersFunction1V2
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2,
	@orders TargetOrderTypeV3 READONLY)
RETURNS @table TABLE ( 
	ProductionTime DateTime2, 
	counter int, 
	OrderNumber varchar(255), 
	SinglePartTargetCount INT, 
	WorkingTimeInMinutes float,
	TimeToProducePartsInMinutes float, 
	TimeForProducedParts float, 
	ProcessingTime float,
	SetupTime float,
	PlannedNumberOfWorkers float,
	ShiftFactorInPercent float,
	ParallelProcessing varchar(1000),
	ProcessNumber int,
	FullCyclePartsProduced int)  

BEGIN

	DECLARE @NumberOfParallelProcesses int = 1;
	DECLARE @isMultiPalletMachine int = 0;

	SELECT @isMultiPalletMachine=[FloatValue]
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @LineThingName
		  and PropertyKey = 'isMultiPalletMachine';


	if @isMultiPalletMachine = 1
	BEGIN
		SELECT @NumberOfParallelProcesses=[FloatValue]
		  FROM [smartKPIMachineKeyValueData]
		  where Machine = @LineThingName
		  and PropertyKey = 'NumberOfParallelProcessesForMultiPalletMachine';
	END;

	if @NumberOfParallelProcesses > 1
		insert into @table (FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, PlannedNumberOfWorkers,WorkingTimeInMinutes, TimeToProducePartsInMinutes, SetupTime, ParallelProcessing, ProcessNumber) 
			select FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, PlannedNumberOfWorkers ,WorkingTimeInMinutes, TimeToProducePartsInMinutes, SetupTime, ParallelProcessing, ProcessNumber
				from dbo.GetCVSProductionTargetForOrdersFunction1V2ForMachining(@LineThingName, @StartTime, @EndTime, @orders);  
	else
		insert into @table (FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, PlannedNumberOfWorkers,WorkingTimeInMinutes, TimeToProducePartsInMinutes, SetupTime, ParallelProcessing, ProcessNumber) 
			select FullCyclePartsProduced, ShiftFactorInPercent, ProductionTime , counter , TimeForProducedParts , ProcessingTime , SinglePartTargetCount, OrderNumber, PlannedNumberOfWorkers ,WorkingTimeInMinutes, TimeToProducePartsInMinutes, SetupTime, ParallelProcessing, ProcessNumber
				from dbo.GetCVSProductionTargetForOrdersFunction1V2ForAssembly(@LineThingName, @StartTime, @EndTime, @orders);  
	
	return;
END;
Go
