--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSTimeLossRawData';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSTimeLossRawData'))
drop FUNCTION GetCVSTimeLossRawData;
GO
CREATE FUNCTION GetCVSTimeLossRawData
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS @table TABLE (	
	StatusTime datetime2, 
	StatusTimeStart datetime2, 
	StatusTimeEnd datetime2, 
	Duration_in_sec int,  
	Duration_in_min float, 
	isProduction int, 
	isShift int, 
	StatusLevel1 varchar(255), 
	StatusLevel1Local Nvarchar(max), 
	StatusLevel2 varchar(255), 
	StatusLevel2Local Nvarchar(max), 
	StatusType varchar(255),
	OrderNumber varchar(255),
	PartNumber varchar(255),
	isPartOK int,
	SerialNumber varchar(255),
	ScrapReason varchar(255),					  
	tgMaxTimeInSec float,
	ProcessingTimeInSec float,
	ProcessingTimeInSecCO float,
	ProcessingTimeInSecAPO float,
	tgMaxTimeInSecTotal float,
	ProcessingTimeInSecTotal float,
	ProcessingTimeInSecCOTotal float,
	ProcessingTimeInSecAPOTotal float,
	PlannedNumberOfWorkers float,
	NumberOfParts int
	)
BEGIN;
	insert into @table (		
		StatusTime, 
		StatusTimeStart, 
		StatusTimeEnd, 
		Duration_in_sec, 
		Duration_in_min, 
		isProduction, 
		isShift, 
		StatusLevel1, 
		StatusLevel1Local, 
		StatusLevel2, 
		StatusLevel2Local, 
		StatusType, 
		OrderNumber, 
		PartNumber, 
		isPartOK,
		SerialNumber,
		ScrapReason,	  
		tgMaxTimeInSec,
		ProcessingTimeInSec,
		ProcessingTimeInSecCO,
		ProcessingTimeInSecAPO,
		tgMaxTimeInSecTotal,
		ProcessingTimeInSecTotal,
		ProcessingTimeInSecCOTotal,
		ProcessingTimeInSecAPOTotal,
		PlannedNumberOfWorkers,
		NumberOfParts
		)
	select		
		StatusTime, 
		StatusTimeStart, 
		StatusTimeEnd, 
		Duration_in_sec, 
		Duration_in_min, 
		isProduction, 
		isShift, 
		StatusLevel1, 
		StatusLevel1Local, 
		StatusLevel2, 
		StatusLevel2Local, 
		StatusType, 
		OrderNumber, 
		PartNumber, 
		isPartOK,
		SerialNumber,
		ScrapReason,	  
		tgMaxTimeInSec,
		ProcessingTimeInSec,
		ProcessingTimeInSecCO,
		ProcessingTimeInSecAPO,
		tgMaxTimeInSecTotal,
		ProcessingTimeInSecTotal,
		ProcessingTimeInSecCOTotal,
		ProcessingTimeInSecAPOTotal,
		PlannedNumberOfWorkers,
		NumberOfParts
	from GetCVSTimeLossRawDataAll(@LineThingName, @StartTime, @EndTime, 'All');
return;
	
END;

GO



--select StatusTime, StatusLevel1, StatusLevel1Local, StatusLevel2, StatusLevel2Local, StatusType from dbo.GetCVSTimeLossRawData('KBLisLaa6MachineThing', '2020-05-05', '2020-05-06') order by 1,3
--select * from dbo.GetCVSTimeLossRawData('KBLisLaa6MachineThing', '2020-05-05', '2020-05-06') order by StatusTime,StatusType, StatusLevel2
--select * from dbo.GetCVSTimeLossRawDataAll('KBLisLaa6MachineThing', '2020-05-05', '2020-05-06', 'Part') order by StatusTime,StatusType, StatusLevel2
--select * from dbo.GetCVSTimeLossRawDataAll('KBLisLaa6MachineThing', '2020-05-05', '2020-05-06', 'Order') order by StatusTime,StatusType, StatusLevel2
--select * from dbo.GetCVSTimeLossRawDataAll('KBLisLaa6MachineThing', '2020-05-05', '2020-05-06', 'Operator Screen') order by StatusTime,StatusType, StatusLevel2
--select * from dbo.GetCVSTimeLossRawDataAll('KBLisLaa6MachineThing', '2020-05-05', '2020-05-06', 'Shift Calendar') order by StatusTime,StatusType, StatusLevel2

