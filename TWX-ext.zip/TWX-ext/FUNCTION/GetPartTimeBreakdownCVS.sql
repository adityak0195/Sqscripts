--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetPartTimeBreakdownCVS';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetPartTimeBreakdownCVS'))
drop FUNCTION GetPartTimeBreakdownCVS;
GO
CREATE FUNCTION GetPartTimeBreakdownCVS
	(@Machine varchar(255),
	@StartTime datetime2,
	@EndTime datetime2)
RETURNS @table TABLE ( 
	ProductionTimeStart datetime2,
	ProductionTimeEnd datetime2,
	ProductionTimeInSeconds int,
	TGMAXTimeInSeconds int,
	OrderNumber varchar(255))  

BEGIN

	declare @lastProductionTime datetime2 = @StartTime;
	declare @lastOrderNumber varchar(255);
	declare @ProductionTime datetime2 = @StartTime;
	declare @OrderNumber varchar(255);

	declare @Orders CURSOR;
	
	--Get last status out of time slot
	SELECT TOP (1) 
		@lastProductionTime=[ProductionTime]
		,@lastOrderNumber=[OrderNumber]
		FROM [smartKPI]
		where Machine = @Machine
		and ProductionTime < @StartTime 
		order by [ProductionTime] desc	;
			
	SET @Orders = CURSOR FOR 
		select ProductionTime, OrderNumber from smartKPI 
			where ProductionTime between @StartTime and @EndTime
			and Machine = @Machine
			order by ProductionTime;

	OPEN @Orders;
		FETCH NEXT FROM @Orders into @ProductionTime, @OrderNumber;
		WHILE @@FETCH_STATUS = 0
			BEGIN;
			

			
			insert into @table (ProductionTimeStart, ProductionTimeEnd, ProductionTimeInSeconds, TGMAXTimeInSeconds, OrderNumber)
				values (@lastProductionTime, @ProductionTime, datediff(second,@lastProductionTime, @ProductionTime), 0, @lastOrderNumber);



			SET @lastProductionTime = @ProductionTime;
			SET @lastOrderNumber = @OrderNumber;
			
			FETCH NEXT FROM @Orders into @ProductionTime, @OrderNumber;
			END;
	CLOSE @Orders;
	DEALLOCATE @Orders;


	return;
	
END;

GO
--declare @dt1 as DateTime2 = '2019-02-07 02:00:00.000';
--declare @dt2 as DateTime2 = '2019-02-07 02:00:00.000';

--select * from GetPartTimeBreakdownCVS ('KBLisLaa2MachineThing', @dt1, @dt2);  
--GO
