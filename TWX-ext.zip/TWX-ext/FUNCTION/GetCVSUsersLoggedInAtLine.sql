--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSUsersLoggedInAtLine';
--------------------------------------------------------------
--------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSUsersLoggedInAtLine'))
drop FUNCTION GetCVSUsersLoggedInAtLine;
GO
CREATE FUNCTION GetCVSUsersLoggedInAtLine
	(@Station varchar(255))
RETURNS int

BEGIN

	DECLARE @numberOfUsers int;
	

	select @numberOfUsers=count(*) from dbo.GetCVSUsersLoggedInListAtLine(@Station) where isLoggedIn = 1;
	return @numberOfUsers;

END;
GO