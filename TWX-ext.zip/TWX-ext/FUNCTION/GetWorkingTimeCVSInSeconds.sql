--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetWorkingTimeCVSInSeconds';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetWorkingTimeCVSInSeconds'))
drop FUNCTION GetWorkingTimeCVSInSeconds;
GO
CREATE FUNCTION  GetWorkingTimeCVSInSeconds   
( @Machine varchar(255),
  @StartDate DateTime2,
  @EndDate DateTime2
)  
RETURNS int  
	BEGIN
	
        declare @WorkingTimeCVSInSeconds int;

	    select @WorkingTimeCVSInSeconds=dbo.GetWorkingTimeCVSInSeconds_V2(@Machine, @StartDate, @EndDate);
	
        RETURN @WorkingTimeCVSInSeconds; 
    END;
		
	
GO	
