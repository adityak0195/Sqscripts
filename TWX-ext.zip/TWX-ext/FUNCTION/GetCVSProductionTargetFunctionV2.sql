--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSProductionTargetFunctionV2';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSProductionTargetFunctionV2'))
drop FUNCTION GetCVSProductionTargetFunctionV2;
GO
CREATE FUNCTION GetCVSProductionTargetFunctionV2
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS int  

BEGIN

	declare @counter int = 0;
	
	select @counter=count(*) from GetCVSProductionTargetFunction1V2(	@LineThingName,
																	@StartTime,
																	@EndTime);

	RETURN @counter;
	
END;

GO

--declare @sdt as DateTime2 = '2019-02-19 06:00:00.000';
--declare @edt as DateTime2 = '2019-02-19 13:30:00.000';
--select dbo.GetCVSProductionTargetFunctionV2('KBLisLaa2MachineThing', @sdt, @edt);  


