--------------------------------------------------------------
--------------------------------------------------------------
print '-- GetCVSTimeLossRawDataToExcel';
--------------------------------------------------------------
--------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'GetCVSTimeLossRawDataToExcel'))
drop FUNCTION GetCVSTimeLossRawDataToExcel;
GO
CREATE FUNCTION [dbo].[GetCVSTimeLossRawDataToExcel]
	(@LineThingName varchar(255),
	@StartTime DateTime2,
	@EndTime DateTime2)
RETURNS @table TABLE (	
	StatusTime datetime2, 
	StatusTimeStart datetime2, 
	StatusTimeEnd datetime2, 
	Duration_in_sec int,  
	Duration_in_min float, 
	isProduction int, 
	isShift int, 
	StatusLevel1 varchar(255), 
	StatusLevel1Local Nvarchar(max), 
	StatusLevel2 varchar(255), 
	StatusLevel2Local Nvarchar(max), 
	StatusType varchar(255),
	OrderNumber varchar(255),
	PartNumber varchar(255),
	isPartOK int,
	SerialNumber varchar(255),
	ScrapReason varchar(255),					  
	tgMaxTimeInSec float,
	ProcessingTimeInSec float,
	ProcessingTimeInSecCO float,
	ProcessingTimeInSecAPO float,
	tgMaxTimeInSecTotal float,
	ProcessingTimeInSecTotal float,
	ProcessingTimeInSecCOTotal float,
	ProcessingTimeInSecAPOTotal float,
	PlannedNumberOfWorkers float,
	NumberOfParts int
	)
BEGIN;
	insert into @table (		
		StatusTime, 
		StatusTimeStart, 
		StatusTimeEnd, 
		Duration_in_sec, 
		Duration_in_min, 
		isProduction, 
		isShift, 
		StatusLevel1, 
		StatusLevel1Local, 
		StatusLevel2, 
		StatusLevel2Local, 
		StatusType, 
		OrderNumber, 
		PartNumber, 
		isPartOK,
		SerialNumber,
		ScrapReason,	  
		tgMaxTimeInSec,
		ProcessingTimeInSec,
		ProcessingTimeInSecCO,
		ProcessingTimeInSecAPO,
		tgMaxTimeInSecTotal,
		ProcessingTimeInSecTotal,
		ProcessingTimeInSecCOTotal,
		ProcessingTimeInSecAPOTotal,
		PlannedNumberOfWorkers,
		NumberOfParts
		)
	select		
		DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()),  StatusTime) as StatusTime, 
		DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()),  StatusTimeStart) as StatusTimeStart,
		DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()),  StatusTimeEnd) as StatusTimeEnd,		
		Duration_in_sec, 
		Duration_in_min, 
		isProduction, 
		isShift, 
		StatusLevel1, 
		StatusLevel1Local, 
		StatusLevel2, 
		StatusLevel2Local, 
		StatusType, 
		OrderNumber, 
		PartNumber, 
		isPartOK,
		SerialNumber,
		ScrapReason,	  
		tgMaxTimeInSec,
		ProcessingTimeInSec,
		ProcessingTimeInSecCO,
		ProcessingTimeInSecAPO,
		tgMaxTimeInSecTotal,
		ProcessingTimeInSecTotal,
		ProcessingTimeInSecCOTotal,
		ProcessingTimeInSecAPOTotal,
		PlannedNumberOfWorkers,
		NumberOfParts
	from GetCVSTimeLossRawDataAll(@LineThingName, @StartTime, @EndTime, 'All');
return;
	
END;

GO

