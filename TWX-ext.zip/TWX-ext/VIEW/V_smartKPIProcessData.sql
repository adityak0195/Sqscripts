--************************************************************************************************************
--************************************************************************************************************
--View V_smartKPIProcessData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create or alter view V_SAPTimePerPart');
	GO

	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'V_smartKPIProcessData'))
	drop view V_smartKPIProcessData;

	go
	
	create view V_smartKPIProcessData as 
	select
		[Id],
		'smartKPIProcessFloatData' as Source,
		[CreationTime],
		UTCCreationTime,
		[Machine] COLLATE database_default as Machine,
		[ProcesDataType] COLLATE database_default as [ProcesDataType],
		[ProcesDataType2] COLLATE database_default as [ProcesDataType2],
		[ProductionTime],
		[ProcesData] as ProcessDataFloat,
		ProcesDataLSL,
		ProcesDataUSL,
		Unit,
		ProcesDataPrecision,
		ProcesDataTargetValueName,
		ProcesDataLowerLimitName,
		ProcesDataUpperLimitName,
		ProcesDataTolerancePos,
		ProcesDataTolerancePosFloat,
		ProcesDataToleranceNegFloat,
		ProcessDataTargetValueTolUnit,
		convert(varchar(max), NULL) COLLATE database_default as ProcessDataString,
		convert(datetime2, NULL) as ProcessDataDateTime,
		convert(bit, 1) as isProcessDataFloat,
		convert(bit, 0) as isProcessDataString,
		convert(bit, 0) as isProcessDataDateTime,
		[SerialNumber] COLLATE database_default as [SerialNumber],
		[PartNumber] COLLATE database_default as [PartNumber],
		[OrderNumber] COLLATE database_default as [OrderNumber],
		[TrackingNumber] COLLATE database_default as [TrackingNumber],
		[PartNumberRevision] COLLATE database_default as [PartNumberRevision],
		[Identifier] COLLATE database_default as [Identifier],
		[ProcesDataTargetValue] as ProcessDataFloatTargetValue,
		convert(varchar(max), NULL) COLLATE database_default as ProcessDataStringTargetValue,
		convert(datetime2, NULL) as ProcessDataDateTimeTargetValue,
		[description] COLLATE database_default as [description],
		[comment] COLLATE database_default as [comment]
		from smartKPIProcessFloatData
	union
	select  
		[Id],
		'smartKPIProcessStringData' as Source,
		[CreationTime],
		UTCCreationTime,
		[Machine] COLLATE database_default,
		[ProcesDataType] COLLATE database_default,
		[ProcesDataType2] COLLATE database_default,
		[ProductionTime],
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		[ProcesData] COLLATE database_default as ProcessDataString,
		convert(datetime2, NULL) as ProcessDataDateTime,
		convert(bit, 0) as isProcessDataFloat,
		convert(bit, 1) as isProcessDataString,
		convert(bit, 0) as isProcessDataDateTime,
		[SerialNumber] COLLATE database_default,
		[PartNumber] COLLATE database_default,
		[OrderNumber] COLLATE database_default,
		[TrackingNumber] COLLATE database_default,
		[PartNumberRevision] COLLATE database_default,
		[Identifier] COLLATE database_default,
		convert(float, NULL) as ProcessDataFloatTargetValue,
		[ProcesDataTargetValue] as ProcessDataStringTargetValue,
		convert(datetime2, NULL) as ProcessDataDateTimeTargetValue,
		[description] COLLATE database_default,
		[comment] COLLATE database_default
		from smartKPIProcessStringData
	union
	select  
		[Id],
		'smartKPIProcessDateTimeData' as Source,
		[CreationTime],
		UTCCreationTime,
		[Machine] COLLATE database_default,
		[ProcesDataType] COLLATE database_default,
		[ProcesDataType2] COLLATE database_default,
		[ProductionTime],
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		convert(varchar(max), NULL) COLLATE database_default as ProcessDataString,
		[ProcesData] as ProcessDataDateTime,
		convert(bit, 0) as isProcessDataFloat,
		convert(bit, 0) as isProcessDataString,
		convert(bit, 1) as isProcessDataDateTime,
		[SerialNumber] COLLATE database_default,
		[PartNumber] COLLATE database_default,
		[OrderNumber] COLLATE database_default,
		[TrackingNumber] COLLATE database_default,
		[PartNumberRevision] COLLATE database_default,
		[Identifier] COLLATE database_default,
		convert(float, NULL) as ProcessDataFloatTargetValue,
		convert(varchar(max), NULL) as ProcessDataStringTargetValue,
		[ProcesDataTargetValue] as ProcessDataDateTimeTargetValue,
		[description] COLLATE database_default,
		[comment] COLLATE database_default
		from smartKPIProcessDateTimeData
GO

