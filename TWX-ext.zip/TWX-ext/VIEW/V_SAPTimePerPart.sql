--************************************************************************************************************
--************************************************************************************************************
--View V_SAPTimePerPart
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create or alter view V_SAPTimePerPart');
	GO

	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'V_SAPTimePerPart'))
	drop view V_SAPTimePerPart;
	
	GO

	create view V_SAPTimePerPart as 
	select REPLICATE('0',12-len(line.OrderNumber))+line.OrderNumber as [orderNumber], 
			 line.OrderNumber as [orderNumberShort], 
			 sum(CASE tgMaxTime.TextValue
				WHEN 'SEC' THEN tgMaxTime.[FloatValue]
				WHEN 'MIN' THEN tgMaxTime.[FloatValue] * 60
				WHEN 'DAY' THEN tgMaxTime.[FloatValue] * 24 * 60 * 60
				ELSE 0
			 END) as [timePerPartInSec],
			 line.TextValue as [Workcenter]
	  from
	  (select TextValue, OrderNumber
	  from [smartKPIOrderKeyValueData]
	  where PropertyKey like 'Line-%') line,
	  (select FloatValue, TextValue, OrderNumber
	  from [smartKPIOrderKeyValueData]
	  where PropertyKey = 'tgMaxTime') tgMaxTime
	  where tgMaxTime.OrderNumber = line.OrderNumber
	  group by line.OrderNumber, line.TextValue;
  
	 GO

