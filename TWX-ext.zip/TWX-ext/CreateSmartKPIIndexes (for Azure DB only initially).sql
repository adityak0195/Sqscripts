--------------------------------------------------------------
--------------------------------------------------------------
-- Archiving
--------------------------------------------------------------
--------------------------------------------------------------
--************************************************************************************************************
--************************************************************************************************************
-- Table SYSTEM_deletedEntries
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_SYSTEM_deletedEntries_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_SYSTEM_deletedEntries_modification_id')
	CREATE INDEX [IX_SYSTEM_deletedEntries_modification_id] ON [SYSTEM_deletedEntries] (TableName, modification_id);
GO


--************************************************************************************************************
--************************************************************************************************************
-- Table smartkpi
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPI_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPI_modification_id')
	CREATE INDEX [IX_smartKPI_modification_id] ON [smartKPI] (modification_id);
GO

PRINT ('create index IX_smartKPI_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPI_modification_id_date')
	CREATE INDEX [IX_smartKPI_modification_id_date] ON [smartKPI] (modification_id, ProductionTime);
GO

PRINT ('create index IX_smartKPI_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPI_move_to_history')
	CREATE INDEX [IX_smartKPI_move_to_history] ON [smartKPI] ([move_to_history]);
GO

PRINT ('create index IX_Confirmation_smartKpi');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_Confirmation_smartKpi')
	create index IX_Confirmation_smartKpi on smartKPI (OrderNumber DESC, SAPOperationNumber ASC, confirmToSAP DESC, confirmedToSAP ASC);
GO

PRINT ('create index IX_PreparePartsToConfirmTruck_smartKpi');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_PreparePartsToConfirmTruck_smartKpi')
	create index IX_PreparePartsToConfirmTruck_smartKpi on smartKPI (confirmToSAP DESC, confirmedToSAP ASC) INCLUDE (Id, OrderNumber, SAPOperationNumber, numberOfParts, isPartOK, Machine, Station);
GO

  
PRINT ('create index IX_smartKPI_Machine_isPartOK_OrderNumber_ProductionTime');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPI_Machine_isPartOK_OrderNumber_ProductionTime')
	CREATE INDEX [IX_smartKPI_Machine_isPartOK_OrderNumber_ProductionTime] ON [smartKPI] ([Machine], [isPartOK], [OrderNumber],[ProductionTime]) INCLUDE ([numberOfParts]);
GO
  
PRINT ('create index IX_OrderNumber_Machine_smartKpi');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_OrderNumber_Machine_smartKpi')
	create index IX_OrderNumber_Machine_smartKpi on smartKPI (Machine ASC, OrderNumber DESC);
GO
  
PRINT ('create index IX_OrderNumber_Machine_smartKpi1');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_OrderNumber_Machine_smartKpi1')
	create index IX_OrderNumber_Machine_smartKpi1 on smartKPI (OrderNumber DESC);
GO
  
PRINT ('create index IX_OrderNumber_Machine_smartKpi2');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_OrderNumber_Machine_smartKpi2')
	create index IX_OrderNumber_Machine_smartKpi2 on smartKPI (Machine ASC, OrderNumber DESC, ProductionTime desc);
GO
  

PRINT ('create index IX_Time_Machine_result_smartKpi');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_Time_Machine_result_smartKpi')
	drop index IX_Time_Machine_result_smartKpi on smartKPI;
GO

PRINT ('create index IX_smartKPI_Machine_isPartOK_ProductionTime');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPI_Machine_isPartOK_ProductionTime')
	CREATE INDEX [IX_smartKPI_Machine_isPartOK_ProductionTime] ON [smartKPI] ([Machine], [isPartOK],[ProductionTime]) INCLUDE ([OrderNumber], [numberOfParts]);
GO
  
PRINT ('drop index IX_Machine_smartKpi');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_smartKpi')
	drop index IX_Machine_smartKpi on smartKPI;
GO

PRINT ('create index IX_Machine_smartKpi');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_smartKpi1')
	create index IX_Machine_smartKpi1 on smartKPI (Machine ASC) INCLUDE ([ProductionTime], [isPartOK], [PartNumber], [SerialNumber], [OrderNumber]);
GO

PRINT ('Create nonclustered index IX_OrderNumber_Machine_smartKpi3');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_OrderNumber_Machine_smartKpi3')
	Create nonclustered index IX_OrderNumber_Machine_smartKpi3 on [smartKPI] ([ProductionTime]) INCLUDE ([OrderNumber])
GO

PRINT ('Create nonclustered index IX_OrderNumber_Machine_smartKpi4');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_OrderNumber_Machine_smartKpi4')
	Create nonclustered index IX_OrderNumber_Machine_smartKpi4 on [smartKPI] ([OrderNumber]) INCLUDE (ProductionTime)
GO

PRINT ('Create nonclustered index IX_smartKPI_Machine_ProductionTime_D7F5E');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPI_Machine_ProductionTime_D7F5E')
	CREATE INDEX [IX_smartKPI_Machine_ProductionTime_D7F5E] ON [smartKPI] ([Machine],[ProductionTime]) INCLUDE ([Id], [isPartOK], [PartNumber], [SerialNumber], [OrderNumber], [ScrapReason], [isUpdated], [numberOfParts]);
GO



--************************************************************************************************************
--************************************************************************************************************
-- Table smartKPIOrderKeyValueData
--************************************************************************************************************
--************************************************************************************************************
PRINT ('create index IX_smartKPIOrderKeyValueData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData_modification_id')
	CREATE INDEX [IX_smartKPIOrderKeyValueData_modification_id] ON [smartKPIOrderKeyValueData] (modification_id);
GO

PRINT ('create index IX_smartKPIOrderKeyValueData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData_modification_id_date')
	CREATE INDEX [IX_smartKPIOrderKeyValueData_modification_id_date] ON [smartKPIOrderKeyValueData] (modification_id, UTCUpdateTime);
GO

PRINT ('create index IX_smartKPIOrderKeyValueData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData_move_to_history')
	CREATE INDEX [IX_smartKPIOrderKeyValueData_move_to_history] ON [smartKPIOrderKeyValueData] ([move_to_history]);
GO

  
PRINT ('create index IX_smartKPIOrderKeyValueData');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData')
	create index IX_smartKPIOrderKeyValueData on smartKPIOrderKeyValueData (OrderNumber DESC, System, PropertyKey, DateTimeValue);
GO

PRINT ('drop index IX_smartKPIOrderKeyValueData1');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData1')
	drop index IX_smartKPIOrderKeyValueData1 on smartKPIOrderKeyValueData;
GO

PRINT ('create index IX_smartKPIOrderKeyValueData2');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData2')
	create index IX_smartKPIOrderKeyValueData2 on smartKPIOrderKeyValueData (OrderNumber desc, PropertyKey);
GO

PRINT ('create index IX_smartKPIOrderKeyValueData3');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData3')
	create index IX_smartKPIOrderKeyValueData3 on smartKPIOrderKeyValueData (PropertyKey);
GO

PRINT ('drop index IX_smartKPIOrderKeyValueData4');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData4')
	drop index IX_smartKPIOrderKeyValueData4 on smartKPIOrderKeyValueData;
GO
  
PRINT ('drop index IX_smartKPIOrderKeyValueData5');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData5')
	drop index IX_smartKPIOrderKeyValueData5 on smartKPIOrderKeyValueData;
GO

PRINT ('create index IX_smartKPIOrderKeyValueData6');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData6')
	drop index IX_smartKPIOrderKeyValueData6 on smartKPIOrderKeyValueData;
GO

PRINT ('create index IX_smartKPIOrderKeyValueData9');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData9')
	create index IX_smartKPIOrderKeyValueData9 on smartKPIOrderKeyValueData (OrderNumber desc) INCLUDE ([PropertyKey], [FloatValue], [TextValue]);
GO

PRINT ('Create nonclustered index IX_smartKPIOrderKeyValueData7');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData7')
	Create nonclustered index IX_smartKPIOrderKeyValueData7 on [smartKPIOrderKeyValueData] ([PropertyKey],[DateTimeValue]) INCLUDE ([System], [OrderNumber])
GO

PRINT ('drop index IX_smartKPIOrderKeyValueData8');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData8')
	drop index IX_smartKPIOrderKeyValueData8 on smartKPIOrderKeyValueData 
GO

PRINT ('drop index IX_smartKPIOrderKeyValueData_TextValue_PropertyKey_UpdateTime');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData_TextValue_PropertyKey_UpdateTime')
	drop INDEX [IX_smartKPIOrderKeyValueData_TextValue_PropertyKey_UpdateTime] ON [smartKPIOrderKeyValueData] ;
GO

PRINT ('create index IX_smartKPIOrderKeyValueData10');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData10')
	create index IX_smartKPIOrderKeyValueData10 on smartKPIOrderKeyValueData (PropertyKey1) INCLUDE (PropertyKey, TextValue);
GO

PRINT ('create index IX_smartKPIOrderKeyValueData11');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData11')
	drop index IX_smartKPIOrderKeyValueData11 on smartKPIOrderKeyValueData;
GO

PRINT ('create index IX_smartKPIOrderKeyValueData12');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData12')
	create index IX_smartKPIOrderKeyValueData12 on smartKPIOrderKeyValueData (PropertyKey1, OrderNumber, Operation) INCLUDE (TextValue, FloatValue, DateTimeValue);
GO

PRINT ('create index IX_smartKPIOrderKeyValueData13');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData13')
	create index IX_smartKPIOrderKeyValueData13 on smartKPIOrderKeyValueData (TextValue1) INCLUDE (OrderNumber);
GO

IF EXISTS(SELECT TOP (1) 'OK' FROM smartKPIMachineData where Machine='KBLIBTruckPlantThing' 
	UNION ALL SELECT TOP (1) 'OK' FROM smartKPIMachineData where Machine='KBLISTruckPlantThing' 
	UNION ALL SELECT TOP (1) 'OK' FROM smartKPIMachineData where Machine='KBKECTruckPlantThing')
		PRINT ('skipped creation of index IX_smartKPIOrderKeyValueData14');
ELSE
    BEGIN
	PRINT ('create index IX_smartKPIOrderKeyValueData14');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData14')
	create index IX_smartKPIOrderKeyValueData14 on smartKPIOrderKeyValueData (UTCUpdateTime desc, OrderNumber desc);
    END
GO

PRINT ('drop index IX_smartKPIOrderKeyValueData15');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData15')
	drop INDEX [IX_smartKPIOrderKeyValueData15] ON [smartKPIOrderKeyValueData];
GO

PRINT ('create index IX_smartKPIOrderKeyValueData16');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData16')
	CREATE INDEX [IX_smartKPIOrderKeyValueData16] ON [smartKPIOrderKeyValueData] ([PropertyKey], [UTCUpdateTime]) INCLUDE ([TextValue], [OrderNumber]);
GO

PRINT ('create index IX_smartKPIOrderKeyValueData17');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderKeyValueData17')
	create index IX_smartKPIOrderKeyValueData17 on smartKPIOrderKeyValueData (PlantId, UTCUpdateTime) INCLUDE (Id, CreationTime ,
		  PropertyKey ,
		  FloatValue ,
		  TextValue ,
		  DateTimeValue ,
		  isFloatValue ,
		  isTextValue ,
		  isDateTimeValue,
		  System ,
		  OrderNumber ,
		  UpdateTime,
		  PropertyKey1,
		  Operation);
GO

--************************************************************************************************************
--************************************************************************************************************
-- Table smartKPIOrderData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIOrderData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderData_modification_id')
	CREATE INDEX [IX_smartKPIOrderData_modification_id] ON [smartKPIOrderData] (modification_id);
GO

PRINT ('create index IX_smartKPIOrderData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderData_modification_id_date')
	CREATE INDEX [IX_smartKPIOrderData_modification_id_date] ON [smartKPIOrderData] (modification_id, UTCUpdateTime);
GO

PRINT ('create index IX_smartKPIOrderData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderData_move_to_history')
	CREATE INDEX [IX_smartKPIOrderData_move_to_history] ON [smartKPIOrderData] ([move_to_history]);
GO


PRINT ('drop index IX_smartKPIOrderData');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderData')
	drop index IX_smartKPIOrderData on smartKPIOrderData;
GO


PRINT ('create index IX_smartKPIOrderData1');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOrderData1')
	create index IX_smartKPIOrderData1 on smartKPIOrderData (UTCUpdateTime DESC, PlantId);
GO


--************************************************************************************************************
--************************************************************************************************************
--Table shiftCalendar
--************************************************************************************************************
--************************************************************************************************************


PRINT ('create index IX_shiftCalendar_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_shiftCalendar_modification_id')
	CREATE INDEX [IX_shiftCalendar_modification_id] ON [shiftCalendar] (modification_id);
GO

PRINT ('create index IX_shiftCalendar_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_shiftCalendar_modification_id_date')
	CREATE INDEX [IX_shiftCalendar_modification_id_date] ON [shiftCalendar] (modification_id, EndTime);
GO

PRINT ('create index IX_shiftCalendar_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_shiftCalendar_move_to_history')
	CREATE INDEX [IX_shiftCalendar_move_to_history] ON [shiftCalendar] ([move_to_history]);
GO

PRINT ('create index IX_Date_Machine_Type_shiftCalendar on shiftCalendar');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Date_Machine_Type_shiftCalendar')
	create index IX_Date_Machine_Type_shiftCalendar on shiftCalendar                          (StartTime DESC, EndTime DESC, Machine, Qualifier);
GO
  
PRINT ('drop index IX_Date_Machine_shiftCalendar on shiftCalendar');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_Date_Machine_shiftCalendar')
	drop index IX_Date_Machine_shiftCalendar on shiftCalendar;
GO
  
PRINT ('create index IX_Date_Machine_shiftCalendar on shiftCalendar');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Date_Machine_shiftCalendar1')
	create index IX_Date_Machine_shiftCalendar1 on shiftCalendar                               (StartTime DESC, EndTime DESC, Machine) INCLUDE ([Qualifier]);
GO
  
PRINT ('create index IX_StartDate_shiftCalendar on shiftCalendar');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_StartDate_shiftCalendar')
	create index IX_StartDate_shiftCalendar on shiftCalendar                                  (StartTime DESC);
GO
  
PRINT ('create index IX_MachineStartPlant_shiftCalendar on shiftCalendar');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineStartPlant_shiftCalendar')
	create index IX_MachineStartPlant_shiftCalendar on shiftCalendar                          (StartTime DESC, Machine, Plant);
GO

PRINT ('drop index IX_MachineStartPlant_shiftCalendar on shiftCalendar');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineStart_shiftCalendar')
	drop index IX_MachineStart_shiftCalendar on shiftCalendar;
GO

PRINT ('create index IX_MachineStartPlant_shiftCalendar on shiftCalendar');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineStart_shiftCalendar1')
	create index IX_MachineStart_shiftCalendar1 on shiftCalendar                               ([Machine],[StartTime]) INCLUDE ([Id], [CreationTime], [Plant], [EndTime], [Qualifier], [Name], [Machine_Full_Name], [Utilization]);
GO

PRINT ('drop index IX_MachineStartPlant_shiftCalendar on shiftCalendar');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineEnd_shiftCalendar')
	drop index IX_MachineEnd_shiftCalendar on shiftCalendar;
GO

PRINT ('create index IX_MachineStartPlant_shiftCalendar on shiftCalendar');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineEnd_shiftCalendar1')
	create index IX_MachineEnd_shiftCalendar1 on shiftCalendar                                 (EndTime DESC, Machine) INCLUDE ([Qualifier]);
GO

PRINT ('Create nonclustered index IX_MachineQualifierStartEnd_shiftCalendar');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineQualifierStartEnd_shiftCalendar')
	Create nonclustered index IX_MachineQualifierStartEnd_shiftCalendar  on [shiftCalendar]   ([Machine],[Qualifier],[StartTime],[EndTime])
GO

PRINT ('Create index  [IX_shiftCalendar_Machine_Name_StartTime]');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_shiftCalendar_Machine_Name_StartTime')
	CREATE INDEX [IX_shiftCalendar_Machine_Name_StartTime] ON [shiftCalendar]                 ([Machine], [Name],[StartTime]) INCLUDE ([Id], [EndTime]);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineKeyValueData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIMachineKeyValueData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineKeyValueData_modification_id')
	CREATE INDEX [IX_smartKPIMachineKeyValueData_modification_id] ON [smartKPIMachineKeyValueData] (modification_id);
GO

PRINT ('create index IX_smartKPIMachineKeyValueData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineKeyValueData_move_to_history')
	CREATE INDEX [IX_smartKPIMachineKeyValueData_move_to_history] ON [smartKPIMachineKeyValueData] ([move_to_history]);
GO

PRINT ('create index IX_smartKPIMachineKeyValueData_Machine_PropertyKey');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineKeyValueData_Machine_PropertyKey')
	create index IX_smartKPIMachineKeyValueData_Machine_PropertyKey on smartKPIMachineKeyValueData (Machine, PropertyKey);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIMachineData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineData_modification_id')
	CREATE INDEX [IX_smartKPIMachineData_modification_id] ON [smartKPIMachineData] (modification_id);
GO

PRINT ('create index IX_smartKPIMachineData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineData_move_to_history')
	CREATE INDEX [IX_smartKPIMachineData_move_to_history] ON [smartKPIMachineData] ([move_to_history]);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIUserKeyValueData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIUserKeyValueData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIUserKeyValueData_modification_id')
	CREATE INDEX [IX_smartKPIUserKeyValueData_modification_id] ON [smartKPIUserKeyValueData] (modification_id);
GO

PRINT ('create index IX_smartKPIUserKeyValueData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIUserKeyValueData_move_to_history')
	CREATE INDEX [IX_smartKPIUserKeyValueData_move_to_history] ON [smartKPIUserKeyValueData] ([move_to_history]);
GO


--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIUserData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIUserData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIUserData_modification_id')
	CREATE INDEX [IX_smartKPIUserData_modification_id] ON [smartKPIUserData] (modification_id);
GO

PRINT ('create index IX_smartKPIUserData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIUserData_move_to_history')
	CREATE INDEX [IX_smartKPIUserData_move_to_history] ON [smartKPIUserData] ([move_to_history]);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineMessageData
--************************************************************************************************************
--************************************************************************************************************
  
PRINT ('create index IX_smartKPIMachineMessageData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_modification_id')
	CREATE INDEX [IX_smartKPIMachineMessageData_modification_id] ON [smartKPIMachineMessageData] (modification_id);
GO

PRINT ('create index IX_smartKPIMachineMessageData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_modification_id_date')
	CREATE INDEX [IX_smartKPIMachineMessageData_modification_id_date] ON [smartKPIMachineMessageData] (modification_id, MessageTime);
GO

PRINT ('create index IX_smartKPIMachineMessageData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_move_to_history')
	CREATE INDEX [IX_smartKPIMachineMessageData_move_to_history] ON [smartKPIMachineMessageData] ([move_to_history]);
GO

PRINT ('drop index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime')
	drop index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime on smartKPIMachineMessageData;
		
PRINT ('drop index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime_MessageType2');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime_MessageType2')
	drop index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime_MessageType2 on smartKPIMachineMessageData;
GO
PRINT ('create index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime_MessageType2_1');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime_MessageType2_1')
	CREATE INDEX [IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime_MessageType2_1] ON [smartKPIMachineMessageData] ([Machine], [MessageType1],[MessageTime], [MessageType2]);
GO

PRINT ('drop index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime1');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime1')
	drop index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime1 on smartKPIMachineMessageData;
GO
PRINT ('create index IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime1_1');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime1_1')
	CREATE INDEX [IX_smartKPIMachineMessageData_Machine_MessageType1_MessageTime1_1] ON [smartKPIMachineMessageData] ([Machine], [MessageType1],[MessageTime]) INCLUDE ([MessageType2]);
GO

PRINT ('create index IX_smartKPIMachineMessageData_MessageType1');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_MessageType1')
	CREATE INDEX [IX_smartKPIMachineMessageData_MessageType1] ON [smartKPIMachineMessageData] ([MessageType1]) INCLUDE ([Machine], [MessageTime]);
GO

PRINT ('drop index IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime')
	drop index IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime on smartKPIMachineMessageData;
GO
PRINT ('drop index IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime_48C35');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime_48C35')
	drop index IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime_48C35 on smartKPIMachineMessageData;
GO
PRINT ('create index IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime_48C35_1');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime_48C35_1')
	CREATE INDEX [IX_smartKPIMachineMessageData_MessageType1_MessageType2_Message_MessageTime_48C35_1] ON [smartKPIMachineMessageData] ([MessageType1], [MessageType2],[MessageTime]);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineStatusData
--************************************************************************************************************
--************************************************************************************************************
		
PRINT ('create index IX_smartKPIMachineStatusData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStatusData_modification_id')
	CREATE INDEX [IX_smartKPIMachineStatusData_modification_id] ON [smartKPIMachineStatusData] (modification_id);
GO

PRINT ('create index IX_smartKPIMachineStatusData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStatusData_modification_id_date')
	CREATE INDEX [IX_smartKPIMachineStatusData_modification_id_date] ON [smartKPIMachineStatusData] (modification_id, StatusTime);
GO

PRINT ('create index IX_smartKPIMachineStatusData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStatusData_move_to_history')
	CREATE INDEX [IX_smartKPIMachineStatusData_move_to_history] ON [smartKPIMachineStatusData] ([move_to_history]);
GO

PRINT ('create index IX_IsRailMachineProductive_smartKPIMachineStatusData');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_IsRailMachineProductive_smartKPIMachineStatusData')
	create index IX_IsRailMachineProductive_smartKPIMachineStatusData on smartKPIMachineStatusData (Id desc, Status, SubStatus, Machine);
GO
  
PRINT ('create index IX_smartKPIMachineStatusData1');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStatusData1')
	create index IX_smartKPIMachineStatusData1 on smartKPIMachineStatusData (Status, Machine, StatusTime);
GO
  
PRINT ('create index IX_smartKPIMachineStatusData2');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStatusData2')
	create index IX_smartKPIMachineStatusData2 on smartKPIMachineStatusData (Status, Machine, StatusTime DESC, CreationTime DESC);
GO
  
PRINT ('drop index IX_MachineStatusTimeType');
	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineStatusTimeType')
	drop index IX_MachineStatusTimeType on smartKPIMachineStatusData;
GO 

PRINT ('Create nonclustered index IX_MachineStatusTimeType1');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_MachineStatusTimeType1')
	create nonclustered index [IX_MachineStatusTimeType1] ON smartKPIMachineStatusData (Machine, StatusType, [StatusTime]) Include ([CreationTime],[Status],[SubStatus]);
GO

PRINT ('Create nonclustered index IX_smartKPIMachineStatusData_StatusTime_381CA');
   	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStatusData_StatusTime_381CA')
	CREATE INDEX [IX_smartKPIMachineStatusData_StatusTime_381CA] ON [smartKPIMachineStatusData] ([StatusTime]) INCLUDE ([Id], [CreationTime], [Machine], [Status]);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessFloatData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIProcessFloatData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_modification_id')
	CREATE INDEX [IX_smartKPIProcessFloatData_modification_id] ON [smartKPIProcessFloatData] (modification_id);
GO

PRINT ('create index IX_smartKPIProcessFloatData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_modification_id_date')
	CREATE INDEX [IX_smartKPIProcessFloatData_modification_id_date] ON [smartKPIProcessFloatData] (modification_id, ProductionTime);
GO

PRINT ('create index IX_smartKPIProcessFloatData_modification_id_date_move_to_history');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_modification_id_date_move_to_history')
	CREATE INDEX [IX_smartKPIProcessFloatData_modification_id_date_move_to_history] ON [smartKPIProcessFloatData] (modification_id, ProductionTime, move_to_history);
GO

PRINT ('create index IX_smartKPIProcessFloatData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_move_to_history')
	CREATE INDEX [IX_smartKPIProcessFloatData_move_to_history] ON [smartKPIProcessFloatData] ([move_to_history]);
GO

if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_move_to_history_ProductionTime')
	CREATE INDEX [IX_smartKPIProcessFloatData_move_to_history_ProductionTime] ON [smartKPIProcessFloatData] ([move_to_history], ProductionTime);
GO

PRINT ('create index IX_Machine_ProcesDataType_ProductionTime_smartKpi');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_ProcesDataType_ProductionTime_smartKpi')
	create index IX_Machine_ProcesDataType_ProductionTime_smartKpi on smartKPIProcessFloatData 
		(Machine ASC, ProcesDataType ASC, ProductionTime DESC);
GO
  
PRINT ('create index IX_Machine_ProcesDataType_ProductionTime_isUpdated_smartKpi');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_ProcesDataType_ProductionTime_isUpdated_smartKpi')
	create index IX_Machine_ProcesDataType_ProductionTime_isUpdated_smartKpi on smartKPIProcessFloatData 
		(Machine ASC, ProcesDataType ASC, ProductionTime DESC, isUpdated DESC);
GO
  
PRINT ('drop index IX_smartKPIProcessFloatData_ProcesData_Machine');
  	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_ProcesData_Machine')
	drop index IX_smartKPIProcessFloatData_ProcesData_Machine on smartKPIProcessFloatData;
GO

PRINT ('create index IX_smartKPIProcessFloatData_Machine_ProcesData');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_Machine_ProcesData')
	CREATE INDEX [IX_smartKPIProcessFloatData_Machine_ProcesData] ON [smartKPIProcessFloatData] ([Machine],[ProcesData]) INCLUDE ([ProcesDataType])
GO

PRINT ('create index IX_smartKPIProcessFloatData_ProductionTime_ProcesDataType_ProcesData');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_ProductionTime_ProcesDataType_ProcesData')
	CREATE INDEX [IX_smartKPIProcessFloatData_ProductionTime_ProcesDataType_ProcesData] ON [smartKPIProcessFloatData] ([ProductionTime],[ProcesDataType],[ProcesData])
GO
  
PRINT ('create index IX_smartKPIProcessFloatData_ProductionTime_Machine');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_ProductionTime_Machine')
	create index IX_smartKPIProcessFloatData_ProductionTime_Machine on smartKPIProcessFloatData (ProductionTime desc, Machine);
GO

PRINT ('create index IX_smartKPIProcessFloatData_ProcesData_F3A96');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_ProcesData_F3A96')
	CREATE INDEX [IX_smartKPIProcessFloatData_ProcesData_F3A96] ON [smartKPIProcessFloatData] ([ProcesData]) INCLUDE ([Machine]);
GO

PRINT ('create index IX_smartKPIProcessFloatData_SerialNumber_Machine_78756');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_SerialNumber_Machine_78756')
	CREATE INDEX [IX_smartKPIProcessFloatData_SerialNumber_Machine_78756] ON [smartKPIProcessFloatData] ([SerialNumber],[Machine]) INCLUDE ([Id], [CreationTime], [ProductionTime], [ProcesDataType], [ProcesData], [PartNumber], [OrderNumber], [ProcesDataLSL], [ProcesDataUSL], [isUpdated], [Unit], [description], [comment], [TrackingNumber], [ProcesDataType2], [PartNumberRevision], [Identifier], [ProcesDataPrecision], [ProcesDataTargetValueName], [ProcesDataTargetValue], [ProcesDataLowerLimitName], [ProcesDataUpperLimitName], [ProcesDataTolerancePos], [ProcesDataToleranceNeg], [ProcesDataTolerancePosFloat], [ProcesDataToleranceNegFloat], [ProcessDataTargetValueTolUnit]);
GO

PRINT ('create index IX_smartKPIProcessFloatData_SerialNumber_PartNumber');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_SerialNumber_PartNumber')
	CREATE INDEX [IX_smartKPIProcessFloatData_SerialNumber_PartNumber] ON [smartKPIProcessFloatData] ([SerialNumber],[PartNumber]);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessFloatData_TrackingNumber_ProcesDataType_ProcesDataType2');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_TrackingNumber_ProcesDataType_ProcesDataType2')
	CREATE INDEX [IX_smartKPIProcessFloatData_TrackingNumber_ProcesDataType_ProcesDataType2] ON [smartKPIProcessFloatData] ([TrackingNumber],[ProcesDataType], ProcesDataType2);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessFloatData_Machine_ProcesDataType_ProcesDataType2');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_Machine_ProcesDataType_ProcesDataType2')
	CREATE INDEX [IX_smartKPIProcessFloatData_Machine_ProcesDataType_ProcesDataType2] ON [smartKPIProcessFloatData] ([Machine],[ProcesDataType], ProcesDataType2);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessFloatData_TrackingNumber');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessFloatData_TrackingNumber')
	CREATE INDEX [IX_smartKPIProcessFloatData_TrackingNumber] ON [smartKPIProcessFloatData] ([TrackingNumber]);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessStringData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIProcessStringData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_modification_id')
	CREATE INDEX [IX_smartKPIProcessStringData_modification_id] ON [smartKPIProcessStringData] (modification_id);
GO

PRINT ('create index IX_smartKPIProcessStringData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_modification_id_date')
	CREATE INDEX [IX_smartKPIProcessStringData_modification_id_date] ON [smartKPIProcessStringData] (modification_id, ProductionTime);
GO

PRINT ('create index IX_smartKPIProcessStringData_modification_id_date_move_to_history');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_modification_id_date_move_to_history')
	CREATE INDEX [IX_smartKPIProcessStringData_modification_id_date_move_to_history] ON [smartKPIProcessStringData] (modification_id, ProductionTime, move_to_history);
GO

PRINT ('create index IX_smartKPIProcessStringData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_move_to_history')
	CREATE INDEX [IX_smartKPIProcessStringData_move_to_history] ON [smartKPIProcessStringData] ([move_to_history]);
GO

if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_move_to_history_ProductionTime')
	CREATE INDEX [IX_smartKPIProcessStringData_move_to_history_ProductionTime] ON [smartKPIProcessStringData] ([move_to_history], ProductionTime);
GO

PRINT ('create index IX_Machine_ProcesDataType_ProductionTime_smartKpi_String');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_ProcesDataType_ProductionTime_smartKpi_String')
	create index IX_Machine_ProcesDataType_ProductionTime_smartKpi_String on smartKPIProcessStringData 
		(Machine ASC, ProcesDataType ASC, ProductionTime DESC);
GO

PRINT ('create index IX_smartKPIProcessStringData_ProductionTime_Machine');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_ProductionTime_Machine')
	create index IX_smartKPIProcessStringData_ProductionTime_Machine on smartKPIProcessStringData (ProductionTime desc, Machine);
GO

PRINT ('create index IX_smartKPIProcessStringData_SerialNumber_PartNumber');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_SerialNumber_PartNumber')
	CREATE INDEX [IX_smartKPIProcessStringData_SerialNumber_PartNumber] ON [smartKPIProcessStringData] ([SerialNumber],[PartNumber]);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessStringData_TrackingNumber_ProcesDataType_ProcesDataType2');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_TrackingNumber_ProcesDataType_ProcesDataType2')
	CREATE INDEX [IX_smartKPIProcessStringData_TrackingNumber_ProcesDataType_ProcesDataType2] ON [smartKPIProcessStringData] ([TrackingNumber],[ProcesDataType], ProcesDataType2);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessStringData_Machine_ProcesDataType_ProcesDataType2');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_Machine_ProcesDataType_ProcesDataType2')
	CREATE INDEX [IX_smartKPIProcessStringData_Machine_ProcesDataType_ProcesDataType2] ON [smartKPIProcessStringData] ([Machine],[ProcesDataType], ProcesDataType2);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessStringData_TrackingNumber');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessStringData_TrackingNumber')
	CREATE INDEX [IX_smartKPIProcessStringData_TrackingNumber] ON [smartKPIProcessStringData] ([TrackingNumber]);
GO


--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessDateTimeData
--************************************************************************************************************
--************************************************************************************************************
PRINT ('create index IX_smartKPIProcessDateTimeData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_modification_id')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_modification_id] ON [smartKPIProcessDateTimeData] (modification_id);
GO

PRINT ('create index IX_smartKPIProcessDateTimeData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_modification_id_date')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_modification_id_date] ON [smartKPIProcessDateTimeData] (modification_id, ProductionTime);
GO

PRINT ('create index IX_smartKPIProcessDateTimeData_modification_id_date_move_to_history');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_modification_id_date_move_to_history')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_modification_id_date_move_to_history] ON [smartKPIProcessDateTimeData] (modification_id, ProductionTime, move_to_history);
GO

PRINT ('create index IX_smartKPIProcessDateTimeData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_move_to_history')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_move_to_history] ON [smartKPIProcessDateTimeData] ([move_to_history]);
GO

if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_move_to_history_ProductionTime')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_move_to_history_ProductionTime] ON [smartKPIProcessDateTimeData] ([move_to_history], ProductionTime);
GO

PRINT ('create index IX_Machine_ProcesDataType_ProductionTime_smartKpi_DateTime');
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_ProcesDataType_ProductionTime_smartKpi_DateTime')
	create index IX_Machine_ProcesDataType_ProductionTime_smartKpi_DateTime on smartKPIProcessDateTimeData 
		(Machine ASC, ProcesDataType ASC, ProductionTime DESC);
GO

PRINT ('create index IX_smartKPIProcessDateTimeData_ProductionTime_Machine');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_ProductionTime_Machine')
	create index IX_smartKPIProcessDateTimeData_ProductionTime_Machine on smartKPIProcessDateTimeData (ProductionTime desc, Machine);
GO

PRINT ('create index IX_smartKPIProcessDateTimeData_SerialNumber_PartNumber');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_SerialNumber_PartNumber')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_SerialNumber_PartNumber] ON [smartKPIProcessDateTimeData] ([SerialNumber],[PartNumber]);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessDateTimeData_TrackingNumber_ProcesDataType_ProcesDataType2');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_TrackingNumber_ProcesDataType_ProcesDataType2')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_TrackingNumber_ProcesDataType_ProcesDataType2] ON [smartKPIProcessDateTimeData] ([TrackingNumber],[ProcesDataType], ProcesDataType2);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessDateTimeData_Machine_ProcesDataType_ProcesDataType2');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_Machine_ProcesDataType_ProcesDataType2')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_Machine_ProcesDataType_ProcesDataType2] ON [smartKPIProcessDateTimeData] ([Machine],[ProcesDataType], ProcesDataType2);
GO

--for CAPS
PRINT ('create index IX_smartKPIProcessDateTimeData_TrackingNumber');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIProcessDateTimeData_TrackingNumber')
	CREATE INDEX [IX_smartKPIProcessDateTimeData_TrackingNumber] ON [smartKPIProcessDateTimeData] ([TrackingNumber]);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineFloatData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIMachineFloatData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineFloatData_modification_id')
	CREATE INDEX [IX_smartKPIMachineFloatData_modification_id] ON [smartKPIMachineFloatData] (modification_id);
GO

PRINT ('create index IX_smartKPIMachineFloatData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineFloatData_modification_id_date')
	CREATE INDEX [IX_smartKPIMachineFloatData_modification_id_date] ON [smartKPIMachineFloatData] (modification_id, MachineTime);
GO

PRINT ('create index IX_smartKPIMachineFloatData_modification_id_date_move_to_history');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineFloatData_modification_id_date_move_to_history')
	CREATE INDEX [IX_smartKPIMachineFloatData_modification_id_date_move_to_history] ON [smartKPIMachineFloatData] (modification_id, MachineTime, move_to_history);
GO

PRINT ('create index IX_smartKPIMachineFloatData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineFloatData_move_to_history')
	CREATE INDEX [IX_smartKPIMachineFloatData_move_to_history] ON [smartKPIMachineFloatData] ([move_to_history]);
GO

if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineFloatData_move_to_history_ProductionTime')
	CREATE INDEX [IX_smartKPIMachineFloatData_move_to_history_ProductionTime] ON [smartKPIMachineFloatData] ([move_to_history], MachineTime);
GO

PRINT ('create index IX_Machine_MachineDataType_MachineTime_smartKpi');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_MachineDataType_MachineTime_smartKpi')
	create index IX_Machine_MachineDataType_MachineTime_smartKpi on smartKPIMachineFloatData 
		(Machine ASC, MachineDataType ASC, MachineTime DESC);
GO
  
PRINT ('create index IX_Machine_ProcesDataType_MachineTime_isUpdated_smartKpi');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_ProcesDataType_MachineTime_isUpdated_smartKpi')
	create index IX_Machine_ProcesDataType_MachineTime_isUpdated_smartKpi on smartKPIMachineFloatData 
		(Machine ASC, MachineDataType ASC, MachineTime DESC, isUpdated DESC);
GO

PRINT ('create index IX_Machine_MachineDataType_comment_MachineTime');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_MachineDataType_comment_MachineTime')
	CREATE NONCLUSTERED INDEX IX_Machine_MachineDataType_comment_MachineTime ON [dbo].[smartKPIMachineFloatData] ([Machine],[MachineDataType],[comment],[MachineTime])
	INCLUDE ([Id],[CreationTime],[MachineData],[MachineDataLSL],[MachineDataUSL],[isUpdated],[Unit],[description]);
GO  
--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIMachineStringData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIMachineStringData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStringData_modification_id')
	CREATE INDEX [IX_smartKPIMachineStringData_modification_id] ON [smartKPIMachineStringData] (modification_id);
GO

PRINT ('create index IX_smartKPIMachineStringData_modification_id_date');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStringData_modification_id_date')
	CREATE INDEX [IX_smartKPIMachineStringData_modification_id_date] ON [smartKPIMachineStringData] (modification_id, MachineTime);
GO

PRINT ('create index IX_smartKPIMachineStringData_modification_id_date_move_to_history');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStringData_modification_id_date_move_to_history')
	CREATE INDEX [IX_smartKPIMachineStringData_modification_id_date_move_to_history] ON [smartKPIMachineStringData] (modification_id, MachineTime, move_to_history);
GO

PRINT ('create index IX_smartKPIMachineStringData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStringData_move_to_history')
	CREATE INDEX [IX_smartKPIMachineStringData_move_to_history] ON [smartKPIMachineStringData] ([move_to_history]);
GO

if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIMachineStringData_move_to_history_ProductionTime')
	CREATE INDEX [IX_smartKPIMachineStringData_move_to_history_ProductionTime] ON [smartKPIMachineStringData] ([move_to_history], MachineTime);
GO

PRINT ('create index IX_Machine_MachineDataType_MachineTime_smartKpi');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Machine_MachineDataType_MachineTime_smartKpi')
	create index IX_Machine_MachineDataType_MachineTime_smartKpi on smartKPIMachineStringData 
		(Machine ASC, MachineDataType ASC, MachineTime DESC);
GO
  

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIKepwareConnectorPointer
--************************************************************************************************************
--************************************************************************************************************



--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessFloatDataBuffer
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_CreationTime_smartKPIProcessFloatDataBuffer on smartKPIProcessFloatDataBuffer');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_CreationTime_smartKPIProcessFloatDataBuffer')
	create index IX_CreationTime_smartKPIProcessFloatDataBuffer on smartKPIProcessFloatDataBuffer (CreationTime);
GO

PRINT ('create index IX_Id_smartKPIProcessFloatDataBuffer on smartKPIProcessFloatDataBuffer');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_Id_smartKPIProcessFloatDataBuffer')
	create index IX_Id_smartKPIProcessFloatDataBuffer on smartKPIProcessFloatDataBuffer (Id);
GO


--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProcessFloatDataBufferError
--************************************************************************************************************
--************************************************************************************************************


--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIJobController
--************************************************************************************************************
--************************************************************************************************************
  

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIOperatorInputMachineDefinition
--************************************************************************************************************
--************************************************************************************************************
PRINT ('create index IX_smartKPIOperatorInputMachineDefinition_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOperatorInputMachineDefinition_modification_id')
	CREATE INDEX [IX_smartKPIOperatorInputMachineDefinition_modification_id] ON [smartKPIOperatorInputMachineDefinition] (modification_id);
GO

PRINT ('create index IX_smartKPIOperatorInputMachineDefinition_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIOperatorInputMachineDefinition_move_to_history')
	CREATE INDEX [IX_smartKPIOperatorInputMachineDefinition_move_to_history] ON [smartKPIOperatorInputMachineDefinition] ([move_to_history]);
GO
		

--************************************************************************************************************
--************************************************************************************************************
--Table SAPTimePerPart
--************************************************************************************************************
--************************************************************************************************************
PRINT ('create index IX_orderNumberShort_SAPTimePerPart on SAPTimePerPart');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_orderNumberShort_SAPTimePerPart')
	create index IX_orderNumberShort_SAPTimePerPart on SAPTimePerPart (orderNumberShort DESC);
GO
  
PRINT ('create index IX_orderNumber_SAPTimePerPart on SAPTimePerPart');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_orderNumber_SAPTimePerPart')
	create index IX_orderNumber_SAPTimePerPart on SAPTimePerPart (orderNumber DESC);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIValues
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPIValues_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIValues_modification_id')
	CREATE INDEX [IX_smartKPIValues_modification_id] ON [smartKPIValues] (modification_id);
GO

PRINT ('create index IX_smartKPIValues_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIValues_move_to_history')
	CREATE INDEX [IX_smartKPIValues_move_to_history] ON [smartKPIValues] ([move_to_history]);
GO

PRINT ('create index IX_smartKPIValues_machine_KPIName_KPICB_KPITB');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIValues_machine_KPIName_KPICB_KPITB')
	CREATE NONCLUSTERED INDEX [IX_smartKPIValues_machine_KPIName_KPICB_KPITB]
	ON [dbo].[smartKPIValues] ([Machine],[KPIName],[KPICalculationBase],[KPITimeBase])
	INCLUDE ([KPIDateTime],[KPIDateTimeEnd]);
GO

PRINT ('create index IX_smartKPIValues_ForDelete');
   	if exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIValues_ForDelete')
	drop index IX_smartKPIValues_ForDelete on smartKPIValues;
GO

PRINT ('create index IX_smartKPIValues_select_KPIs');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPIValues_select_KPIs')
	CREATE INDEX [IX_smartKPIValues_select_KPIs] ON smartKPIValues (Machine, KPIName, KPIDateTime, KPIDateTimeEnd, KPICalculationBase) INCLUDE ([KPIFloatValue], KPITimeBase);
GO

--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIJobLogger
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_all_smartKPIJobLogger on smartKPIJobLogger');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_all_smartKPIJobLogger')
	create index IX_all_smartKPIJobLogger on smartKPIJobLogger (Job ASC, CreationTime DESC);
GO



--************************************************************************************************************
--************************************************************************************************************
--Table smartKPISAPPMKeyValueData
--************************************************************************************************************
--************************************************************************************************************

PRINT ('create index IX_smartKPISAPPMKeyValueData_modification_id');
	if not exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPISAPPMKeyValueData_modification_id')
	CREATE INDEX [IX_smartKPISAPPMKeyValueData_modification_id] ON [smartKPISAPPMKeyValueData] (modification_id);
GO

PRINT ('create index IX_smartKPISAPPMKeyValueData_move_to_history');
  	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_smartKPISAPPMKeyValueData_move_to_history')
	CREATE INDEX [IX_smartKPISAPPMKeyValueData_move_to_history] ON [smartKPISAPPMKeyValueData] ([move_to_history]);
GO


--************************************************************************************************************
--************************************************************************************************************
--Table smartKPIProductiveStateDefinition
--************************************************************************************************************
--************************************************************************************************************
  

--************************************************************************************************************
--************************************************************************************************************
--TEMP TABLES
--************************************************************************************************************
--************************************************************************************************************

	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_TEMP_SmartKPIFullShift')
		create index IX_TEMP_SmartKPIFullShift on TEMP_SmartKPIFullShift (CurrentStartTime, CurrentEndTime, Machine) INCLUDE (CurrentName);
	GO
	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_TEMP_SmartKPIFullShift1')
		create index IX_TEMP_SmartKPIFullShift1 on TEMP_SmartKPIFullShift (CurrentStartTime, CurrentEndTime);
	GO

	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_TEMP_SmartKPICVSProductionTargetDetail')
		create index IX_TEMP_SmartKPICVSProductionTargetDetail on TEMP_SmartKPICVSProductionTargetDetail (LineThingName, StartTime, EndTime) INCLUDE (counter);
	GO

	if NOT exists (SELECT *  FROM sys.indexes  WHERE name='IX_TEMP_SmartKPICVSProductionTarget')
		create index IX_TEMP_SmartKPICVSProductionTarget on TEMP_SmartKPICVSProductionTarget (LineThingName, StartTime, EndTime) INCLUDE (Target);
	GO



--------------------------------------
--KEEP THIS AT THE END OF THE SCRIPT--
--------------------------------------
-- 1.1:
--    Created
-- 1.2:
--    New Indexes for move_to_history/ProductionTime (MachineTime) --> Process and Machine Data

-- Set new Version number for updates!


--------------------------------------
DECLARE @versionOLD varchar(255);
DECLARE @versionNEW varchar(255) = '1.2' ;
--------------------------------------


select @versionOLD=[TextValue] from [smartKPIMachineKeyValueData] where Machine = 'IndexVersionFromDBScript' and [PropertyKey] = 'IndexVersionFromDBScript'
update [smartKPIMachineKeyValueData] set [TextValue] = @versionNEW where Machine = 'IndexVersionFromDBScript' and [PropertyKey] = 'IndexVersionFromDBScript'
print('Old Version: '+@versionOLD);
print('New Version: '+@versionNEW);

