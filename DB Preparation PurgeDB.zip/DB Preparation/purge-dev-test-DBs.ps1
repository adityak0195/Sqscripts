$User = $args[0]
$PW = $args[1]

echo '********************************************************'
echo 'User:'
echo $User

c:
cd "C:\KBData\GitHubDesktop\MSSQL-DB-Scripts\DB Preparation"

echo '********************************************************'

echo 'start'

cmd /c "purge-dev-test-DBs.bat $User $PW"

Get-Content .\dboutput.txt

$File = "dblogfile.txt"
$DBError = [IO.File]::ReadAllText($File)
if ($DBError -ne '' ) {Write-Error $DBError}

echo 'end'
echo '********************************************************'
