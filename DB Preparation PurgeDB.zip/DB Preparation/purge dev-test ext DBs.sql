delete from shiftCalendar where EndTime < DATEADD(MONTH,-2, GETUTCDATE()) and Plant != 'TEST';
delete from smartKPI where ProductionTime < DATEADD(MONTH,-2, GETUTCDATE()) and OrderNumber not in ('TESTORDER', 'TESTORDER2');
delete from smartKPIJobLogger where UTCCreationTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from smartKPIMachineFloatData where MachineTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from smartKPIMachineStringData where MachineTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from smartKPIMachineMessageData where MessageTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from smartKPIMachineStatusData where StatusTime < DATEADD(MONTH,-2, GETUTCDATE()) and Machine not in ('TESTSTATION1', 'TESTSTATION2');
delete from smartKPIOrderData where UpdateTime < DATEADD(MONTH,-3, GETUTCDATE()) and System != 'TESTSYSTEM';
delete from smartKPIOrderKeyValueData where UpdateTime < DATEADD(MONTH,-3, GETUTCDATE()) and System != 'TESTSYSTEM';
delete from smartKPIProcessFloatData where ProductionTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from smartKPIProcessStringData where ProductionTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from smartKPIProcessDateTimeData where ProductionTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from SYSTEM_deletedEntries where UTCCreationTime < DATEADD(MONTH,-1, GETUTCDATE());
delete from smartKPIValues where KPIDateTimeEnd < DATEADD(MONTH,-2, GETUTCDATE());
delete from TEMP_SmartKPIFullShift where CurrentEndTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from TEMP_SmartKPICVSProductionTargetDetail where EndTime < DATEADD(MONTH,-2, GETUTCDATE());
delete from TEMP_SmartKPICVSProductionTarget where EndTime < DATEADD(MONTH,-2, GETUTCDATE());

DBCC SHRINKDATABASE (0);
