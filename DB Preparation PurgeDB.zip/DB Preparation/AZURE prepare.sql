master:

-- rename DB
ALTER DATABASE yyy SET OFFLINE WITH ROLLBACK IMMEDIATE 
ALTER DATABASE yyy SET ONLINE
ALTER DATABASE yyy MODIFY NAME = www


CREATE LOGIN xxxx WITH password=N'yyyy';
CREATE USER xxxx FROM LOGIN xxxx;

DB:

--DROP USER PowerBi;
CREATE USER PowerBi FROM LOGIN PowerBi;
CREATE USER Nagios FROM LOGIN Nagios;
CREATE USER xxxx FROM LOGIN xxxx;
CREATE USER twx_admin FROM LOGIN twx_admin;
EXEC sp_addrolemember N'db_owner', N'twx_admin'
GO
EXEC sp_addrolemember N'db_owner', N'xxxx'
GO
EXEC sp_addrolemember N'db_datareader', N'PowerBi'
GO
EXEC sp_addrolemember N'db_datareader', N'Nagios'
GO

--ALTER AUTHORIZATION ON SCHEMA::twschema TO xxxx;
--ALTER USER xxxx WITH DEFAULT_SCHEMA = twschema;
--ALTER USER twx_admin WITH DEFAULT_SCHEMA = twschema;


master:

****
select * from sys.databases 
where collation_name != 'Latin1_General_100_CS_AS_SC' 
and name not in ('master', 'fdm_kba_preprod', 'cpi_sap_cloud_platform_integration')
and name not like '%_caps';

****

select * from sys.databases where compatibility_level != 150

ALTER DATABASE twx_kba_test_ext  
SET COMPATIBILITY_LEVEL = 150;  
GO

****

select name, snapshot_isolation_state, snapshot_isolation_state_desc, is_read_committed_snapshot_on 
from sys.databases
where snapshot_isolation_state != 1
or snapshot_isolation_state_desc != 'ON'
or is_read_committed_snapshot_on != 1;

ALTER DATABASE DatabaseName
SET READ_COMMITTED_SNAPSHOT ON
GO

ALTER DATABASE DatabaseName
SET ALLOW_SNAPSHOT_ISOLATION ON
GO

***************************************************************************************************************

DB Rollen:

SELECT    roles.principal_id                            AS RolePrincipalID
    ,    roles.name                                    AS RolePrincipalName
    ,    database_role_members.member_principal_id    AS MemberPrincipalID
    ,    members.name                                AS MemberPrincipalName
FROM sys.database_role_members AS database_role_members  
JOIN sys.database_principals AS roles  
    ON database_role_members.role_principal_id = roles.principal_id  
JOIN sys.database_principals AS members  
    ON database_role_members.member_principal_id = members.principal_id;  
GO



Schema owner:

select s.name as schema_name,
    s.schema_id,
    u.name as schema_owner
from sys.schemas s
    inner join sys.sysusers u
        on u.uid = s.principal_id
order by s.name


server roles:

ALTER SERVER ROLE ##MS_ServerStateReader##
	ADD MEMBER twx_admin;  
GO

SELECT
		sql_logins.principal_id			AS MemberPrincipalID
	,	sql_logins.name					AS MemberPrincipalName
	,	roles.principal_id				AS RolePrincipalID
	,	roles.name						AS RolePrincipalName
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS roles
    ON server_role_members.role_principal_id = roles.principal_id
INNER JOIN sys.sql_logins AS sql_logins 
    ON server_role_members.member_principal_id = sql_logins.principal_id
;  
GO  



*************************************************
SHRINKDATABASE

select type_desc, size from sys.database_files
DBCC SHRINKDATABASE (0);
select type_desc, size from sys.database_files

*************************************************
Blocking Queries


SELECT TOP 10 
	r.session_id, 
	r.plan_handle,      
	r.sql_handle, 
	r.request_id,      
	r.start_time, 
	r.status,      
	r.command, 
	r.database_id,      
	r.user_id, 
	r.wait_type,      
	r.wait_time, 
	r.last_wait_type,      
	r.wait_resource, 
	r.total_elapsed_time,      
	r.cpu_time, 
	r.transaction_isolation_level,      
	r.row_count, 
	st.text  
	FROM sys.dm_exec_requests r  
	CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) as st  
	WHERE r.blocking_session_id = 0       
	and r.session_id in       
		(SELECT distinct(blocking_session_id)           FROM sys.dm_exec_requests)  
	GROUP BY r.session_id, 
	r.plan_handle,      
	r.sql_handle, 
	r.request_id,      
	r.start_time, 
	r.status,      
	r.command, 
	r.database_id,      
	r.user_id, 
	r.wait_type,      
	r.wait_time, 
	r.last_wait_type,      
	r.wait_resource, 
	r.total_elapsed_time,      
	r.cpu_time, 
	r.transaction_isolation_level,      
	r.row_count, 
	st.text  
	ORDER BY r.total_elapsed_time desc

*************************************************
Check DATABASE after migration

select next value for modification_sequence
**

	Declare @tables CURSOR;
	Declare @name varchar(255);
	Declare @select nvarchar(max);
	Declare @param nvarchar(max);
	Declare @return int;


	SET @tables = CURSOR FOR select name
	    FROM sys.all_objects
		where type = 'U' order by 1;


		OPEN @tables;
			FETCH NEXT FROM @tables into @name;
		
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				print '************************************';
				print @name;
				set @param = '@returnOUT int OUTPUT';

				set @select = 'select @returnOUT=min(Id) from '+@name;
				exec sp_executesql @select,@param,@returnOUT=@return OUTPUT;
				print 'min: '+cast(@return as varchar(100));
				
				set @select = 'select @returnOUT=max(Id) from '+@name;
				exec sp_executesql @select,@param,@returnOUT=@return OUTPUT;
				print 'max: '+cast(@return as varchar(100));

				set @select = 'select @returnOUT=count(*) from '+@name;
				exec sp_executesql @select,@param,@returnOUT=@return OUTPUT;
				print 'count: '+cast(@return as varchar(100));

				FETCH NEXT FROM @tables into @name;
			END;
		CLOSE @tables;
		DEALLOCATE @tables;


--************************************************************************************************
For EA:
master:

CREATE LOGIN xxxx WITH password=N'yyyy';

ea:
CREATE USER xxxx FROM LOGIN xxxx;
EXEC sp_addrolemember N'db_datawriter', N'xxxx'
EXEC sp_addrolemember N'db_datareader', N'xxxx'
GO

--************************************************************************************************
Adding description:

	create table testTable 
		(testColumn1 varchar(255) null,
		 testColumn2 DateTime2 null);
GO


DECLARE @tableDescription sql_variant; 
DECLARE @tableName nvarchar (255);
set @tableName = 'testTable';
SET @tableDescription = N'description testTable'


DECLARE @columnDescription sql_variant; 
DECLARE @columnName nvarchar (255);
DECLARE @tableSchema nvarchar (255) = N'dbo';
DECLARE @commentName nvarchar (255) = N'MS_Description';

--Table
if not exists (SELECT * FROM fn_listextendedproperty (NULL, 'schema',@tableSchema, 'table', @tableName, default, default) where name = @commentName)
  EXEC sys.sp_addextendedproperty @name=@commentName, @value=@tableDescription , @level0type=N'SCHEMA',@level0name=@tableSchema, @level1type=N'TABLE',@level1name=@tableName;
EXEC sys.sp_updateextendedproperty @name=@commentName, @value=@tableDescription , @level0type=N'SCHEMA',@level0name=@tableSchema, @level1type=N'TABLE' ,@level1name=@tableName;
SELECT * FROM fn_listextendedproperty (NULL, 'schema',@tableSchema, 'table', @tableName, default, default);


--Column
set @columnName = 'testColumn1';
SET @columnDescription = N'description testColumn1'

if not exists (SELECT * FROM fn_listextendedproperty (NULL, 'schema',@tableSchema, 'table', @tableName, 'column', @columnName) where name = @commentName)
  EXEC sys.sp_addextendedproperty @name=@commentName, @value=@columnDescription , @level0type=N'SCHEMA',@level0name=@tableSchema, @level1type=N'TABLE',@level1name=@tableName,@level2type = N'COLUMN', @level2name = @columnName;
EXEC sys.sp_updateextendedproperty @name=@commentName, @value=@columnDescription , @level0type=N'SCHEMA',@level0name=@tableSchema, @level1type=N'TABLE' ,@level1name=@tableName,@level2type = N'COLUMN', @level2name = @columnName;
SELECT * FROM fn_listextendedproperty (NULL, 'schema',@tableSchema, 'table', @tableName, 'column', @columnName);
