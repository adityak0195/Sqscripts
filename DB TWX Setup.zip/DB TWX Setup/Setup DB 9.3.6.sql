--Start after preparation

--ALTER AUTHORIZATION ON SCHEMA::twschema TO xxxx;
--ALTER USER xxxx WITH DEFAULT_SCHEMA = twschema;


--End after preparation




ALTER DATABASE CURRENT SET READ_COMMITTED_SNAPSHOT ON
GO

-- The stmt below will allow MSSQL to record updated rows' versioning information automatically in the tempDB table for reads on a snapshot
ALTER DATABASE CURRENT SET ALLOW_SNAPSHOT_ISOLATION ON
GO

CREATE SCHEMA twschema 
GO

ALTER USER twx_admin WITH DEFAULT_SCHEMA = twschema;
Go

execute as user = 'twx_admin';
go



/*Schema Name      : thingworx-Model-schema
 Database          : MSSQL
 Tables            : 45 TABLES
 Stored Procedures : 1) upsert_aspect_model 2) upsert_user_properties 3) upsert_extension 4) fail_if_not_system_owner
*/

-----------------TABLES CREATION START-------------------------------------------------------------
/****** Object: Table [model_index] **************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [model_index](
	[id] [bigint] IDENTITY(0, 1) NOT NULL,
	[entity_name] [nvarchar](255) NOT NULL,
	[entity_type] [int] NOT NULL,
	[last_modified_time] [datetime2](7) NOT NULL,
	[description] [nvarchar](max) NULL,
	[identifier] [nvarchar](1000) NULL,
	[entity_id] [nvarchar](max) NOT NULL,
	[tags] [nvarchar](max) NULL,
	[project_name] [nvarchar](450) NULL,
    CONSTRAINT [model_index_pkey] PRIMARY KEY ([id])
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [model_index_ukey] UNIQUE ([entity_type] ASC, [entity_name] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [applicationkey_model] *****************************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [applicationkey_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[clientName] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[expirationDate] [datetime2](7) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[ipWhitelist] [nvarchar](max) NULL,
	[keyId] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[userNameReference] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [applicationkey_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [applicationkey_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [applicationkey_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object: Table [aspect_model] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [aspect_model](
	[entity_name] [nvarchar](255) NOT NULL,
	[entity_type] [int] NOT NULL,
	[mskey] [nvarchar](64) NOT NULL,
	[value] [nvarchar](max) NULL,
 CONSTRAINT [aspect_model_pkey] PRIMARY KEY
(
	[mskey] ASC,
	[entity_type] ASC,
	[entity_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [authenticator_model] ******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [authenticator_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[priority] [int] NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [authenticator_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [authenticator_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [authenticator_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [dashboard_model] **********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dashboard_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[dashboard] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [dashboard_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [dashboard_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [dashboard_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [datashape_model] **********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [datashape_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[baseDataShape] [nvarchar](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[fieldDefinitions] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [datashape_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [datashape_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [datashape_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [datatable_model] **********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [datatable_model](
	[entity_id] [bigint] NOT NULL,
	[alertConfigurations] [nvarchar](max) NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[identifier] [nvarchar](max) NULL,
	[implementedShapes] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[propertyBindings] [nvarchar](max) NULL,
	[published] [bit] NULL,
	[remoteEventBindings] [nvarchar](max) NULL,
	[remotePropertyBindings] [nvarchar](max) NULL,
	[remoteServiceBindings] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[thingShape] [nvarchar](max) NULL,
	[thingTemplate] [nvarchar](max) NULL,
	[type] [int] NULL,
	[valueStream] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [datatable_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [datatable_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [datatable_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [datatagvocabulary_model] **************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [datatagvocabulary_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[isDynamic] [bit] NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [datatagvocabulary_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [datatagvocabulary_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [datatagvocabulary_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [directoryservice_model] ***************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [directoryservice_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[priority] [int] NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [directoryservice_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [directoryservice_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [directoryservice_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [extensionpackage_model] ***************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [extensionpackage_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[buildNumber] [nvarchar](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[extensionPackageManifest] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[minimumThingWorxVersion] [nvarchar](max) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[groupId] [nvarchar](max) NULL,
	[artifactId] [nvarchar](max) NULL,
	[packageVersion] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[vendor] [nvarchar](max) NULL,
	[migratorClass] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	[applicationRuntimeRequired] [bit] NULL,
	[haCompatible] [bit] NULL,
	CONSTRAINT [extensionpackage_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [extensionpackage_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [extensionpackage_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [notificationdefinition_model] *********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [notificationdefinition_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[contents] [nvarchar](max) NULL,
	[events] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[recipients] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [notificationdefinition_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [notificationdefinition_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [notificationdefinition_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [notificationcontent_model] ************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [notificationcontent_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[handlerID] [nvarchar](max) NULL,
	[handlerEntity] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[serviceDefinitions] [nvarchar](max) NULL,
	[serviceImplementations] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL
	CONSTRAINT [notificationcontent_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [notificationcontent_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [notificationcontent_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [extensions] ***************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [extensions](
	[name] [nvarchar](255) NOT NULL,
	[resource] [varbinary](max) NOT NULL,
	[checksum] [nvarchar](max) NOT NULL,
 CONSTRAINT [extensions_pkey] PRIMARY KEY
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [file_transfer_job] ********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [file_transfer_job](
	[id] [nvarchar](450) NOT NULL,
	[targetChecksum] [nvarchar](max) NULL,
	[code] [int] NULL,
	[isAsync] [bit] NULL,
	[maxSize] [bigint] NULL,
	[stagingDir] [nvarchar](max) NULL,
	[sourceFile] [nvarchar](max) NULL,
	[startPosition] [numeric](30, 6) NULL,
	[timeout] [bigint] NULL,
	[isRestartEnabled] [bit] NULL,
	[duration] [bigint] NULL,
	[targetFile] [nvarchar](max) NULL,
	[startTime] [bigint] NULL,
	[state] [nvarchar](max) NULL,
	[sourcePath] [nvarchar](max) NULL,
	[sourceRepository] [nvarchar](max) NULL,
	[blockCount] [bigint] NULL,
	[bytesTransferred] [numeric](30, 6) NULL,
	[targetPath] [nvarchar](max) NULL,
	[sourceChecksum] [nvarchar](max) NULL,
	[transferId] [nvarchar](max) NULL,
	[message] [nvarchar](max) NULL,
	[blockSize] [bigint] NULL,
	[size] [numeric](30, 6) NULL,
	[endTime] [bigint] NULL,
	[targetRepository] [nvarchar](max) NULL,
	[user] [nvarchar](max) NULL,
	[isComplete] [bit] NULL,
	[reservationId] [nvarchar](max) NULL,
	[isQueueable] [bit] NULL,
	[enqueueTime] [bigint] NULL,
	[enqueueCount] [bigint] NULL,
	[metadata] [nvarchar](max) NULL,
 CONSTRAINT [file_transfer_job_pkey] PRIMARY KEY
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [file_transfer_job_offline_queue] ******************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [file_transfer_job_offline_queue](
	[id] [nvarchar](450) NOT NULL,
	[targetChecksum] [nvarchar](max) NULL,
	[code] [int] NULL,
	[isAsync] [bit] NULL,
	[maxSize] [bigint] NULL,
	[stagingDir] [nvarchar](max) NULL,
	[sourceFile] [nvarchar](max) NULL,
	[startPosition] [numeric](30, 6) NULL,
	[timeout] [bigint] NULL,
	[isRestartEnabled] [bit] NULL,
	[duration] [bigint] NULL,
	[targetFile] [nvarchar](max) NULL,
	[startTime] [bigint] NULL,
	[state] [nvarchar](max) NULL,
	[sourcePath] [nvarchar](max) NULL,
	[sourceRepository] [nvarchar](max) NULL,
	[blockCount] [bigint] NULL,
	[bytesTransferred] [numeric](30, 6) NULL,
	[targetPath] [nvarchar](max) NULL,
	[sourceChecksum] [nvarchar](max) NULL,
	[transferId] [nvarchar](max) NULL,
	[message] [nvarchar](max) NULL,
	[blockSize] [bigint] NULL,
	[size] [numeric](30, 6) NULL,
	[endTime] [bigint] NULL,
	[targetRepository] [nvarchar](max) NULL,
	[user] [nvarchar](max) NULL,
	[isComplete] [bit] NULL,
	[isQueueable] [bit] NULL,
	[enqueueTime] [bigint] NULL,
	[enqueueCount] [bigint] NULL,
	[metadata] [nvarchar](max) NULL,
	[thingName] [nvarchar](max) NOT NULL,
 CONSTRAINT [file_transfer_job_offline_queue_pkey] PRIMARY KEY
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [group_model] **************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [group_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[members] [nvarchar](max) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[scimId] [nvarchar](255),
	[scimExternalId] [nvarchar](255),
	[scimDisplayName] [nvarchar](255),
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [group_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [group_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [group_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [localizationtable_model] **************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [localizationtable_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[languageCommon] [nvarchar](max) NULL,
	[languageNative] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [localizationtable_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [localizationtable_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [localizationtable_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [log_model] ****************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [log_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[logLevel] [nvarchar](max) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [log_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [log_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [log_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [mashup_model] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [mashup_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[columns] [numeric](30, 6) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[mashupContent] [nvarchar](max) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[parameterDefinitions] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[relatedEntities] [nvarchar](max) NULL,
	[rows] [numeric](30, 6) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	[preview] [varbinary](max) NULL,
	CONSTRAINT [mashup_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [mashup_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [mashup_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [mediaentity_model] *********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [mediaentity_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[content] [varbinary](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [mediaentity_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [mediaentity_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [mediaentity_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [menu_model] ***************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [menu_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[groupReferences] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[imageURL] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[menuItems] [nvarchar](max) NULL,
	[menuLabel] [nvarchar](max) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [menu_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [menu_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [menu_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [modeltagvocabulary_model] *************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [modeltagvocabulary_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[isDynamic] [bit] NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [modeltagvocabulary_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [modeltagvocabulary_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [modeltagvocabulary_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [network_model] ************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [network_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[connections] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [network_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [network_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [network_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [organization_model] *******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [organization_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[connections] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[loginButtonStyle] [nvarchar](max) NULL,
	[loginImage] [varbinary](max) NULL,
	[loginPrompt] [nvarchar](max) NULL,
	[loginStyle] [nvarchar](max) NULL,
	[mobileMashup] [nvarchar](max) NULL,
	[name] [nvarchar](255) NOT NULL,
	[organizationalUnits] [nvarchar](max) NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[loginResetPassword] [bit] NULL,
	[resetMailServer] [nvarchar](max) NULL,
	[resetMailSubject] [nvarchar](max) NULL,
	[resetMailContent] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [organization_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [organization_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [organization_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [persistenceprovider_model] ************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [persistenceprovider_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[persistenceProviderPackage] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [persistenceprovider_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [persistenceprovider_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [persistenceprovider_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [persistenceproviderpackage_model] *****************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [persistenceproviderpackage_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [persistenceproviderpackage_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [persistenceproviderpackage_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [persistenceproviderpackage_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [project_model] ************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [project_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[publishResult] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[groupId] [nvarchar](max) NULL,
	[artifactId] [nvarchar](max) NULL,
	[version] [nvarchar](max) NULL,
	[state] [nvarchar](max) NOT NULL DEFAULT 'DRAFT',
	[minPlatformVersion] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [project_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [project_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [project_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [resource_model] ***********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [resource_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[serviceDefinitions] [nvarchar](max) NULL,
	[serviceImplementations] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [resource_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [resource_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [resource_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [root_entity_collection] ***************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [root_entity_collection](
	[name] [nvarchar](255) NOT NULL,
	[type] [int] NULL,
	[description] [nvarchar](max) NULL,
	[owner] [nvarchar](max) NULL,
	[last_modified_time] [datetime2](7) NULL,
	[pid] [int] IDENTITY(1,1) NOT NULL,
	[className] [nvarchar](max) NULL,
    CONSTRAINT [root_entity_collection_type_ukey] UNIQUE ([type]),
 CONSTRAINT [root_entity_collection_pkey] PRIMARY KEY
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [scriptfunctionlibrary_model] **********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [scriptfunctionlibrary_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[functionDefinitions] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [scriptfunctionlibrary_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [scriptfunctionlibrary_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [scriptfunctionlibrary_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [statedefinition_model] ****************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [statedefinition_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[content] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [statedefinition_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [statedefinition_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [statedefinition_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [stream_model] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stream_model](
	[entity_id] [bigint] NOT NULL,
	[alertConfigurations] [nvarchar](max) NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[identifier] [nvarchar](max) NULL,
	[implementedShapes] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[propertyBindings] [nvarchar](max) NULL,
	[published] [bit] NULL,
	[remoteEventBindings] [nvarchar](max) NULL,
	[remotePropertyBindings] [nvarchar](max) NULL,
	[remoteServiceBindings] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[thingShape] [nvarchar](max) NULL,
	[thingTemplate] [nvarchar](max) NULL,
	[type] [int] NULL,
	[valueStream] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [stream_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [stream_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [stream_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [styledefinition_model] ****************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [styledefinition_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[content] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [styledefinition_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [styledefinition_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [styledefinition_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [styletheme_model] ****************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [styletheme_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[content] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	[preview] [varbinary](max) NULL,
	CONSTRAINT [styletheme_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [styletheme_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [styletheme_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [subsystem_model] **********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [subsystem_model](
	[entity_id] [bigint] NOT NULL,
	[autoStart] [bit] NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[dependsOn] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[friendlyName] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [subsystem_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [subsystem_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [subsystem_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [system_ownership] *********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [system_ownership](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[platform] [nvarchar](max) NULL,
	[took_ownership] [datetime2](7) default SYSDATETIMEOFFSET(),
 CONSTRAINT [system_ownership_pkey] PRIMARY KEY
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [tag_index] ****************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [tag_index](
	[pid] [int] IDENTITY(1,1) NOT NULL,
	[entity_name] [nvarchar](255) NOT NULL,
	[vocabulary_name] [nvarchar](64) NOT NULL,
	[term_name] [nvarchar](64) NOT NULL,
	[entity_identifier] [nvarchar](max) NOT NULL,
	[vocabulary_type] [int] NOT NULL,
	[tenant_id] [nvarchar](64) NOT NULL,
 CONSTRAINT [model_tag_index_pkey] PRIMARY KEY
(
	[tenant_id] ASC,
	[term_name] ASC,
	[vocabulary_name] ASC,
	[entity_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [thing_model] **************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [thing_model](
	[entity_id] [bigint] NOT NULL,
	[alertConfigurations] [nvarchar](max) NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[identifier] [nvarchar](max) NULL,
	[implementedShapes] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[propertyBindings] [nvarchar](max) NULL,
	[published] [bit] NULL,
	[remoteEventBindings] [nvarchar](max) NULL,
	[remotePropertyBindings] [nvarchar](max) NULL,
	[remoteServiceBindings] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[thingShape] [nvarchar](max) NULL,
	[thingTemplate] [nvarchar](max) NULL,
	[type] [int] NULL,
	[valueStream] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [thing_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [thing_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [thing_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [thingpackage_model] *******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [thingpackage_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[thingShape] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	[baseThingTemplate] [nvarchar](max) NULL,
	CONSTRAINT [thingpackage_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [thingpackage_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [thingpackage_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [thingshape_model] *********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [thingshape_model](
	[entity_id] [bigint] NOT NULL,
	[alertConfigurations] [nvarchar](max) NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[propertyBindings] [nvarchar](max) NULL,
	[remoteEventBindings] [nvarchar](max) NULL,
	[remotePropertyBindings] [nvarchar](max) NULL,
	[remoteServiceBindings] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[thingShape] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [thingshape_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [thingshape_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [thingshape_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [thingtemplate_model] ******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [thingtemplate_model](
	[entity_id] [bigint] NOT NULL,
	[alertConfigurations] [nvarchar](max) NULL,
	[avatar] [varbinary](max) NULL,
	[baseThingTemplate] [nvarchar](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[implementedShapes] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[propertyBindings] [nvarchar](max) NULL,
	[remoteEventBindings] [nvarchar](max) NULL,
	[remotePropertyBindings] [nvarchar](max) NULL,
	[remoteServiceBindings] [nvarchar](max) NULL,
	[sharedConfigurationTables] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[thingPackage] [nvarchar](max) NULL,
	[thingShape] [nvarchar](max) NULL,
	[type] [int] NULL,
	[valueStream] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [thingtemplate_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [thingtemplate_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [thingtemplate_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [transfer_reservation] *****************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [transfer_reservation](
	[id] [nvarchar](450) NOT NULL,
	[reservedBy] [nvarchar](max) NULL,
	[reservedAt] [bigint] NULL,
 CONSTRAINT [transfer_reservation_pkey] PRIMARY KEY
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [user_model] ***************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [user_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[mobileMashup] [nvarchar](max) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[password] [nvarchar](max) NULL,
	[passwordHash] [nvarchar](max) NULL,
	[passwordHashAlgorithm] [nvarchar](max) NULL,
	[passwordHashIterationCount] [int] NULL,
	[passwordHashSaltSizeInBytes] [int] NULL,
	[passwordHashSizeInBytes] [int] NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[locked] [bit] NULL,
	[lockedTime] [datetime2](7) NULL,
	[scimId] [nvarchar](255),
	[scimExternalId] [nvarchar](255),
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [user_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [user_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [user_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [user_model_properties] ****************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [user_model_properties](
	[entity_name] [nvarchar](255) NOT NULL,
	[mskey] [nvarchar](64) NOT NULL,
	[value] [nvarchar](max) NULL,
 CONSTRAINT [user_model_properties_pkey] PRIMARY KEY
(
	[mskey] ASC,
	[entity_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [valuestream_model] ********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [valuestream_model](
	[entity_id] [bigint] NOT NULL,
	[alertConfigurations] [nvarchar](max) NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[enabled] [bit] NULL,
	[homeMashup] [nvarchar](max) NULL,
	[identifier] [nvarchar](max) NULL,
	[implementedShapes] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[propertyBindings] [nvarchar](max) NULL,
	[published] [bit] NULL,
	[remoteEventBindings] [nvarchar](max) NULL,
	[remotePropertyBindings] [nvarchar](max) NULL,
	[remoteServiceBindings] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[thingShape] [nvarchar](max) NULL,
	[thingTemplate] [nvarchar](max) NULL,
	[type] [int] NULL,
	[valueStream] [nvarchar](max) NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [valuestream_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [valuestream_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [valuestream_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [vocabulary_terms] *********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [vocabulary_terms](
	[pid] [int] IDENTITY(1,1) NOT NULL,
	[vocabulary_name] [nvarchar](64) NOT NULL,
	[term_name] [nvarchar](64) NOT NULL,
	[vocabulary_id] [nvarchar](max) NOT NULL,
	[vocabulary_type] [int] NOT NULL,
 CONSTRAINT [vocabulary_terms_pkey] PRIMARY KEY
(
	[vocabulary_type] ASC,
	[term_name] ASC,
	[vocabulary_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [widget_model] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [widget_model](
	[entity_id] [bigint] NOT NULL,
	[avatar] [varbinary](max) NULL,
	[className] [nvarchar](max) NULL,
	[configurationChanges] [nvarchar](max) NULL,
	[configurationTables] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[documentationContent] [nvarchar](max) NULL,
	[homeMashup] [nvarchar](max) NULL,
	[lastModifiedDate] [datetime2](7) NULL,
	[name] [nvarchar](255) NOT NULL,
	[owner] [nvarchar](max) NULL,
	[projectName] [nvarchar](max) NULL,
	[tags] [nvarchar](max) NULL,
	[tenantId] [nvarchar](max) NULL,
	[type] [int] NULL,
	[configurationTableDefinitions] [nvarchar](max) NULL,
	CONSTRAINT [widget_model_pkey] PRIMARY KEY ([entity_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [widget_entity_fkey] FOREIGN KEY
		([entity_id]) REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [widget_name_ukey] UNIQUE ([name]) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [ServiceDefinitions] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ServiceDefinitions](
	[id] [bigint] IDENTITY(0, 1) NOT NULL,
	[name_chk] AS CHECKSUM([name]) PERSISTED NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[category] [nvarchar](max) NOT NULL,
	[isAllowOverride] [bit] NOT NULL DEFAULT 0,
	[isOpen] [bit] NOT NULL DEFAULT 0,
	[isLocalOnly] [bit] NOT NULL DEFAULT 0,
	[isPrivate] [bit] NOT NULL DEFAULT 0,
	[resultType] [nvarchar](max) NOT NULL,
	[parameterDefinitions] [nvarchar](max) NOT NULL,
	[aspects] [nvarchar](max) NOT NULL,
	CONSTRAINT [service_defs_pkey] PRIMARY KEY ([id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [service_defs_lookup_idx] ON [ServiceDefinitions] ([name_chk]);
GO

/****** Object: Table [ServiceImplementations] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ServiceImplementations](
	[id] [bigint] IDENTITY(0, 1) NOT NULL,
	[name_chk] AS CHECKSUM([name]) PERSISTED NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[handlerName] [nvarchar](max) NOT NULL,
	[lastModifiedDate] [datetime2](7) NOT NULL,
	[configurationTables] [nvarchar](max) NOT NULL,
	CONSTRAINT [service_impls_pkey] PRIMARY KEY ([id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [service_impls_lookup_idx] ON [ServiceImplementations] ([name_chk]);
GO

/****** Object: Table [RemoteServiceBindings] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [RemoteServiceBindings](
	[id] [bigint] IDENTITY(0, 1) NOT NULL,
	[name_chk] AS CHECKSUM([name]) PERSISTED NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[sourceName] [nvarchar](max) NOT NULL,
	[enableQueue] [bit] NOT NULL DEFAULT 0,
	[timeout] [bigint] DEFAULT 0,
	CONSTRAINT [service_bindings_pkey] PRIMARY KEY ([id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [service_bindings_lookup_idx] ON [RemoteServiceBindings] ([name_chk]);
GO

/****** Object: Table [EventDefinitions] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [EventDefinitions](
	[id] [bigint] IDENTITY (0, 1) NOT NULL,
	[name_chk] AS CHECKSUM([name]) PERSISTED NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[category] [nvarchar](max) NOT NULL,
	[dataShape] [nvarchar](max) NOT NULL,
	[aspects] [nvarchar](max) NOT NULL,
	CONSTRAINT [event_defs_pkey] PRIMARY KEY ([id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [event_defs_lookup_idx] ON [EventDefinitions] ([name_chk]);
GO

/****** Object: Table [Subscriptions] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Subscriptions](
	[id] [bigint] IDENTITY(0, 1) NOT NULL,
	[name_chk] AS CHECKSUM([name]) PERSISTED NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[enabled] [bit] NOT NULL,
	[source] [nvarchar](max) NOT NULL,
	[sourceType] [nvarchar](max) NOT NULL,
	[sourceProperty] [nvarchar](max) NOT NULL,
	[eventName] [nvarchar](max) NOT NULL,
	[alertName] [nvarchar](max) NOT NULL,
	[category] [nvarchar](max),
	[lastModifiedDate] [datetime2](7) NOT NULL,
	[trigger] [nvarchar](max),
	[aspects] [nvarchar](max) NOT NULL,
	CONSTRAINT [subscriptions_pkey] PRIMARY KEY ([id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [subscriptions_lookup_idx] ON [Subscriptions] ([name_chk]);
GO
/****** Object: Table [Entities_ServiceDefinitions] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Entities_ServiceDefinitions](
	[entity_id] [bigint] NOT NULL,
	[definition_id] [bigint] NOT NULL,
	CONSTRAINT [entity_servdefs_ukey] UNIQUE CLUSTERED ([definition_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [entity_servdefs_entity_fkey] FOREIGN KEY ([entity_id])
		REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [entity_servdefs_service_def_fkey] FOREIGN KEY ([definition_id])
		REFERENCES [ServiceDefinitions] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE
)
GO

CREATE NONCLUSTERED INDEX [ents_service_defs_lookup_idx] ON [Entities_ServiceDefinitions] ([entity_id]);
GO

/****** Object: Table [Entities_ServiceImplementations] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Entities_ServiceImplementations](
	[entity_id] [bigint] NOT NULL,
	[implementation_id] [bigint] NOT NULL,
	CONSTRAINT [entity_servimpls_ukey] UNIQUE CLUSTERED ([implementation_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [entity_servimpls_entity_fkey] FOREIGN KEY ([entity_id])
		REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [entity_servimpls_service_impl_fkey] FOREIGN KEY ([implementation_id])
		REFERENCES [ServiceImplementations] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE
)
GO

CREATE NONCLUSTERED INDEX [ents_service_impls_lookup_idx] ON [Entities_ServiceImplementations] ([entity_id]);
GO

/****** Object: Table [Entities_RemoteServiceBindings] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Entities_RemoteServiceBindings](
	[entity_id] [bigint] NOT NULL,
	[binding_id] [bigint] NOT NULL,
	CONSTRAINT [entity_bindings_ukey] UNIQUE CLUSTERED ([binding_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [entity_bindings_entity_fkey] FOREIGN KEY ([entity_id])
		REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [entity_bindings_binding_fkey] FOREIGN KEY ([binding_id])
		REFERENCES [RemoteServiceBindings] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE
)
GO

CREATE NONCLUSTERED INDEX [ents_service_bindings_lookup_idx] ON [Entities_RemoteServiceBindings] ([entity_id]);
GO

/****** Object: Table [Entities_Subscriptions] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Entities_Subscriptions](
	[entity_id] [bigint] NOT NULL,
	[subscription_id] [bigint] NOT NULL,
	CONSTRAINT [entity_subs_ukey] UNIQUE CLUSTERED ([subscription_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [entity_subs_entity_fkey] FOREIGN KEY ([entity_id])
		REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [entity_subs_subs_fkey] FOREIGN KEY ([subscription_id])
		REFERENCES [Subscriptions] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE
)
GO

CREATE NONCLUSTERED INDEX [ents_subscriptions_lookup_idx] ON [Entities_Subscriptions] ([entity_id]);
GO

/****** Object: Table [Entities_EventDefinitions] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Entities_EventDefinitions](
	[entity_id] [bigint] NOT NULL,
	[event_id] [bigint] NOT NULL,
	CONSTRAINT [entity_events_ukey] UNIQUE CLUSTERED ([event_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [entity_events_entity_fkey] FOREIGN KEY ([entity_id])
		REFERENCES [model_index] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT [entity_events_event_fkey] FOREIGN KEY ([event_id])
		REFERENCES [EventDefinitions] ([id])
		ON UPDATE CASCADE ON DELETE CASCADE
)
GO

CREATE NONCLUSTERED INDEX [ents_event_defs_lookup_idx] ON [Entities_EventDefinitions] ([entity_id]);
GO

/****** Object: Table [sync_log] ******************************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [sync_log](
	[id] [bigint] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[platform] [nvarchar](max), -- Arbitrary text describing the owning platform instance.
	[user_name] [nvarchar](max), -- Arbitrary text describing the owning user name
	[changes] [nvarchar](max),
	[dependencies] [nvarchar](max)
)
GO

-----------TABLES CREATION END---------------------------------------------------------------------

-----------INDEX /CONSTRAINT CREATION START--------------------------------------------------------
SET ANSI_PADDING ON
GO

/****** Object: Index [model_index_modelindex_project_name_index] ********************************/
CREATE NONCLUSTERED INDEX [model_index_modelindex_project_name_index] ON [model_index]
(
	[project_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object: Index [tag_index_modeltagindex_tag_index] ****************************************/
CREATE NONCLUSTERED INDEX [tag_index_modeltagindex_tag_index] ON [tag_index]
(
	[term_name] ASC,
	[vocabulary_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [vocabulary_terms_vocabularyterms_terms_index] *****************************/
CREATE NONCLUSTERED INDEX [vocabulary_terms_vocabularyterms_terms_index] ON [vocabulary_terms]
(
	[vocabulary_type] ASC,
	[term_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [vocabulary_terms_vocabularyterms_vocabulary_index] ************************/
CREATE NONCLUSTERED INDEX [vocabulary_terms_vocabularyterms_vocabulary_index] ON [vocabulary_terms]
(
	[vocabulary_type] ASC,
	[vocabulary_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [extensions] WITH NOCHECK ADD CONSTRAINT [extensions_name_fkey] FOREIGN KEY([name])
REFERENCES [extensionpackage_model] ([name])
GO

ALTER TABLE [extensions] NOCHECK CONSTRAINT [extensions_name_fkey]
GO

-----------INDEX /CONSTRAINT CREATION START--------------------------------------------------------

-----------STOERED PROCEDURES CREATION START-------------------------------------------------------

/****** Object: StoredProcedure [upsert_aspect_model] ********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE  [upsert_aspect_model]
(
 @inserting_name nvarchar(255),
 @inserting_type int,
 @inserting_key nvarchar(64),
 @inserting_value nvarchar(max)
)
AS
BEGIN
IF EXISTS (SELECT * FROM aspect_model WHERE entity_name = @inserting_name AND entity_type = @inserting_type AND mskey = @inserting_key)
	UPDATE aspect_model SET entity_name = @inserting_name, entity_type = @inserting_type, mskey = @inserting_key, value = @inserting_value WHERE entity_name = @inserting_name AND entity_type = @inserting_type AND mskey = @inserting_key;
ELSE
	INSERT INTO aspect_model (entity_name, entity_type, mskey, value) VALUES (@inserting_name, @inserting_type, @inserting_key, @inserting_value);
END

GO
/****** StoredProcedure End **********************************************************************/

/****** Object: StoredProcedure [upsert_user_properties] *****************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [upsert_user_properties]
(
@inserting_name nvarchar(255),
@inserting_key nvarchar(64),
@inserting_value nvarchar(max)
)
AS
DECLARE @Iterator INT
SET @Iterator = 0
BEGIN
	WHILE (@Iterator < 3)
	BEGIN
    IF EXISTS (SELECT * FROM user_model_properties WHERE entity_name = @inserting_name AND mskey = @inserting_key)
			BEGIN
				UPDATE user_model_properties SET entity_name = @inserting_name, mskey = @inserting_key, value = @inserting_value WHERE entity_name = @inserting_name AND mskey = @inserting_key;
				RETURN;
			END
    ELSE
			BEGIN
				INSERT INTO user_model_properties (entity_name, mskey, value) VALUES (@inserting_name, @inserting_key, @inserting_value);
			RETURN;
			END
		WAITFOR DELAY '00:00:01';
		SET @Iterator = @Iterator + 1;
	END;
END;

GO
/****** StoredProcedure End **********************************************************************/

/****** Object: StoredProcedure [upsert_extension] ***********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [upsert_extension]
(
@extension_name nvarchar(255),
@extension_resource varbinary(max),
@extension_checksum nvarchar(max)
)
AS
DECLARE @Iterator INT
SET @Iterator = 0
BEGIN
	WHILE (@Iterator < 3)
	BEGIN
    IF EXISTS (SELECT * FROM extensions WHERE name = @extension_name)
			BEGIN
				UPDATE extensions SET checksum = @extension_checksum, resource = @extension_resource WHERE name = @extension_name;
				RETURN;
			END
    ELSE
			BEGIN
				INSERT INTO extensions (name, resource, checksum) VALUES (@extension_name, @extension_resource, @extension_checksum);
			  RETURN;
			END
		WAITFOR DELAY '00:00:01';
		SET @Iterator = @Iterator + 1;
  END;
END;

GO
/****** StoredProcedure End **********************************************************************/

/****** Object: StoredProcedure [fail_if_not_system_owner] ***************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [fail_if_not_system_owner]
(
@system_ownership_id int
)
AS
BEGIN
IF NOT EXISTS (SELECT id FROM system_ownership WHERE id IN (SELECT TOP(1) id FROM system_ownership ORDER BY took_ownership DESC ) AND id = @system_ownership_id)

  THROW 50001, 'Database access prohibited because System Ownership has been lost', 1;

END

GO
/****** StoredProcedure End **********************************************************************/

-------------STOERED PROCEDURES CREATION END-------------------------------------------------------

CREATE TABLE [thinggroup_model] (
    [entity_id] bigint NOT NULL,
    [avatar] [varbinary] (max) NULL,
    [className] [nvarchar](max) NULL,
    [configurationChanges] [nvarchar](max) NULL,
    [configurationTables] [nvarchar](max) NULL,
    [description] [nvarchar](max) NULL,
    [documentationContent] [nvarchar](max) NULL,
    [homeMashup] [nvarchar](max) NULL,
    [lastModifiedDate] [datetime2](7) NULL,
    [name] [nvarchar](255) NOT NULL,
    [owner] [nvarchar](max) NULL,
    [projectName] [nvarchar](max) NULL,
    [tags] [nvarchar](max) NULL,
    [tenantId] [nvarchar](max) NULL,
    [type] [int] NULL,
    [configurationTableDefinitions] [nvarchar](max) NULL,
    CONSTRAINT [thinggroup_model_pkey] PRIMARY KEY ([entity_id]),
    CONSTRAINT [thinggroup_model_entity_fkey] FOREIGN KEY ([entity_id]) REFERENCES [model_index] ([id]) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT [thinggroup_model_name_ukey] UNIQUE ([name])
);

CREATE TABLE [thinggroup_members_model] (
    [thinggroup_entity_name] [nvarchar](255) NOT NULL,
    [member_entity_name] [nvarchar](255) NOT NULL,
    [member_entity_typecode] integer NOT NULL
);

-- The following creates a unique non-clustered index across the 3 columns 
CREATE UNIQUE INDEX [thinggroup_members_model_member_entity_nametype_index] ON [thinggroup_members_model] (
    [thinggroup_entity_name],
    [member_entity_name],
    [member_entity_typecode]
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];
GO

/****** Object: Table [runtimepermissions] *************************************************************/
CREATE TABLE [runtimepermissions] (
    [principalId] [bigint],
    [collectionType] [int],
    [entityId] [bigint],
    [permissionType] [int],
    [isPermitted] [bit],
    [isInstancePermission] [bit],
    [resource] [nvarchar](255),
    CONSTRAINT [runtimepermissions_root_entity_collection_type_fkey] FOREIGN KEY ([collectionType]) REFERENCES root_entity_collection ([type]) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT [runtimepermissions_model_index_for_id_fkey] FOREIGN KEY ([entityId]) REFERENCES [model_index] ([id]) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT [runtimepermissions_ukey] UNIQUE ([principalId], [collectionType], [entityId], [permissionType], [isInstancePermission], [resource])
    		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
GO

CREATE NONCLUSTERED INDEX [runtimepermissions_principal_lookup_idx] ON [runtimepermissions] ([principalId])
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

CREATE NONCLUSTERED INDEX [runtimepermissions_entity_lookup_idx] ON [runtimepermissions] ([entityId])
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

/****** END [runtimepermissions] *************************************************************/

/****** Object: Table [designtimepermissions] *************************************************************/
CREATE TABLE [designtimepermissions] (
    [principalId] [bigint],
    [collectionType] [int],
    [entityId] [bigint],
    [permissionType] [int],
    [isPermitted] [bit],
    [isInstancePermission] [bit],
    CONSTRAINT [designtimepermissions_root_entity_collection_type_fkey] FOREIGN KEY ([collectionType]) REFERENCES root_entity_collection ([type]) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT [designtimepermissions_model_index_for_id_fkey] FOREIGN KEY ([entityId]) REFERENCES [model_index] ([id]) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT [designtimepermissions_ukey] UNIQUE ([principalId], [collectionType], [entityId], [permissionType], [isInstancePermission])
    		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
GO

CREATE NONCLUSTERED INDEX [designtimepermissions_principal_lookup_idx] ON [designtimepermissions] ([principalId])
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

CREATE NONCLUSTERED INDEX [designtimepermissions_entity_lookup_idx] ON [designtimepermissions] ([entityId])
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

/****** END [designtimepermissions] *************************************************************/

/****** Object: Table [visibilitypermissions] *************************************************************/
CREATE TABLE [visibilitypermissions] (
    [principalId] [bigint],
    [collectionType] [int],
    [entityId] [bigint],
    [permissionType] [int],
    [isPermitted] [bit],
    [isInstancePermission] [bit],
    [subEntityName] [nvarchar](255),
    CONSTRAINT [visibilitypermissions_root_entity_collection_type_fkey] FOREIGN KEY ([collectionType]) REFERENCES root_entity_collection ([type]) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT [visibilitypermissions_model_index_for_id_fkey] FOREIGN KEY ([entityId]) REFERENCES [model_index] ([id]) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT [visibilitypermissions_ukey] UNIQUE ([principalId], [collectionType], [entityId], [permissionType], [isInstancePermission], [subEntityName])
    		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
GO

CREATE NONCLUSTERED INDEX [visibilitypermissions_principal_lookup_idx] ON [visibilitypermissions] ([principalId])
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

CREATE NONCLUSTERED INDEX [visibilitypermissions_entity_lookup_idx] ON [visibilitypermissions] ([entityId])
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

/****** END [visibilitypermissions] *************************************************************/

/****** Object: Trigger [trg_delete_CASCADE_permissions_principal] **************************************/
CREATE OR ALTER TRIGGER trg_delete_CASCADE_permissions_principal
    ON model_index FOR DELETE
    AS
BEGIN
    SET NOCOUNT ON
    --only delete from permissions if the entity is a principal
    IF (SELECT entity_type FROM DELETED) = 2701 OR (SELECT entity_type FROM DELETED) = 2801
      OR (SELECT entity_type FROM DELETED) = 8011
    BEGIN
        DELETE FROM runtimepermissions WHERE principalId IN (SELECT id FROM DELETED);
        DELETE FROM designtimepermissions WHERE principalId IN (SELECT id FROM DELETED);
        DELETE FROM visibilitypermissions WHERE principalId IN (SELECT id FROM DELETED);
    END
END
GO
/****** END [trg_delete_CASCADE_permissions_principal] ****************************************************/


/****** Object: StoredProcedure [delete_aspect_model_entries] ********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE  [delete_aspect_model_entries]
(
 @entity_name nvarchar(255),
 @entity_type int
)
AS
BEGIN
DECLARE @mskeyCursor CURSOR;
DECLARE @mskey nvarchar(64)

SET @mskeyCursor = CURSOR FOR
select mskey from aspect_model where entity_type=@entity_type and entity_name=@entity_name

OPEN @mskeyCursor 
   
FETCH NEXT FROM @mskeyCursor 
    INTO @mskey

WHILE @@FETCH_STATUS = 0
    BEGIN
      DELETE FROM aspect_model where entity_name=@entity_name and entity_type=@entity_type and mskey=@mskey
      FETCH NEXT FROM @mskeyCursor 
      INTO @mskey 
    END; 

    CLOSE @mskeyCursor ;
    DEALLOCATE @mskeyCursor;
END
GO
/****** StoredProcedure End **********************************************************************/






















/*
 Schema Name       : thingworx-property-schema
 Database          : MSSQL
 Tables            : 1) property_vtq, 2)system_version
 Stored Procedures : 1) upsert_property_vtq, 2) insert_with_upsert_property_vtq 
*/

-----------------TABLES CREATION START------------------------------------------------------------

/****** Object: Table [property_vtq] *************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [property_vtq](
        [id] [nvarchar](192) NOT NULL,
        [name] [nvarchar](255) NOT NULL,
        [value] [varbinary](max) NULL,
        [time] [bigint] NULL,
        [quality] [nvarchar](max) NULL,
        [basetype] [smallint] NULL,
        [value_string] [nvarchar](750) NULL,
        [value_long] [bigint] NULL,
        [value_double] [float](53) NULL,
        [value_boolean] [bit] NULL,
        [value_timestamp] [datetimeoffset] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object: Index [property_vtq_id_name_index] ****************************/
CREATE UNIQUE NONCLUSTERED INDEX [property_vtq_id_name_index] ON [property_vtq]
(
	[id] ASC,
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/*** Add composite indexes ***/
CREATE NONCLUSTERED INDEX [property_vtq_basetype_string_index] ON [property_vtq]
(
	basetype, value_string ASC
)WHERE value_string IS NOT NULL
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [property_vtq_basetype_long_index] ON [property_vtq]
(
	basetype, value_long ASC
)WHERE value_long IS NOT NULL
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [property_vtq_basetype_double_index] ON [property_vtq]
(
	basetype, value_double ASC
)WHERE value_double IS NOT NULL
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [property_vtq_basetype_boolean_index] ON [property_vtq]
(
	basetype, value_boolean ASC
)WHERE value_boolean IS NOT NULL
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [property_vtq_basetype_timestamp_index] ON [property_vtq]
(
	basetype, value_timestamp ASC
)WHERE value_timestamp IS NOT NULL
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Table [system_version] ***********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [system_version](
	[pid] [int] IDENTITY(1,1) NOT NULL,
	[server_name] [nvarchar](255) NOT NULL,
	[server_code] [int] NOT NULL,
	[is_data_provider_supported] [bit] NOT NULL,
	[is_model_provider_supported] [bit] NOT NULL,
	[is_property_provider_supported] [bit] NOT NULL,
	[model_schema_version] [int] NOT NULL,
	[data_schema_version] [int] NOT NULL,
	[property_schema_version] [int] NOT NULL,
	[major_version] [nvarchar](10) NOT NULL,
	[minor_version] [nvarchar](10) NULL,
	[revision] [nvarchar](45) NOT NULL,
	[build] [nvarchar](45) NOT NULL,
	[creationdate] [datetime2](7) NULL,
 CONSTRAINT [system_version_pkey] PRIMARY KEY
(
	[pid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
-----------------TABLES CREATION END---------------------------------------------------------------

-----------INDEX /CONSTRAINT CREATION START--------------------------------------------------------
ALTER TABLE [system_version] ADD DEFAULT ('1753-01-01 00:00:00') FOR [creationdate]
GO

/****** Object: Index [system_version_systemversion_servername_index] ****************************/
CREATE NONCLUSTERED INDEX [system_version_systemversion_servername_index] ON [system_version]
(
	[server_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

-----------INDEX /CONSTRAINT CREATION END----------------------------------------------------------

-----------STORED PROCEDURES CREATION START--------------------------------------------------------

-----------STORED PROCEDURES CREATION END----------------------------------------------------------

















/*
 Schema Name       : thingworx-data-schema
 Database          : MSSQL
 Tables           : 1) blog 2) blog_comment 3) data_table 4) stream 5) value_stream 6) wiki 7) wiki_comment 8) wiki_history 9) data_table_indexes 10) audit_subsystem_data
 Stored Procedures : 1) upsert_stream_entry 2) batch_stream_entry 3) upsert_value_stream_entry 4 ) batch_value_stream_entry
 Sequences         : 1) blog_entry_id_seq 2) wiki_entry_id_seq
 */

-----------SEQUENCE CREATION START----------------------------------------------------------------
/****** Object: Sequences Start *****************************************************************/
CREATE SEQUENCE [blog_entry_id_seq]
  START WITH 1
  INCREMENT BY 1
  NO MINVALUE
  NO MAXVALUE;
  
GO

CREATE SEQUENCE [wiki_entry_id_seq]
  START WITH 1
  INCREMENT BY 1
  NO MINVALUE
  NO MAXVALUE;
  
GO
/****** Object: Sequences End ********************************************************************/
-----------SEQUENCE CREATION END------------------------------------------------------------------

-----------TABLES CREATION START------------------------------------------------------------------ 
/****** Object: Table [blog] ********************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [blog](
	[entry_id] [bigint] DEFAULT ( NEXT VALUE FOR [blog_entry_id_seq]) NOT NULL,
	[time] [datetime2](7) NULL,
	[entity_id] [nvarchar](255) NULL,
	[title] [nvarchar](max) NULL,
	[content] [nvarchar](max) NULL,
	[rating_average] [real] NULL,
	[rating_count] [int] NULL,
	[location] [nvarchar](max) NULL,
	[source_id] [nvarchar](255) NULL,
	[source_type] [nvarchar](255) NULL,
	[tags] [nvarchar](max) NULL,
	[last_updated] [datetime2](7) NULL,
	[is_sticky] [bit] NULL,
 CONSTRAINT [blog_pkey] PRIMARY KEY
(
	[entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object: Table [blog_comment] ******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [blog_comment](
	[entry_id] [bigint] DEFAULT ( NEXT VALUE FOR [blog_entry_id_seq]) NOT NULL,
	[blog_entry_id] [bigint] NULL,
	[parent_entry_id] [bigint] NULL,
	[content] [nvarchar](max) NULL,
	[location] [nvarchar](max) NULL,
	[source_id] [nvarchar](255) NULL,
	[source_type] [nvarchar](255) NULL,
	[tags] [nvarchar](max) NULL,
	[time] [datetime2](7) NULL,
 CONSTRAINT [blog_comment_pkey] PRIMARY KEY
(
	[entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object: Table [data_table] ********************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [data_table](
	[entry_id] [bigint] IDENTITY(1,1) NOT NULL,
	[entity_id] [nvarchar](255) NULL,
	[entity_key] [nvarchar](128) NULL,
	[field_values] [nvarchar](max) NULL,
	[location] [nvarchar](max) NULL,
	[source_id] [nvarchar](255) NULL,
	[source_type] [nvarchar](255) NULL,
	[tags] [nvarchar](max) NULL,
	[time] [datetime2](7) NULL,
	[full_text] [nvarchar](max) NULL,
 CONSTRAINT [data_table_pkey] PRIMARY KEY
(
	[entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [EntityId_Key_UniqueKey] UNIQUE NONCLUSTERED 
(
	[entity_id] ASC,
	[entity_key] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object: Table [data_table_indexes] ************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [data_table_indexes](
	[entry_id] [bigint] NOT NULL,
	[entity_id] [nvarchar](128) NOT NULL,
	[index_name] [nvarchar](255) NOT NULL,
	[mskey] [nvarchar](255) NOT NULL,
 CONSTRAINT [data_table_indexes_pkey] PRIMARY KEY
(
    [entity_id] ASC,
	[entry_id] ASC,
	[index_name] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 

GO

/****** Object: Table [stream] ************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stream](
	[entry_id] [bigint] IDENTITY(1,1) NOT NULL,
	[entity_id] [nvarchar](175) NULL,
	[source_id] [nvarchar](175) NULL,
	[time] [datetime2] (7) NULL,
	[field_values] [nvarchar](max) NULL,
	[location] [nvarchar](255) NULL,
	[source_type] [nvarchar](96) NULL,
	[tags] [nvarchar](max) NULL,
 CONSTRAINT [PK_stream] PRIMARY KEY
(
	[entry_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object: Table [value_stream] ******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [value_stream](
	[entry_id] [bigint] IDENTITY(1,1) NOT NULL,
	[entity_id] [nvarchar](128) NULL,
	[source_id] [nvarchar](128) NULL,
	[time] [datetime2](7) NULL,
	[property_type] [int] NULL,
	[property_name] [nvarchar](128) NULL,
	[property_value] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object: Table [wiki] **************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [wiki](
	[entry_id] [bigint] DEFAULT( NEXT VALUE FOR [wiki_entry_id_seq]) NOT NULL,
	[time] [datetime2](7) NULL,
	[entity_id] [nvarchar](255) NULL,
	[parent_entry_id] [nvarchar](255) NULL,
	[title] [nvarchar](max) NULL,
	[content] [nvarchar](max) NULL,
	[rating_average] [real] NULL,
	[rating_count] [int] NULL,
	[location] [nvarchar](max) NULL,
	[source_id] [nvarchar](255) NULL,
	[source_type] [nvarchar](255) NULL,
	[tags] [nvarchar](max) NULL,
 CONSTRAINT [wiki_pkey] PRIMARY KEY
(
	[entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [wiki_comment] ******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [wiki_comment](
	[entry_id] [bigint] DEFAULT( NEXT VALUE FOR [wiki_entry_id_seq]) NOT NULL,
	[wiki_entry_id] [bigint] NULL,
	[parent_entry_id] [bigint] NULL,
	[content] [nvarchar](max) NULL,
	[location] [nvarchar](max) NULL,
	[source_id] [nvarchar](255) NULL,
	[source_type] [nvarchar](255) NULL,
	[tags] [nvarchar](max) NULL,
	[time] [datetime2](7) NULL,
 CONSTRAINT [wiki_comment_pkey] PRIMARY KEY
(
	[entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [wiki_history] ******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [wiki_history](
	[entry_id] [int] IDENTITY(1,1) NOT NULL,
	[wiki_entry_id] [bigint] NULL,
	[entity_id] [nvarchar](255) NULL,
	[content] [nvarchar](max) NULL,
	[location] [nvarchar](max) NULL,
	[source_id] [nvarchar](255) NULL,
	[source_type] [nvarchar](255) NULL,
	[tags] [nvarchar](max) NULL,
	[time] [datetime2](7) NULL,
 CONSTRAINT [wiki_history_pkey] PRIMARY KEY
(
	[entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object: Table [audit_subsystem_data] **********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [audit_subsystem_data](
	[entry_id] [bigint] IDENTITY(1,1) NOT NULL,
	[timestamp] [datetime2] NOT NULL,
	[auditCategory] [varchar](255) NOT NULL,
	[message] [nvarchar](255) NOT NULL,
	[messageArgs] [nvarchar](max) NOT NULL,
	[user] [bigint] NULL,
	[userName] [nvarchar](255) NULL,
	[source] [bigint] NULL,
	[sourceName] [nvarchar](255) NULL,
	[sourceType] [int] NULL,
	[application] [varchar](255) NOT NULL,
 CONSTRAINT [entry_id] PRIMARY KEY
(
	[entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)

GO
SET ANSI_PADDING ON

GO
-----------TABLES CREATION END--------------------------------------------------------------------

-----------INDEX /CONSTRAINT CREATION START-------------------------------------------------------
SET ANSI_PADDING ON
GO

/****** Object: Index [blog_id_index] ***********************************************************/
CREATE NONCLUSTERED INDEX [blog_id_index] ON [blog]
(
	[entity_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [blog_comment_collaboration_id_index] *************************************/
CREATE NONCLUSTERED INDEX [blog_comment_collaboration_id_index] ON [blog_comment]
(
	[blog_entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [data_table_indexes_mskey_index] *************************/
CREATE NONCLUSTERED INDEX [data_table_indexes_mskey_index] ON [data_table_indexes]
(
    [mskey] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object: Index [stream_entity_id_source_id_source_type_time_key] *************************/
CREATE UNIQUE NONCLUSTERED INDEX [stream_entity_id_source_id_source_type_time_key] ON [stream]
(
	[entity_id] ASC,
	[source_id] ASC,
	[source_type] ASC,
	[time] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [stream_id_time_index] ****************************************************/
CREATE NONCLUSTERED INDEX [stream_id_time_index] ON [stream]
(
	[entity_id] ASC,
	[time] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX [ValStream-EntID_SouId_Propname_PropType_Tm] ON [value_stream]
(
	[entity_id] ASC,
	[source_id] ASC,
	[property_name] ASC,
	[property_type] ASC,
	[time] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

/****** Object: Index [WikiCom_Wiki_Entry_Id_NonCluIndex] ****************************************/
CREATE NONCLUSTERED INDEX [WikiCom_Wiki_Entry_Id_NonCluIndex] ON [wiki_comment]
(
	[wiki_entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

/****** Object: Index [WikiHist_Wiki_Entry_Id_NonClusIndex] **************************************/
CREATE NONCLUSTERED INDEX [WikiHist_Wiki_Entry_Id_NonClusIndex] ON [wiki_history]
(
	[wiki_entry_id] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

ALTER TABLE [blog_comment] WITH NOCHECK ADD CONSTRAINT [comment_blog_entry_id_fkey] FOREIGN KEY([blog_entry_id])
REFERENCES [blog] ([entry_id])
GO

ALTER TABLE [blog_comment] NOCHECK CONSTRAINT [comment_blog_entry_id_fkey]
GO

ALTER TABLE [wiki_comment] WITH NOCHECK ADD CONSTRAINT [comment_wiki_entry_id_fkey] FOREIGN KEY([wiki_entry_id])
REFERENCES [wiki] ([entry_id])
GO

ALTER TABLE [wiki_comment] NOCHECK CONSTRAINT [comment_wiki_entry_id_fkey]
GO

ALTER TABLE [wiki_history] WITH NOCHECK ADD CONSTRAINT [wiki_history_wiki_entry_id_fkey] FOREIGN KEY([wiki_entry_id])
REFERENCES [wiki] ([entry_id])
GO

ALTER TABLE [wiki_history] NOCHECK CONSTRAINT [wiki_history_wiki_entry_id_fkey]
GO

/****** Object: Index [audit_subsystem_data_timestamp_index] *************************/
CREATE NONCLUSTERED INDEX [audit_subsystem_data_timestamp_index] ON [audit_subsystem_data]
(
	[timestamp] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [audit_subsystem_data_source_timestamp_index] *************************/
CREATE NONCLUSTERED INDEX [audit_subsystem_data_source_timestamp_index] ON [audit_subsystem_data]
(
	[source] ASC,
	[timestamp] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [audit_subsystem_data_user_timestamp_index] *************************/
CREATE NONCLUSTERED INDEX [audit_subsystem_data_user_timestamp_index] ON [audit_subsystem_data]
(
	[user] ASC,
	[timestamp] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object: Index [audit_subsystem_data_category_timestamp_index] *************************/
CREATE NONCLUSTERED INDEX [audit_subsystem_data_category_timestamp_index] ON [audit_subsystem_data]
(
	[auditCategory] ASC,
	[timestamp] ASC
) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
---------------INDEX /CONSTRAINT CREATION END------------------------------------------------------

---------------STORED PROCEDURES CREATION START----------------------------------------------------

/****** Object: StoredProcedure [upsert_stream_entry] ********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [upsert_stream_entry]
(
@entity_id_value nvarchar(175),
@source_id_value nvarchar(175),
@time_value datetime2,
@field_values_value nvarchar(max), 
@location_value nvarchar(255), 
@source_type_value nvarchar(96), 
@tags_value nvarchar(max)
) 
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @entry_id_table TABLE(ID int);
	BEGIN TRY
		INSERT INTO stream (entity_id, source_id, time, field_values, location, source_type, tags)
		OUTPUT INSERTED.entry_id INTO @entry_id_table
		values (@entity_id_value, @source_id_value, @time_value, @field_values_value, @location_value, @source_type_value, @tags_value)
		SELECT * FROM @entry_id_table;
	END	TRY
	BEGIN CATCH
		UPDATE stream SET field_values=@field_values_value, location=@location_value, tags=@tags_value
		OUTPUT INSERTED.entry_id INTO @entry_id_table
		WHERE entity_id=@entity_id_value and source_id=@source_id_value and time=@time_value and source_type=@source_type_value;
		SELECT * FROM @entry_id_table;
	END CATCH
END;

GO
/****** StoredProcedure End **********************************************************************/

/****** Object: StoredProcedure [batch_stream_entry] *********************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [batch_stream_entry]
(
@entity_id_value nvarchar(175),
@source_id_value nvarchar(175),
@time_value datetime2,
@field_values_value nvarchar(max), 
@location_value nvarchar(255), 
@source_type_value nvarchar(96), 
@tags_value nvarchar(max)
) 
AS
BEGIN
  SET NOCOUNT ON;  
	BEGIN TRY
		INSERT INTO stream (entity_id, source_id, time, field_values, location, source_type, tags)
		values (@entity_id_value, @source_id_value, @time_value, @field_values_value, @location_value, @source_type_value, @tags_value)
		RETURN;
	END	TRY
	BEGIN CATCH
		UPDATE stream SET field_values=@field_values_value, location=@location_value, tags=@tags_value
		WHERE entity_id=@entity_id_value and source_id=@source_id_value and time=@time_value and source_type=@source_type_value;
		RETURN;
	END CATCH
END;

GO
/****** StoredProcedure End **********************************************************************/

/****** Object: StoredProcedure [upsert_value_stream_entry] **************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [upsert_value_stream_entry]
(
@entity_id_value nvarchar(128),
@source_id_value nvarchar(128),
@time_value datetime2,
@property_type_value int, 
@property_name_value nvarchar(128),
@property_value_value nvarchar(max)
) 
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @entry_id_table TABLE(ID int);
  BEGIN TRY
	INSERT INTO value_stream (entity_id, source_id, time, property_type, property_name, property_value)
	OUTPUT INSERTED.entry_id INTO @entry_id_table
	values (@entity_id_value, @source_id_value, @time_value, @property_type_value, @property_name_value, @property_value_value);
	SELECT * from @entry_id_table;
  END TRY
  BEGIN CATCH  
	UPDATE value_stream SET property_value=@property_value_value
	OUTPUT INSERTED.entry_id INTO @entry_id_table 
	WHERE entity_id=@entity_id_value and source_id=@source_id_value and property_name=@property_name_value and property_type=@property_type_value and time=@time_value;
	SELECT * from @entry_id_table;
	END CATCH
END;

GO
/****** StoredProcedure End **********************************************************************/

/****** Object: StoredProcedure [batch_value_stream_entry] ***************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [batch_value_stream_entry]
(
@entity_id_value nvarchar(128),
@source_id_value nvarchar(128),
@time_value datetime2,
@property_type_value int, 
@property_name_value nvarchar(128),
@property_value_value nvarchar(max)
) 
AS
BEGIN
  SET NOCOUNT ON;
  BEGIN TRY
		INSERT INTO value_stream (entity_id, source_id, time, property_type, property_name, property_value)
		values (@entity_id_value, @source_id_value, @time_value, @property_type_value, @property_name_value, @property_value_value);
		RETURN;
  END TRY
  BEGIN CATCH
		UPDATE value_stream SET property_value=@property_value_value
		WHERE entity_id=@entity_id_value and source_id=@source_id_value and property_name=@property_name_value and property_type=@property_type_value and time=@time_value;
	    RETURN;
  END CATCH
END;

GO
/****** StoredProcedure End **********************************************************************/

---------------STORED PROCEDURES CREATION END-----------------------------------------------------








/**

A table for storing authorized grants per user, resource server pairs

TOKEN: Encrypted binary serialization of OAuth2AccessToken object.
AUTHENTICATION_ID: This is the primary key and should represent resource server / principal pair. For example: rs_id + user_id

**/

/****** Object: Table [OAUTH_CLIENT_TOKEN] ******************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT name FROM sys.tables WHERE name='OAUTH_CLIENT_TOKEN')
CREATE TABLE [OAUTH_CLIENT_TOKEN](
	[TOKEN] [varbinary](8000),
	[AUTHENTICATION_ID] [varchar](256) PRIMARY KEY NOT NULL
)

GO